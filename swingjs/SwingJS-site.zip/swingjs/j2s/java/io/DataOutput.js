(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DataOutput");
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-09-26 09:29:28 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
