(function(){var P$=Clazz.newPackage("java.awt");
/*c*/var C$=Clazz.newClass(P$, "Checkbox", null, 'swingjs.a2s.Checkbox');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (label) {
;C$.superclazz.c$$S.apply(this,[label]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z',  function (label, state) {
;C$.superclazz.c$$S$Z.apply(this,[label, state]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$java_awt_CheckboxGroup',  function (label, state, group) {
;C$.superclazz.c$$S$Z$java_awt_CheckboxGroup.apply(this,[label, state, group]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_CheckboxGroup$Z',  function (label, group, state) {
;C$.superclazz.c$$S$Z$java_awt_CheckboxGroup.apply(this,[label, state, group]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-09-26 09:29:07 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
