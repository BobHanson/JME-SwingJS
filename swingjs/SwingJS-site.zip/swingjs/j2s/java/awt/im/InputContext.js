(function(){var P$=Clazz.newPackage("java.awt.im"),I$=[[0,'sun.awt.im.InputMethodContext']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InputContext");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
return Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'selectInputMethod$java_util_Locale',  function (locale) {
return false;
});

Clazz.newMeth(C$, 'getLocale$',  function () {
return null;
});

Clazz.newMeth(C$, 'setCharacterSubsets$Character_SubsetA',  function (subsets) {
});

Clazz.newMeth(C$, 'setCompositionEnabled$Z',  function (enable) {
});

Clazz.newMeth(C$, 'isCompositionEnabled$',  function () {
return false;
});

Clazz.newMeth(C$, 'reconvert$',  function () {
});

Clazz.newMeth(C$, 'dispatchEvent$java_awt_AWTEvent',  function (event) {
});

Clazz.newMeth(C$, 'removeNotify$java_awt_Component',  function (client) {
});

Clazz.newMeth(C$, 'endComposition$',  function () {
});

Clazz.newMeth(C$, 'dispose$',  function () {
});

Clazz.newMeth(C$, 'getInputMethodControlObject$',  function () {
return null;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-31 18:17:26 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
