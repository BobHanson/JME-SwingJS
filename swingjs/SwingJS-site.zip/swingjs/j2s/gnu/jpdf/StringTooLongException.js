(function(){var P$=Clazz.newPackage("gnu.jpdf"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "StringTooLongException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['msg']]]

Clazz.newMeth(C$, 'c$$S',  function (msg) {
Clazz.super_(C$, this);
this.msg=msg;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return this.msg;
});

Clazz.newMeth(C$, 'getMessage$',  function () {
return this.msg;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-20 12:13:02 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
