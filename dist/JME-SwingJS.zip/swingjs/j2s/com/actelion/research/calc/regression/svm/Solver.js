(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},p$2={},p$3={},I$=[[0,['com.actelion.research.calc.regression.svm.Cache','.head_t'],'com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.regression.svm.Cache','java.util.Random','com.actelion.research.calc.regression.svm.Solver','com.actelion.research.calc.regression.svm.SVC_Q','com.actelion.research.calc.regression.svm.Solver_NU','com.actelion.research.calc.regression.svm.ONE_CLASS_Q','com.actelion.research.calc.regression.svm.SVR_Q',['com.actelion.research.calc.regression.svm.Solver','.SolutionInfo'],['com.actelion.research.calc.regression.svm.svm','.decision_function'],'org.machinelearning.svm.libsvm.svm_problem','org.machinelearning.svm.libsvm.svm_node','org.machinelearning.svm.libsvm.svm_model','com.actelion.research.calc.regression.svm.Kernel','java.io.DataOutputStream','java.io.BufferedOutputStream','java.io.FileOutputStream','org.machinelearning.svm.libsvm.svm_parameter','java.util.StringTokenizer','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Solver", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['SolutionInfo',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['unshrink'],'D',['eps','Cp','Cn'],'I',['active_size','l'],'O',['y','byte[]','G','double[]','alpha_status','byte[]','alpha','double[]','Q','com.actelion.research.calc.regression.svm.QMatrix','QD','double[]','+p','active_set','int[]','G_bar','double[]']]]

Clazz.newMeth(C$, 'get_C$I',  function (i) {
return (this.y[i] > 0) ? this.Cp : this.Cn;
});

Clazz.newMeth(C$, 'update_alpha_status$I',  function (i) {
if (this.alpha[i] >= this.get_C$I(i) ) this.alpha_status[i]=1;
 else if (this.alpha[i] <= 0 ) this.alpha_status[i]=0;
 else this.alpha_status[i]=2;
});

Clazz.newMeth(C$, 'is_upper_bound$I',  function (i) {
return this.alpha_status[i] == 1;
});

Clazz.newMeth(C$, 'is_lower_bound$I',  function (i) {
return this.alpha_status[i] == 0;
});

Clazz.newMeth(C$, 'is_free$I',  function (i) {
return this.alpha_status[i] == 2;
});

Clazz.newMeth(C$, 'swap_index$I$I',  function (i, j) {
this.Q.swap_index$I$I(i, j);
do {
var tmp=this.y[i];
this.y[i]=this.y[j];
this.y[j]=tmp;
} while (false);
do {
var tmp=this.G[i];
this.G[i]=this.G[j];
this.G[j]=tmp;
} while (false);
do {
var tmp=this.alpha_status[i];
this.alpha_status[i]=this.alpha_status[j];
this.alpha_status[j]=tmp;
} while (false);
do {
var tmp=this.alpha[i];
this.alpha[i]=this.alpha[j];
this.alpha[j]=tmp;
} while (false);
do {
var tmp=this.p[i];
this.p[i]=this.p[j];
this.p[j]=tmp;
} while (false);
do {
var tmp=this.active_set[i];
this.active_set[i]=this.active_set[j];
this.active_set[j]=tmp;
} while (false);
do {
var tmp=this.G_bar[i];
this.G_bar[i]=this.G_bar[j];
this.G_bar[j]=tmp;
} while (false);
});

Clazz.newMeth(C$, 'reconstruct_gradient$',  function () {
if (this.active_size == this.l) return;
var i;
var j;
var nr_free=0;
for (j=this.active_size; j < this.l; j++) this.G[j]=this.G_bar[j] + this.p[j];

for (j=0; j < this.active_size; j++) if (this.is_free$I(j)) ++nr_free;

if (2 * nr_free < this.active_size) $I$(2).info$S("\nWARNING: using -h 0 may be faster\n");
if (nr_free * this.l > 2 * this.active_size * (this.l - this.active_size) ) {
for (i=this.active_size; i < this.l; i++) {
var Q_i=this.Q.get_Q$I$I(i, this.active_size);
for (j=0; j < this.active_size; j++) if (this.is_free$I(j)) this.G[i]+=this.alpha[j] * Q_i[j];

}
} else {
for (i=0; i < this.active_size; i++) if (this.is_free$I(i)) {
var Q_i=this.Q.get_Q$I$I(i, this.l);
var alpha_i=this.alpha[i];
for (j=this.active_size; j < this.l; j++) this.G[j]+=alpha_i * Q_i[j];

}
}});

Clazz.newMeth(C$, 'Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController',  function (l, Q, p_, y_, alpha_, Cp, Cn, eps, si, shrinking, pg) {
this.l=l;
this.Q=Q;
this.QD=Q.get_QD$();
this.p=p_.clone$();
this.y=y_.clone$();
this.alpha=alpha_.clone$();
this.Cp=Cp;
this.Cn=Cn;
this.eps=eps;
this.unshrink=false;
{
this.alpha_status=Clazz.array(Byte.TYPE, [l]);
for (var i=0; i < l; i++) this.update_alpha_status$I(i);

}{
this.active_set=Clazz.array(Integer.TYPE, [l]);
for (var i=0; i < l; i++) this.active_set[i]=i;

this.active_size=l;
}{
this.G=Clazz.array(Double.TYPE, [l]);
this.G_bar=Clazz.array(Double.TYPE, [l]);
var i;
for (i=0; i < l; i++) {
this.G[i]=this.p[i];
this.G_bar[i]=0;
}
for (i=0; i < l; i++) if (!this.is_lower_bound$I(i)) {
var Q_i=Q.get_Q$I$I(i, l);
var alpha_i=this.alpha[i];
var j;
for (j=0; j < l; j++) this.G[j]+=alpha_i * Q_i[j];

if (this.is_upper_bound$I(i)) for (j=0; j < l; j++) this.G_bar[j]+=this.get_C$I(i) * Q_i[j];

}
}var iter=0;
var max_iter=Math.max(10000000, l > 21474836 ? 2147483647 : 100 * l);
var counter=Math.min(l, 1000) + 1;
var working_set=Clazz.array(Integer.TYPE, [2]);
if (pg != null ) {
pg.startProgress$S$I$I("Solve", 0, l);
}while (iter < max_iter){
if (pg != null ) {
pg.updateProgress$I(counter);
if (pg.threadMustDie$()) {
break;
}}if (--counter == 0) {
counter=Math.min(l, 1000);
if (shrinking != 0) this.do_shrinking$();
$I$(2).info$S(".");
}if (this.select_working_set$IA(working_set) != 0) {
this.reconstruct_gradient$();
this.active_size=l;
$I$(2).info$S("*");
if (this.select_working_set$IA(working_set) != 0) break;
 else counter=1;
}var i=working_set[0];
var j=working_set[1];
++iter;
var Q_i=Q.get_Q$I$I(i, this.active_size);
var Q_j=Q.get_Q$I$I(j, this.active_size);
var C_i=this.get_C$I(i);
var C_j=this.get_C$I(j);
var old_alpha_i=this.alpha[i];
var old_alpha_j=this.alpha[j];
if (this.y[i] != this.y[j]) {
var quad_coef=this.QD[i] + this.QD[j] + 2 * Q_i[j] ;
if (quad_coef <= 0 ) quad_coef=1.0E-12;
var delta=(-this.G[i] - this.G[j]) / quad_coef;
var diff=this.alpha[i] - this.alpha[j];
this.alpha[i]+=delta;
this.alpha[j]+=delta;
if (diff > 0 ) {
if (this.alpha[j] < 0 ) {
this.alpha[j]=0;
this.alpha[i]=diff;
}} else {
if (this.alpha[i] < 0 ) {
this.alpha[i]=0;
this.alpha[j]=-diff;
}}if (diff > C_i - C_j ) {
if (this.alpha[i] > C_i ) {
this.alpha[i]=C_i;
this.alpha[j]=C_i - diff;
}} else {
if (this.alpha[j] > C_j ) {
this.alpha[j]=C_j;
this.alpha[i]=C_j + diff;
}}} else {
var quad_coef=this.QD[i] + this.QD[j] - 2 * Q_i[j];
if (quad_coef <= 0 ) quad_coef=1.0E-12;
var delta=(this.G[i] - this.G[j]) / quad_coef;
var sum=this.alpha[i] + this.alpha[j];
this.alpha[i]-=delta;
this.alpha[j]+=delta;
if (sum > C_i ) {
if (this.alpha[i] > C_i ) {
this.alpha[i]=C_i;
this.alpha[j]=sum - C_i;
}} else {
if (this.alpha[j] < 0 ) {
this.alpha[j]=0;
this.alpha[i]=sum;
}}if (sum > C_j ) {
if (this.alpha[j] > C_j ) {
this.alpha[j]=C_j;
this.alpha[i]=sum - C_j;
}} else {
if (this.alpha[i] < 0 ) {
this.alpha[i]=0;
this.alpha[j]=sum;
}}}var delta_alpha_i=this.alpha[i] - old_alpha_i;
var delta_alpha_j=this.alpha[j] - old_alpha_j;
for (var k=0; k < this.active_size; k++) {
this.G[k]+=Q_i[k] * delta_alpha_i + Q_j[k] * delta_alpha_j;
}
{
var ui=this.is_upper_bound$I(i);
var uj=this.is_upper_bound$I(j);
this.update_alpha_status$I(i);
this.update_alpha_status$I(j);
var k;
if (ui != this.is_upper_bound$I(i) ) {
Q_i=Q.get_Q$I$I(i, l);
if (ui) for (k=0; k < l; k++) this.G_bar[k]-=C_i * Q_i[k];

 else for (k=0; k < l; k++) this.G_bar[k]+=C_i * Q_i[k];

}if (uj != this.is_upper_bound$I(j) ) {
Q_j=Q.get_Q$I$I(j, l);
if (uj) for (k=0; k < l; k++) this.G_bar[k]-=C_j * Q_j[k];

 else for (k=0; k < l; k++) this.G_bar[k]+=C_j * Q_j[k];

}}}
if (iter >= max_iter) {
if (this.active_size < l) {
this.reconstruct_gradient$();
this.active_size=l;
$I$(2).info$S("*");
}System.err.print$S("\nWARNING: reaching max number of iterations\n");
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["WARNING: reaching max number of iterations"]);
}si.rho=this.calculate_rho$();
{
var v=0;
var i;
for (i=0; i < l; i++) v+=this.alpha[i] * (this.G[i] + this.p[i]);

si.obj=v / 2;
}{
for (var i=0; i < l; i++) alpha_[this.active_set[i]]=this.alpha[i];

}si.upper_bound_p=Cp;
si.upper_bound_n=Cn;
$I$(2,"info$S",["\noptimization finished, #iter = " + iter + "\n" ]);
});

Clazz.newMeth(C$, 'select_working_set$IA',  function (working_set) {
var Gmax=-Infinity;
var Gmax2=-Infinity;
var Gmax_idx=-1;
var Gmin_idx=-1;
var obj_diff_min=Infinity;
for (var t=0; t < this.active_size; t++) if (this.y[t] == 1) {
if (!this.is_upper_bound$I(t)) if (-this.G[t] >= Gmax ) {
Gmax=-this.G[t];
Gmax_idx=t;
}} else {
if (!this.is_lower_bound$I(t)) if (this.G[t] >= Gmax ) {
Gmax=this.G[t];
Gmax_idx=t;
}}
var i=Gmax_idx;
var Q_i=null;
if (i != -1) Q_i=this.Q.get_Q$I$I(i, this.active_size);
for (var j=0; j < this.active_size; j++) {
if (this.y[j] == 1) {
if (!this.is_lower_bound$I(j)) {
var grad_diff=Gmax + this.G[j];
if (this.G[j] >= Gmax2 ) Gmax2=this.G[j];
if (grad_diff > 0 ) {
var obj_diff;
var quad_coef=this.QD[i] + this.QD[j] - 2.0 * this.y[i] * Q_i[j] ;
if (quad_coef > 0 ) obj_diff=-(grad_diff * grad_diff) / quad_coef;
 else obj_diff=-(grad_diff * grad_diff) / 1.0E-12;
if (obj_diff <= obj_diff_min ) {
Gmin_idx=j;
obj_diff_min=obj_diff;
}}}} else {
if (!this.is_upper_bound$I(j)) {
var grad_diff=Gmax - this.G[j];
if (-this.G[j] >= Gmax2 ) Gmax2=-this.G[j];
if (grad_diff > 0 ) {
var obj_diff;
var quad_coef=this.QD[i] + this.QD[j] + 2.0 * this.y[i] * Q_i[j]  ;
if (quad_coef > 0 ) obj_diff=-(grad_diff * grad_diff) / quad_coef;
 else obj_diff=-(grad_diff * grad_diff) / 1.0E-12;
if (obj_diff <= obj_diff_min ) {
Gmin_idx=j;
obj_diff_min=obj_diff;
}}}}}
if (Gmax + Gmax2 < this.eps  || Gmin_idx == -1 ) return 1;
working_set[0]=Gmax_idx;
working_set[1]=Gmin_idx;
return 0;
});

Clazz.newMeth(C$, 'be_shrunk$I$D$D',  function (i, Gmax1, Gmax2) {
if (this.is_upper_bound$I(i)) {
if (this.y[i] == 1) return (-this.G[i] > Gmax1 );
 else return (-this.G[i] > Gmax2 );
} else if (this.is_lower_bound$I(i)) {
if (this.y[i] == 1) return (this.G[i] > Gmax2 );
 else return (this.G[i] > Gmax1 );
} else return (false);
}, p$2);

Clazz.newMeth(C$, 'do_shrinking$',  function () {
var i;
var Gmax1=-Infinity;
var Gmax2=-Infinity;
for (i=0; i < this.active_size; i++) {
if (this.y[i] == 1) {
if (!this.is_upper_bound$I(i)) {
if (-this.G[i] >= Gmax1 ) Gmax1=-this.G[i];
}if (!this.is_lower_bound$I(i)) {
if (this.G[i] >= Gmax2 ) Gmax2=this.G[i];
}} else {
if (!this.is_upper_bound$I(i)) {
if (-this.G[i] >= Gmax2 ) Gmax2=-this.G[i];
}if (!this.is_lower_bound$I(i)) {
if (this.G[i] >= Gmax1 ) Gmax1=this.G[i];
}}}
if (this.unshrink == false  && Gmax1 + Gmax2 <= this.eps * 10  ) {
this.unshrink=true;
this.reconstruct_gradient$();
this.active_size=this.l;
}for (i=0; i < this.active_size; i++) if (p$2.be_shrunk$I$D$D.apply(this, [i, Gmax1, Gmax2])) {
--this.active_size;
while (this.active_size > i){
if (!p$2.be_shrunk$I$D$D.apply(this, [this.active_size, Gmax1, Gmax2])) {
this.swap_index$I$I(i, this.active_size);
break;
}--this.active_size;
}
}
});

Clazz.newMeth(C$, 'calculate_rho$',  function () {
var r;
var nr_free=0;
var ub=Infinity;
var lb=-Infinity;
var sum_free=0;
for (var i=0; i < this.active_size; i++) {
var yG=this.y[i] * this.G[i];
if (this.is_lower_bound$I(i)) {
if (this.y[i] > 0) ub=Math.min(ub, yG);
 else lb=Math.max(lb, yG);
} else if (this.is_upper_bound$I(i)) {
if (this.y[i] < 0) ub=Math.min(ub, yG);
 else lb=Math.max(lb, yG);
} else {
++nr_free;
sum_free+=yG;
}}
if (nr_free > 0) r=sum_free / nr_free;
 else r=(ub + lb) / 2;
return r;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.Solver, "SolutionInfo", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['obj','rho','upper_bound_p','upper_bound_n','r']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
