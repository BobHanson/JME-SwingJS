(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.neuralnetwork"),I$=[[0,['smile.regression.NeuralNetwork','.ActivationFunction']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NeuralNetworkParameterHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getActivationFunctionName$smile_regression_NeuralNetwork_ActivationFunction',  function (activationFunction) {
var type="";
switch (activationFunction) {
case $I$(1).LOGISTIC_SIGMOID:
type="LogisticSigmoid";
break;
case $I$(1).TANH:
type="Tangens";
break;
}
return type;
}, 1);

Clazz.newMeth(C$, 'getActivationFunction$S',  function (type) {
var activationFunction=null;
if ("LogisticSigmoid".equals$O(type)) {
activationFunction=$I$(1).LOGISTIC_SIGMOID;
} else if ("Tangens".equals$O(type)) {
activationFunction=$I$(1).TANH;
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown activation function type " + type + "." ]);
}return activationFunction;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:55 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
