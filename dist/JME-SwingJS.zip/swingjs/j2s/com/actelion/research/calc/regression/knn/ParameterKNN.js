(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.knn"),I$=[[0,'StringBuilder','com.actelion.research.calc.regression.ParameterRegressionMethod','java.io.File']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterKNN", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['neighbours']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["KNN regression"]);C$.$init$.apply(this);
this.setNeighbours$I(3);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (neighbours) {
;C$.superclazz.c$$S.apply(this,["KNN regression"]);C$.$init$.apply(this);
this.setNeighbours$I(neighbours);
}, 1);

Clazz.newMeth(C$, 'getNeighbours$',  function () {
return this.neighbours;
});

Clazz.newMeth(C$, 'setNeighbours$I',  function (neighbours) {
this.neighbours=neighbours;
this.properties.setProperty$S$S("Neighbours", Integer.toString$I(neighbours));
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var parameterKNN=o;
if (this.neighbours > parameterKNN.neighbours) {
cmp=1;
} else if (this.neighbours < parameterKNN.neighbours) {
cmp=-1;
}return cmp;
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.neighbours=Integer.parseInt$S(this.properties.getProperty$S("Neighbours"));
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["ParameterKNN{"]);
sb.append$S("name=").append$S(this.getName$());
sb.append$S("neighbours=").append$I(this.neighbours);
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(2).getHeader$();
li.add$O("Neighbours");
return li;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var dir=Clazz.new_($I$(3,1).c$$S,["/home/korffmo1/tmp/tmp00"]);
var fiProp=Clazz.new_($I$(3,1).c$$java_io_File$S,[dir, "knn.properties"]);
var parameterKNN=Clazz.new_(C$);
parameterKNN.setNeighbours$I(3);
parameterKNN.write$java_io_File(fiProp);
var parameterKNNIn=Clazz.new_(C$);
parameterKNNIn.read$java_io_File(fiProp);
System.out.println$S(parameterKNNIn.toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:05 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
