(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics.median"),I$=[[0,'java.util.Collections','com.actelion.research.calc.statistics.median.ModelMedianInteger','com.actelion.research.util.ArrayUtils','com.actelion.research.calc.statistics.median.ModelMedianLong','java.util.ArrayList','com.actelion.research.calc.statistics.median.ModelMedianDouble']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MedianStatisticFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getPercentileFromSorted$java_util_List$D',  function (liScore, fraction) {
if (liScore.size$() == 1) {
return (liScore.get$I(0)).valueOf();
}var percentile=0;
var len=liScore.size$();
if ((((len * fraction)|0)) == (len * fraction) ) {
var index1=((len * fraction)|0) - 1;
var index2=index1 + 1;
if (index1 < 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fraction to small."]);
}percentile=((liScore.get$I(index1)).$c() + (liScore.get$I(index2)).$c()) / 2.0;
} else {
var index1=((len * fraction)|0);
percentile=(liScore.get$I(index1)).valueOf();
}return percentile;
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSorted$DA$D',  function (arr, fraction) {
return C$.getPercentileFromSorted$DA$D$I$I(arr, fraction, 0, arr.length);
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSorted$FA$D',  function (arr, fraction) {
return C$.getPercentileFromSorted$FA$D$I$I(arr, fraction, 0, arr.length);
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSorted$DA$D$I$I',  function (arr, fraction, indexStart, length) {
if (arr.length == 1) {
return arr[0];
}var percentile=0;
if ((((length * fraction)|0)) == (length * fraction) ) {
var index1=((length * fraction)|0) - 1 + indexStart;
var index2=index1 + 1 + indexStart ;
if (index1 < 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fraction to small."]);
}percentile=(arr[index1] + arr[index2]) / 2.0;
} else {
var index1=((length * fraction)|0) + indexStart;
percentile=arr[index1];
}return percentile;
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSorted$FA$D$I$I',  function (arr, fraction, indexStart, length) {
if (arr.length == 1) {
return arr[0];
}var percentile=0;
if ((((length * fraction)|0)) == (length * fraction) ) {
var index1=((length * fraction)|0) - 1 + indexStart;
var index2=index1 + 1 + indexStart ;
if (index1 < 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fraction to small."]);
}percentile=(arr[index1] + arr[index2]) / 2.0;
} else {
var index1=((length * fraction)|0) + indexStart;
percentile=arr[index1];
}return percentile;
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSortedInt$java_util_List$D',  function (liScore, fraction) {
if (liScore.size$() == 1) {
return (liScore.get$I(0)).valueOf();
}var percentile=0;
var len=liScore.size$();
if ((((len * fraction)|0)) == (len * fraction) ) {
var index1=(((len * fraction) + 0.5)|0) - 1;
var index2=index1 + 1;
if (index1 < 0) {
index1=0;
}percentile=(((liScore.get$I(index1)).$c() + (liScore.get$I(index2)).$c())|0) / 2.0;
} else {
var index1=((len * fraction)|0);
percentile=(liScore.get$I(index1)).valueOf();
}return percentile;
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSortedLong$java_util_List$D',  function (liScore, fraction) {
if (liScore.size$() == 1) {
return (liScore.get$I(0)).valueOf();
}var percentile=0;
var len=liScore.size$();
if ((((len * fraction)|0)) == (len * fraction) ) {
var index1=(((len * fraction) + 0.5)|0) - 1;
var index2=index1 + 1;
if (index1 < 0) {
index1=0;
}percentile=Clazz.toLong(((Long.$add((liScore.get$I(index1)).$c(),(liScore.get$I(index2)).$c())) / 2.0));
} else {
var index1=((len * fraction)|0);
percentile=(liScore.get$I(index1)).valueOf();
}return Long.$dval(percentile);
}, 1);

Clazz.newMeth(C$, 'getMedianForInteger$java_util_List',  function (liScore) {
$I$(1).sort$java_util_List(liScore);
var modelMedian=Clazz.new_($I$(2,1));
modelMedian.lowerQuartile=((C$.getPercentileFromSortedInt$java_util_List$D(liScore, 0.25) + 0.5)|0);
modelMedian.median=((C$.getPercentileFromSortedInt$java_util_List$D(liScore, 0.5) + 0.5)|0);
modelMedian.upperQuartile=((C$.getPercentileFromSortedInt$java_util_List$D(liScore, 0.75) + 0.5)|0);
modelMedian.size=liScore.size$();
return modelMedian;
}, 1);

Clazz.newMeth(C$, 'getMedianForInteger$IA',  function (a) {
return C$.getMedianForInteger$java_util_List($I$(3).toList$IA(a));
}, 1);

Clazz.newMeth(C$, 'getMedianForLong$java_util_List',  function (liScore) {
$I$(1).sort$java_util_List(liScore);
var modelMedian=Clazz.new_($I$(4,1));
modelMedian.lowerQuartile=Clazz.toLong((C$.getPercentileFromSortedLong$java_util_List$D(liScore, 0.25) + 0.5));
modelMedian.median=Clazz.toLong((C$.getPercentileFromSortedLong$java_util_List$D(liScore, 0.5) + 0.5));
modelMedian.upperQuartile=Clazz.toLong((C$.getPercentileFromSortedLong$java_util_List$D(liScore, 0.75) + 0.5));
modelMedian.size=liScore.size$();
return modelMedian;
}, 1);

Clazz.newMeth(C$, 'getMedianForDouble$java_util_Collection',  function (liScoreRaw) {
if (liScoreRaw.size$() < 1) return null;
var liScore=Clazz.new_($I$(5,1).c$$java_util_Collection,[liScoreRaw]);
$I$(1).sort$java_util_List(liScore);
var modelMedian=Clazz.new_($I$(6,1));
modelMedian.lowerQuartile=C$.getPercentileFromSorted$java_util_List$D(liScore, 0.25);
modelMedian.median=C$.getPercentileFromSorted$java_util_List$D(liScore, 0.5);
modelMedian.upperQuartile=C$.getPercentileFromSorted$java_util_List$D(liScore, 0.75);
modelMedian.size=liScore.size$();
return modelMedian;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
