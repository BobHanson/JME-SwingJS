(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Logarithm");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'get$D$D',  function (value, base) {
return Math.log(value) / Math.log(base);
}, 1);

Clazz.newMeth(C$, 'log2$I',  function (n) {
if (n <= 0) throw Clazz.new_(Clazz.load('IllegalArgumentException'));
return 31 - Integer.numberOfLeadingZeros$I(n);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:33 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
