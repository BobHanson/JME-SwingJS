(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls"),I$=[[0,'com.actelion.research.calc.regression.linear.pls.SimPLSLMOValidation','com.actelion.research.calc.regression.linear.pls.PLSRegressionModelCalculator','com.actelion.research.calc.regression.ModelError']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RegressionModelCalculatorOptimumFactors");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['centerData'],'I',['factorsMin'],'O',['B','com.actelion.research.calc.Matrix','+YHat']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.centerData=false;
}, 1);

Clazz.newMeth(C$, 'setCenterData$Z',  function (centerData) {
this.centerData=centerData;
});

Clazz.newMeth(C$, 'calculateModel$com_actelion_research_util_datamodel_ModelXYIndex$I$I',  function (dataXYTrain, factorsStart, factorsEnd) {
var simPLSLMOValidation=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix,[dataXYTrain.X, dataXYTrain.Y]);
simPLSLMOValidation.setFractionLeaveOut$D(0.25);
simPLSLMOValidation.setNumRepetitions$I(7);
var errTestMin=2147483647;
this.factorsMin=1;
for (var i=factorsStart; i < factorsEnd + 1; i++) {
simPLSLMOValidation.setNumFactors$I(i);
var errTest=simPLSLMOValidation.calculateMedianTestError$();
if (errTest < errTestMin ) {
errTestMin=errTest;
this.factorsMin=i;
}}
System.out.println$S("Optimum number of factors " + this.factorsMin);
var rmc=Clazz.new_($I$(2,1));
rmc.setCenterData$Z(this.centerData);
rmc.setFactors$I(this.factorsMin);
var yHat=rmc.createModel$com_actelion_research_util_datamodel_ModelXYIndex(dataXYTrain);
var modelErrorTrain=$I$(3).calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(dataXYTrain.Y, yHat);
this.B=rmc.getB$();
this.YHat=rmc.getYHat$();
return modelErrorTrain;
});

Clazz.newMeth(C$, 'getB$',  function () {
return this.B;
});

Clazz.newMeth(C$, 'getYHat$',  function () {
return this.YHat;
});

Clazz.newMeth(C$, 'getFactorsMin$',  function () {
return this.factorsMin;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
