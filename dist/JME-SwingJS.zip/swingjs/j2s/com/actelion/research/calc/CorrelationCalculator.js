(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),p$1={},I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CorrelationCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mValueCount'],'O',['mValueCountMatrix','int[][]']]
,['O',['TYPE_LONG_NAME','String[]','+TYPE_NAME','+TYPE_CODE']]]

Clazz.newMeth(C$, 'calculateCorrelation$com_actelion_research_calc_INumericalDataColumn$com_actelion_research_calc_INumericalDataColumn$I',  function (column1, column2, correlationType) {
var valueCount=column1.getValueCount$();
if (valueCount != column2.getValueCount$()) return NaN;
var r=NaN;
if (correlationType == 0) {
this.mValueCount=0;
var xMean=0;
var yMean=0;
for (var i=0; i < valueCount; i++) {
var x=column1.getValueAt$I(i);
var y=column2.getValueAt$I(i);
if (!Double.isNaN$D(x) && !Double.isNaN$D(y) ) {
xMean+=x;
yMean+=y;
++this.mValueCount;
}}
if (this.mValueCount < 2) return NaN;
xMean/=this.mValueCount;
yMean/=this.mValueCount;
var sumdxdx=0;
var sumdxdy=0;
var sumdydy=0;
for (var i=0; i < valueCount; i++) {
var x=column1.getValueAt$I(i);
var y=column2.getValueAt$I(i);
if (!Double.isNaN$D(x) && !Double.isNaN$D(y) ) {
var dx=x - xMean;
var dy=y - yMean;
sumdxdx+=dx * dx;
sumdxdy+=dx * dy;
sumdydy+=dy * dy;
}}
r=sumdxdy / Math.sqrt(sumdxdx * sumdydy);
} else if (correlationType == 1) {
if (valueCount < 2) return NaN;
this.mValueCount=0;
var xValue=Clazz.array(Double.TYPE, [valueCount]);
var yValue=Clazz.array(Double.TYPE, [valueCount]);
for (var i=0; i < valueCount; i++) {
xValue[this.mValueCount]=column1.getValueAt$I(i);
yValue[this.mValueCount]=column2.getValueAt$I(i);
if (!Double.isNaN$D(xValue[this.mValueCount]) && !Double.isNaN$D(yValue[this.mValueCount]) ) ++this.mValueCount;
}
for (var i=this.mValueCount; i < valueCount; i++) {
xValue[i]=NaN;
yValue[i]=NaN;
}
$I$(1).sort$DA(xValue);
$I$(1).sort$DA(yValue);
var sumdxdx=0;
var sumdxdy=0;
var sumdydy=0;
var mean=(this.mValueCount + 1) / 2;
for (var i=0; i < valueCount; i++) {
if (!Double.isNaN$D(column1.getValueAt$I(i)) && !Double.isNaN$D(column2.getValueAt$I(i)) ) {
var xPosition=p$1.getPosition$DA$D.apply(this, [xValue, column1.getValueAt$I(i)]);
var yPosition=p$1.getPosition$DA$D.apply(this, [yValue, column2.getValueAt$I(i)]);
var dx=xPosition - mean;
var dy=yPosition - mean;
sumdxdx+=dx * dx;
sumdxdy+=dx * dy;
sumdydy+=dy * dy;
}}
r=sumdxdy / Math.sqrt(sumdxdx * sumdydy);
}return r;
});

Clazz.newMeth(C$, 'getValueCount$',  function () {
return this.mValueCount;
});

Clazz.newMeth(C$, 'getValueCountMatrix$',  function () {
return this.mValueCountMatrix;
});

Clazz.newMeth(C$, 'calculateMatrix$com_actelion_research_calc_INumericalDataColumnA$I',  function (numericalColumn, type) {
var matrix=Clazz.array(Double.TYPE, [numericalColumn.length, null]);
this.mValueCountMatrix=Clazz.array(Integer.TYPE, [numericalColumn.length, null]);
for (var i=1; i < numericalColumn.length; i++) {
matrix[i]=Clazz.array(Double.TYPE, [i]);
this.mValueCountMatrix[i]=Clazz.array(Integer.TYPE, [i]);
for (var j=0; j < i; j++) {
matrix[i][j]=this.calculateCorrelation$com_actelion_research_calc_INumericalDataColumn$com_actelion_research_calc_INumericalDataColumn$I(numericalColumn[i], numericalColumn[j], type);
this.mValueCountMatrix[i][j]=this.mValueCount;
}
}
return matrix;
});

Clazz.newMeth(C$, 'getPosition$DA$D',  function (array, value) {
var position=$I$(1).binarySearch$DA$D(array, value);
var position1=position;
while (position1 > 0 && array[position1 - 1] == value  )--position1;

var position2=position;
while (position2 < array.length - 1 && array[position2 + 1] == value  )++position2;

return ((position1 + position2)) / 2 + 1;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.TYPE_LONG_NAME=Clazz.array(String, -1, ["Bravais-Pearson (linear correlation)", "Spearman (correlation of ranks)"]);
C$.TYPE_NAME=Clazz.array(String, -1, ["Bravais-Pearson", "Spearman"]);
C$.TYPE_CODE=Clazz.array(String, -1, ["bravais-pearson", "spearman"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
