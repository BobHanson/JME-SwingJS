(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),p$1={},I$=[[0,'java.util.ArrayList',['com.actelion.research.calc.ScaleClasses','.Limit'],'java.util.Collections','java.text.DecimalFormat','java.util.Random']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ScaleClasses", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Limit',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['validated'],'O',['liLimit','java.util.List']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.liLimit=Clazz.new_($I$(1,1));
this.validated=false;
}, 1);

Clazz.newMeth(C$, 'add$D$D$D$D',  function (inLow, inHigh, scLow, scHigh) {
var lim=Clazz.new_($I$(2,1).c$$D$D$D$D,[inLow, inHigh, scLow, scHigh]);
this.add$com_actelion_research_calc_ScaleClasses_Limit(lim);
});

Clazz.newMeth(C$, 'add$com_actelion_research_calc_ScaleClasses_Limit',  function (lim) {
this.liLimit.add$O(lim);
this.validated=false;
});

Clazz.newMeth(C$, 'scale$D',  function (v) {
var sc=NaN;
if (!this.validated) {
if (!this.validate$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Validation failed! Discontinuous limits definition!"]);
}}for (var limit, $limit = this.liLimit.iterator$(); $limit.hasNext$()&&((limit=($limit.next$())),1);) {
if (limit.isInRange$D(v)) {
sc=limit.scale$D(v);
break;
}}
return sc;
});

Clazz.newMeth(C$, 'scale$F',  function (v) {
var sc=0;
for (var limit, $limit = this.liLimit.iterator$(); $limit.hasNext$()&&((limit=($limit.next$())),1);) {
if (limit.isInRange$D(v)) {
sc=limit.scale$D(v);
break;
}}
return sc;
});

Clazz.newMeth(C$, 'validate$',  function () {
$I$(3,"sort$java_util_List$java_util_Comparator",[this.liLimit, ((P$.ScaleClasses$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ScaleClasses$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_calc_ScaleClasses_Limit$com_actelion_research_calc_ScaleClasses_Limit','compare$O$O'],  function (o1, o2) {
var c=0;
if (o1.mInLow > o2.mInLow ) {
c=1;
} else if (o1.mInLow < o2.mInLow ) {
c=-1;
}return c;
});
})()
), Clazz.new_(P$.ScaleClasses$1.$init$,[this, null]))]);
var valid=true;
for (var i=1; i < this.liLimit.size$(); i++) {
var h0=this.liLimit.get$I(i - 1).mInHigh;
var l1=this.liLimit.get$I(i).mInLow;
if (Math.abs(h0 - l1) > 1.0E-7 ) {
valid=false;
break;
}}
return valid;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var n=20;
var nf=Clazz.new_($I$(4,1).c$$S,["0.000"]);
var scw=Clazz.new_(C$);
scw.add$D$D$D$D(0.0, 0.25, 0, 0.45);
scw.add$D$D$D$D(0.25, 0.75, 0.45, 0.55);
scw.add$D$D$D$D(0.75, 1.0, 0.55, 1.0);
var rnd=Clazz.new_($I$(5,1));
var li=Clazz.new_($I$(1,1));
li.add$O(Double.valueOf$D(0.0));
li.add$O(Double.valueOf$D(0.1));
li.add$O(Double.valueOf$D(0.25));
li.add$O(Double.valueOf$D(0.5));
li.add$O(Double.valueOf$D(0.6));
li.add$O(Double.valueOf$D(0.7));
li.add$O(Double.valueOf$D(0.8));
li.add$O(Double.valueOf$D(0.9));
li.add$O(Double.valueOf$D(0.91));
li.add$O(Double.valueOf$D(1.0));
for (var ddd, $ddd = li.iterator$(); $ddd.hasNext$()&&((ddd=($ddd.next$())),1);) {
var sc=scw.scale$D((ddd).valueOf());
System.out.println$S("val " + nf.format$O(ddd) + " scaled " + nf.format$D(sc) );
}
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ScaleClasses, "Limit", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mInHigh','mInLow','mScHigh','mScLow','mDeltaIn','mDeltaSc','mScale']]]

Clazz.newMeth(C$, 'c$$D$D$D$D',  function (inLow, inHigh, scLow, scHigh) {
;C$.$init$.apply(this);
this.mInHigh=inHigh;
this.mScHigh=scHigh;
this.mInLow=inLow;
this.mScLow=scLow;
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.mDeltaIn=this.mInHigh - this.mInLow;
this.mDeltaSc=this.mScHigh - this.mScLow;
this.mScale=this.mDeltaSc / this.mDeltaIn;
}, p$1);

Clazz.newMeth(C$, 'scale$D',  function (v) {
var sc=0;
var vn=v - this.mInLow;
sc=vn * this.mScale + this.mScLow;
return sc;
});

Clazz.newMeth(C$, 'isInRange$D',  function (v) {
if (v >= this.mInLow  && v <= this.mInHigh  ) return true;
 else return false;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:33 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
