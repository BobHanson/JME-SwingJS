(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TorsionPrediction");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mTorsion','short[]','+mFrequency','mTorsionRange','short[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$IA',  function (mol, torsionAtom) {
;C$.$init$.apply(this);
var atom1=torsionAtom[1];
var atom2=torsionAtom[2];
var conns1=mol.getConnAtoms$I(atom1) - 1;
var conns2=mol.getConnAtoms$I(atom2) - 1;
if (conns1 > 3 || conns2 > 3 ) {
this.mTorsion=Clazz.array(Short.TYPE, [4]);
this.mTorsion[0]=(45|0);
this.mTorsion[1]=(135|0);
this.mTorsion[2]=(225|0);
this.mTorsion[2]=(315|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [4, 2]);
this.mTorsionRange[0][0]=(30|0);
this.mTorsionRange[0][1]=(60|0);
this.mTorsionRange[1][0]=(120|0);
this.mTorsionRange[1][1]=(150|0);
this.mTorsionRange[2][0]=(210|0);
this.mTorsionRange[2][1]=(240|0);
this.mTorsionRange[2][0]=(300|0);
this.mTorsionRange[2][1]=(330|0);
this.mFrequency=Clazz.array(Short.TYPE, [4]);
this.mFrequency[0]=(25|0);
this.mFrequency[1]=(25|0);
this.mFrequency[2]=(25|0);
this.mFrequency[3]=(25|0);
} else if ((mol.getAtomPi$I(atom1) == 0 || mol.getAtomicNo$I(atom1) > 9 ) && (mol.getAtomPi$I(atom2) == 0 || mol.getAtomicNo$I(atom2) > 9 ) ) {
if ((conns1 == 3 && conns2 == 3 ) || (conns1 == 3 && conns2 == 2 ) || (conns1 == 3 && conns2 == 1 ) || (conns1 == 2 && conns2 == 3 ) || (conns1 == 1 && conns2 == 3 ) || (conns1 == 2 && conns2 == 2  && (torsionAtom[0] != -1 || torsionAtom[3] != -1 ) )  ) {
this.mTorsion=Clazz.array(Short.TYPE, [3]);
this.mTorsion[0]=(60|0);
this.mTorsion[1]=(180|0);
this.mTorsion[2]=(300|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [3, 2]);
this.mTorsionRange[0][0]=(45|0);
this.mTorsionRange[0][1]=(75|0);
this.mTorsionRange[1][0]=(165|0);
this.mTorsionRange[1][1]=(195|0);
this.mTorsionRange[2][0]=(285|0);
this.mTorsionRange[2][1]=(315|0);
this.mFrequency=Clazz.array(Short.TYPE, [3]);
this.mFrequency[0]=(33|0);
this.mFrequency[1]=(33|0);
this.mFrequency[2]=(33|0);
} else if ((conns1 == 1 && conns2 == 2  && torsionAtom[3] == -1 ) || (conns1 == 2 && conns2 == 1  && torsionAtom[0] == -1 ) ) {
this.mTorsion=Clazz.array(Short.TYPE, [3]);
this.mTorsion[0]=(60|0);
this.mTorsion[1]=(180|0);
this.mTorsion[2]=(300|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [3, 2]);
this.mTorsionRange[0][0]=(45|0);
this.mTorsionRange[0][1]=(75|0);
this.mTorsionRange[1][0]=(165|0);
this.mTorsionRange[1][1]=(195|0);
this.mTorsionRange[2][0]=(285|0);
this.mTorsionRange[2][1]=(315|0);
this.mFrequency=Clazz.array(Short.TYPE, [3]);
this.mFrequency[0]=(40|0);
this.mFrequency[1]=(20|0);
this.mFrequency[2]=(40|0);
} else if ((conns1 == 1 && conns2 == 1 ) || (conns1 == 1 && conns2 == 2  && torsionAtom[3] != -1 ) || (conns1 == 2 && conns2 == 1  && torsionAtom[0] != -1 ) || (conns1 == 2 && conns2 == 2  && torsionAtom[0] == -1  && torsionAtom[3] == -1 )  ) {
this.mTorsion=Clazz.array(Short.TYPE, [3]);
this.mTorsion[0]=(60|0);
this.mTorsion[1]=(180|0);
this.mTorsion[2]=(300|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [3, 2]);
this.mTorsionRange[0][0]=(45|0);
this.mTorsionRange[0][1]=(75|0);
this.mTorsionRange[1][0]=(165|0);
this.mTorsionRange[1][1]=(195|0);
this.mTorsionRange[2][0]=(285|0);
this.mTorsionRange[2][1]=(315|0);
this.mFrequency=Clazz.array(Short.TYPE, [3]);
this.mFrequency[0]=(25|0);
this.mFrequency[1]=(50|0);
this.mFrequency[2]=(25|0);
}} else if (((mol.getAtomPi$I(atom1) == 0 || mol.getAtomicNo$I(atom1) > 9 ) && mol.getAtomPi$I(atom2) == 1 ) || ((mol.getAtomPi$I(atom2) == 0 || mol.getAtomicNo$I(atom2) > 9 ) && mol.getAtomPi$I(atom1) == 1 ) ) {
if (conns1 == 3 || conns2 == 3 ) {
this.mTorsion=Clazz.array(Short.TYPE, [6]);
this.mTorsion[0]=(0|0);
this.mTorsion[1]=(60|0);
this.mTorsion[2]=(120|0);
this.mTorsion[3]=(180|0);
this.mTorsion[4]=(240|0);
this.mTorsion[5]=(300|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [6, 2]);
this.mTorsionRange[0][0]=(-15|0);
this.mTorsionRange[0][1]=(15|0);
this.mTorsionRange[1][0]=(45|0);
this.mTorsionRange[1][1]=(75|0);
this.mTorsionRange[2][0]=(105|0);
this.mTorsionRange[2][1]=(135|0);
this.mTorsionRange[3][0]=(165|0);
this.mTorsionRange[3][1]=(195|0);
this.mTorsionRange[4][0]=(225|0);
this.mTorsionRange[4][1]=(255|0);
this.mTorsionRange[5][0]=(285|0);
this.mTorsionRange[5][1]=(315|0);
this.mFrequency=Clazz.array(Short.TYPE, [6]);
this.mFrequency[0]=(16|0);
this.mFrequency[1]=(16|0);
this.mFrequency[2]=(16|0);
this.mFrequency[3]=(16|0);
this.mFrequency[4]=(16|0);
this.mFrequency[5]=(16|0);
} else if (conns1 == 1 && conns2 == 1 ) {
this.mTorsion=Clazz.array(Short.TYPE, [2]);
this.mTorsion[0]=(120|0);
this.mTorsion[1]=(240|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [2, 2]);
this.mTorsionRange[0][0]=(105|0);
this.mTorsionRange[0][1]=(135|0);
this.mTorsionRange[1][0]=(225|0);
this.mTorsionRange[1][1]=(255|0);
this.mFrequency=Clazz.array(Short.TYPE, [2]);
this.mFrequency[0]=(50|0);
this.mFrequency[1]=(50|0);
} else if ((mol.getAtomPi$I(atom1) == 1 && conns1 == 2  && conns2 == 1 ) || (mol.getAtomPi$I(atom2) == 1 && conns2 == 2  && conns1 == 1 ) ) {
this.mTorsion=Clazz.array(Short.TYPE, [2]);
this.mTorsion[0]=(90|0);
this.mTorsion[1]=(270|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [2, 2]);
this.mTorsionRange[0][0]=(75|0);
this.mTorsionRange[0][1]=(105|0);
this.mTorsionRange[1][0]=(255|0);
this.mTorsionRange[1][1]=(285|0);
this.mFrequency=Clazz.array(Short.TYPE, [2]);
this.mFrequency[0]=(50|0);
this.mFrequency[1]=(50|0);
} else if ((mol.getAtomPi$I(atom1) == 1 && conns1 == 1  && conns2 == 2  && torsionAtom[3] == -1 ) || (mol.getAtomPi$I(atom2) == 1 && conns2 == 1  && conns1 == 2  && torsionAtom[0] == -1 ) ) {
this.mTorsion=Clazz.array(Short.TYPE, [3]);
this.mTorsion[0]=(0|0);
this.mTorsion[1]=(120|0);
this.mTorsion[2]=(240|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [3, 2]);
this.mTorsionRange[0][0]=(-15|0);
this.mTorsionRange[0][1]=(15|0);
this.mTorsionRange[1][0]=(105|0);
this.mTorsionRange[1][1]=(135|0);
this.mTorsionRange[2][0]=(225|0);
this.mTorsionRange[2][1]=(255|0);
this.mFrequency=Clazz.array(Short.TYPE, [3]);
this.mFrequency[0]=(60|0);
this.mFrequency[1]=(20|0);
this.mFrequency[2]=(20|0);
} else if ((mol.getAtomPi$I(atom1) == 1 && conns1 == 1  && conns2 == 2  && torsionAtom[3] != -1 ) || (mol.getAtomPi$I(atom2) == 1 && conns2 == 1  && conns1 == 2  && torsionAtom[0] != -1 ) ) {
this.mTorsion=Clazz.array(Short.TYPE, [3]);
this.mTorsion[0]=(0|0);
this.mTorsion[1]=(120|0);
this.mTorsion[2]=(240|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [3, 2]);
this.mTorsionRange[0][0]=(-15|0);
this.mTorsionRange[0][1]=(15|0);
this.mTorsionRange[1][0]=(105|0);
this.mTorsionRange[1][1]=(135|0);
this.mTorsionRange[2][0]=(225|0);
this.mTorsionRange[2][1]=(255|0);
this.mFrequency=Clazz.array(Short.TYPE, [3]);
this.mFrequency[0]=(20|0);
this.mFrequency[1]=(40|0);
this.mFrequency[2]=(40|0);
} else if (conns1 == 2 && conns2 == 2 ) {
if (torsionAtom[0] == -1 || torsionAtom[3] == -1 ) {
this.mTorsion=Clazz.array(Short.TYPE, [2]);
this.mTorsion[0]=(0|0);
this.mTorsion[1]=(180|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [2, 2]);
this.mTorsionRange[0][0]=(-15|0);
this.mTorsionRange[0][1]=(15|0);
this.mTorsionRange[1][0]=(165|0);
this.mTorsionRange[1][1]=(195|0);
this.mFrequency=Clazz.array(Short.TYPE, [2]);
this.mFrequency[0]=(50|0);
this.mFrequency[1]=(50|0);
} else {
this.mTorsion=Clazz.array(Short.TYPE, [2]);
this.mTorsion[0]=(90|0);
this.mTorsion[1]=(270|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [2, 2]);
this.mTorsionRange[0][0]=(75|0);
this.mTorsionRange[0][1]=(105|0);
this.mTorsionRange[1][0]=(255|0);
this.mTorsionRange[1][1]=(285|0);
this.mFrequency=Clazz.array(Short.TYPE, [2]);
this.mFrequency[0]=(50|0);
this.mFrequency[1]=(50|0);
}}} else if (mol.getAtomPi$I(atom1) == 1 && mol.getAtomPi$I(atom2) == 1 ) {
if (conns1 == 1 && conns2 == 1 ) {
this.mTorsion=Clazz.array(Short.TYPE, [2]);
this.mTorsion[0]=(0|0);
this.mTorsion[1]=(180|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [2, 2]);
this.mTorsionRange[0][0]=(-15|0);
this.mTorsionRange[0][1]=(15|0);
this.mTorsionRange[1][0]=(165|0);
this.mTorsionRange[1][1]=(195|0);
this.mFrequency=Clazz.array(Short.TYPE, [2]);
this.mFrequency[0]=(10|0);
this.mFrequency[1]=(90|0);
} else {
this.mTorsion=Clazz.array(Short.TYPE, [6]);
this.mTorsion[0]=(0|0);
this.mTorsion[1]=(50|0);
this.mTorsion[2]=(130|0);
this.mTorsion[3]=(180|0);
this.mTorsion[4]=(230|0);
this.mTorsion[5]=(310|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [6, 2]);
this.mTorsionRange[0][0]=(-15|0);
this.mTorsionRange[0][1]=(15|0);
this.mTorsionRange[1][0]=(35|0);
this.mTorsionRange[1][1]=(65|0);
this.mTorsionRange[2][0]=(115|0);
this.mTorsionRange[2][1]=(145|0);
this.mTorsionRange[3][0]=(165|0);
this.mTorsionRange[3][1]=(195|0);
this.mTorsionRange[4][0]=(215|0);
this.mTorsionRange[4][1]=(245|0);
this.mTorsionRange[5][0]=(295|0);
this.mTorsionRange[5][1]=(325|0);
this.mFrequency=Clazz.array(Short.TYPE, [6]);
this.mFrequency[0]=(40|0);
this.mFrequency[1]=(5|0);
this.mFrequency[2]=(5|0);
this.mFrequency[3]=(40|0);
this.mFrequency[4]=(5|0);
this.mFrequency[5]=(5|0);
}} else {
this.mTorsion=Clazz.array(Short.TYPE, [1]);
this.mTorsion[0]=(180|0);
this.mTorsionRange=Clazz.array(Short.TYPE, [1, 2]);
this.mTorsionRange[0][0]=(165|0);
this.mTorsionRange[0][1]=(195|0);
this.mFrequency=Clazz.array(Short.TYPE, [1]);
this.mFrequency[0]=(100|0);
}}, 1);

Clazz.newMeth(C$, 'getTorsions$',  function () {
return this.mTorsion;
});

Clazz.newMeth(C$, 'getTorsionFrequencies$',  function () {
return this.mFrequency;
});

Clazz.newMeth(C$, 'getTorsionRanges$',  function () {
return this.mTorsionRange;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
