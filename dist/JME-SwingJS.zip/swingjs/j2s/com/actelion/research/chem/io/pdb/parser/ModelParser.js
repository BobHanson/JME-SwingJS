(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),p$1={},I$=[[0,'com.actelion.research.chem.io.pdb.parser.AtomRecord']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['indexLine']]]

Clazz.newMeth(C$, 'parse$java_util_List$I$java_util_List$java_util_List',  function (liRaw, indexLine, protAtomRecords, hetAtomRecords) {
var tagAtom="ATOM";
var tagHeteroAtom="HETATM";
var l0=liRaw.get$I(indexLine);
if (!l0.startsWith$S(tagAtom) && !l0.startsWith$S(tagHeteroAtom) && !l0.startsWith$S("MODEL")  ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in parsing atoms."]);
}this.indexLine=indexLine;
var start=indexLine;
var lastRecord=null;
for (var i=start; i < liRaw.size$(); i++) {
var line=liRaw.get$I(i);
if (line.startsWith$S(tagAtom)) {
var modelAtom=p$1.parseAtom$S.apply(this, [line]);
lastRecord=modelAtom;
protAtomRecords.add$O(modelAtom);
} else if (line.startsWith$S(tagHeteroAtom)) {
var modelAtom=p$1.parseAtom$S.apply(this, [line]);
lastRecord=modelAtom;
hetAtomRecords.add$O(modelAtom);
} else if (line.startsWith$S("ANISOU")) {
continue;
} else if (line.startsWith$S("TER")) {
if (lastRecord != null ) lastRecord.setTerminalC$Z(true);
} else if (line.startsWith$S("MODEL")) {
continue;
} else if (line.startsWith$S("ENDMDL")) {
if (lastRecord != null ) lastRecord.setTerminalC$Z(true);
} else {
this.indexLine=i;
break;
}}
});

Clazz.newMeth(C$, 'parseAtom$S',  function (line) {
var serialId=Integer.parseInt$S(line.substring$I$I(6, 11).trim$());
var atomName=line.substring$I$I(12, 16).trim$();
var altLoc=line.substring$I$I(16, 17).trim$();
var residueName=line.substring$I$I(17, 20).trim$();
var chainId=line.substring$I$I(21, 22).trim$();
var resSeq=Integer.parseInt$S(line.substring$I$I(22, 26).trim$());
var insertionCode=line.substring$I$I(26, 27).trim$();
var x=Double.parseDouble$S(line.substring$I$I(30, 38).trim$());
var y=-Double.parseDouble$S(line.substring$I$I(38, 46).trim$());
var z=-Double.parseDouble$S(line.substring$I$I(46, 54).trim$());
var occupancy=(line.length$() < 60) ? 1.0 : Double.parseDouble$S(line.substring$I$I(54, 60).trim$());
var tempFactor=(line.length$() < 66) ? 50.0 : Double.parseDouble$S(line.substring$I$I(60, 66).trim$());
var element=(line.length$() < 78) ? atomName.substring$I$I(0, 1) : line.substring$I$I(76, 78).trim$();
element=element.toLowerCase$();
element=element.substring$I$I(0, 1).toUpperCase$() + element.substring$I(1);
var modelAtom=Clazz.new_($I$(1,1).c$$I$S$S$S$S$I$S$D$D$D$D$D$S,[serialId, atomName, altLoc, residueName, chainId, resSeq, insertionCode, x, y, z, occupancy, tempFactor, element]);
return modelAtom;
}, p$1);

Clazz.newMeth(C$, 'getIndexLine$',  function () {
return this.indexLine;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
