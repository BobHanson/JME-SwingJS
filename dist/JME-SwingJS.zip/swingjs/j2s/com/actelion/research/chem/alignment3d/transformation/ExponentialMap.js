(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.alignment3d.transformation.Quaternion']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExponentialMap");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['p','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_alignment3d_transformation_Quaternion',  function (q) {
;C$.$init$.apply(this);
p$1.calc$com_actelion_research_chem_alignment3d_transformation_Quaternion.apply(this, [q]);
p$1.checkParameterization.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Coordinates',  function (p) {
;C$.$init$.apply(this);
this.p=p;
p$1.checkParameterization.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D',  function (p1, p2, p3) {
;C$.$init$.apply(this);
this.p=Clazz.new_($I$(1,1).c$$D$D$D,[p1, p2, p3]);
}, 1);

Clazz.newMeth(C$, 'getP$',  function () {
return this.p;
});

Clazz.newMeth(C$, 'calc$com_actelion_research_chem_alignment3d_transformation_Quaternion',  function (q) {
var axis=Clazz.new_($I$(1,1).c$$D$D$D,[0, 0, 0]);
var qv=Clazz.new_([q.getQ1$(), q.getQ2$(), q.getQ3$()],$I$(1,1).c$$D$D$D);
var qw=q.getQ0$();
var qvLength=qv.getLength$();
var angle=2 * Math.atan2(qvLength, qw);
if (angle > 1.0E-6 ) axis=qv.scaleC$D(1.0 / Math.sin(angle / 2.0));
axis.scale$D(angle);
this.p=axis;
}, p$1);

Clazz.newMeth(C$, 'toQuaternion$',  function () {
var cosp;
var sinp;
var theta;
theta=this.p.getLength$();
cosp=Math.cos(0.5 * theta);
sinp=Math.sin(0.5 * theta);
var scalar=cosp;
var v;
if (theta < 1.0E-6 ) v=this.p.scaleC$D(0.5 - theta * theta / 48.0);
 else v=this.p.scaleC$D(sinp / theta);
return Clazz.new_($I$(2,1).c$$D$D$D$D,[scalar, v.x, v.y, v.z]);
});

Clazz.newMeth(C$, 'checkParameterization',  function () {
var theta=this.p.getLength$();
if (theta > 3.141592653589793 ) {
var scl=theta;
if (theta > 6.283185307179586 ) {
theta=theta % (6.283185307179586);
scl=theta / scl;
this.p.scale$D(scl);
}if (theta > 3.141592653589793 ) {
scl=theta;
theta=6.283185307179586 - theta;
scl=1.0 - 6.283185307179586 / scl;
this.p.scale$D(scl);
}}}, p$1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var c=0.707106781;
var transforms2=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1]), Clazz.array(Double.TYPE, -1, [c, c, 0, 0]), Clazz.array(Double.TYPE, -1, [c, 0, c, 0]), Clazz.array(Double.TYPE, -1, [c, 0, 0, c]), Clazz.array(Double.TYPE, -1, [-0.5, 0.5, 0.5, -0.5]), Clazz.array(Double.TYPE, -1, [0.5, -0.5, 0.5, -0.5]), Clazz.array(Double.TYPE, -1, [0.5, 0.5, 0.5, -0.5]), Clazz.array(Double.TYPE, -1, [0.5, -0.5, -0.5, -0.5]), Clazz.array(Double.TYPE, -1, [0.5, 0.5, -0.5, -0.5])]);
for (var transform, $transform = 0, $$transform = transforms2; $transform<$$transform.length&&((transform=($$transform[$transform])),1);$transform++) {
var eMap=Clazz.new_(C$.c$$com_actelion_research_chem_alignment3d_transformation_Quaternion,[Clazz.new_($I$(2,1).c$$D$D$D$D,[transform[0], transform[1], transform[2], transform[3]])]);
System.out.println$O(eMap.toQuaternion$());
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
