(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'java.util.HashSet','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','com.actelion.research.chem.descriptor.flexophore.PPNodeViz','StringBuilder','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistVizHiddenPPPoints", null, 'com.actelion.research.chem.descriptor.flexophore.MolDistHistViz', 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrMapHiddenPPPoints','byte[]','hsHiddenIndex','java.util.HashSet']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistVizHiddenPPPoints',  function (mdhvhpp) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz.apply(this,[mdhvhpp]);C$.$init$.apply(this);
p$1.init.apply(this, []);
this.hsHiddenIndex.addAll$java_util_Collection(mdhvhpp.hsHiddenIndex);
p$1.hidden2Map.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz.apply(this,[mdhv]);C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist.apply(this,[mdh]);C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.hsHiddenIndex=Clazz.new_($I$(1,1));
var size=C$.superclazz.prototype.getNumPPNodes$.apply(this, []);
this.arrMapHiddenPPPoints=Clazz.array(Byte.TYPE, [size]);
p$1.hidden2Map.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'hidden2Map',  function () {
var size=C$.superclazz.prototype.getNumPPNodes$.apply(this, []);
var cc=0;
for (var i=($b$[0] = 0, $b$[0]); i < size; ($b$[0]=i,i=(++$b$[0],$b$[0]))) {
if (!this.hsHiddenIndex.contains$O(Byte.valueOf$B(i))) {
this.arrMapHiddenPPPoints[cc++]=i;
}}
}, p$1);

Clazz.newMeth(C$, 'addMandatoryPharmacophorePoint$I',  function (indexNodeAbsolute) {
if (this.isHiddenPharmacophorePointAbsolute$B(($b$[0] = indexNodeAbsolute, $b$[0]))) {
this.removeHiddenPharmacophorePoint$B(($b$[0] = indexNodeAbsolute, $b$[0]));
}C$.superclazz.prototype.addMandatoryPharmacophorePoint$I.apply(this, [indexNodeAbsolute]);
});

Clazz.newMeth(C$, 'removeInevitablePharmacophorePoint$I',  function (indexNodeAbsolute) {
C$.superclazz.prototype.removeInevitablePharmacophorePoint$I.apply(this, [indexNodeAbsolute]);
});

Clazz.newMeth(C$, 'addHiddenPharmacophorePoint$B',  function (indexPPNodeAbsolute) {
this.hsHiddenIndex.add$O(Byte.valueOf$B(indexPPNodeAbsolute));
p$1.hidden2Map.apply(this, []);
});

Clazz.newMeth(C$, 'removeHiddenPharmacophorePoint$B',  function (indexPPNodeAbsolute) {
this.hsHiddenIndex.remove$O(Byte.valueOf$B(indexPPNodeAbsolute));
p$1.hidden2Map.apply(this, []);
});

Clazz.newMeth(C$, 'resetHiddenPharmacophorePoints$',  function () {
this.hsHiddenIndex.clear$();
p$1.hidden2Map.apply(this, []);
});

Clazz.newMeth(C$, 'getRelMaxDistInHistSkipHidden$I$I',  function (indexAt1, indexAt2) {
return C$.superclazz.prototype.getRelMaxDistInHist$I$I.apply(this, [this.arrMapHiddenPPPoints[indexAt1], this.arrMapHiddenPPPoints[indexAt2]]);
});

Clazz.newMeth(C$, 'getNodeSkipHidden$I',  function (indexNode) {
return C$.superclazz.prototype.getNode$I.apply(this, [this.arrMapHiddenPPPoints[indexNode]]);
});

Clazz.newMeth(C$, 'getDistHistSkipHidden$I$I$BA',  function (indexAt1, indexAt2, arr) {
return C$.superclazz.prototype.getDistHist$I$I$BA.apply(this, [this.arrMapHiddenPPPoints[indexAt1], this.arrMapHiddenPPPoints[indexAt2], arr]);
});

Clazz.newMeth(C$, 'getDistHistSkipHidden$I$I',  function (indexAt1, indexAt2) {
return C$.superclazz.prototype.getDistHist$I$I.apply(this, [this.arrMapHiddenPPPoints[indexAt1], this.arrMapHiddenPPPoints[indexAt2]]);
});

Clazz.newMeth(C$, 'isInevitablePharmacophorePointSkipHidden$I',  function (indexNode) {
return C$.superclazz.prototype.isMandatoryPharmacophorePoint$I.apply(this, [this.arrMapHiddenPPPoints[indexNode]]);
});

Clazz.newMeth(C$, 'getNumInevitablePharmacophorePointsSkipHidden$',  function () {
var inevitable=0;
var size=this.getSizeSkipHidden$();
for (var i=0; i < size; i++) {
if (this.isInevitablePharmacophorePointSkipHidden$I(i)) {
++inevitable;
}}
return inevitable;
});

Clazz.newMeth(C$, 'getSizeSkipHidden$',  function () {
return C$.superclazz.prototype.getNumPPNodes$.apply(this, []) - this.hsHiddenIndex.size$();
});

Clazz.newMeth(C$, 'getHashSetHiddenIndex$',  function () {
return this.hsHiddenIndex;
});

Clazz.newMeth(C$, 'isHiddenPharmacophorePointAbsolute$B',  function (indexNodeAbsolute) {
return this.hsHiddenIndex.contains$O(Byte.valueOf$B(indexNodeAbsolute));
});

Clazz.newMeth(C$, 'isInevitablePharmacophorePointAbsolute$I',  function (indexNodeAbsolute) {
return C$.superclazz.prototype.isMandatoryPharmacophorePoint$I.apply(this, [indexNodeAbsolute]);
});

Clazz.newMeth(C$, 'getMolDistHistVizSkipHidden$',  function () {
var ffCopy=$I$(2).finalizeMolecule$com_actelion_research_chem_Molecule3D(this.molecule3D);
var size=this.getSizeSkipHidden$();
var mdhv=Clazz.new_($I$(2,1).c$$I$com_actelion_research_chem_Molecule3D,[size, ffCopy]);
var sizeAbsolute=this.getNumPPNodes$();
for (var i=0; i < sizeAbsolute; i++) {
if (!this.isHiddenPharmacophorePointAbsolute$B(($b$[0] = i, $b$[0]))) {
var node=Clazz.new_([this.getNode$I(i)],$I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz);
var indexNNew=mdhv.addNode$com_actelion_research_chem_descriptor_flexophore_PPNodeViz(node);
if (this.isInevitablePharmacophorePointAbsolute$I(i)) {
mdhv.addMandatoryPharmacophorePoint$I(indexNNew);
}}}
for (var i=0; i < size; i++) {
for (var j=i + 1; j < size; j++) {
var arrDistHist=this.getDistHistSkipHidden$I$I(i, j);
mdhv.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
mdhv.realize$();
return mdhv;
});

Clazz.newMeth(C$, 'toStringHiddenAndInevitable$',  function () {
var sb=Clazz.new_($I$(4,1));
sb.append$S(this.toStringInevitable$());
sb.append$S("\n");
sb.append$S("Num hidden " + this.hsHiddenIndex.size$());
sb.append$S("\n");
sb.append$S("Index hidden ");
for (var indexHidden, $indexHidden = this.hsHiddenIndex.iterator$(); $indexHidden.hasNext$()&&((indexHidden=($indexHidden.next$()).objectValue$()),1);) {
sb.append$S(indexHidden + " ");
}
sb.append$S("\n");
sb.append$S("Map hidden " + $I$(5).toString$BA(this.arrMapHiddenPPPoints));
return sb.toString();
});
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
