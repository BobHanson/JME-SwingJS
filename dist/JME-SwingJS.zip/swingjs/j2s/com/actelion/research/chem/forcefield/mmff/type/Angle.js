(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.type"),I$=[[0,'java.util.HashSet','com.actelion.research.chem.forcefield.mmff.type.Bond']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Angle");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (mol, a1, a2, a3, size) {
var rings=mol.getRingSet$();
var angle=Clazz.new_($I$(1,1));
angle.add$O(Integer.valueOf$I(a1));
angle.add$O(Integer.valueOf$I(a2));
angle.add$O(Integer.valueOf$I(a3));
if (mol.getBond$I$I(a1, a2) >= 0 && mol.getBond$I$I(a2, a3) >= 0 ) for (var r=0; r < rings.getSize$(); r++) if (rings.getRingSize$I(r) == size) {
var ring=Clazz.new_($I$(1,1));
for (var a, $a = 0, $$a = rings.getRingAtoms$I(r); $a<$$a.length&&((a=($$a[$a])),1);$a++) ring.add$O(Integer.valueOf$I(a));

if (ring.containsAll$java_util_Collection(angle)) return true;
}
return false;
}, 1);

Clazz.newMeth(C$, 'getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (table, mol, a1, a2, a3) {
var bondsum=$I$(2).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a1, a2) + $I$(2).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a2, a3);
var type=bondsum;
if (C$.inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, 3)) type+=bondsum > 0 ? 4 : 3;
 else if (C$.inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, 4)) type+=bondsum > 0 ? 6 : 4;
return type;
}, 1);

Clazz.newMeth(C$, 'getStbnType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (table, mol, a1, a2, a3) {
var a1t=mol.getAtomType$I(a1);
var a3t=mol.getAtomType$I(a3);
var b1tf=$I$(2).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a1, a2);
var b2tf=$I$(2).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a2, a3);
var b1t=a1t <= a3t ? b1tf : b2tf;
var b2t=a1t < a3t ? b2tf : b1tf;
var angt=C$.getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(table, mol, a1, a2, a3);
switch (angt) {
case 1:
return (b1t > 0 || b1t == b2t ) ? 1 : 2;
case 2:
return 3;
case 3:
return 5;
case 4:
return 4;
case 5:
return (b1t > 0 || b1t == b2t ) ? 6 : 7;
case 6:
return 8;
case 7:
return (b1t > 0 || b1t == b2t ) ? 9 : 10;
case 8:
return 11;
}
return 0;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
