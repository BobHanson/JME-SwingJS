(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,['com.actelion.research.chem.DiversitySelector','.DiversitySelectorRecord'],'java.util.Arrays',['com.actelion.research.chem.DiversitySelector','.DiversitySelectorComparator']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DiversitySelector", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'com.actelion.research.calc.DataProcessor');
C$.$classes$=[['DiversitySelectorRecord',4],['DiversitySelectorComparator',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mAddingToExistingSet'],'I',['mNoOfFeatures','mExistingSetCount'],'O',['mFeatureList','long[][]','mCentroidVector','double[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'initializeExistingSet$I',  function (noOfKeys) {
this.mFeatureList=Clazz.array(Long.TYPE, [1, null]);
this.mCentroidVector=Clazz.array(Double.TYPE, [noOfKeys]);
this.mExistingSetCount=0;
});

Clazz.newMeth(C$, 'addToExistingSet$JA',  function (featureList) {
this.mFeatureList[0]=featureList;
var record=Clazz.new_($I$(1,1).c$$I,[this, null, 0]);
p$1.addToCentroidVector.apply(record, []);
this.mAddingToExistingSet=true;
++this.mExistingSetCount;
});

Clazz.newMeth(C$, 'setExistingSet$JAA',  function (featureList) {
this.mCentroidVector=Clazz.array(Double.TYPE, [64 * featureList[0].length]);
this.mFeatureList=featureList;
for (var compound=0; compound < featureList.length; compound++) {
var record=Clazz.new_($I$(1,1).c$$I,[this, null, compound]);
p$1.addToCentroidVector.apply(record, []);
}
this.mAddingToExistingSet=true;
this.mExistingSetCount=featureList.length;
});

Clazz.newMeth(C$, 'select$JAA$I',  function (featureList, compoundsToSelect) {
var compoundsAvailable=featureList.length;
this.mNoOfFeatures=64 * featureList[0].length;
this.mFeatureList=featureList;
if (compoundsToSelect > compoundsAvailable) compoundsToSelect=compoundsAvailable;
this.startProgress$S$I$I("Creating Key Lists...", 0, compoundsAvailable);
var recordList=Clazz.array($I$(1), [compoundsAvailable]);
for (var compound=0; compound < compoundsAvailable; compound++) {
recordList[compound]=Clazz.new_($I$(1,1).c$$I,[this, null, compound]);
if ((compound & 255) == 255) {
if (this.threadMustDie$()) {
this.stopProgress$S("Selection cancelled");
return null;
}this.updateProgress$I(compound);
}}
this.startProgress$S$I$I("Locating Starting Compound...", 0, compoundsAvailable);
if (!this.mAddingToExistingSet) {
this.mCentroidVector=Clazz.array(Double.TYPE, [this.mNoOfFeatures]);
for (var compound=0; compound < compoundsAvailable; compound++) {
p$1.addToCentroidVector.apply(recordList[compound], []);
if ((compound & 255) == 255) {
if (this.threadMustDie$()) {
this.stopProgress$S("Selection cancelled");
return null;
}this.updateProgress$I((compound/2|0));
}}
var maxDotProduct=0.0;
var maxCompoundIndex=0;
for (var compound=0; compound < compoundsAvailable; compound++) {
var dotProduct=0.0;
for (var keyIndex=0; keyIndex < recordList[compound].mKeyList.length; keyIndex++) {
var key=recordList[compound].mKeyList[keyIndex];
dotProduct+=(this.mCentroidVector[key] - recordList[compound].mWeight) * recordList[compound].mWeight;
}
if (maxDotProduct < dotProduct ) {
maxDotProduct=dotProduct;
maxCompoundIndex=compound;
}if ((compound & 255) == 255) {
if (this.threadMustDie$()) {
this.stopProgress$S("Selection cancelled");
return null;
}this.updateProgress$I(((compoundsAvailable + compound)/2|0));
}}
var startCompound=recordList[maxCompoundIndex];
recordList[maxCompoundIndex]=recordList[0];
recordList[0]=startCompound;
this.mCentroidVector=Clazz.array(Double.TYPE, [this.mNoOfFeatures]);
p$1.addToCentroidVector.apply(startCompound, []);
}this.startProgress$S$I$I("Selecting Compounds...", 0, compoundsToSelect);
var selectionCycle=0;
for (var compound=(this.mAddingToExistingSet) ? 0 : 1; compound < compoundsToSelect; compound++) {
var noOfCompoundsToSort=((10.0 * (this.mExistingSetCount + compoundsAvailable) / (this.mExistingSetCount + compound))|0);
var mask=3;
while (noOfCompoundsToSort < compoundsAvailable - compound){
if ((selectionCycle & mask) != 0) break;
mask=(mask << 2) | 3;
noOfCompoundsToSort*=4;
}
var lastCompoundToConsider=compound + noOfCompoundsToSort;
if (lastCompoundToConsider > compoundsAvailable) lastCompoundToConsider=compoundsAvailable;
for (var i=compound; i < lastCompoundToConsider; i++) p$1.calculateDotProduct.apply(recordList[i], []);

$I$(2,"sort$OA$I$I$java_util_Comparator",[recordList, compound, lastCompoundToConsider, Clazz.new_($I$(3,1),[this, null])]);
p$1.addToCentroidVector.apply(recordList[compound], []);
++selectionCycle;
if (this.threadMustDie$()) {
this.stopProgress$S("Selection cancelled");
return null;
}this.updateProgress$I(compound);
}
var selected=Clazz.array(Integer.TYPE, [compoundsToSelect]);
for (var compound=0; compound < compoundsToSelect; compound++) selected[compound]=recordList[compound].mCompoundIndex;

this.stopProgress$S("Compound Selection Done");
return selected;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.DiversitySelector, "DiversitySelectorRecord", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mWeight','mDotProduct'],'I',['mCompoundIndex'],'O',['mKeyList','int[]']]]

Clazz.newMeth(C$, 'c$$I',  function (index) {
;C$.$init$.apply(this);
var count=0;
for (var feature=0; feature < this.b$['com.actelion.research.chem.DiversitySelector'].mNoOfFeatures; feature++) if (Long.$ne((Long.$and(this.b$['com.actelion.research.chem.DiversitySelector'].mFeatureList[index][(feature/64|0)],(1 << (63 - feature % 64)))),0 )) ++count;

this.mKeyList=Clazz.array(Integer.TYPE, [count]);
count=0;
for (var feature=0; feature < this.b$['com.actelion.research.chem.DiversitySelector'].mNoOfFeatures; feature++) if (Long.$ne((Long.$and(this.b$['com.actelion.research.chem.DiversitySelector'].mFeatureList[index][(feature/64|0)],(1 << (63 - feature % 64)))),0 )) this.mKeyList[count++]=feature;

this.mWeight=1.0 / Math.sqrt(count);
this.mCompoundIndex=index;
}, 1);

Clazz.newMeth(C$, 'addToCentroidVector',  function () {
for (var i=0; i < this.mKeyList.length; i++) this.b$['com.actelion.research.chem.DiversitySelector'].mCentroidVector[this.mKeyList[i]]+=this.mWeight;

}, p$1);

Clazz.newMeth(C$, 'calculateDotProduct',  function () {
this.mDotProduct=0.0;
for (var i=0; i < this.mKeyList.length; i++) this.mDotProduct+=this.mWeight * this.b$['com.actelion.research.chem.DiversitySelector'].mCentroidVector[this.mKeyList[i]];

}, p$1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DiversitySelector, "DiversitySelectorComparator", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'compare$O$O',  function (o1, o2) {
var d1=(o1).mDotProduct;
var d2=(o2).mDotProduct;
return (d1 < d2 ) ? -1 : (d1 == d2 ) ? 0 : 1;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:37 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
