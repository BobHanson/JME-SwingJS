(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.reaction.ReactionArrow','com.actelion.research.chem.TextDrawingObject']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DrawingObjectFactory");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'createObject$S',  function (descriptor) {
var START="<DrawingObject type=\"";
if (!descriptor.startsWith$S("<DrawingObject type=\"") || !descriptor.endsWith$S("></DrawingObject>") ) return null;
var index=descriptor.indexOf$I$I("\"", "<DrawingObject type=\"".length$());
if (index == -1) return null;
var type=descriptor.substring$I$I("<DrawingObject type=\"".length$(), index);
var detail=descriptor.substring$I$I("<DrawingObject type=\"".length$() + type.length$() + 1 , descriptor.length$() - "></DrawingObject>".length$());
if (type.equals$O("arrow")) return Clazz.new_($I$(1,1).c$$S,[detail]);
if (type.equals$O("text")) return Clazz.new_($I$(2,1).c$$S,[detail]);
return null;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:37 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
