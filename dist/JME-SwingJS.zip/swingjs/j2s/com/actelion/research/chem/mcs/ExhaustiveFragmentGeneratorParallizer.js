(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'java.util.HashSet','com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorBonds','com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer','Thread','com.actelion.research.chem.mcs.BondVector2IdCode','com.actelion.research.chem.Canonizer','java.util.ArrayList','java.util.concurrent.atomic.AtomicInteger','Runtime','java.util.concurrent.ConcurrentHashMap','java.util.concurrent.Executors',['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer','.RunEFG']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExhaustiveFragmentGeneratorParallizer", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['RunEFG',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['nCores','bits'],'O',['queuePipe','com.actelion.research.util.Pipeline','liHashMapIdCode_Fragment','java.util.List','ccProcessedRecords','java.util.concurrent.atomic.AtomicInteger','+ccMoleculeToLarge']]
,['I',['TOTAL_CAPACITY']]]

Clazz.newMeth(C$, 'c$$I',  function (bits) {
;C$.$init$.apply(this);
this.bits=bits;
this.liHashMapIdCode_Fragment=Clazz.new_($I$(7,1));
this.ccProcessedRecords=Clazz.new_($I$(8,1));
this.ccMoleculeToLarge=Clazz.new_($I$(8,1));
this.nCores=$I$(9).getRuntime$().availableProcessors$();
if (this.nCores > 1) {
--this.nCores;
}}, 1);

Clazz.newMeth(C$, 'process$com_actelion_research_util_Pipeline$I$Z$Z',  function (queuePipe, maxSizeFrag, cleaveRingBonds, addWildcards) {
for (var hm, $hm = this.liHashMapIdCode_Fragment.iterator$(); $hm.hasNext$()&&((hm=($hm.next$())),1);) {
hm.clear$();
}
var maxBondsPlusBondsWildcards=maxSizeFrag + 24 + 1 ;
for (var i=this.liHashMapIdCode_Fragment.size$(); i < maxBondsPlusBondsWildcards; i++) {
if (i < 4) {
this.liHashMapIdCode_Fragment.add$O(Clazz.new_($I$(10,1)));
} else {
this.liHashMapIdCode_Fragment.add$O(Clazz.new_($I$(10,1).c$$I,[10000]));
}}
this.queuePipe=queuePipe;
this.ccProcessedRecords.set$I(0);
var cores=$I$(9).getRuntime$().availableProcessors$();
var poolSize=cores - 1;
if (poolSize == 0) {
poolSize=1;
}var executorService=$I$(11).newFixedThreadPool$I(poolSize);
var liRunEFG=Clazz.new_($I$(7,1));
for (var i=0; i < poolSize; i++) {
var extractor=Clazz.new_($I$(12,1).c$$I$I$Z$Z,[this, null, this.bits, maxSizeFrag, cleaveRingBonds, addWildcards]);
executorService.execute$Runnable(extractor);
liRunEFG.add$O(extractor);
}
executorService.shutdown$();
while (!executorService.isTerminated$()){
try {
$I$(4).sleep$J(10000);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
System.out.println$S(" Processed records " + this.ccProcessedRecords.get$() + "." );
System.out.println$S(" Molecules still in pipeline " + queuePipe.sizePipe$() + "." );
var ccFrags=0;
for (var hm, $hm = this.liHashMapIdCode_Fragment.iterator$(); $hm.hasNext$()&&((hm=($hm.next$())),1);) {
ccFrags+=hm.size$();
}
System.out.println$S(" Unique fragments " + ccFrags + "." );
}
System.out.println$S(" Processed records " + this.ccProcessedRecords.get$() + "." );
System.out.println$S(" Molecules still in pipeline " + queuePipe.sizePipe$() + "." );
var ccFrags=0;
for (var hm, $hm = this.liHashMapIdCode_Fragment.iterator$(); $hm.hasNext$()&&((hm=($hm.next$())),1);) {
ccFrags+=hm.size$();
}
System.out.println$S(" Unique fragments " + ccFrags + "." );
System.out.println$S("Finished all " + Clazz.new_(java.util.Date).toString());
});

Clazz.newMeth(C$, 'getFragmentList$',  function () {
var li=Clazz.new_($I$(7,1));
for (var hm, $hm = this.liHashMapIdCode_Fragment.iterator$(); $hm.hasNext$()&&((hm=($hm.next$())),1);) {
li.addAll$java_util_Collection(hm.values$());
}
return li;
});

C$.$static$=function(){C$.$static$=0;
C$.TOTAL_CAPACITY=((10 * Math.pow(10, 6))|0);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.ExhaustiveFragmentGeneratorParallizer, "RunEFG", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['addWildcards','cleaveRingBonds'],'I',['maxSizeFrag'],'O',['hsIdCode','java.util.HashSet','efg','com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorBonds']]]

Clazz.newMeth(C$, 'c$$I$I$Z$Z',  function (bits, maxSizeFrag, cleaveRingBonds, addWildcards) {
;C$.$init$.apply(this);
this.maxSizeFrag=maxSizeFrag;
this.addWildcards=addWildcards;
this.cleaveRingBonds=cleaveRingBonds;
this.hsIdCode=Clazz.new_($I$(1,1));
this.efg=Clazz.new_([bits, $I$(3).TOTAL_CAPACITY],$I$(2,1).c$$I$I);
}, 1);

Clazz.newMeth(C$, 'run$',  function () {
while (!this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].queuePipe.wereAllDataFetched$()){
var mol=this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].queuePipe.pollData$();
if (mol == null ) {
try {
$I$(4).sleep$J(500);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
continue;
}if (mol.getBonds$() <= this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].bits) {
try {
this.process$com_actelion_research_chem_StereoMolecule(mol);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
} else {
this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].ccMoleculeToLarge.incrementAndGet$();
}this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].ccProcessedRecords.incrementAndGet$();
}
});

Clazz.newMeth(C$, 'process$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.hsIdCode.clear$();
var bondVector2IdCode=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
this.efg.set$com_actelion_research_chem_ExtendedMolecule$I(mol, this.maxSizeFrag);
this.efg.generateFragmentsAllBonds$();
var bonds=mol.getBonds$();
var n=Math.min(bonds, this.maxSizeFrag + 1);
for (var i=0; i < n; i++) {
var liFragDefByBnds=this.efg.getFragments$I(i);
for (var fragDefByBnds, $fragDefByBnds = liFragDefByBnds.iterator$(); $fragDefByBnds.hasNext$()&&((fragDefByBnds=($fragDefByBnds.next$())),1);) {
if (!this.cleaveRingBonds && bondVector2IdCode.containsFragmentOpenRing$com_actelion_research_chem_properties_complexity_IBitArray(fragDefByBnds) ) {
continue;
}var bnds=fragDefByBnds.getBitsSet$();
var fragmentNew=bondVector2IdCode.getFragment$com_actelion_research_chem_properties_complexity_IBitArray$Z(fragDefByBnds, this.addWildcards);
if (fragmentNew.getMol$().getBonds$() >= this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].liHashMapIdCode_Fragment.size$()) {
var can=Clazz.new_([fragmentNew.getMol$()],$I$(6,1).c$$com_actelion_research_chem_StereoMolecule);
System.out.println$S("ExhaustiveFragmentGeneratorParallizer RunEFG bonds fragment " + bnds);
System.out.println$S("ExhaustiveFragmentGeneratorParallizer RunEFG bonds fragment with wildcards " + fragmentNew.getMol$().getBonds$());
System.out.println$S(can.getIDCode$());
continue;
}var hmIdCode_Fragment=this.b$['com.actelion.research.chem.mcs.ExhaustiveFragmentGeneratorParallizer'].liHashMapIdCode_Fragment.get$I(fragmentNew.getMol$().getBonds$());
if (!hmIdCode_Fragment.containsKey$O(fragmentNew.getIdcode$())) {
fragmentNew.setFrequencySumAll$I(0);
hmIdCode_Fragment.put$O$O(fragmentNew.getIdcode$(), fragmentNew);
}var fragment=hmIdCode_Fragment.get$O(fragmentNew.getIdcode$());
fragment.incrementFrequencySumAll$();
if (this.hsIdCode.add$O(fragment.getIdcode$())) {
fragment.incrementFrequencyOnePerMol$();
}}
}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:26 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
