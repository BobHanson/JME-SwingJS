(function(){var P$=Clazz.newPackage("com.actelion.research.chem.coords"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InventorCharge");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atom','charge'],'O',['fragment','com.actelion.research.chem.coords.InventorFragment']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_coords_InventorFragment$I$I',  function (fragment, atom, charge) {
;C$.$init$.apply(this);
this.fragment=fragment;
this.atom=atom;
this.charge=charge;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
