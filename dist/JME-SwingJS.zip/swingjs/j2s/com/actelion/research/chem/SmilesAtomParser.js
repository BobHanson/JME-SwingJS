(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},p$2={},I$=[[0,'com.actelion.research.util.SortedList','java.util.ArrayList',['com.actelion.research.chem.SmilesAtomParser','.AtomLabelInfo'],'java.util.Arrays',['com.actelion.research.chem.SmilesAtomParser','.SmilesRange'],'com.actelion.research.chem.Molecule','java.nio.charset.StandardCharsets','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SmilesAtomParser", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['AtomLabelInfo',10],['SmilesRange',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['parityFound','isClockwise','smartsFeatureFound','mAllowCactvs'],'I',['atomicNo','abnormalValence','charge','mapNo','explicitHydrogens','mMode'],'J',['atomQueryFeatures'],'O',['mParentParser','com.actelion.research.chem.SmilesParser','atomList','com.actelion.research.util.SortedList','recursiveSmartsList','java.util.ArrayList','+excludeGroupList']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_SmilesParser$I',  function (parser, mode) {
;C$.$init$.apply(this);
this.mParentParser=parser;
this.mMode=mode;
this.mAllowCactvs=(mode & 16) == 0;
this.atomicNo=-1;
this.charge=0;
this.mapNo=0;
this.abnormalValence=-1;
this.explicitHydrogens=-1;
this.atomQueryFeatures=0;
}, 1);

Clazz.newMeth(C$, 'addAtomToList$I',  function (atomicNo) {
if (this.atomList == null ) this.atomList=Clazz.new_($I$(1,1));
this.atomList.add$O(Integer.valueOf$I(atomicNo));
}, p$2);

Clazz.newMeth(C$, 'parseAtomOutsideBrackets$BA$I$I$Z',  function (smiles, position, endIndex, allowSmarts) {
if (smiles[position - 1] == 42 ) {
this.atomicNo=6;
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(1)));
} else if (smiles[position - 1] == 63 ) {
this.atomicNo=0;
} else if ((smiles[position - 1] == 65  || smiles[position - 1] == 97  ) && allowSmarts ) {
this.atomicNo=6;
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(1)));
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(smiles[position - 1] == 65  ? 4 : 2)));
this.smartsFeatureFound=true;
} else {
switch (Character.toUpperCase$I(smiles[position - 1])) {
case 66:
if (position < endIndex && smiles[position] == 114  ) {
this.atomicNo=35;
++position;
} else this.atomicNo=5;
break;
case 67:
if (position < endIndex && smiles[position] == 108  ) {
this.atomicNo=17;
++position;
} else this.atomicNo=6;
break;
case 70:
this.atomicNo=9;
break;
case 73:
this.atomicNo=53;
break;
case 78:
this.atomicNo=7;
break;
case 79:
this.atomicNo=8;
break;
case 80:
this.atomicNo=15;
break;
case 83:
this.atomicNo=16;
break;
}
}return position;
});

Clazz.newMeth(C$, 'advanceJustAfterClosingBracket$BA$I',  function (smiles, position) {
var level=0;
while (position < smiles.length && (smiles[position] != 93  || level != 0 ) ){
if (smiles[position] == 91 ) ++level;
 else if (smiles[position] == 93 ) --level;
++position;
}
if (position == smiles.length) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: No matching closing bracket found."]);
return position + 1;
}, p$2);

Clazz.newMeth(C$, 'parseAtomInsideBrackets$BA$I$I$Z$Z',  function (smiles, position, endIndex, allowSmarts, allowAtomOptions) {
if (smiles[position - 1] == 36 ) {
this.recursiveSmartsList=Clazz.new_($I$(2,1));
position+=p$2.parseRecursiveGroup$BA$I$java_util_ArrayList.apply(this, [smiles, position - 1, this.recursiveSmartsList]) - 1;
if (smiles[position++] != 93 ) {
if (!allowAtomOptions) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: A positive recursive SMARTS followed by another one or by atom query features is not supported. Position:" + (position - 1)]);
if ((this.mMode & 128) == 0) position=p$2.advanceJustAfterClosingBracket$BA$I.apply(this, [smiles, position]);
}return position;
}if (smiles[position - 1] == 42 ) {
this.atomicNo=6;
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(1)));
} else if (smiles[position - 1] == 63 ) {
this.atomicNo=0;
} else {
var isNotList=(smiles[position - 1] == 33 );
if (isNotList) {
this.smartsFeatureFound=true;
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(1)));
++position;
}if (smiles[position - 1] == 82  && allowSmarts  && (Character.isDigit$I(smiles[position]) || (this.mAllowCactvs && smiles[position] == 123  ) ) ) {
this.atomicNo=6;
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(1)));
--position;
if (isNotList) --position;
} else {
var labelInfo=Clazz.new_($I$(3,1));
if (!p$2.parseAtomLabelInBrackets$BA$I$I$com_actelion_research_chem_SmilesAtomParser_AtomLabelInfo.apply(this, [smiles, position - 1, endIndex, labelInfo])) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Unexpected character in atom definition:'" + (String.fromCharCode(smiles[position - 1])) + "' position:" + (position - 1) ]);
this.atomicNo=labelInfo.atomicNo;
position+=labelInfo.labelLength - 1;
if ((this.mMode & 3) != 2) this.explicitHydrogens=9;
if (allowSmarts && (smiles[position] == 44  || isNotList ) ) {
var mayBeAromatic=labelInfo.mayBeAromatic;
var mayBeAliphatic=labelInfo.mayBeAliphatic;
var start=position - labelInfo.labelLength;
while (start < endIndex){
if (!p$2.parseAtomLabelInBrackets$BA$I$I$com_actelion_research_chem_SmilesAtomParser_AtomLabelInfo.apply(this, [smiles, start, endIndex, labelInfo])) {
if (!isNotList) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Unexpected character in atom list:'" + (String.fromCharCode(smiles[start])) + "'. Position:" + start ]);
break;
}if (labelInfo.atomicNo == 1) {
if (!isNotList) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Hydrogen is not supported in positive atom lists:'" +  String.instantialize($I$(4).copyOfRange$BA$I$I(smiles, start, endIndex)) + "'. Position:" + start ]);
} else {
p$2.addAtomToList$I.apply(this, [labelInfo.atomicNo]);
mayBeAromatic=!!(mayBeAromatic|(labelInfo.mayBeAromatic));
mayBeAliphatic=!!(mayBeAliphatic|(labelInfo.mayBeAliphatic));
}start+=labelInfo.labelLength;
if (isNotList && smiles[start] != 59   && smiles[start] != 38  ) break;
if (!isNotList && smiles[start] != 44  ) break;
if (isNotList && smiles[start + 1] != 33  ) break;
++start;
if (smiles[start] == 33 ) ++start;
}
if (this.atomList != null  && this.atomList.size$() > 1 ) {
this.explicitHydrogens=-1;
if (!mayBeAliphatic) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(2)));
 else if (!mayBeAromatic) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(4)));
}position=start;
}}}var range=Clazz.new_($I$(5,1).c$$BA,[smiles]);
var skipCount=Clazz.array(Integer.TYPE, [1]);
var squareBracketOpen=true;
while (squareBracketOpen){
if (smiles[position] == 64 ) {
++position;
if (smiles[position] == 64 ) {
this.isClockwise=true;
++position;
}this.parityFound=true;
continue;
}if (smiles[position] == 58 ) {
++position;
while (Character.isDigit$I(smiles[position])){
this.mapNo=10 * this.mapNo + smiles[position] - 48;
++position;
}
continue;
}if (smiles[position] == 91 ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: nested square brackets found. Position:" + position]);
if (smiles[position] == 93 ) {
++position;
squareBracketOpen=false;
continue;
}this.charge=p$2.parseCharge$BA$I$IA.apply(this, [smiles, position, skipCount]);
if (skipCount[0] != 0) {
position+=skipCount[0];
if (this.charge == 0) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(167772160)));
continue;
}var isNot=(smiles[position] == 33 );
if (isNot) ++position;
if (smiles[position] == 72 ) {
++position;
position+=range.parse$I$I$I(position, 1, 1);
var flags=0;
if (range.min <= 0 && range.max >= 0 ) (flags=Long.$or(flags,(128)));
if (range.min <= 1 && range.max >= 1 ) (flags=Long.$or(flags,(256)));
if (range.min <= 2 && range.max >= 2 ) (flags=Long.$or(flags,(512)));
if (range.min <= 3 && range.max >= 3 ) (flags=Long.$or(flags,(1024)));
if (isNot) {
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
this.explicitHydrogens=-1;
} else {
if (range.isSingle$()) {
this.explicitHydrogens=range.min;
} else {
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,((Long.$and(1920,(Long.$not(flags)))))));
this.explicitHydrogens=-1;
}}continue;
}if (smiles[position] == 68  || smiles[position] == 100  ) {
++position;
position+=range.parse$I$I$I(position, 1, 1);
var flags=0;
if (range.min <= 0 && range.max >= 0 ) (flags=Long.$or(flags,(131072)));
if (range.min <= 1 && range.max >= 1 ) (flags=Long.$or(flags,(262144)));
if (range.min <= 2 && range.max >= 2 ) (flags=Long.$or(flags,(524288)));
if (range.min <= 3 && range.max >= 3 ) (flags=Long.$or(flags,(1048576)));
if (range.min <= 4 && range.max >= 4 ) (flags=Long.$or(flags,(2097152)));
if (Long.$ne(flags,0 )) {
if (isNot) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
 else if (Long.$ne((Long.$and(this.atomQueryFeatures,4063232)),0 )) (this.atomQueryFeatures=Long.$and(this.atomQueryFeatures,((Long.$not(flags)))));
 else {
flags=Long.$xor(flags,4063232);
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
}}continue;
}if (smiles[position] == 122  && this.mAllowCactvs ) {
++position;
position+=range.parse$I$I$I(position, 1, 4);
var flags=0;
if (range.min <= 0 && range.max >= 0 ) (flags=Long.$or(flags,(549755813888)));
if (range.min <= 1 && range.max >= 1 ) (flags=Long.$or(flags,(1099511627776)));
if (range.min <= 2 && range.max >= 2 ) (flags=Long.$or(flags,(2199023255552)));
if (range.min <= 3 && range.max >= 3 ) (flags=Long.$or(flags,(4398046511104)));
if (range.min <= 4 && range.max >= 4 ) (flags=Long.$or(flags,(8796093022208)));
if (Long.$ne(flags,0 )) {
if (isNot) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
 else if (Long.$ne((Long.$and(this.atomQueryFeatures,17042430230528)),0 )) (this.atomQueryFeatures=Long.$and(this.atomQueryFeatures,((Long.$not(flags)))));
 else {
flags=Long.$xor(flags,17042430230528);
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
}}continue;
}if (smiles[position] == 88 ) {
++position;
position+=range.parse$I$I$I(position, 1, 1);
var valences=$I$(6).cAtomValence[this.atomicNo];
if (valences == null ) continue;
var valence=valences[0];
var localCharge=p$2.parseCharge$BA$I$IA.apply(this, [smiles, position, skipCount]);
if (skipCount[0] != 0) {
if ($I$(6).isAtomicNoElectronegative$I(this.atomicNo)) valence+=localCharge;
 else if (this.atomicNo == 6) valence-=Math.abs(localCharge);
 else valence-=localCharge;
}var flags=0;
if (valence - range.min <= 0 && valence - range.max >= 0 ) (flags=Long.$or(flags,(16384)));
if (valence - range.min <= 1 && valence - range.max >= 1 ) (flags=Long.$or(flags,(32768)));
if (valence - range.min <= 2 && valence - range.max >= 2 ) (flags=Long.$or(flags,(65536)));
if (Long.$ne(flags,0 )) {
if (isNot) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
 else if (Long.$ne((Long.$and(this.atomQueryFeatures,114688)),0 )) (this.atomQueryFeatures=Long.$and(this.atomQueryFeatures,((Long.$not(flags)))));
 else {
flags=Long.$xor(flags,114688);
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
}}continue;
}if (smiles[position] == 65  || smiles[position] == 97  ) {
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,((!!(isNot ^ smiles[position] == 65 )) ? 4 : 2)));
++position;
continue;
}if (smiles[position] == 82 ) {
++position;
position+=range.parse$I$I$I(position, 1, 3);
var flags=0;
if (range.min <= 0 && range.max >= 0 ) (flags=Long.$or(flags,(8)));
if (range.min <= 1 && range.max >= 1 ) (flags=Long.$or(flags,(16)));
if (range.min <= 2 && range.max >= 2 ) (flags=Long.$or(flags,(32)));
if (range.min <= 3 && range.max >= 3 ) (flags=Long.$or(flags,(64)));
if (range.max > 3) this.mParentParser.smartsWarning$S((isNot ? "!R" : "R") + range.max);
if (Long.$ne(flags,0 )) {
if (isNot) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
 else if (Long.$ne((Long.$and(this.atomQueryFeatures,120)),0 )) (this.atomQueryFeatures=Long.$and(this.atomQueryFeatures,((Long.$not(flags)))));
 else {
flags=Long.$xor(flags,120);
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(flags)));
}}continue;
}if (smiles[position] == 114 ) {
++position;
position+=range.parse$I$I$I(position, 1, 1);
if (range.isDefault) {
if (isNot) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(384)));
 else (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(8)));
continue;
}var ringSize=range.min;
if (range.isRange$()) this.mParentParser.smartsWarning$S((isNot ? "!r" : "r") + range.toString());
if (!isNot && ringSize >= 3  && ringSize <= 7 ) (this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,((ringSize << 22))));
 else if (!range.isRange$()) this.mParentParser.smartsWarning$S((isNot ? "!r" : "r") + ringSize);
continue;
}if (smiles[position] == 118 ) {
++position;
position+=range.parse$I$I$I(position, 1, 1);
var valence=range.min;
if (range.isRange$()) this.mParentParser.smartsWarning$S((isNot ? "!v" : "v") + range.toString());
if (!isNot && valence <= 14 ) this.abnormalValence=valence;
 else if (!range.isRange$()) this.mParentParser.smartsWarning$S((isNot ? "!v" : "v") + valence);
continue;
}if (smiles[position] == 94 ) {
++position;
var hybridization=smiles[position++] - 48;
if (hybridization < 1 || hybridization > 3 ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Unsupported hybridization. Position:" + position]);
var piElectrons=(hybridization == 1) ? 65536 : (hybridization == 2) ? 32768 : 16384;
if (!isNot) piElectrons=Long.$and(114688,(Long.$not(piElectrons)));
(this.atomQueryFeatures=Long.$or(this.atomQueryFeatures,(piElectrons)));
continue;
}if (smiles[position] == 36 ) {
if (!isNot) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: non-negated recursive SMARTS relating to preceding atom are not supported yet. Position:" + position]);
if (this.excludeGroupList == null ) this.excludeGroupList=Clazz.new_($I$(2,1));
position+=p$2.parseRecursiveGroup$BA$I$java_util_ArrayList.apply(this, [smiles, position, this.excludeGroupList]);
continue;
}if (allowSmarts && (smiles[position] == 59  || smiles[position] == 38  ) ) {
this.smartsFeatureFound=true;
++position;
continue;
}if (allowSmarts && smiles[position] == 44   && p$2.isRepeatedAllowedORFeature$BA$I$IA.apply(this, [smiles, position, skipCount]) ) {
this.smartsFeatureFound=true;
position+=skipCount[0] + 1;
continue;
}if (allowSmarts && smiles[position] == 44   && (this.mMode & 128) != 0 ) {
this.smartsFeatureFound=true;
position+=1;
break;
}if (smiles[position] == 44 ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: alternative atom definitions not supported. (Tip: enumerate SMARTS): '" + String.fromCharCode(smiles[position]) + "', position:" + position ]);
throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: unexpected character inside brackets: '" + String.fromCharCode(smiles[position]) + "', position:" + position ]);
}
return position;
});

Clazz.newMeth(C$, 'parseAtomLabelInBrackets$BA$I$I$com_actelion_research_chem_SmilesAtomParser_AtomLabelInfo',  function (smiles, position, endIndex, info) {
info.mayBeAromatic=true;
info.mayBeAliphatic=true;
if (smiles[position] == 35 ) {
++position;
this.smartsFeatureFound=true;
info.atomicNo=0;
info.labelLength=1;
while (position < endIndex && Character.isDigit$I(smiles[position]) ){
info.atomicNo=10 * info.atomicNo + smiles[position] - 48;
++info.labelLength;
++position;
}
if (info.atomicNo == 0 || info.atomicNo >= $I$(6).cAtomLabel.length ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Atomic number out of range. position:" + (position - 1)]);
return true;
}if (smiles[position] >= 65  && smiles[position] <= 90  ) {
info.labelLength=(smiles[position + 1] >= 97  && smiles[position + 1] <= 122  ) ? 2 : 1;
info.atomicNo=$I$(6,"getAtomicNoFromLabel$S",[ String.instantialize(smiles, position, info.labelLength, $I$(7).UTF_8)]);
if (info.labelLength == 2 && info.atomicNo == 0 ) {
info.labelLength=1;
info.atomicNo=$I$(6,"getAtomicNoFromLabel$S",[ String.instantialize(smiles, position, info.labelLength, $I$(7).UTF_8)]);
}info.mayBeAromatic=false;
if (info.atomicNo == 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Unknown atom label. position:" + (position - 1)]);
return true;
}if ((smiles[position] == 65  && smiles[position + 1] == 115  ) || (smiles[position] == 83  && smiles[position + 1] == 101  ) ) {
info.labelLength=2;
info.atomicNo=$I$(6,"getAtomicNoFromLabel$S",[ String.instantialize(smiles, position, info.labelLength, $I$(7).UTF_8)]);
info.mayBeAliphatic=false;
return true;
}if (smiles[position] == 99  || smiles[position] == 110   || smiles[position] == 111   || smiles[position] == 112   || smiles[position] == 115  ) {
info.labelLength=1;
info.atomicNo=$I$(6,"getAtomicNoFromLabel$S",[ String.instantialize(smiles, position, info.labelLength, $I$(7).UTF_8)]);
info.mayBeAliphatic=false;
return true;
}return false;
}, p$2);

Clazz.newMeth(C$, 'parseCharge$BA$I$IA',  function (smiles, position, characterCount) {
characterCount[0]=0;
if (smiles[position] == 43  || smiles[position] == 45  ) {
var symbol=smiles[position];
var charge=1;
++characterCount[0];
while (smiles[position + characterCount[0]] == symbol){
++charge;
++characterCount[0];
}
if (charge == 1 && Character.isDigit$I(smiles[position + 1]) ) {
charge=smiles[position + 1] - 48;
++characterCount[0];
}return symbol == 43  ? charge : -charge;
}return 0;
}, p$2);

Clazz.newMeth(C$, 'addParsedAtom$com_actelion_research_chem_StereoMolecule$C$I',  function (mol, theChar, position) {
var atom=mol.addAtom$I(this.atomicNo);
mol.setAtomCharge$I$I(atom, this.charge);
mol.setAtomMapNo$I$I$Z(atom, this.mapNo, false);
mol.setAtomAbnormalValence$I$I(atom, this.abnormalValence);
if (Long.$ne(this.atomQueryFeatures,0 )) {
if (Long.$ne((Long.$and(this.atomQueryFeatures,2)),0 )) {
(this.atomQueryFeatures=Long.$and(this.atomQueryFeatures,((Long.$not(2)))));
mol.setAtomMarker$I$Z(atom, true);
} else {
mol.setAtomMarker$I$Z(atom, false);
}mol.setAtomQueryFeature$I$J$Z(atom, this.atomQueryFeatures, true);
}if (this.atomList != null ) {
var list=Clazz.array(Integer.TYPE, [this.atomList.size$()]);
for (var i=0; i < this.atomList.size$(); i++) list[i]=(this.atomList.get$I(i)).$c();

mol.setAtomList$I$IA(atom, list);
this.atomList.removeAll$();
} else {
if (Character.isLowerCase$C(theChar)) {
if (this.atomicNo != 5 && this.atomicNo != 6  && this.atomicNo != 7  && this.atomicNo != 8  && this.atomicNo != 15  && this.atomicNo != 16  && this.atomicNo != 33  && this.atomicNo != 34 ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: atomicNo " + this.atomicNo + " must not be aromatic. Position:" + (position - 1) ]);
mol.setAtomMarker$I$Z(atom, true);
} else {
mol.setAtomMarker$I$Z(atom, false);
}}if (this.excludeGroupList != null ) {
for (var group, $group = this.excludeGroupList.iterator$(); $group.hasNext$()&&((group=($group.next$())),1);) {
group.setAtomicNo$I$I(0, 0);
mol.addSubstituent$com_actelion_research_chem_Molecule$I(group, atom);
}
}if (this.explicitHydrogens != -1 && this.atomicNo != 1 ) {
var bytes=Clazz.array(Byte.TYPE, [1]);
bytes[0]=(this.explicitHydrogens|0);
mol.setAtomCustomLabel$I$BA(atom, bytes);
}return atom;
});

Clazz.newMeth(C$, 'parseRecursiveGroup$BA$I$java_util_ArrayList',  function (smiles, dollarIndex, groupList) {
if (smiles[dollarIndex + 1] != 40 ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: '$' for recursive SMARTS must be followed by '('. position:" + dollarIndex]);
var openBrackets=1;
var endIndex=dollarIndex + 2;
while (endIndex < smiles.length && openBrackets > 0 ){
if (smiles[endIndex] == 40 ) ++openBrackets;
 else if (smiles[endIndex] == 41 ) --openBrackets;
++endIndex;
}
if (openBrackets > 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Missing closing ')' for recursive SMARTS. '('-position:" + (dollarIndex + 1)]);
var group=Clazz.new_($I$(8,1).c$$I$I,[16, 16]);
group.setFragment$Z(true);
var parser=Clazz.new_($I$(9,1).c$$I,[this.mMode]);
parser.setEnumerationPositionList$java_util_ArrayList(this.mParentParser.getEnumerationPositionList$());
parser.parse$com_actelion_research_chem_StereoMolecule$BA$I$I(group, smiles, dollarIndex + 2, endIndex - 1);
groupList.add$O(group);
if (smiles[dollarIndex - 1] == 33 ) for (var atom=0; atom < group.getAllAtoms$(); atom++) group.setAtomQueryFeature$I$J$Z(atom, 536870912, true);

return endIndex - dollarIndex;
}, p$2);

Clazz.newMeth(C$, 'isRepeatedAllowedORFeature$BA$I$IA',  function (smiles, commaPosition, skipCount) {
if (commaPosition < 3) return false;
var index1=commaPosition - 1;
if (smiles[index1] == 43  || smiles[index1] == 45  ) --index1;
if (!Character.isDigit$I(smiles[index1])) return false;
--index1;
if (smiles[index1] != 68  && smiles[index1] != 82   && smiles[index1] != 88   && smiles[index1] != 122  ) return false;
skipCount[0]=0;
while (index1 > 0 && Character.isLetter$I(smiles[index1 - 1]) ){
--index1;
++skipCount[0];
}
var index2=commaPosition + 1;
while (Character.isLetter$I(smiles[index1])){
if (smiles.length <= index2 || smiles[index1] != smiles[index2] ) return false;
++index1;
++index2;
}
return true;
}, p$2);

Clazz.newMeth(C$, 'atomQueryFeaturesFound$',  function () {
return Long.$ne(this.atomQueryFeatures,0 ) || this.atomList != null  ;
});

Clazz.newMeth(C$, 'getExcludeGroupList$',  function () {
return this.excludeGroupList;
});

Clazz.newMeth(C$, 'getRecursiveGroup$',  function () {
return this.recursiveSmartsList == null  ? null : this.recursiveSmartsList.get$I(0);
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.SmilesAtomParser, "AtomLabelInfo", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mayBeAromatic','mayBeAliphatic'],'I',['atomicNo','labelLength']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.atomicNo=-1;
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.SmilesAtomParser, "SmilesRange", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isDefault'],'I',['pos','min','max'],'O',['smiles','byte[]']]]

Clazz.newMeth(C$, 'c$$BA',  function (smiles) {
;C$.$init$.apply(this);
this.smiles=smiles;
}, 1);

Clazz.newMeth(C$, 'parse$I$I$I',  function (position, defaultMin, defaultMax) {
this.isDefault=false;
this.pos=position;
if (Character.isDigit$I(this.smiles[position])) {
var val=p$1.parseInt.apply(this, []);
this.min=this.max=val;
var firstLetter=position - 1;
while (firstLetter > 1 && Character.isLetterOrDigit$I(this.smiles[firstLetter - 1]) )--firstLetter;

while (this.smiles[this.pos] == 44 ){
var lettersMatch=true;
var letterCount=position - firstLetter;
for (var i=0; i < letterCount; i++) {
if (this.smiles[firstLetter + i] != this.smiles[this.pos + 1 + i ]) {
lettersMatch=false;
break;
}}
if (!lettersMatch) break;
this.pos+=1 + letterCount;
val=p$1.parseInt.apply(this, []);
if (this.min > val) this.min=val;
 else if (this.max < val) this.max=val;
}
return this.pos - position;
}if (this.smiles[position] == 123  && Character.isDigit$I(this.smiles[position + 1]) ) {
++this.pos;
this.min=p$1.parseInt.apply(this, []);
if (this.smiles[this.pos++] != 45 ) return 0;
if (!Character.isDigit$I(this.smiles[this.pos])) return 0;
this.max=p$1.parseInt.apply(this, []);
if (this.smiles[this.pos++] != 125 ) return 0;
return this.pos - position;
}this.min=defaultMin;
this.max=defaultMax;
this.isDefault=true;
return 0;
});

Clazz.newMeth(C$, 'isSingle$',  function () {
return this.max == this.min;
});

Clazz.newMeth(C$, 'isRange$',  function () {
return this.max > this.min;
});

Clazz.newMeth(C$, 'toString',  function () {
return "{" + this.min + "-" + this.max + "}" ;
});

Clazz.newMeth(C$, 'parseInt',  function () {
var num=this.smiles[this.pos++] - 48;
if (Character.isDigit$I(this.smiles[this.pos])) num=10 * num + (this.smiles[this.pos++] - 48);
return num;
}, p$1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
