(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.prediction.CLogPPredictor','com.actelion.research.chem.prediction.SolubilityPredictor','com.actelion.research.chem.prediction.PolarSurfaceAreaPredictor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PropertyCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMolecule','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mMolecule=mol;
mol.normalizeAmbiguousBonds$();
}, 1);

Clazz.newMeth(C$, 'getAcceptorCount$',  function () {
var count=0;
for (var atom=0; atom < this.mMolecule.getAllAtoms$(); atom++) if (this.mMolecule.getAtomicNo$I(atom) == 7 || this.mMolecule.getAtomicNo$I(atom) == 8 ) ++count;

return count;
});

Clazz.newMeth(C$, 'getDonorCount$',  function () {
var count=0;
for (var atom=0; atom < this.mMolecule.getAllAtoms$(); atom++) if ((this.mMolecule.getAtomicNo$I(atom) == 7 || this.mMolecule.getAtomicNo$I(atom) == 8 ) && this.mMolecule.getAllHydrogens$I(atom) > 0 ) ++count;

return count;
});

Clazz.newMeth(C$, 'getLogP$',  function () {
try {
return Clazz.new_($I$(1,1)).assessCLogP$com_actelion_research_chem_StereoMolecule(this.mMolecule);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return -999.0;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getLogPDetail$',  function () {
return Clazz.new_($I$(1,1)).getDetail$com_actelion_research_chem_StereoMolecule(this.mMolecule);
});

Clazz.newMeth(C$, 'getLogS$',  function () {
return Clazz.new_($I$(2,1)).assessSolubility$com_actelion_research_chem_StereoMolecule(this.mMolecule);
});

Clazz.newMeth(C$, 'getLogSDetail$',  function () {
return Clazz.new_($I$(2,1)).getDetail$com_actelion_research_chem_StereoMolecule(this.mMolecule);
});

Clazz.newMeth(C$, 'getPolarSurfaceArea$',  function () {
return Clazz.new_($I$(3,1)).assessPSA$com_actelion_research_chem_StereoMolecule(this.mMolecule);
});

Clazz.newMeth(C$, 'getPolarSurfaceAreaDetail$',  function () {
return Clazz.new_($I$(3,1)).getDetail$com_actelion_research_chem_StereoMolecule(this.mMolecule);
});

Clazz.newMeth(C$, 'getRotatableBondCount$',  function () {
return this.mMolecule.getRotatableBondCount$();
});

Clazz.newMeth(C$, 'getStereoCenterCount$',  function () {
return this.mMolecule.getStereoCenterCount$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:48 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
