(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),p$1={},I$=[[0,'java.util.Hashtable','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.IsomericSmilesCreator','com.actelion.research.chem.Molecule','java.util.HashMap','java.util.Arrays','com.actelion.research.chem.coords.CoordinateInventor','io.github.dan2097.jnainchi.InchiAPI','java.util.Locale',['io.github.dan2097.jnainchi.InchiOptions','.InchiOptionsBuilder'],'java.util.StringTokenizer','io.github.dan2097.jnainchi.InchiFlag','io.github.dan2097.jnainchi.InchiInput','io.github.dan2097.jnainchi.InchiAtom','java.util.BitSet','io.github.dan2097.jnainchi.InchiBond','io.github.dan2097.jnainchi.InchiBondStereo','io.github.dan2097.jnainchi.InchiBondType','com.actelion.research.chem.inchi.InchiUtils','io.github.dan2097.jnainchi.inchi.InchiLibrary','com.sun.jna.Native','java.io.FileInputStream','io.github.dan2097.jnainchi.JnaInchi']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIOCL");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.map=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['getInchiModel','isInputInChI','getKey','isFixedH','getAuxInfo'],'S',['inchi'],'O',['inchiInput','io.github.dan2097.jnainchi.InchiInput','mol','com.actelion.research.chem.StereoMolecule','map','java.util.Map','thisAtom','io.github.dan2097.jnainchi.InchiAtom','thisBond','io.github.dan2097.jnainchi.InchiBond','thisStereo','io.github.dan2097.jnainchi.InchiStereo']]
,['Z',['isJS','useIXA'],'I',['ntests'],'S',['inchiVersionInternal']]]

Clazz.newMeth(C$, 'init$Runnable',  function (r) {
if (C$.isJS) C$.useIXA=true;
C$.getInstance$().initAndRun$Runnable(r);
}, 1);

Clazz.newMeth(C$, 'getInChI$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInstance$(), [mol, null, options, false]);
}, 1);

Clazz.newMeth(C$, 'getInChI$S$S',  function (molFileDataOrInChI, options) {
return p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInstance$(), [null, molFileDataOrInChI, options, false]);
}, 1);

Clazz.newMeth(C$, 'getInChIFromSmiles$S$S',  function (smiles, options) {
var mol=Clazz.new_($I$(2,1));
try {
Clazz.new_($I$(3,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, smiles);
return C$.getInChI$com_actelion_research_chem_StereoMolecule$S(mol, options);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getInChIKey$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInstance$(), [mol, null, options, true]);
}, 1);

Clazz.newMeth(C$, 'getInChIKey$S$S',  function (molFileDataOrInChI, options) {
return p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInstance$(), [null, molFileDataOrInChI, options, true]);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInChI$S$S',  function (inchi, moreOptions) {
return C$.getInstance$().getInchiInputFromInChIPvt$S$S(inchi, moreOptions);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromOCLMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
return C$.getInstance$().getInchiInputFromMolPvt$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'getOCLMoleculeFromInchiInput$io_github_dan2097_jnainchi_InchiInput$com_actelion_research_chem_StereoMolecule',  function (input, mol) {
C$.getInstance$().getMoleculeFromInchiInput$io_github_dan2097_jnainchi_InchiInput$com_actelion_research_chem_StereoMolecule(input, mol);
}, 1);

Clazz.newMeth(C$, 'getMoleculeFromInChIRaw$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
try {
p$1.getMoleculeFromInChIPvt$S$com_actelion_research_chem_StereoMolecule$S.apply(C$.getInstance$(), [inchi, mol, null]);
return true;
} catch (e) {
e.printStackTrace$();
return false;
}
}, 1);

Clazz.newMeth(C$, 'getSmilesFromInChI$S',  function (inchi) {
var mol=Clazz.new_($I$(2,1));
C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(inchi, mol);
return $I$(4).createSmiles$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'getInChIFromInChI$S$S',  function (inchi, options) {
var isReference=("reference".equals$O(options));
try {
var mol=Clazz.new_($I$(2,1));
C$.getMoleculeFromInChIOpt$S$com_actelion_research_chem_StereoMolecule$S(inchi, mol, null);
var inchiS=C$.getInChI$com_actelion_research_chem_StereoMolecule$S(mol, "standard");
if (inchiS == null  || inchiS.length$() == 0  || options == null   || options.trim$().length$() == 0 ) {
return inchiS;
}mol=Clazz.new_($I$(2,1));
C$.getMoleculeFromInChIOpt$S$com_actelion_research_chem_StereoMolecule$S(inchiS, mol, null);
inchi=C$.getInChI$com_actelion_research_chem_StereoMolecule$S(mol, isReference ? "fixedh" : options);
return (isReference && inchi.length$() < inchiS.length$()  ? inchiS : inchi);
} catch (e) {
e.printStackTrace$();
return null;
}
}, 1);

Clazz.newMeth(C$, 'getInChIModelJSON$S',  function (inchi) {
return p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInstance$(), [null, inchi, "model", false]);
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
return Clazz.new_(C$);
}, 1);

Clazz.newMeth(C$, 'getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z',  function (inputMol, molDataOrInChI, options, retKey) {
if ("version".equals$O(options) || "description".equals$O(options) ) {
return C$.getInChIVersion$Z("description".equals$O(options));
}System.out.println$S("test " + ++C$.ntests);
try {
if (inputMol == null  && (molDataOrInChI == null  || molDataOrInChI.length$() == 0 ) ) return null;
if (inputMol != null  && inputMol.getAllAtoms$() == 0 ) {
return "";
}options=p$1.setFieldsPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [inputMol, molDataOrInChI, options, retKey]);
if (options == null ) {
return null;
}if (this.mol != null ) molDataOrInChI=null;
if (this.inchi != null ) {
if (!this.getKey || this.inchi.length$() == 0 ) return this.inchi;
this.mol=null;
molDataOrInChI=this.inchi;
}var ret=this.getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S(this.mol, molDataOrInChI, options);
if (ret != null  && options.length$() == 0  && ret.startsWith$S("InChI=")  && !ret.startsWith$S("InChI=1S/") ) {
this.reportInchicError$S("inchi C inchifrom standard InChI without \'1S/\'! Fixing...");
ret="InChI=1S/" + ret.substring$I(8);
}return ret;
} catch (e) {
{
e = (e.getMessage$ ? e.getMessage$() : e);
}
System.err.println$S("InChIOCL exception: " + e);
return null;
}
}, p$1);

Clazz.newMeth(C$, 'reportInchicError$S',  function (msg) {
System.out.flush$();
System.err.println$S(msg);
System.err.flush$();
});

Clazz.newMeth(C$, 'setFieldsPvt$com_actelion_research_chem_StereoMolecule$S$S$Z',  function (mol, molDataOrInChI, options, getKey) {
if (options == null ) options="";
var lc=options.toLowerCase$().trim$();
var getInchiModel=(lc.indexOf$S("model") == 0);
var optionKey=(lc.indexOf$S("key") >= 0);
var getAuxInfo=(lc.indexOf$S("auxinfo") >= 0);
var inchi=this.inchi=null;
var isFixedH=(lc.indexOf$S("fixedh") >= 0);
var optionalFixedH=(lc.indexOf$S("fixedh?") >= 0);
if (lc.indexOf$S("fixedh") < 0) {
options=lc=lc.replace$CharSequence$CharSequence("standard", "");
}var inputIsInChI=(molDataOrInChI != null  && molDataOrInChI.startsWith$S("InChI=") );
if (!inputIsInChI) {
options=lc;
if (optionKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "");
options=options.replace$CharSequence$CharSequence("key", "");
}}if (getInchiModel) {
optionKey=isFixedH=optionalFixedH=false;
options="";
}if (optionalFixedH) {
inchi=p$1.getInChIOptionallyFixedH$com_actelion_research_chem_StereoMolecule$S$Z$S.apply(this, [mol, molDataOrInChI, inputIsInChI, lc]);
mol=null;
molDataOrInChI=null;
if (inchi == null ) options=null;
} else if (inputIsInChI && isFixedH ) {
mol=Clazz.new_($I$(2,1));
C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(molDataOrInChI, mol);
inchi=null;
inputIsInChI=false;
}this.getInchiModel=getInchiModel;
this.isInputInChI=(inputIsInChI || inchi != null  );
this.inchi=inchi;
this.isFixedH=isFixedH;
this.getKey=optionKey || getKey ;
this.mol=mol;
this.getAuxInfo=getAuxInfo;
return (options == null  ? null : options.trim$());
}, p$1);

Clazz.newMeth(C$, 'getInChIOptionallyFixedH$com_actelion_research_chem_StereoMolecule$S$Z$S',  function (mol, molDataOrInChI, inputInChI, options) {
if (mol == null ) {
if (inputInChI) {
var inchi=molDataOrInChI;
molDataOrInChI=null;
mol=Clazz.new_($I$(2,1));
C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(inchi, mol);
}}var fxd=p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molDataOrInChI, options.replace$C$C("?", " "), false]);
if (fxd == null ) {
return null;
}options=options.replace$CharSequence$CharSequence("fixedh?", "");
var std=p$1.getInChIPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molDataOrInChI, options, false]);
return (fxd.indexOf$S("/f") < 0 ? std : fxd);
}, p$1);

Clazz.newMeth(C$, 'getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
try {
C$.getMoleculeFromInChIOpt$S$com_actelion_research_chem_StereoMolecule$S(inchi, mol, "fixamides");
return true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getMoleculeFromInChIOpt$S$com_actelion_research_chem_StereoMolecule$S',  function (inchi, mol, moreOptions) {
try {
p$1.getMoleculeFromInChIPvt$S$com_actelion_research_chem_StereoMolecule$S.apply(C$.getInstance$(), [inchi, mol, moreOptions]);
return true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getMoleculeFromInChIPvt$S$com_actelion_research_chem_StereoMolecule$S',  function (inchi, mol, moreOptions) {
this.getMoleculeFromInchiInput$io_github_dan2097_jnainchi_InchiInput$com_actelion_research_chem_StereoMolecule(C$.getInchiInputFromInChI$S$S(inchi, moreOptions), mol);
}, p$1);

Clazz.newMeth(C$, 'getMoleculeFromInchiInput$io_github_dan2097_jnainchi_InchiInput$com_actelion_research_chem_StereoMolecule',  function (input, mol) {
this.inchiInput=input;
this.initializeInchiModel$();
var nAtoms=this.getNumAtoms$();
var nBonds=this.getNumBonds$();
var nStereo=this.getNumStereo0D$();
for (var i=0; i < nAtoms; i++) {
this.setAtom$I(i);
var sym=this.getElementType$();
var atom=mol.addAtom$I($I$(5).getAtomicNoFromLabel$S(sym));
mol.setAtomCharge$I$I(atom, this.getCharge$());
var mass=this.getIsotopicMass$();
mol.setAtomMass$I$I(atom, mass);
}
var doubleBonds=Clazz.new_($I$(6,1));
for (var i=0; i < nBonds; i++) {
this.setBond$I(i);
var i1=this.getIndexOriginAtom$();
var i2=this.getIndexTargetAtom$();
var bt=C$.getOCLSimpleBondType$S(this.getInchiBondType$());
var bond=mol.addBond$I$I$I(i1, i2, bt);
switch (bt) {
case 1:
break;
case 2:
doubleBonds.put$O$O(Integer.valueOf$I(C$.getBondKey$I$I(i1, i2)), Integer.valueOf$I(bond));
break;
}
}
for (var i=0; i < nStereo; i++) {
this.setStereo0D$I(i);
var centerAtom=this.getCenterAtom$();
var neighbors=this.getNeighbors$();
if (neighbors.length != 4) continue;
var p=-1;
switch (this.getStereoType$()) {
case "TETRAHEDRAL":
p=C$.getOCLAtomParity$S$Z(this.getParity$(), C$.isOrdered$IA(neighbors));
mol.setAtomParity$I$I$Z(centerAtom, p, false);
break;
case "DOUBLEBOND":
var ib=C$.findDoubleBond$java_util_Map$IA(doubleBonds, neighbors);
if (ib < 0) {
System.err.println$S("InChIJNI cannot find double bond for atoms " + $I$(7).toString$IA(neighbors));
continue;
}p=C$.getOCLBondParity$S$Z(this.getParity$(), (neighbors[0] < neighbors[3]));
mol.setBondParity$I$I$Z(ib, p, false);
break;
case "ALLENE":
p=C$.getOCLBondParity$S$Z(this.getParity$(), (neighbors[0] > neighbors[3]));
mol.setAtomParity$I$I$Z(centerAtom, p, false);
break;
case "NONE":
continue;
}
}
mol.setParitiesValid$I(0);
mol.setParitiesPreset$Z(true);
Clazz.new_($I$(8,1).c$$I,[64]);
mol.ensureHelperArrays$I(31);
});

Clazz.newMeth(C$, 'getBondKey$I$I',  function (i1, i2) {
return (Math.min(i1, i2) << 16) + Math.max(i1, i2);
}, 1);

Clazz.newMeth(C$, 'findDoubleBond$java_util_Map$IA',  function (doubleBonds, neighbors) {
var ib=doubleBonds.get$O(Integer.valueOf$I(C$.getBondKey$I$I(neighbors[1], neighbors[2])));
return (ib == null  ? -1 : ib.intValue$());
}, 1);

Clazz.newMeth(C$, 'getOCLBondParity$S$Z',  function (parity, isReversed) {
switch (parity) {
case "ODD":
return (isReversed ? 2 : 1);
case "EVEN":
return (isReversed ? 1 : 2);
case "UNKNOWN":
return 3;
case "NONE":
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'isOrdered$IA',  function (list) {
var ok=true;
for (var i=0; i < list.length - 1; i++) {
var l1=list[i];
for (var j=i + 1; j < list.length; j++) {
var l2=list[j];
if (l1 > l2) {
list[j]=l1;
l1=list[i]=l2;
ok=!ok;
}}
}
return ok;
}, 1);

Clazz.newMeth(C$, 'getOCLAtomParity$S$Z',  function (parity, isOrdered) {
var isOdd=false;
switch (parity) {
case "ODD":
isOdd=true;
case "EVEN":
return (!!(isOdd ^ isOrdered) ? 1 : 2);
case "UNKNOWN":
return 3;
case "NONE":
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'getOCLSimpleBondType$S',  function (type) {
switch (type) {
case "NONE":
return 0;
case "ALTERN":
return 8;
case "DOUBLE":
return 2;
case "TRIPLE":
return 4;
case "SINGLE":
default:
return 1;
}
}, 1);

Clazz.newMeth(C$, 'initAndRun$Runnable',  function (r) {
$I$(9).initAndRun$Runnable(r);
});

Clazz.newMeth(C$, 'getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S',  function (mol, molFileDataOrInChI, options) {
try {
var inchi=null;
var moreOptions=(options.toLowerCase$java_util_Locale($I$(10).ROOT).indexOf$S("fixamides") >= 0 ? "fixamides" : null);
var ops=C$.getOptions$S(options);
var out=null;
if (this.isInputInChI) {
if (this.getKey) {
inchi=molFileDataOrInChI;
} else {
out=p$1.inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions.apply(this, [molFileDataOrInChI, ops]);
}} else if (mol == null ) {
out=p$1.molToInchi$S$io_github_dan2097_jnainchi_InchiOptions.apply(this, [molFileDataOrInChI, ops]);
} else {
out=p$1.toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions.apply(this, [C$.getInchiInputFromOCLMolecule$com_actelion_research_chem_StereoMolecule(mol), C$.getOptions$S(options)]);
}if (out != null ) {
if (this.getAuxInfo) return out.getAuxInfo$();
var msg=out.getMessage$();
if (msg != null ) System.err.println$S(msg);
inchi=out.getInchi$();
}if (this.getInchiModel) {
return $I$(9,"getJSONFromInchiInput$io_github_dan2097_jnainchi_InchiInput",[C$.getInchiInputFromInChI$S$S(inchi, moreOptions)]);
}return (this.getKey ? p$1.inchiToInchiKey$S.apply(this, [inchi]).getInchiKey$() : inchi);
} catch (e) {
e.printStackTrace$();
return "";
}
});

Clazz.newMeth(C$, 'getOptions$S',  function (options) {
var builder=Clazz.new_($I$(11,1));
var t=Clazz.new_($I$(12,1).c$$S,[options]);
while (t.hasMoreElements$()){
var o=t.nextToken$();
var f=$I$(13).getFlagFromName$S(o);
if (f == null ) {
switch (o) {
case "auxinfo":
break;
default:
System.err.println$S("InChIJNA InChI option " + o + " not recognized -- ignored" );
break;
}
} else {
builder.withFlag$io_github_dan2097_jnainchi_InchiFlagA(Clazz.array($I$(13), -1, [f]));
}}
return builder.build$();
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromMolPvt$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(1);
var struc=Clazz.new_($I$(14,1));
var nAtoms=mol.getAllAtoms$();
var atoms=Clazz.array($I$(15), [nAtoms]);
var bsCarbonAtoms=Clazz.new_($I$(16,1));
for (var i=0; i < nAtoms; i++) {
var elem=mol.getAtomicNo$I(i);
var sym=$I$(5).cAtomLabel[elem];
var iso=mol.getAtomMass$I(i);
if (elem == 1) {
sym="H";
} else if (elem == 6) bsCarbonAtoms.set$I(i);
var a=atoms[i]=Clazz.new_([sym, mol.getAtomX$I(i), -mol.getAtomY$I(i), mol.getAtomZ$I(i)],$I$(15,1).c$$S$D$D$D);
a.setCharge$I(mol.getAtomCharge$I(i));
if (iso > 0) a.setIsotopicMass$I(iso);
a.setImplicitHydrogen$I(mol.getImplicitHydrogens$I(i));
}
var nBonds=mol.getAllBonds$();
var bsDoubleBondAtoms=Clazz.new_($I$(16,1));
var bsStereoAtoms=Clazz.new_($I$(16,1));
var bsStereoBonds=Clazz.new_($I$(16,1));
var bonds=Clazz.array($I$(17), [nBonds]);
for (var i=0; i < nBonds; i++) {
var oclOrder=mol.getBondTypeSimple$I(i);
var order=C$.getInChIOrder$I(oclOrder);
if (order != null ) {
var atom1=mol.getBondAtom$I$I(0, i);
var atom2=mol.getBondAtom$I$I(1, i);
var oclType=mol.getBondType$I(i);
var oclParity=mol.getBondParity$I(i);
var stereo=C$.getInChIStereo$I$I$I(oclOrder, oclType, oclParity);
switch (stereo) {
case $I$(18).NONE:
if (order === $I$(19).DOUBLE ) {
bsDoubleBondAtoms.set$I(atom1);
bsDoubleBondAtoms.set$I(atom2);
}break;
case $I$(18).SINGLE_1DOWN:
case $I$(18).SINGLE_1UP:
if (mol.getAllConnAtoms$I(atom1) == 3) {
bsStereoBonds.set$I(i);
bsStereoAtoms.set$I$Z(atom1, !bsStereoAtoms.get$I(atom1));
}break;
default:
break;
}
bonds[i]=Clazz.new_($I$(17,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo,[atoms[atom1], atoms[atom2], order, stereo]);
}}
bsStereoAtoms.and$java_util_BitSet(bsDoubleBondAtoms);
bsStereoAtoms.and$java_util_BitSet(bsCarbonAtoms);
if (!bsStereoAtoms.isEmpty$()) {
C$.checkAllenes$com_actelion_research_chem_StereoMolecule$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiBondA$java_util_BitSet$java_util_BitSet(mol, atoms, bonds, bsStereoAtoms, bsStereoBonds);
}for (var i=0; i < nAtoms; i++) {
struc.addAtom$io_github_dan2097_jnainchi_InchiAtom(atoms[i]);
}
for (var i=0; i < nBonds; i++) {
if (bonds[i] != null ) struc.addBond$io_github_dan2097_jnainchi_InchiBond(bonds[i]);
}
return struc;
});

Clazz.newMeth(C$, 'checkAllenes$com_actelion_research_chem_StereoMolecule$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiBondA$java_util_BitSet$java_util_BitSet',  function (mol, atoms, bonds, bsStereoAtoms, bsStereoBonds) {
for (var iatom=bsStereoAtoms.nextSetBit$I(0); iatom >= 0; iatom=bsStereoAtoms.nextSetBit$I(iatom + 1)) {
var ibondStereo=-1;
var ibondNone=-1;
var n=mol.getAllConnAtoms$I(iatom);
for (var i=0; i < n; i++) {
var ibond=mol.getConnBond$I$I(iatom, i);
if (mol.getConnBondOrder$I$I(iatom, i) == 1) {
if (bsStereoBonds.get$I(ibond)) ibondStereo=ibond;
 else ibondNone=ibond;
}}
if (ibondNone >= 0 && ibondStereo >= 0 ) {
var stereo=(bonds[ibondStereo].getStereo$() === $I$(18).SINGLE_1UP  ? $I$(18).SINGLE_1DOWN : $I$(18).SINGLE_1UP);
var iatom1=bonds[ibondNone].getStart$();
var iatom2=bonds[ibondNone].getEnd$();
var isAtom1=(iatom1 === atoms[iatom] );
bonds[ibondNone]=Clazz.new_([isAtom1 ? iatom1 : iatom2, isAtom1 ? iatom2 : iatom1, $I$(19).SINGLE, stereo],$I$(17,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo);
}}
}, 1);

Clazz.newMeth(C$, 'getInChIOrder$I',  function (oclOrder) {
switch (oclOrder) {
case 1:
return $I$(19).SINGLE;
case 2:
return $I$(19).DOUBLE;
case 4:
return $I$(19).TRIPLE;
case 8:
return $I$(19).ALTERN;
case 16:
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'getInChIStereo$I$I$I',  function (oclOrder, oclType, oclParity) {
if (oclOrder == 1) {
switch (oclType) {
case 129:
return $I$(18).SINGLE_1DOWN;
case 257:
return $I$(18).SINGLE_1UP;
default:
if (oclParity == 3) {
return (oclOrder == 2 ? $I$(18).DOUBLE_EITHER : $I$(18).SINGLE_1EITHER);
}}
}return $I$(18).NONE;
}, 1);

Clazz.newMeth(C$, 'initializeInchiModel$',  function () {
for (var i=this.getNumAtoms$(); --i >= 0; ) this.map.put$O$O(this.inchiInput.getAtom$I(i), Integer.valueOf$I(i));

});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
return this.inchiInput.getAtoms$().size$();
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
this.thisAtom=this.inchiInput.getAtom$I(i);
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return this.thisAtom.getElName$();
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.thisAtom.getX$();
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.thisAtom.getY$();
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.thisAtom.getZ$();
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.thisAtom.getCharge$();
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
return $I$(20,"getActualMass$S$I",[this.getElementType$(), this.thisAtom.getIsotopicMass$()]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return this.thisAtom.getImplicitHydrogen$();
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
return this.inchiInput.getBonds$().size$();
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
this.thisBond=this.inchiInput.getBond$I(i);
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return this.map.get$O(this.thisBond.getStart$()).intValue$();
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return this.map.get$O(this.thisBond.getEnd$()).intValue$();
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
var type=this.thisBond.getType$();
return type.name$();
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
return this.inchiInput.getStereos$().size$();
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
this.thisStereo=this.inchiInput.getStereos$().get$I(i);
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
var an=this.thisStereo.getAtoms$();
var n=an.length;
var a=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < n; i++) {
a[i]=this.map.get$O(an[i]).intValue$();
}
return a;
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
var ca=this.thisStereo.getCentralAtom$();
return (ca == null  ? -1 : this.map.get$O(ca).intValue$());
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return C$.uc$O(this.thisStereo.getType$());
});

Clazz.newMeth(C$, 'getParity$',  function () {
return C$.uc$O(this.thisStereo.getParity$());
});

Clazz.newMeth(C$, 'uc$O',  function (o) {
return o.toString().toUpperCase$java_util_Locale($I$(10).ROOT);
}, 1);

Clazz.newMeth(C$, 'getInChIVersion$Z',  function (fullDescription) {
if (C$.useIXA) return $I$(9).getInChIVersion$Z(fullDescription);
if (C$.inchiVersionInternal == null ) {
var f=$I$(21).JNA_NATIVE_LIB.getFile$();
C$.inchiVersionInternal=C$.extractInchiVersionInternal$java_io_File(f);
if (C$.inchiVersionInternal == null ) {
try {
f=$I$(22,"extractFromResourcePath$S",[$I$(21).JNA_NATIVE_LIB.getName$()]);
C$.inchiVersionInternal=C$.extractInchiVersionInternal$java_io_File(f);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}if (C$.inchiVersionInternal == null ) C$.inchiVersionInternal="unknown";
}return C$.inchiVersionInternal;
}, 1);

Clazz.newMeth(C$, 'extractInchiVersionInternal$java_io_File',  function (f) {
System.out.println$O(f);
var s=null;
try {
var fis=Clazz.new_($I$(23,1).c$$java_io_File,[f]);
try {
var b=Clazz.array(Byte.TYPE, [Long.$ival(f.length$())]);
fis.read$BA(b);
s= String.instantialize(b);
var pt=s.indexOf$S("InChI version");
if (pt < 0) {
s=null;
} else {
s=s.substring$I$I(pt, s.indexOf$I$I("\u0000", pt));
}fis.close$();
f.delete$();

}finally{/*res*/fis&&fis.close$&&fis.close$();}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return s;
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInChIPvt$S$S',  function (inchi, moreOptions) {
if (C$.useIXA) {
return $I$(9).getInchiInputFromInChI$S$S(inchi, moreOptions);
} else {
return $I$(24).getInchiInputFromInchi$S(inchi).getInchiInput$();
}});

Clazz.newMeth(C$, 'inchiToInchiKey$S',  function (inchi) {
if (C$.useIXA) {
return $I$(9).inchiToInchiKey$S(inchi);
} else {
return $I$(24).inchiToInchiKey$S(inchi);
}}, p$1);

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions',  function (input, options) {
if (C$.useIXA) {
return $I$(9).toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions(input, options);
} else {
return $I$(24).toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions(input, options);
}}, p$1);

Clazz.newMeth(C$, 'molToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (molFileData, options) {
if (C$.useIXA) {
return $I$(9).molFileToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molFileData, options);
} else {
return $I$(24).molToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molFileData, options);
}}, p$1);

Clazz.newMeth(C$, 'inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
if (C$.useIXA) {
return $I$(9).inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions(inchi, options);
} else {
return $I$(24).inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions(inchi, options);
}}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.isJS=true ||false;
C$.useIXA=true;
C$.ntests=0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:20:20 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
