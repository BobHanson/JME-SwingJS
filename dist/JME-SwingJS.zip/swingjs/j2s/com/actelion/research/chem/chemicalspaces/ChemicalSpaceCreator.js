(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces"),p$1={},p$2={},I$=[[0,'java.util.ArrayList','java.util.Random','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.chemicalspaces.synthon.SynthonReactor','java.util.stream.Collectors','java.util.HashMap','java.util.concurrent.ConcurrentHashMap','com.actelion.research.chem.descriptor.DescriptorHandlerLongFFP512','com.actelion.research.chem.SSSearcher','com.actelion.research.chem.chemicalspaces.ChemicalSpaceCreator','java.util.Arrays','com.actelion.research.chem.chemicalspaces.synthon.SynthonCreator','com.actelion.research.chem.SSSearcherWithIndex','java.util.Collections','com.actelion.research.chem.reaction.Reactor','java.util.HashSet','com.actelion.research.chem.CanonizerUtil',['com.actelion.research.chem.chemicalspaces.ChemicalSpaceCreator','.CombinatorialLibrary'],'java.io.BufferedWriter','java.io.OutputStreamWriter','java.io.FileOutputStream','java.nio.charset.StandardCharsets','com.actelion.research.chem.io.DWARFileCreator','java.io.File','StringBuilder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['CombinatorialLibrary',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['outdirectory','java.io.File','bbs','java.util.Set','bbData','java.util.Map','reactions','java.util.List','+functionalizations']]]

Clazz.newMeth(C$, 'c$$java_util_Set$java_util_List$java_io_File',  function (bbs, reactions, outdirectory) {
;C$.$init$.apply(this);
this.bbs=bbs;
this.reactions=reactions;
this.outdirectory=outdirectory;
this.functionalizations=Clazz.new_($I$(1,1));
for (var rxn, $rxn = reactions.iterator$(); $rxn.hasNext$()&&((rxn=($rxn.next$())),1);) {
if (rxn.getReactants$() == 1) this.functionalizations.add$O(rxn);
}
reactions.removeAll$java_util_Collection(this.functionalizations);
}, 1);

Clazz.newMeth(C$, 'setOutdirectory$java_io_File',  function (outdirectory) {
this.outdirectory=outdirectory;
});

Clazz.newMeth(C$, 'setBBs$java_util_Set',  function (bbs) {
this.bbs=bbs;
});

Clazz.newMeth(C$, 'setBBData$java_util_Map',  function (bbData) {
this.bbData=bbData;
});

Clazz.newMeth(C$, 'setReactions$java_util_List',  function (reactions) {
this.reactions=reactions;
});

Clazz.newMeth(C$, 'create$',  function () {
var allSynthonTransformations=Clazz.new_($I$(7,1));
C$.generateSynthonTransformations$java_util_List$java_util_Map(this.reactions, allSynthonTransformations);
var processedToOrigIDCode=Clazz.new_($I$(8,1));
var reactionsWithSynthons=Clazz.new_($I$(8,1));
C$.processBuildingBlocks$java_util_Collection$java_util_concurrent_ConcurrentMap$java_util_List(this.bbs, processedToOrigIDCode, this.functionalizations);
var fps=Clazz.new_($I$(8,1));
C$.calcFragFPs$java_util_Collection$java_util_concurrent_ConcurrentMap(processedToOrigIDCode.keySet$(), fps);
C$.generateSynthons$java_util_List$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_Map(this.reactions, processedToOrigIDCode, reactionsWithSynthons, fps, allSynthonTransformations);
p$2.generateCombinatoriaLibraries$java_util_concurrent_ConcurrentMap$java_util_Map.apply(this, [reactionsWithSynthons, allSynthonTransformations]);
});

Clazz.newMeth(C$, 'calcFragFPs$java_util_Collection$java_util_concurrent_ConcurrentMap',  function (idcodes, fps) {
idcodes.parallelStream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (idc) /*block*/{
var parser=Clazz.new_($I$(3,1));
var dhf=Clazz.new_($I$(9,1));
var mol=Clazz.new_($I$(4,1));
try {
parser.parse$com_actelion_research_chem_StereoMolecule$S.apply(parser, [mol, idc]);
var desc=dhf.createDescriptor$com_actelion_research_chem_StereoMolecule.apply(dhf, [mol]);
this.$finals$.fps.put$O$O.apply(this.$finals$.fps, [idc, desc]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda1.$init$,[this, {fps:fps}])));
}, 1);

Clazz.newMeth(C$, 'processBuildingBlocks$java_util_Collection$java_util_concurrent_ConcurrentMap$java_util_List',  function (bbs, processedToOrigIDCode, functionalizations) {
bbs.parallelStream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (idcode) /*block*/{
var mol=Clazz.new_($I$(3,1)).getCompactMolecule$S.apply(Clazz.new_($I$(3,1)), [idcode]);
if (mol != null ) {
mol.ensureHelperArrays$I.apply(mol, [31]);
mol.stripSmallFragments$.apply(mol, []);
mol.normalizeAmbiguousBonds$.apply(mol, []);
if (this.$finals$.processedToOrigIDCode.get$O.apply(this.$finals$.processedToOrigIDCode, [mol.getIDCode$.apply(mol, [])]) != null ) return;
this.$finals$.processedToOrigIDCode.put$O$O.apply(this.$finals$.processedToOrigIDCode, [mol.getIDCode$.apply(mol, []), idcode]);
for (var functionalization, $functionalization = this.$finals$.functionalizations.iterator$(); $functionalization.hasNext$()&&((functionalization=($functionalization.next$())),1);) {
var searcher=Clazz.new_($I$(10,1));
searcher.setFragment$com_actelion_research_chem_StereoMolecule.apply(searcher, [functionalization.getReactant$I.apply(functionalization, [0])]);
searcher.setMolecule$com_actelion_research_chem_StereoMolecule.apply(searcher, [mol]);
if (searcher.isFragmentInMolecule$.apply(searcher, [])) {
var product=$I$(11,"getProduct$com_actelion_research_chem_reaction_Reaction$java_util_List",[functionalization, $I$(12,"asList$OA",[Clazz.array($I$(4), -1, [mol])])]);
if (product != null ) this.$finals$.processedToOrigIDCode.put$O$O.apply(this.$finals$.processedToOrigIDCode, [product.getIDCode$.apply(product, []), idcode]);
}}
}});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda2.$init$,[this, {processedToOrigIDCode:processedToOrigIDCode,functionalizations:functionalizations}])));
}, 1);

Clazz.newMeth(C$, 'generateSynthons$java_util_List$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_Map',  function (reactions, processedBBToBB, reactionsWithSynthons, fps, allSynthonTransformations) {
for (var rxn, $rxn = reactions.iterator$(); $rxn.hasNext$()&&((rxn=($rxn.next$())),1);) {
C$.processReaction$com_actelion_research_chem_reaction_Reaction$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_Map(rxn, processedBBToBB, reactionsWithSynthons, fps, allSynthonTransformations);
}
}, 1);

Clazz.newMeth(C$, 'generateSynthonTransformations$java_util_List$java_util_Map',  function (reactions, allSynthonTransformations) {
for (var rxn, $rxn = reactions.iterator$(); $rxn.hasNext$()&&((rxn=($rxn.next$())),1);) {
var synthonTransformations=Clazz.new_($I$(1,1));
try {
var transformations=$I$(13).create$com_actelion_research_chem_reaction_Reaction(rxn);
synthonTransformations=$I$(12).asList$OA(transformations);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
allSynthonTransformations.put$O$O(rxn.getName$(), synthonTransformations);
}
}, 1);

Clazz.newMeth(C$, 'processReaction$com_actelion_research_chem_reaction_Reaction$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_concurrent_ConcurrentMap$java_util_Map',  function (rxn, processedToOrigBB, reactionsWithSynthons, fps, synthonTransformations) {
var reactants=Clazz.new_($I$(1,1));
C$.getReactants$com_actelion_research_chem_reaction_Reaction$java_util_concurrent_ConcurrentMap$java_util_List$java_util_Map(rxn, processedToOrigBB, reactants, fps);
reactionsWithSynthons.putIfAbsent$O$O(rxn.getName$(), Clazz.new_($I$(1,1)));
for (var i=0; i < reactants.size$(); i++) {
var rList=reactants.get$I(i);
var synthonList=Clazz.new_($I$(8,1));
reactionsWithSynthons.get$O(rxn.getName$()).add$O(synthonList);
var synthonTransformation=synthonTransformations.get$O(rxn.getName$()).get$I(i);
rList.parallelStream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (idcode) /*block*/{
var parser=Clazz.new_($I$(3,1));
var bb=Clazz.new_($I$(4,1));
parser.parse$com_actelion_research_chem_StereoMolecule$S.apply(parser, [bb, idcode]);
bb.ensureHelperArrays$I.apply(bb, [31]);
var synthonIDCode=$I$(11).transformToSynthon$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_StereoMolecule(this.$finals$.synthonTransformation, bb);
var origIDCode=this.$finals$.processedToOrigBB.get$O.apply(this.$finals$.processedToOrigBB, [idcode]);
if (synthonIDCode != null ) {
this.$finals$.synthonList.put$O$O.apply(this.$finals$.synthonList, [synthonIDCode, origIDCode]);
}});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda3.$init$,[this, {synthonList:synthonList,synthonTransformation:synthonTransformation,processedToOrigBB:processedToOrigBB}])));
}
}, 1);

Clazz.newMeth(C$, 'getReactants$com_actelion_research_chem_reaction_Reaction$java_util_concurrent_ConcurrentMap$java_util_List$java_util_Map',  function (rxn, processedToOrigIDCode, reactants, fps) {
var searchers=Clazz.array($I$(14), [rxn.getReactants$()]);
for (var i=0; i < rxn.getReactants$(); i++) {
var dhf=Clazz.new_($I$(9,1));
var r=rxn.getReactant$I(i);
var reactantFFP=dhf.createDescriptor$com_actelion_research_chem_StereoMolecule(r);
var searcher=Clazz.new_($I$(14,1));
searcher.setFragment$com_actelion_research_chem_StereoMolecule$JA(r, reactantFFP);
searchers[i]=searcher;
}
for (var i=0; i < rxn.getReactants$(); i++) {
var reactantList=$I$(15,"synchronizedList$java_util_List",[Clazz.new_($I$(1,1))]);
var ii=i;
processedToOrigIDCode.keySet$().stream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (processedIDcode) /*block*/{
var mol=Clazz.new_($I$(3,1)).getCompactMolecule$S.apply(Clazz.new_($I$(3,1)), [processedIDcode]);
if (mol != null ) {
var fp=this.$finals$.fps.get$O.apply(this.$finals$.fps, [processedIDcode]);
if (fp == null ) return;
var matchesReaction=$I$(11).matchesReactionRole$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_SSSearcherWithIndexA$I$com_actelion_research_chem_StereoMolecule$JA(this.$finals$.rxn, this.$finals$.searchers, this.$finals$.ii, mol, fp);
if (matchesReaction) this.$finals$.reactantList.add$O.apply(this.$finals$.reactantList, [processedIDcode]);
}});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda4.$init$,[this, {rxn:rxn,fps:fps,searchers:searchers,ii:ii,reactantList:reactantList}])));
reactants.add$O(reactantList);
}
}, 1);

Clazz.newMeth(C$, 'transformToSynthon$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_StereoMolecule',  function (synthonTransformation, bb) {
var synthonIDCode=null;
var reactor=Clazz.new_($I$(16,1).c$$com_actelion_research_chem_reaction_Reaction$I$I,[synthonTransformation, 15, 2147483647]);
bb.ensureHelperArrays$I(31);
reactor.setReactant$I$com_actelion_research_chem_StereoMolecule(0, bb);
var productCodes=reactor.getProductIDCodes$();
var productCount=C$.getNormalizedProductsCount$com_actelion_research_chem_StereoMoleculeAA(reactor.getProducts$());
if (productCount == 0 || productCount > 1 ) return synthonIDCode;
 else {
synthonIDCode=productCodes[0][0];
}return synthonIDCode;
}, 1);

Clazz.newMeth(C$, 'getProduct$com_actelion_research_chem_reaction_Reaction$java_util_List',  function (rxn, reactants) {
var reactor=Clazz.new_($I$(16,1).c$$com_actelion_research_chem_reaction_Reaction$I$I,[rxn, 15, 2147483647]);
for (var i=0; i < reactants.size$(); i++) reactor.setReactant$I$com_actelion_research_chem_StereoMolecule(i, reactants.get$I(i));

var products=reactor.getProducts$();
return products.length == 1 && products[0].length == 1  ? products[0][0] : null;
}, 1);

Clazz.newMeth(C$, 'getNormalizedProductsCount$com_actelion_research_chem_StereoMoleculeAA',  function (products) {
var normalizedProducts=Clazz.new_($I$(17,1));
for (var i=0; i < products.length; i++) {
for (var j=0; j < products[i].length; j++) {
normalizedProducts.add$O(Long.valueOf$J($I$(18).getTautomerHash$com_actelion_research_chem_StereoMolecule$Z(products[i][j], true)));
}
}
return normalizedProducts.size$();
}, 1);

Clazz.newMeth(C$, 'generateCombinatoriaLibraries$java_util_concurrent_ConcurrentMap$java_util_Map',  function (reactionsWithSynthons, synthonTransformations) {
var productsWithSynthons=Clazz.new_($I$(7,1));
var productsWithBBs=Clazz.new_($I$(7,1));
var productsWithReactions=Clazz.new_($I$(7,1));
var functionalizations=Clazz.new_($I$(17,1));
for (var rxn, $rxn = this.reactions.iterator$(); $rxn.hasNext$()&&((rxn=($rxn.next$())),1);) {
if (rxn.getReactants$() == 1) functionalizations.add$O(rxn);
}
var sizes=Clazz.new_($I$(1,1));
this.reactions.stream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_reaction_Reaction','accept$O'],  function (reaction) /*block*/{
if (reaction.getReactants$.apply(reaction, []) < 2) return;
var parser=Clazz.new_($I$(3,1));
var combiLibrary=Clazz.new_($I$(19,1));
combiLibrary.reaction=reaction;
var libraryReaction=reaction.getName$.apply(reaction, []);
combiLibrary.bbSynthons=this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [libraryReaction]);
var precursorLibs=Clazz.new_($I$(1,1));
combiLibrary.precursorLibs=precursorLibs;
if (reaction.getReactants$.apply(reaction, []) > 2) {
p$1.cleanup.apply(combiLibrary, []);
this.$finals$.sizes.add$O.apply(this.$finals$.sizes, [Long.valueOf$J(combiLibrary.getSize$.apply(combiLibrary, []))]);
try {
p$2.writeCombinatorialLibrary$com_actelion_research_chem_chemicalspaces_ChemicalSpaceCreator_CombinatorialLibrary.apply(this.b$['com.actelion.research.chem.chemicalspaces.ChemicalSpaceCreator'], [combiLibrary]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$.apply(e, []);
} else {
throw e;
}
}
return;
}var searchers=Clazz.array($I$(14), [reaction.getReactants$.apply(reaction, [])]);
for (var i=0; i < searchers.length; i++) {
var searcher=Clazz.new_($I$(14,1));
searcher.setFragment$com_actelion_research_chem_StereoMolecule$JA.apply(searcher, [reaction.getReactant$I.apply(reaction, [i]), null]);
searchers[i]=searcher;
}
for (var libReactantID=0; libReactantID < this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [libraryReaction]).size$.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [libraryReaction]), []); libReactantID++) {
var precursorLib=Clazz.new_($I$(7,1));
precursorLibs.add$O.apply(precursorLibs, [precursorLib]);
var synthonTransformation=this.$finals$.synthonTransformations.get$O.apply(this.$finals$.synthonTransformations, [libraryReaction]).get$I.apply(this.$finals$.synthonTransformations.get$O.apply(this.$finals$.synthonTransformations, [libraryReaction]), [libReactantID]);
var genericProduct=synthonTransformation.getProduct$I.apply(synthonTransformation, [0]);
var offset=0;
for (var a=0; a < genericProduct.getAtoms$.apply(genericProduct, []); a++) {
if (genericProduct.getAtomicNo$I.apply(genericProduct, [a]) >= 92) ++offset;
}
for (var reactionPrec, $reactionPrec = this.b$['com.actelion.research.chem.chemicalspaces.ChemicalSpaceCreator'].reactions.iterator$(); $reactionPrec.hasNext$()&&((reactionPrec=($reactionPrec.next$())),1);) {
if (reactionPrec.getReactants$.apply(reactionPrec, []) != 2) continue;
var precursorReaction=reactionPrec.getName$.apply(reactionPrec, []);
for (var reactantID=0; reactantID < this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]).size$.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]), []); reactantID++) {
var libSynthons=Clazz.new_($I$(1,1));
var precursorName=null;
precursorName=precursorReaction + "_" + reactantID ;
precursorLib.put$O$O.apply(precursorLib, [precursorName, libSynthons]);
var dummyReactants=Clazz.new_($I$(7,1));
for (var l=0; l < reactionPrec.getReactants$.apply(reactionPrec, []); l++) {
if (l == reactantID) continue;
 else {
dummyReactants.put$O$O.apply(dummyReactants, [Integer.valueOf$I(l), reactionPrec.getReactant$I.apply(reactionPrec, [l])]);
}}
for (var i=0; i < this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]).size$.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]), []); i++) {
var precursorSynthons=Clazz.new_($I$(7,1));
libSynthons.add$O.apply(libSynthons, [precursorSynthons]);
}
var twoConnectorSynthons=libSynthons.get$I.apply(libSynthons, [reactantID]);
var synthons=this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]).get$I.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]), [reactantID]);
for (var synthon, $synthon = synthons.keySet$.apply(synthons, []).iterator$(); $synthon.hasNext$()&&((synthon=($synthon.next$())),1);) {
var mol=Clazz.new_($I$(4,1));
var bb=synthons.get$O.apply(synthons, [synthon]);
parser.parse$com_actelion_research_chem_StereoMolecule$S.apply(parser, [mol, synthon]);
var reactedBB=$I$(11).dummyReaction$S$com_actelion_research_chem_reaction_Reaction$java_util_Map$I(bb, reactionPrec, dummyReactants, reactantID);
if (reactedBB == null ) continue;
if ($I$(11).matchesReactionRole$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_SSSearcherWithIndexA$I$com_actelion_research_chem_StereoMolecule$JA(reaction, searchers, libReactantID, reactedBB, null)) {
$I$(11).mutateConnectorAtoms$com_actelion_research_chem_StereoMolecule$I(mol, offset);
var transformedSynthon=$I$(11).transformToSynthon$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_StereoMolecule(synthonTransformation, mol);
if (transformedSynthon != null ) twoConnectorSynthons.put$O$O.apply(twoConnectorSynthons, [transformedSynthon, bb]);
} else {
for (var functionalization, $functionalization = this.$finals$.functionalizations.iterator$(); $functionalization.hasNext$()&&((functionalization=($functionalization.next$())),1);) {
if (this.$finals$.functionalizations.contains$O.apply(this.$finals$.functionalizations, [reactionPrec])) continue;
var ssearcher=Clazz.new_($I$(10,1));
ssearcher.setFragment$com_actelion_research_chem_StereoMolecule.apply(ssearcher, [functionalization.getReactant$I.apply(functionalization, [0])]);
ssearcher.setMolecule$com_actelion_research_chem_StereoMolecule.apply(ssearcher, [reactedBB]);
if (ssearcher.isFragmentInMolecule$.apply(ssearcher, [])) {
var product=$I$(11,"getProduct$com_actelion_research_chem_reaction_Reaction$java_util_List",[functionalization, $I$(12,"asList$OA",[Clazz.array($I$(4), -1, [reactedBB])])]);
if (product == null ) continue;
 else {
if ($I$(11).matchesReactionRole$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_SSSearcherWithIndexA$I$com_actelion_research_chem_StereoMolecule$JA(reaction, searchers, libReactantID, product, null)) {
var prod=$I$(11,"getProduct$com_actelion_research_chem_reaction_Reaction$java_util_List",[functionalization, $I$(12,"asList$OA",[Clazz.array($I$(4), -1, [mol])])]);
if (prod == null ) continue;
$I$(11).mutateConnectorAtoms$com_actelion_research_chem_StereoMolecule$I(prod, offset);
var transformedSynthon=$I$(11).transformToSynthon$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_StereoMolecule(synthonTransformation, prod);
if (!precursorLib.containsKey$O.apply(precursorLib, [precursorName])) {
var libSynthons2=Clazz.new_($I$(1,1));
precursorLib.put$O$O.apply(precursorLib, [precursorName, libSynthons2]);
for (var i=0; i < this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]).size$.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]), []); i++) {
var precursorSynthons2=Clazz.new_($I$(7,1));
libSynthons2.add$O.apply(libSynthons2, [precursorSynthons2]);
}
}precursorLib.get$O.apply(precursorLib, [precursorName]).get$I.apply(precursorLib.get$O.apply(precursorLib, [precursorName]), [reactantID]).put$O$O.apply(precursorLib.get$O.apply(precursorLib, [precursorName]).get$I.apply(precursorLib.get$O.apply(precursorLib, [precursorName]), [reactantID]), [transformedSynthon, bb]);
}}}}
}}
for (var j=0; j < this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]).size$.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]), []); j++) {
if (j == reactantID) {
continue;
} else {
var compatibleSynthons=this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]).get$I.apply(this.$finals$.reactionsWithSynthons.get$O.apply(this.$finals$.reactionsWithSynthons, [precursorReaction]), [j]);
var mutatedSynthons=Clazz.new_($I$(7,1));
for (var s, $s = compatibleSynthons.keySet$.apply(compatibleSynthons, []).iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) {
var mutatedSynthon=Clazz.new_($I$(4,1));
var compatible=true;
parser.parse$com_actelion_research_chem_StereoMolecule$S.apply(parser, [mutatedSynthon, s]);
for (var sssearcher, $sssearcher = 0, $$sssearcher = searchers; $sssearcher<$$sssearcher.length&&((sssearcher=($$sssearcher[$sssearcher])),1);$sssearcher++) {
sssearcher.setMolecule$com_actelion_research_chem_StereoMolecule$JA.apply(sssearcher, [mutatedSynthon, null]);
if (sssearcher.isFragmentInMolecule$.apply(sssearcher, [])) compatible=false;
}
if (!compatible) continue;
$I$(11).mutateConnectorAtoms$com_actelion_research_chem_StereoMolecule$I(mutatedSynthon, offset);
mutatedSynthons.put$O$O.apply(mutatedSynthons, [mutatedSynthon.getIDCode$.apply(mutatedSynthon, []), compatibleSynthons.get$O.apply(compatibleSynthons, [s])]);
}
libSynthons.get$I.apply(libSynthons, [j]).putAll$java_util_Map.apply(libSynthons.get$I.apply(libSynthons, [j]), [mutatedSynthons]);
}}
}
}
}
p$1.cleanup.apply(combiLibrary, []);
this.$finals$.sizes.add$O.apply(this.$finals$.sizes, [Long.valueOf$J(combiLibrary.getSize$.apply(combiLibrary, []))]);
System.out.println$S.apply(System.out, [reaction.getName$.apply(reaction, [])]);
combiLibrary.generateRandomProducts$I$java_util_Map$java_util_Map$java_util_Map.apply(combiLibrary, [1000, this.$finals$.productsWithSynthons, this.$finals$.productsWithBBs, this.$finals$.productsWithReactions]);
try {
p$2.writeCombinatorialLibrary$com_actelion_research_chem_chemicalspaces_ChemicalSpaceCreator_CombinatorialLibrary.apply(this.b$['com.actelion.research.chem.chemicalspaces.ChemicalSpaceCreator'], [combiLibrary]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$.apply(e, []);
} else {
throw e;
}
}
});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda5.$init$,[this, {productsWithReactions:productsWithReactions,functionalizations:functionalizations,productsWithSynthons:productsWithSynthons,sizes:sizes,reactionsWithSynthons:reactionsWithSynthons,synthonTransformations:synthonTransformations,productsWithBBs:productsWithBBs}])));
try {
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(22,1).c$$S,["space.dwar"]), $I$(23).UTF_8],$I$(21,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(20,1).c$$java_io_Writer);
var creator=Clazz.new_($I$(24,1).c$$java_io_BufferedWriter,[writer]);
var synthonColumns=Clazz.new_($I$(1,1));
for (var i=0; i < 4; i++) {
synthonColumns.add$O(Integer.valueOf$I(creator.addStructureColumn$S$S("Synthon" + (i + 1), "IDcode")));
}
var bbColumns=Clazz.new_($I$(1,1));
for (var i=0; i < 4; i++) {
bbColumns.add$O(Integer.valueOf$I(creator.addStructureColumn$S$S("BB" + (i + 1), "IDcode")));
}
var reactionColumns=Clazz.new_($I$(1,1));
for (var i=0; i < 3; i++) {
reactionColumns.add$O(Integer.valueOf$I(creator.addAlphanumericalColumn$S("Reaction" + (i + 1))));
}
var structureColumn=creator.addStructureColumn$S$S("Product", "IDcode");
creator.writeHeader$I(-1);
productsWithSynthons.entrySet$().stream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map_Entry','accept$O'],  function (e) /*block*/{
this.$finals$.creator.setRowStructure$S$I.apply(this.$finals$.creator, [e.getKey$.apply(e, []), this.$finals$.structureColumn]);
var synthons=e.getValue$.apply(e, []);
for (var i=0; i < synthons.size$.apply(synthons, []); i++) {
this.$finals$.creator.setRowStructure$S$I.apply(this.$finals$.creator, [synthons.get$I.apply(synthons, [i]), (this.$finals$.synthonColumns.get$I.apply(this.$finals$.synthonColumns, [i])).$c()]);
}
var bbs=this.$finals$.productsWithBBs.get$O.apply(this.$finals$.productsWithBBs, [e.getKey$.apply(e, [])]);
for (var i=0; i < bbs.size$.apply(bbs, []); i++) {
this.$finals$.creator.setRowStructure$S$I.apply(this.$finals$.creator, [bbs.get$I.apply(bbs, [i]), (this.$finals$.bbColumns.get$I.apply(this.$finals$.bbColumns, [i])).$c()]);
}
var reactions=this.$finals$.productsWithReactions.get$O.apply(this.$finals$.productsWithReactions, [e.getKey$.apply(e, [])]);
for (var i=0; i < reactions.size$.apply(reactions, []); i++) {
this.$finals$.creator.setRowValue$S$I.apply(this.$finals$.creator, [reactions.get$I.apply(reactions, [i]), (this.$finals$.reactionColumns.get$I.apply(this.$finals$.reactionColumns, [i])).$c()]);
}
try {
this.$finals$.creator.writeCurrentRow$.apply(this.$finals$.creator, []);
} catch (e3) {
if (Clazz.exceptionOf(e3,"java.io.IOException")){
e3.printStackTrace$.apply(e3, []);
} else {
throw e3;
}
}
});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda6.$init$,[this, {synthonColumns:synthonColumns,productsWithReactions:productsWithReactions,reactionColumns:reactionColumns,bbColumns:bbColumns,structureColumn:structureColumn,productsWithBBs:productsWithBBs,creator:creator}])));
creator.writeEnd$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("########");
e.printStackTrace$();
} else {
throw e;
}
}
var size=(sizes.stream$().reduce$O$java_util_function_BinaryOperator(Long.valueOf$J(0), (P$.ChemicalSpaceCreator$lambda7$||(P$.ChemicalSpaceCreator$lambda7$=(((P$.ChemicalSpaceCreator$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$Long$Long','apply$O$O'],  function (e1, e2) { return (Long.valueOf$J(Long.$add((e1).$c(),(e2).$c())));});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda7.$init$,[this, null]))))))).valueOf();
System.out.println$S("totSize");
System.out.println$J(size);
}, p$2);

Clazz.newMeth(C$, 'dummyReaction$S$com_actelion_research_chem_reaction_Reaction$java_util_Map$I',  function (bbIDCode, rxn, reactants, reactantID) {
var product=null;
var searcher=Clazz.new_($I$(10,1));
searcher.setFragment$com_actelion_research_chem_StereoMolecule(rxn.getReactant$I(reactantID));
var mol=Clazz.new_($I$(3,1)).getCompactMolecule$S(bbIDCode);
if (mol != null ) {
searcher.setMolecule$com_actelion_research_chem_StereoMolecule(mol);
if (searcher.isFragmentInMolecule$()) {
var reactor=Clazz.new_($I$(16,1).c$$com_actelion_research_chem_reaction_Reaction$I$I,[rxn, 15, 2147483647]);
reactor.setReactant$I$com_actelion_research_chem_StereoMolecule(reactantID, mol);
for (var i, $i = reactants.keySet$().iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
reactor.setReactant$I$com_actelion_research_chem_StereoMolecule(i, reactants.get$O(Integer.valueOf$I(i)));
}
var products=reactor.getProducts$();
if (products.length == 1 && products[0].length == 1 ) product=products[0][0];
}}return product;
}, 1);

Clazz.newMeth(C$, 'mutateConnectorAtoms$com_actelion_research_chem_StereoMolecule$I',  function (mol, offset) {
for (var a=0; a < mol.getAtoms$(); a++) {
var atomicNo=mol.getAtomicNo$I(a);
if (atomicNo >= 92) {
atomicNo+=offset;
mol.setAtomicNo$I$I(a, atomicNo);
}}
mol.ensureHelperArrays$I(7);
}, 1);

Clazz.newMeth(C$, 'writeCombinatorialLibrary$com_actelion_research_chem_chemicalspaces_ChemicalSpaceCreator_CombinatorialLibrary',  function (combiLib) {
var htmcdir=Clazz.new_($I$(25,1).c$$S,[this.outdirectory + "/CombinatorialLibraries/"]);
htmcdir.mkdir$();
var htmcSubDir=Clazz.new_([htmcdir.getAbsolutePath$() + "/" + combiLib.reaction.getName$() ],$I$(25,1).c$$S);
htmcSubDir.mkdir$();
var dirA=Clazz.new_([htmcSubDir.getAbsolutePath$() + "/A"],$I$(25,1).c$$S);
dirA.mkdir$();
var dirB=Clazz.new_([htmcSubDir.getAbsolutePath$() + "/B"],$I$(25,1).c$$S);
dirB.mkdir$();
var dirC=null;
var dirD=null;
if (combiLib.bbSynthons.size$() > 2) {
dirC=Clazz.new_([htmcSubDir.getAbsolutePath$() + "/C"],$I$(25,1).c$$S);
dirC.mkdir$();
}if (combiLib.bbSynthons.size$() > 3) {
dirD=Clazz.new_([htmcSubDir.getAbsolutePath$() + "/D"],$I$(25,1).c$$S);
dirD.mkdir$();
}if (combiLib.precursorLibs.size$() == 2) {
for (var i=0; i < combiLib.precursorLibs.size$(); i++) {
var dir=null;
if (i == 0) dir=Clazz.new_([dirA.getAbsolutePath$() + "/virtual_bbs"],$I$(25,1).c$$S);
 else dir=Clazz.new_([dirB.getAbsolutePath$() + "/virtual_bbs"],$I$(25,1).c$$S);
dir.mkdir$();
for (var flowReaction, $flowReaction = combiLib.precursorLibs.get$I(i).keySet$().iterator$(); $flowReaction.hasNext$()&&((flowReaction=($flowReaction.next$())),1);) {
var flowDir=dir.getAbsoluteFile$() + "/" + flowReaction ;
var flowSynthons=combiLib.precursorLibs.get$I(i).get$O(flowReaction);
var counter=1;
for (var synthons, $synthons = flowSynthons.iterator$(); $synthons.hasNext$()&&((synthons=($synthons.next$())),1);) {
if (synthons.isEmpty$()) continue;
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(22,1).c$$S,[flowDir + "_" + counter + ".dwar" ]), $I$(23).UTF_8],$I$(21,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(20,1).c$$java_io_Writer);
var creator=Clazz.new_($I$(24,1).c$$java_io_BufferedWriter,[writer]);
var synthonColumn=creator.addStructureColumn$S$S("Synthon", "IDcode");
var structureColumn=creator.addStructureColumn$S$S("Building Block", "IDcode");
var fields=Clazz.new_($I$(1,1));
if (this.bbData != null ) {
this.bbData.values$().stream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map','accept$O'],  function (e) /*block*/{
for (var key, $key = e.keySet$.apply(e, []).iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
if (!this.$finals$.fields.contains$O.apply(this.$finals$.fields, [key])) this.$finals$.fields.add$O.apply(this.$finals$.fields, [key]);
}
});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda8.$init$,[this, {fields:fields}])));
}var fieldIndexes=Clazz.new_($I$(1,1));
for (var field, $field = fields.iterator$(); $field.hasNext$()&&((field=($field.next$())),1);) {
var columnIndex=creator.addAlphanumericalColumn$S(field);
fieldIndexes.add$O(Integer.valueOf$I(columnIndex));
}
creator.writeHeader$I(-1);
for (var s, $s = synthons.keySet$().iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) {
var origIDCode=synthons.get$O(s);
if (this.bbData != null ) {
var propertyMap=this.bbData.get$O(origIDCode);
for (var j=0; j < fields.size$(); j++) {
var field=fields.get$I(j);
var sb=Clazz.new_($I$(26,1));
var values=propertyMap.get$O(field);
if (values != null ) {
values.forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda9||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (e) { return (this.$finals$.sb.append$S.apply(this.$finals$.sb, [e]).append$S.apply(this.$finals$.sb.append$S.apply(this.$finals$.sb, [e]), [";"]));});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda9.$init$,[this, {sb:sb}])));
}creator.setRowValue$S$I(sb.toString(), (fieldIndexes.get$I(j)).$c());
}
}creator.setRowStructure$S$I(s, synthonColumn);
creator.setRowStructure$S$I(origIDCode, structureColumn);
creator.writeCurrentRow$();
}
creator.writeEnd$();
++counter;
}
}
}
}var i=0;
for (var synthons, $synthons = combiLib.bbSynthons.iterator$(); $synthons.hasNext$()&&((synthons=($synthons.next$())),1);) {
if (synthons.isEmpty$()) continue;
var dir=null;
switch (i) {
case 0:
dir=dirA;
break;
case 1:
dir=dirB;
break;
case 2:
dir=dirC;
break;
case 3:
dir=dirD;
break;
default:
break;
}
var outfile=dir + "/" + combiLib.reaction.getName$() + ".dwar" ;
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(22,1).c$$S,[outfile]), $I$(23).UTF_8],$I$(21,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(20,1).c$$java_io_Writer);
var creator=Clazz.new_($I$(24,1).c$$java_io_BufferedWriter,[writer]);
var synthonColumn=creator.addStructureColumn$S$S("Synthon", "IDcode");
var structureColumn=creator.addStructureColumn$S$S("Building Block", "IDcode");
var fields=Clazz.new_($I$(1,1));
if (this.bbData != null ) {
this.bbData.values$().stream$().forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda10||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map','accept$O'],  function (e) /*block*/{
for (var key, $key = e.keySet$.apply(e, []).iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
if (!this.$finals$.fields.contains$O.apply(this.$finals$.fields, [key])) this.$finals$.fields.add$O.apply(this.$finals$.fields, [key]);
}
});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda10.$init$,[this, {fields:fields}])));
}var fieldIndeces=Clazz.new_($I$(1,1));
for (var field, $field = fields.iterator$(); $field.hasNext$()&&((field=($field.next$())),1);) {
var columnIndex=creator.addAlphanumericalColumn$S(field);
fieldIndeces.add$O(Integer.valueOf$I(columnIndex));
}
creator.writeHeader$I(-1);
for (var s, $s = synthons.keySet$().iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) {
var origIDCode=synthons.get$O(s);
if (this.bbData != null ) {
var propertyMap=this.bbData.get$O(origIDCode);
for (var j=0; j < fields.size$(); j++) {
var field=fields.get$I(j);
var sb=Clazz.new_($I$(26,1).c$$S,[""]);
var values=propertyMap.get$O(field);
if (values != null ) {
values.forEach$java_util_function_Consumer(((P$.ChemicalSpaceCreator$lambda11||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$lambda11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'],  function (e) { return (this.$finals$.sb.append$S.apply(this.$finals$.sb, [e + ";"]));});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$lambda11.$init$,[this, {sb:sb}])));
}creator.setRowValue$S$I(sb.toString(), (fieldIndeces.get$I(j)).$c());
}
}creator.setRowStructure$S$I(s, synthonColumn);
creator.setRowStructure$S$I(synthons.get$O(s), structureColumn);
creator.writeCurrentRow$();
}
creator.writeEnd$();
++i;
}
}, p$2);

Clazz.newMeth(C$, 'matchesReactionRole$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_SSSearcherWithIndexA$I$com_actelion_research_chem_StereoMolecule$JA',  function (rxn, searchers, component, reactant, index) {
var isMatch=true;
var searcher=searchers[component];
searcher.setMolecule$com_actelion_research_chem_StereoMolecule$JA(reactant, index);
if (searcher.isFragmentInMolecule$()) {
for (var j=0; j < rxn.getReactants$(); j++) {
if (component != j && !rxn.getReactant$I(component).getIDCode$().equals$O(rxn.getReactant$I(j).getIDCode$()) ) {
var searcher2=searchers[j];
searcher2.setMolecule$com_actelion_research_chem_StereoMolecule$JA(reactant, index);
if (searcher2.isFragmentInMolecule$()) {
isMatch=false;
}}}
} else {
isMatch=false;
}return isMatch;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ChemicalSpaceCreator, "CombinatorialLibrary", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.toRemove=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['reaction','com.actelion.research.chem.reaction.Reaction','bbSynthons','java.util.List','+precursorLibs','+toRemove']]]

Clazz.newMeth(C$, 'cleanup',  function () {
for (var precursorLib, $precursorLib = this.precursorLibs.iterator$(); $precursorLib.hasNext$()&&((precursorLib=($precursorLib.next$())),1);) {
for (var reaction, $reaction = precursorLib.keySet$().iterator$(); $reaction.hasNext$()&&((reaction=($reaction.next$())),1);) {
for (var synthons, $synthons = precursorLib.get$O(reaction).iterator$(); $synthons.hasNext$()&&((synthons=($synthons.next$())),1);) {
if (synthons == null ) this.toRemove.add$O(reaction);
 else if (synthons.isEmpty$()) this.toRemove.add$O(reaction);
}
}
for (var r, $r = this.toRemove.iterator$(); $r.hasNext$()&&((r=($r.next$())),1);) {
precursorLib.remove$O(r);
}
this.toRemove=Clazz.new_($I$(1,1));
}
}, p$1);

Clazz.newMeth(C$, 'getSize$',  function () {
var sizeOneStep=1;
for (var synthons, $synthons = this.bbSynthons.iterator$(); $synthons.hasNext$()&&((synthons=($synthons.next$())),1);) {
(sizeOneStep=Long.$mul(sizeOneStep,(synthons.size$())));
}
if (this.precursorLibs.size$() == 2) {
var reactantsA=this.bbSynthons.get$I(0).size$();
var precursorLibsA=this.precursorLibs.get$I(0);
var reactantsB=this.bbSynthons.get$I(1).size$();
var precursorLibsB=this.precursorLibs.get$I(1);
for (var precReaction, $precReaction = precursorLibsA.keySet$().iterator$(); $precReaction.hasNext$()&&((precReaction=($precReaction.next$())),1);) {
var precLibA=precursorLibsA.get$O(precReaction);
var precSize=1;
for (var precLib, $precLib = precLibA.iterator$(); $precLib.hasNext$()&&((precLib=($precLib.next$())),1);) {
precSize*=precLib.size$();
}
(reactantsA=Long.$add(reactantsA,(precSize)));
}
for (var precReaction, $precReaction = precursorLibsB.keySet$().iterator$(); $precReaction.hasNext$()&&((precReaction=($precReaction.next$())),1);) {
var precLibB=precursorLibsB.get$O(precReaction);
var precSize=1;
for (var precLib, $precLib = precLibB.iterator$(); $precLib.hasNext$()&&((precLib=($precLib.next$())),1);) {
precSize*=precLib.size$();
}
(reactantsB=Long.$add(reactantsB,(precSize)));
}
return Long.$mul(reactantsA,reactantsB);
} else return sizeOneStep;
});

Clazz.newMeth(C$, 'generateRandomProducts$I$java_util_Map$java_util_Map$java_util_Map',  function (nProducts, productsWithSynthons, productsWithBBs, productsWithReactions) {
var rnd=Clazz.new_($I$(2,1));
var parser=Clazz.new_($I$(3,1));
var max=Long.$add(productsWithSynthons.keySet$().size$(),Math.min$J$J(this.getSize$(), nProducts));
while (Long.$lt(productsWithSynthons.keySet$().size$(),max )){
var synthons=Clazz.new_($I$(1,1));
var bbs=Clazz.new_($I$(1,1));
var reactions=Clazz.new_($I$(1,1));
var preCoupledSynthons=Clazz.new_($I$(1,1));
var precursorName="";
reactions.add$O(this.reaction.getName$());
for (var i=0; i < this.reaction.getReactants$(); i++) {
var r=rnd.nextInt$I(2);
var libs=this.precursorLibs.get$I(i);
if (libs.isEmpty$() || r == 0 ) {
if (this.bbSynthons.get$I(i).isEmpty$()) return;
var r2=rnd.nextInt$I(this.bbSynthons.get$I(i).size$());
var mol=Clazz.new_($I$(4,1));
var s=this.bbSynthons.get$I(i);
var keys=Clazz.new_([s.keySet$()],$I$(1,1).c$$java_util_Collection);
parser.parse$com_actelion_research_chem_StereoMolecule$S(mol, keys.get$I(r2));
synthons.add$O(mol);
bbs.add$O(s.get$O(keys.get$I(r2)));
preCoupledSynthons.add$O(mol);
} else {
var precursors=Clazz.new_($I$(1,1));
var reactionNr=rnd.nextInt$I(libs.keySet$().size$());
var keys=Clazz.new_([libs.keySet$()],$I$(1,1).c$$java_util_Collection);
var lib=libs.get$O(keys.get$I(reactionNr));
precursorName=keys.get$I(reactionNr);
reactions.add$O(precursorName);
for (var precursorBBs, $precursorBBs = lib.iterator$(); $precursorBBs.hasNext$()&&((precursorBBs=($precursorBBs.next$())),1);) {
var keySet2=Clazz.new_([precursorBBs.keySet$()],$I$(1,1).c$$java_util_Collection);
var r3=rnd.nextInt$I(keySet2.size$());
var mol=Clazz.new_($I$(4,1));
parser.parse$com_actelion_research_chem_StereoMolecule$S(mol, keySet2.get$I(r3));
synthons.add$O(mol);
bbs.add$O(precursorBBs.get$O(keySet2.get$I(r3)));
precursors.add$O(mol);
}
try {
preCoupledSynthons.add$O($I$(5).react$java_util_List(precursors));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}}
try {
var product=$I$(5).react$java_util_List(preCoupledSynthons);
if (product == null  || productsWithSynthons.containsKey$O(product.getIDCode$()) ) continue;
var bbIDCodes=synthons.stream$().map$java_util_function_Function(((P$.ChemicalSpaceCreator$CombinatorialLibrary$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemicalSpaceCreator$CombinatorialLibrary$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_StereoMolecule','apply$O'],  function (e) { return (e.getIDCode$.apply(e, []));});
})()
), Clazz.new_(P$.ChemicalSpaceCreator$CombinatorialLibrary$lambda1.$init$,[this, null]))).collect$java_util_stream_Collector($I$(6).toList$());
productsWithSynthons.put$O$O(product.getIDCode$(), bbIDCodes);
productsWithBBs.put$O$O(product.getIDCode$(), bbs);
productsWithReactions.put$O$O(product.getIDCode$(), reactions);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:01 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
