(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),I$=[[0,'java.util.TreeMap','com.actelion.research.chem.io.CompoundFileHelper']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CompoundFileFilter", null, 'javax.swing.filechooser.FileFilter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mDescription=null;
this.mFullDescription=null;
this.mUseExtensionsInDescription=true;
},1);

C$.$fields$=[['Z',['mUseExtensionsInDescription'],'S',['mDescription','mFullDescription'],'O',['mFilterMap','java.util.TreeMap']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.mFilterMap=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (extension) {
C$.c$$S$S.apply(this, [extension, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$S',  function (extension, description) {
C$.c$.apply(this, []);
if (extension != null ) this.addExtension$S(extension);
if (description != null ) this.setDescription$S(description);
}, 1);

Clazz.newMeth(C$, 'c$$SA',  function (filters) {
C$.c$$SA$S.apply(this, [filters, null]);
}, 1);

Clazz.newMeth(C$, 'c$$SA$S',  function (filters, description) {
C$.c$.apply(this, []);
for (var i=0; i < filters.length; i++) this.addExtension$S(filters[i]);

if (description != null ) this.setDescription$S(description);
}, 1);

Clazz.newMeth(C$, 'accept$java_io_File',  function (f) {
if (f != null ) {
if (f.isDirectory$()) return true;
var extension=this.getExtension$java_io_File(f);
if (extension != null  && this.mFilterMap.get$O(this.getExtension$java_io_File(f)) != null  ) return true;
}return false;
});

Clazz.newMeth(C$, 'getExtension$java_io_File',  function (f) {
return $I$(2).getExtension$java_io_File(f);
});

Clazz.newMeth(C$, 'addExtension$S',  function (extension) {
if (this.mFilterMap == null ) this.mFilterMap=Clazz.new_($I$(1,1));
this.mFilterMap.put$O$O(extension.toLowerCase$(), this);
this.mFullDescription=null;
});

Clazz.newMeth(C$, 'getDescription$',  function () {
if (this.mFullDescription == null ) {
if (this.mDescription == null  || this.isExtensionListInDescription$() ) {
this.mFullDescription=(this.mDescription == null ) ? "(" : this.mDescription + " (";
var iterator=this.mFilterMap.keySet$().stream$().sorted$().iterator$();
this.mFullDescription+=iterator.next$();
while (iterator.hasNext$())this.mFullDescription+=", " + iterator.next$();

this.mFullDescription+=")";
} else {
this.mFullDescription=this.mDescription;
}}return this.mFullDescription;
});

Clazz.newMeth(C$, 'setDescription$S',  function (description) {
this.mDescription=description;
this.mFullDescription=null;
});

Clazz.newMeth(C$, 'addDescription$S',  function (description) {
if (this.mDescription == null ) this.mDescription=description;
 else this.mDescription=this.mDescription.concat$S(", " + description);
});

Clazz.newMeth(C$, 'setExtensionListInDescription$Z',  function (b) {
this.mUseExtensionsInDescription=b;
this.mFullDescription=null;
});

Clazz.newMeth(C$, 'isExtensionListInDescription$',  function () {
return this.mUseExtensionsInDescription;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
