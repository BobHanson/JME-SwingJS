(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),I$=[[0,'java.util.Scanner','Math','java.util.Random']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HungarianAlgorithm");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'readInput$S',  function (prompt) {
var $in=Clazz.new_($I$(1,1).c$$java_io_InputStream,[System.$in]);
System.out.print$S(prompt);
var input=$in.nextInt$();
return input;
}, 1);

Clazz.newMeth(C$, 'printTime$D',  function (time) {
var timeElapsed="";
var days=(($I$(2).floor(time)|0)/(86400)|0);
var hours=(($I$(2,"floor",[time % (86400)])|0)/(3600)|0);
var minutes=($I$(2,"floor",[(time % 3600) / 60])|0);
var seconds=Long.$ival($I$(2).round$D(time % 60));
if (days > 0) timeElapsed=Integer.toString$I(days) + "d:";
if (hours > 0) timeElapsed=timeElapsed + Integer.toString$I(hours) + "h:" ;
if (minutes > 0) timeElapsed=timeElapsed + Integer.toString$I(minutes) + "m:" ;
timeElapsed=timeElapsed + Integer.toString$I(seconds) + "s" ;
System.out.print$S("\nTotal time required: " + timeElapsed + "\n\n" );
}, 1);

Clazz.newMeth(C$, 'generateRandomArray$DAA$S',  function (array, randomMethod) {
var generator=Clazz.new_($I$(3,1));
for (var i=0; i < array.length; i++) {
for (var j=0; j < array[i].length; j++) {
if (randomMethod.equals$O("random")) {
array[i][j]=generator.nextDouble$();
}if (randomMethod.equals$O("gaussian")) {
array[i][j]=generator.nextGaussian$() / 4;
if (array[i][j] > 0.5 ) {
array[i][j]=0.5;
}if (array[i][j] < -0.5 ) {
array[i][j]=-0.5;
}array[i][j]=array[i][j] + 0.5;
}}
}
}, 1);

Clazz.newMeth(C$, 'findLargest$DAA',  function (array) {
var largest=0;
for (var i=0; i < array.length; i++) {
for (var j=0; j < array[i].length; j++) {
if (array[i][j] > largest ) {
largest=array[i][j];
}}
}
return largest;
}, 1);

Clazz.newMeth(C$, 'transpose$DAA',  function (array) {
var transposedArray=Clazz.array(Double.TYPE, [array[0].length, array.length]);
for (var i=0; i < transposedArray.length; i++) {
for (var j=0; j < transposedArray[i].length; j++) {
transposedArray[i][j]=array[j][i];
}
}
return transposedArray;
}, 1);

Clazz.newMeth(C$, 'copyOf$DAA',  function (original) {
var copy=Clazz.array(Double.TYPE, [original.length, original[0].length]);
for (var i=0; i < original.length; i++) {
System.arraycopy$O$I$O$I$I(original[i], 0, copy[i], 0, original[i].length);
}
return copy;
}, 1);

Clazz.newMeth(C$, 'hgAlgorithm$DAA$S',  function (array, sumType) {
var cost=C$.copyOf$DAA(array);
if (sumType.equalsIgnoreCase$S("max")) {
var maxWeight=C$.findLargest$DAA(cost);
for (var i=0; i < cost.length; i++) {
for (var j=0; j < cost[i].length; j++) {
cost[i][j]=(maxWeight - cost[i][j]);
}
}
}var maxCost=C$.findLargest$DAA(cost);
var mask=Clazz.array(Integer.TYPE, [cost.length, cost[0].length]);
var rowCover=Clazz.array(Integer.TYPE, [cost.length]);
var colCover=Clazz.array(Integer.TYPE, [cost[0].length]);
var zero_RC=Clazz.array(Integer.TYPE, [2]);
var step=1;
var done=false;
while (done == false ){
switch (step) {
case 1:
step=C$.hg_step1$I$DAA(step, cost);
break;
case 2:
step=C$.hg_step2$I$DAA$IAA$IA$IA(step, cost, mask, rowCover, colCover);
break;
case 3:
step=C$.hg_step3$I$IAA$IA(step, mask, colCover);
break;
case 4:
step=C$.hg_step4$I$DAA$IAA$IA$IA$IA(step, cost, mask, rowCover, colCover, zero_RC);
break;
case 5:
step=C$.hg_step5$I$IAA$IA$IA$IA(step, mask, rowCover, colCover, zero_RC);
break;
case 6:
step=C$.hg_step6$I$DAA$IA$IA$D(step, cost, rowCover, colCover, maxCost);
break;
case 7:
done=true;
break;
}
}
var assignment=Clazz.array(Integer.TYPE, [array.length, 2]);
for (var i=0; i < mask.length; i++) {
for (var j=0; j < mask[i].length; j++) {
if (mask[i][j] == 1) {
assignment[i][0]=i;
assignment[i][1]=j;
}}
}
return assignment;
}, 1);

Clazz.newMeth(C$, 'hg_step1$I$DAA',  function (step, cost) {
var minval;
for (var i=0; i < cost.length; i++) {
minval=cost[i][0];
for (var j=0; j < cost[i].length; j++) {
if (minval > cost[i][j] ) {
minval=cost[i][j];
}}
for (var j=0; j < cost[i].length; j++) {
cost[i][j]=cost[i][j] - minval;
}
}
step=2;
return step;
}, 1);

Clazz.newMeth(C$, 'hg_step2$I$DAA$IAA$IA$IA',  function (step, cost, mask, rowCover, colCover) {
for (var i=0; i < cost.length; i++) {
for (var j=0; j < cost[i].length; j++) {
if ((cost[i][j] == 0 ) && (colCover[j] == 0) && (rowCover[i] == 0)  ) {
mask[i][j]=1;
colCover[j]=1;
rowCover[i]=1;
}}
}
C$.clearCovers$IA$IA(rowCover, colCover);
step=3;
return step;
}, 1);

Clazz.newMeth(C$, 'hg_step3$I$IAA$IA',  function (step, mask, colCover) {
for (var i=0; i < mask.length; i++) {
for (var j=0; j < mask[i].length; j++) {
if (mask[i][j] == 1) {
colCover[j]=1;
}}
}
var count=0;
for (var j=0; j < colCover.length; j++) {
count=count + colCover[j];
}
if (count >= mask.length) {
step=7;
} else {
step=4;
}return step;
}, 1);

Clazz.newMeth(C$, 'hg_step4$I$DAA$IAA$IA$IA$IA',  function (step, cost, mask, rowCover, colCover, zero_RC) {
var row_col=Clazz.array(Integer.TYPE, [2]);
var done=false;
while (done == false ){
row_col=C$.findUncoveredZero$IA$DAA$IA$IA(row_col, cost, rowCover, colCover);
if (row_col[0] == -1) {
done=true;
step=6;
} else {
mask[row_col[0]][row_col[1]]=2;
var starInRow=false;
for (var j=0; j < mask[row_col[0]].length; j++) {
if (mask[row_col[0]][j] == 1) {
starInRow=true;
row_col[1]=j;
}}
if (starInRow == true ) {
rowCover[row_col[0]]=1;
colCover[row_col[1]]=0;
} else {
zero_RC[0]=row_col[0];
zero_RC[1]=row_col[1];
done=true;
step=5;
}}}
return step;
}, 1);

Clazz.newMeth(C$, 'findUncoveredZero$IA$DAA$IA$IA',  function (row_col, cost, rowCover, colCover) {
row_col[0]=-1;
row_col[1]=0;
var i=0;
var done=false;
while (done == false ){
var j=0;
while (j < cost[i].length){
if (cost[i][j] == 0  && rowCover[i] == 0  && colCover[j] == 0 ) {
row_col[0]=i;
row_col[1]=j;
done=true;
}j=j + 1;
}
i=i + 1;
if (i >= cost.length) {
done=true;
}}
return row_col;
}, 1);

Clazz.newMeth(C$, 'hg_step5$I$IAA$IA$IA$IA',  function (step, mask, rowCover, colCover, zero_RC) {
var count=0;
var path=Clazz.array(Integer.TYPE, [(mask[0].length * mask.length), 2]);
path[count][0]=zero_RC[0];
path[count][1]=zero_RC[1];
var done=false;
while (done == false ){
var r=C$.findStarInCol$IAA$I(mask, path[count][1]);
if (r >= 0) {
count=count + 1;
path[count][0]=r;
path[count][1]=path[count - 1][1];
} else {
done=true;
}if (done == false ) {
var c=C$.findPrimeInRow$IAA$I(mask, path[count][0]);
count=count + 1;
path[count][0]=path[count - 1][0];
path[count][1]=c;
}}
C$.convertPath$IAA$IAA$I(mask, path, count);
C$.clearCovers$IA$IA(rowCover, colCover);
C$.erasePrimes$IAA(mask);
step=3;
return step;
}, 1);

Clazz.newMeth(C$, 'findStarInCol$IAA$I',  function (mask, col) {
var r=-1;
for (var i=0; i < mask.length; i++) {
if (mask[i][col] == 1) {
r=i;
}}
return r;
}, 1);

Clazz.newMeth(C$, 'findPrimeInRow$IAA$I',  function (mask, row) {
var c=-1;
for (var j=0; j < mask[row].length; j++) {
if (mask[row][j] == 2) {
c=j;
}}
return c;
}, 1);

Clazz.newMeth(C$, 'convertPath$IAA$IAA$I',  function (mask, path, count) {
for (var i=0; i <= count; i++) {
if (mask[(path[i][0])][(path[i][1])] == 1) {
mask[(path[i][0])][(path[i][1])]=0;
} else {
mask[(path[i][0])][(path[i][1])]=1;
}}
}, 1);

Clazz.newMeth(C$, 'erasePrimes$IAA',  function (mask) {
for (var i=0; i < mask.length; i++) {
for (var j=0; j < mask[i].length; j++) {
if (mask[i][j] == 2) {
mask[i][j]=0;
}}
}
}, 1);

Clazz.newMeth(C$, 'clearCovers$IA$IA',  function (rowCover, colCover) {
for (var i=0; i < rowCover.length; i++) {
rowCover[i]=0;
}
for (var j=0; j < colCover.length; j++) {
colCover[j]=0;
}
}, 1);

Clazz.newMeth(C$, 'hg_step6$I$DAA$IA$IA$D',  function (step, cost, rowCover, colCover, maxCost) {
var minval=C$.findSmallest$DAA$IA$IA$D(cost, rowCover, colCover, maxCost);
for (var i=0; i < rowCover.length; i++) {
for (var j=0; j < colCover.length; j++) {
if (rowCover[i] == 1) {
cost[i][j]=cost[i][j] + minval;
}if (colCover[j] == 0) {
cost[i][j]=cost[i][j] - minval;
}}
}
step=4;
return step;
}, 1);

Clazz.newMeth(C$, 'findSmallest$DAA$IA$IA$D',  function (cost, rowCover, colCover, maxCost) {
var minval=maxCost;
for (var i=0; i < cost.length; i++) {
for (var j=0; j < cost[i].length; j++) {
if (rowCover[i] == 0 && colCover[j] == 0  && (minval > cost[i][j] ) ) {
minval=cost[i][j];
}}
}
return minval;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:23 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
