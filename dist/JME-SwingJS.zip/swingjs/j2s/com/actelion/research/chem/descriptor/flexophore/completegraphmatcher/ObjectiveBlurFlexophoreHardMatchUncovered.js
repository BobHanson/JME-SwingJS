(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.completegraphmatcher"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.PPNodeSimilarity','com.actelion.research.chem.descriptor.flexophore.SlidingWindowDistHist','com.actelion.research.chem.descriptor.flexophore.generator.ConstantsFlexophoreGenerator','java.util.Arrays','StringBuilder','com.actelion.research.util.Formatter','com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','com.actelion.research.calc.Matrix','com.actelion.research.calc.graph.MinimumSpanningTree','com.actelion.research.chem.descriptor.flexophore.DistHist','com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.HistogramMatchCalculator']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ObjectiveBlurFlexophoreHardMatchUncovered", null, null, 'com.actelion.research.util.graph.complete.IObjectiveCompleteGraph');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['modeQuery','validHelpersQuery','validHelpersBase','resetSimilarityArrays','optimisticHistogramSimilarity','excludeHistogramSimilarity','fragmentNodesMapping','verbose'],'D',['threshNodeMinSimilarityStart','threshHistogramSimilarity','sumDistanceMinSpanTreeQuery','sumDistanceMinSpanTreeBase','avrPairwiseMappingScaled','coverageQuery','coverageBase','similarity'],'I',['marginQuery','nodesBase','nodesQuery','numMandatoryPPPoints'],'J',['deltaNanoQueryBlur','deltaNanoBaseBlur','deltaNanoSimilarity'],'O',['mdhvBase','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','+mdhvBaseBlurredHist','+mdhvQuery','+mdhvQueryBlurredHist','arrTmpHist','byte[]','nodeSimilarity','com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.PPNodeSimilarity','arrSimilarityNodes','float[][]','+arrSimilarityHistograms','arrRelativeDistanceMatrixQuery','double[][]','+arrRelativeDistanceMatrixBase','arrSimilarityTmp','double[]','maHelperAdjacencyQuery','com.actelion.research.calc.Matrix','+maHelperAdjacencyBase','arrMandatoryPPPoint','boolean[]','slidingWindowDistHist','com.actelion.research.chem.descriptor.flexophore.SlidingWindowDistHist']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I$I$D$D.apply(this, [-1, 1, 0.9, 0.15]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$D$D',  function (versionInteractionTable, modePPNodeSimilarity, threshSimilarityNodeHardMatch, threshHistogramSimilarity) {
;C$.$init$.apply(this);
this.arrTmpHist=Clazz.array(Byte.TYPE, [80]);
this.nodeSimilarity=Clazz.new_($I$(1,1).c$$I$I,[versionInteractionTable, modePPNodeSimilarity]);
this.nodeSimilarity.setThreshSimilarityHardMatch$D(threshSimilarityNodeHardMatch);
this.threshHistogramSimilarity=threshHistogramSimilarity;
this.threshNodeMinSimilarityStart=0.9;
this.slidingWindowDistHist=Clazz.new_([$I$(3).FILTER],$I$(2,1).c$$DA);
this.modeQuery=false;
this.deltaNanoQueryBlur=0;
this.deltaNanoBaseBlur=0;
this.deltaNanoSimilarity=0;
this.setFragmentNodesMapping$Z(false);
this.setOptimisticHistogramSimilarity$Z(false);
this.marginQuery=0;
this.excludeHistogramSimilarity=false;
p$1.initSimilarityMatrices.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'setFragmentNodesMapping$Z',  function (fragmentNodesMapping) {
this.fragmentNodesMapping=fragmentNodesMapping;
});

Clazz.newMeth(C$, 'setMarginQuery$I',  function (marginQuery) {
this.marginQuery=marginQuery;
});

Clazz.newMeth(C$, 'setOptimisticHistogramSimilarity$Z',  function (optimisticHistogramSimilarity) {
this.optimisticHistogramSimilarity=optimisticHistogramSimilarity;
if (optimisticHistogramSimilarity) {
this.threshHistogramSimilarity=1.0E-7;
}});

Clazz.newMeth(C$, 'setExcludeHistogramSimilarity$Z',  function (excludeHistogramSimilarity) {
this.excludeHistogramSimilarity=excludeHistogramSimilarity;
});

Clazz.newMeth(C$, 'isExcludeHistogramSimilarity$',  function () {
return this.excludeHistogramSimilarity;
});

Clazz.newMeth(C$, 'initSimilarityMatrices',  function () {
this.arrSimilarityNodes=Clazz.array(Float.TYPE, [64, null]);
for (var i=0; i < 64; i++) {
this.arrSimilarityNodes[i]=Clazz.array(Float.TYPE, [64]);
$I$(4).fill$FA$F(this.arrSimilarityNodes[i], -1.0);
}
var maxNumHistograms=2016;
this.arrSimilarityHistograms=Clazz.array(Float.TYPE, [maxNumHistograms, null]);
for (var i=0; i < maxNumHistograms; i++) {
this.arrSimilarityHistograms[i]=Clazz.array(Float.TYPE, [maxNumHistograms]);
$I$(4).fill$FA$F(this.arrSimilarityHistograms[i], -1.0);
}
this.arrSimilarityTmp=Clazz.array(Double.TYPE, [64]);
}, p$1);

Clazz.newMeth(C$, 'setModeQuery$Z',  function (modeQuery) {
this.modeQuery=modeQuery;
});

Clazz.newMeth(C$, 'isModeQuery$',  function () {
return this.modeQuery;
});

Clazz.newMeth(C$, 'toStringParameter$',  function () {
var sb=Clazz.new_($I$(5,1));
sb.append$S("ObjectiveFlexophoreHardMatchUncovered Thresh histogram similarity ");
sb.append$D(this.threshHistogramSimilarity);
sb.append$S(", thresh node similarity start " + new Double(this.threshNodeMinSimilarityStart).toString());
sb.append$S(", ");
sb.append$S(this.nodeSimilarity.toStringParameter$());
return sb.toString();
});

Clazz.newMeth(C$, 'resetSimilarityMatrices',  function () {
for (var i=0; i < this.nodesQuery; i++) {
for (var j=0; j < this.nodesBase; j++) {
this.arrSimilarityNodes[i][j]=-1.0;
}
}
var numHistogramsQuery=(((this.nodesQuery * this.nodesQuery) - this.nodesQuery)/2|0);
var numHistogramsBase=(((this.nodesBase * this.nodesBase) - this.nodesBase)/2|0);
for (var i=0; i < numHistogramsQuery; i++) {
for (var j=0; j < numHistogramsBase; j++) {
this.arrSimilarityHistograms[i][j]=-1.0;
}
}
this.resetSimilarityArrays=false;
}, p$1);

Clazz.newMeth(C$, 'setVerbose$Z',  function (v) {
this.verbose=v;
this.nodeSimilarity.setVerbose$Z(v);
});

Clazz.newMeth(C$, 'isValidSolution$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
var mapping=true;
if (!this.validHelpersQuery) {
p$1.calculateHelpersQuery.apply(this, []);
}if (!this.validHelpersBase) {
p$1.calculateHelpersBase.apply(this, []);
}if (this.resetSimilarityArrays) {
p$1.resetSimilarityMatrices.apply(this, []);
}var heap=solution.getSizeHeap$();
if (this.numMandatoryPPPoints > 0) {
var ccInevitablePPPointsInSolution=0;
for (var i=0; i < heap; i++) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(i);
if (this.mdhvQueryBlurredHist.isMandatoryPharmacophorePoint$I(indexNodeQuery)) {
++ccInevitablePPPointsInSolution;
}}
var neededMinInevitablePPPoints=Math.min(heap, this.numMandatoryPPPoints);
if (ccInevitablePPPointsInSolution < neededMinInevitablePPPoints) {
mapping=false;
}}if (!this.fragmentNodesMapping && mapping ) {
var heteroNodeQuery=false;
var heteroNodeBase=false;
for (var i=0; i < heap; i++) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(i);
var nodeQuery=this.mdhvQueryBlurredHist.getNode$I(indexNodeQuery);
if (nodeQuery.hasHeteroAtom$()) {
heteroNodeQuery=true;
}var indexNodeBase=solution.getIndexCorrespondingBaseNode$I(indexNodeQuery);
var nodeBase=this.mdhvBaseBlurredHist.getNode$I(indexNodeBase);
if (nodeBase.hasHeteroAtom$()) {
heteroNodeBase=true;
}if (heteroNodeQuery && heteroNodeBase ) {
break;
}}
if (!heteroNodeQuery || !heteroNodeBase ) {
mapping=false;
}}if (mapping) {
for (var i=0; i < heap; i++) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(i);
var indexNodeBase=solution.getIndexCorrespondingBaseNode$I(indexNodeQuery);
if (!this.areNodesMapping$I$I(indexNodeQuery, indexNodeBase)) {
mapping=false;
break;
}}
}if (mapping && !this.excludeHistogramSimilarity ) {
 outer : for (var i=0; i < heap; i++) {
var indexNode1Query=solution.getIndexQueryFromHeap$I(i);
var indexNode1Base=solution.getIndexCorrespondingBaseNode$I(indexNode1Query);
for (var j=i + 1; j < heap; j++) {
var indexNode2Query=solution.getIndexQueryFromHeap$I(j);
var indexNode2Base=solution.getIndexCorrespondingBaseNode$I(indexNode2Query);
if (!p$1.areHistogramsMapping$I$I$I$I.apply(this, [indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base])) {
mapping=false;
break outer;
} else {
}}
}
}return mapping;
});

Clazz.newMeth(C$, 'areNodesMapping$I$I',  function (indexNodeQuery, indexNodeBase) {
if (!this.validHelpersQuery) {
p$1.calculateHelpersQuery.apply(this, []);
}if (!this.validHelpersBase) {
p$1.calculateHelpersBase.apply(this, []);
}if (this.resetSimilarityArrays) {
p$1.resetSimilarityMatrices.apply(this, []);
}var match=true;
var simNodes=this.getSimilarityNodes$I$I(indexNodeQuery, indexNodeBase);
var ppNodeBase=this.mdhvBaseBlurredHist.getNode$I(indexNodeBase);
var ppNodeQuery=this.mdhvQueryBlurredHist.getNode$I(indexNodeQuery);
var interactionTypeCountBase=ppNodeBase.getInteractionTypeCount$();
var interactionTypeCountQuery=ppNodeQuery.getInteractionTypeCount$();
var threshCalc=0;
if (interactionTypeCountBase > interactionTypeCountQuery) {
threshCalc=Math.pow(this.threshNodeMinSimilarityStart, interactionTypeCountBase);
} else {
threshCalc=Math.pow(this.threshNodeMinSimilarityStart, interactionTypeCountQuery);
}if (simNodes < threshCalc ) {
match=false;
}return match;
});

Clazz.newMeth(C$, 'areHistogramsMapping$I$I$I$I',  function (indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base) {
var match=true;
var simHistograms=this.getSimilarityHistogram$I$I$I$I(indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base);
if (simHistograms < this.threshHistogramSimilarity ) {
match=false;
}return match;
}, p$1);

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
var t0=System.nanoTime$();
if (!this.validHelpersQuery) {
p$1.calculateHelpersQuery.apply(this, []);
}if (!this.validHelpersBase) {
p$1.calculateHelpersBase.apply(this, []);
}if (this.resetSimilarityArrays) {
p$1.resetSimilarityMatrices.apply(this, []);
}var heap=solution.getSizeHeap$();
if (this.modeQuery) {
if (this.nodesQuery != heap) {
this.similarity=0;
return this.similarity;
}}if (this.fragmentNodesMapping && heap == 1 ) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(0);
var indexNodeBase=solution.getIndexCorrespondingBaseNode$I(indexNodeQuery);
this.similarity=this.getSimilarityNodes$I$I(indexNodeQuery, indexNodeBase);
return this.similarity;
}if (this.numMandatoryPPPoints > 0) {
var ccMandatoryPPPoints=0;
for (var i=0; i < heap; i++) {
var indexNode1Query=solution.getIndexQueryFromHeap$I(i);
if (this.arrMandatoryPPPoint[indexNode1Query]) {
++ccMandatoryPPPoints;
}}
if (this.numMandatoryPPPoints > ccMandatoryPPPoints) {
this.similarity=0;
return this.similarity;
}}var cc=0;
var nMappings=(((heap * heap) - heap)/2|0);
var arrMappingWeights=Clazz.array(Double.TYPE, [nMappings]);
var arrSimilarityWeighted=Clazz.array(Double.TYPE, [nMappings]);
for (var i=0; i < heap; i++) {
var indexNode1Query=solution.getIndexQueryFromHeap$I(i);
var indexNode1Base=solution.getIndexCorrespondingBaseNode$I(indexNode1Query);
for (var j=i + 1; j < heap; j++) {
var indexNode2Query=solution.getIndexQueryFromHeap$I(j);
var indexNode2Base=solution.getIndexCorrespondingBaseNode$I(indexNode2Query);
var scorePairwiseMapping=p$1.getScorePairwiseMapping$I$I$I$I.apply(this, [indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base]);
var w=this.mdhvQuery.getWeightPharmacophorePoint$I(indexNode1Query) * this.mdhvQuery.getWeightPharmacophorePoint$I(indexNode2Query);
arrMappingWeights[cc]=w;
arrSimilarityWeighted[cc++]=scorePairwiseMapping * w;
if (this.verbose) {
System.out.println$S("scorePairwiseMapping " + $I$(6,"format2$Double",[Double.valueOf$D(scorePairwiseMapping)]));
}}
}
var sumMappingWeights=$I$(7).sum$DA(arrMappingWeights);
var sumSimilarityWeighted=$I$(7).sum$DA(arrSimilarityWeighted);
this.avrPairwiseMappingScaled=sumSimilarityWeighted / sumMappingWeights;
this.coverageQuery=p$1.getRatioMinimumSpanningTreeQuery$com_actelion_research_util_graph_complete_SolutionCompleteGraph.apply(this, [solution]);
this.coverageBase=p$1.getRatioMinimumSpanningTreeBase$com_actelion_research_util_graph_complete_SolutionCompleteGraph.apply(this, [solution]);
var coverage=this.coverageQuery * this.coverageBase;
var ratioNodesMatchQuery=Math.min(this.nodesQuery, heap) / Math.max(this.nodesQuery, heap);
var ratioNodesMatchBase=Math.min(heap, this.nodesBase) / Math.max(heap, this.nodesBase);
if (this.modeQuery) {
this.similarity=this.avrPairwiseMappingScaled * this.coverageQuery * this.coverageQuery * ratioNodesMatchQuery * ratioNodesMatchQuery ;
} else {
this.similarity=this.avrPairwiseMappingScaled * coverage * ratioNodesMatchQuery * ratioNodesMatchBase ;
}if (this.verbose) {
var sb=Clazz.new_($I$(5,1));
sb.append$S("ObjectiveFlexophoreHardMatchUncovered");
sb.append$S(" similarity");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(this.similarity)]));
sb.append$S("\t");
sb.append$S("avrPairwiseMappingScaled");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(this.avrPairwiseMappingScaled)]));
sb.append$S("\t");
sb.append$S("coverage");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(coverage)]));
sb.append$S("\t");
sb.append$S("ratioNodesMatchQuery");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(ratioNodesMatchQuery)]));
sb.append$S("\t");
sb.append$S("ratioNodesMatchBase");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(ratioNodesMatchBase)]));
System.out.println$S(sb.toString());
}(this.deltaNanoSimilarity=Long.$add(this.deltaNanoSimilarity,(Long.$sub(System.nanoTime$(),t0))));
return this.similarity;
});

Clazz.newMeth(C$, 'getSimilarityHistograms$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
var t0=System.nanoTime$();
if (!this.validHelpersQuery) {
p$1.calculateHelpersQuery.apply(this, []);
}if (!this.validHelpersBase) {
p$1.calculateHelpersBase.apply(this, []);
}if (this.resetSimilarityArrays) {
p$1.resetSimilarityMatrices.apply(this, []);
}var heap=solution.getSizeHeap$();
if (this.modeQuery) {
if (this.nodesQuery != heap) {
this.similarity=0;
return this.similarity;
}}var sumSimDistHist=0;
for (var i=0; i < heap; i++) {
var indexNode1Query=solution.getIndexQueryFromHeap$I(i);
var indexNode1Base=solution.getIndexCorrespondingBaseNode$I(indexNode1Query);
for (var j=i + 1; j < heap; j++) {
var indexNode2Query=solution.getIndexQueryFromHeap$I(j);
var indexNode2Base=solution.getIndexCorrespondingBaseNode$I(indexNode2Query);
var simDistHist=this.getSimilarityHistogram$I$I$I$I(indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base);
sumSimDistHist+=simDistHist;
if (this.verbose) {
System.out.println$S("scorePairwiseMapping " + $I$(6,"format2$Double",[Double.valueOf$D(simDistHist)]));
}}
}
var mappings=((heap * heap) - heap) / 2.0;
var simDistHistAvr=(sumSimDistHist / mappings);
return simDistHistAvr;
});

Clazz.newMeth(C$, 'getSimilarityNodes$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
var t0=System.nanoTime$();
if (this.resetSimilarityArrays) {
p$1.resetSimilarityMatrices.apply(this, []);
}var heap=solution.getSizeHeap$();
if (this.modeQuery) {
if (Math.abs(this.nodesQuery - heap) > this.marginQuery) {
this.similarity=0;
return this.similarity;
}}if (this.fragmentNodesMapping && heap == 1 ) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(0);
var indexNodeBase=solution.getIndexCorrespondingBaseNode$I(indexNodeQuery);
this.similarity=this.getSimilarityNodes$I$I(indexNodeQuery, indexNodeBase);
return this.similarity;
}var sumSimilarityNodesWeighted=0;
var sumWeights=0;
for (var i=0; i < heap; i++) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(i);
var w=this.mdhvQuery.getWeightPharmacophorePoint$I(indexNodeQuery);
var indexNodeBase=solution.getIndexCorrespondingBaseNode$I(indexNodeQuery);
var similarityNodePairWeighted=this.getSimilarityNodes$I$I(indexNodeQuery, indexNodeBase) * w;
sumSimilarityNodesWeighted+=similarityNodePairWeighted;
sumWeights+=w;
}
this.avrPairwiseMappingScaled=sumSimilarityNodesWeighted / sumWeights;
this.coverageQuery=0;
this.coverageBase=0;
var ratioNodesMatchQuery=Math.min(this.nodesQuery, heap) / Math.max(this.nodesQuery, heap);
var ratioNodesMatchBase=Math.min(heap, this.nodesBase) / Math.max(heap, this.nodesBase);
if (this.modeQuery) {
this.similarity=this.avrPairwiseMappingScaled * ratioNodesMatchQuery * ratioNodesMatchQuery ;
} else {
this.similarity=this.avrPairwiseMappingScaled * ratioNodesMatchQuery * ratioNodesMatchBase ;
}if (this.verbose) {
var sb=Clazz.new_($I$(5,1));
sb.append$S("ObjectiveFlexophoreHardMatchUncovered");
sb.append$S(" similarity nodes");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(this.similarity)]));
sb.append$S("\t");
sb.append$S("avrPairwiseMappingScaled");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(this.avrPairwiseMappingScaled)]));
sb.append$S("\t");
sb.append$S("ratioNodesMatchQuery");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(ratioNodesMatchQuery)]));
sb.append$S("\t");
sb.append$S("ratioNodesMatchBase");
sb.append$S("\t");
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(ratioNodesMatchBase)]));
System.out.println$S(sb.toString());
}(this.deltaNanoSimilarity=Long.$add(this.deltaNanoSimilarity,(Long.$sub(System.nanoTime$(),t0))));
return this.similarity;
});

Clazz.newMeth(C$, 'getSimilarityHistogramsForNode$com_actelion_research_util_graph_complete_SolutionCompleteGraph$I',  function (solution, indexHeap) {
var heap=solution.getSizeHeap$();
if (this.modeQuery) {
if (this.nodesQuery != heap) {
return 0;
}}var sumPairwiseMapping=0;
var indexNode1Query=solution.getIndexQueryFromHeap$I(indexHeap);
var indexNode1Base=solution.getIndexCorrespondingBaseNode$I(indexNode1Query);
for (var i=0; i < heap; i++) {
if (indexHeap == i) continue;
var indexNode2Query=solution.getIndexQueryFromHeap$I(i);
var indexNode2Base=solution.getIndexCorrespondingBaseNode$I(indexNode2Query);
var simHists=this.getSimilarityHistogram$I$I$I$I(indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base);
sumPairwiseMapping+=simHists;
if (this.verbose) {
System.out.println$S("scorePairwiseMapping " + $I$(6,"format2$Double",[Double.valueOf$D(simHists)]));
}}
var mappings=heap - 1;
var avrPairwiseMapping=sumPairwiseMapping / mappings;
return avrPairwiseMapping;
});

Clazz.newMeth(C$, 'getDeltaNanoQueryBlur$',  function () {
return this.deltaNanoQueryBlur;
});

Clazz.newMeth(C$, 'getDeltaNanoBaseBlur$',  function () {
return this.deltaNanoBaseBlur;
});

Clazz.newMeth(C$, 'getDeltaNanoSimilarity$',  function () {
return this.deltaNanoSimilarity;
});

Clazz.newMeth(C$, 'setMatchingInfoInQueryAndBase$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
this.mdhvQuery.resetInfoColor$();
this.mdhvBase.resetInfoColor$();
var heap=solution.getSizeHeap$();
for (var i=0; i < heap; i++) {
var indexNodeQuery=solution.getIndexQueryFromHeap$I(i);
var indexNodeBase=solution.getIndexCorrespondingBaseNode$I(indexNodeQuery);
var similarityMappingNodes=this.getSimilarityNodes$I$I(indexNodeQuery, indexNodeBase);
this.mdhvQuery.setSimilarityMappingNodes$I$F(indexNodeQuery, similarityMappingNodes);
this.mdhvQuery.setMappingIndex$I$I(indexNodeQuery, i);
this.mdhvBase.setMappingIndex$I$I(indexNodeBase, i);
this.mdhvBase.setSimilarityMappingNodes$I$F(indexNodeBase, similarityMappingNodes);
}
});

Clazz.newMeth(C$, 'isModeFragment$',  function () {
return this.fragmentNodesMapping;
});

Clazz.newMeth(C$, 'getBase$',  function () {
return this.mdhvBase;
});

Clazz.newMeth(C$, 'getQuery$',  function () {
return this.mdhvQuery;
});

Clazz.newMeth(C$, ['setBase$com_actelion_research_chem_descriptor_flexophore_IMolDistHist','setBase$com_actelion_research_util_graph_complete_ICompleteGraph'],  function (iMolDistHistBase) {
if (iMolDistHistBase.getNumPPNodes$() >= 64) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of base pharmacophore nodes (" + iMolDistHistBase.getNumPPNodes$() + ") exceeds limit of " + 64 + "." ]);
}var t0=System.nanoTime$();
if (Clazz.instanceOf(iMolDistHistBase, "com.actelion.research.chem.descriptor.flexophore.MolDistHistViz")) {
this.mdhvBase=iMolDistHistBase;
this.mdhvBaseBlurredHist=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz,[iMolDistHistBase]);
} else if (Clazz.instanceOf(iMolDistHistBase, "com.actelion.research.chem.descriptor.flexophore.MolDistHist")) {
this.mdhvBase=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[iMolDistHistBase]);
this.mdhvBaseBlurredHist=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[iMolDistHistBase]);
}if ((this.slidingWindowDistHist != null ) && !this.fragmentNodesMapping ) this.slidingWindowDistHist.apply$com_actelion_research_chem_descriptor_flexophore_DistHist(this.mdhvBaseBlurredHist);
this.nodesBase=iMolDistHistBase.getNumPPNodes$();
this.validHelpersBase=false;
this.resetSimilarityArrays=true;
if (!p$1.checkAtomTypes$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz.apply(this, [this.mdhvBase])) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Base contains Invalid atom type for similarity calculation " + this.mdhvBase.getMolDistHist$().toString() + "." ]);
}(this.deltaNanoBaseBlur=Long.$add(this.deltaNanoBaseBlur,(Long.$sub(System.nanoTime$(),t0))));
});

Clazz.newMeth(C$, 'setSlidingWindowDistHistNull$',  function () {
this.slidingWindowDistHist=null;
});

Clazz.newMeth(C$, ['setQuery$com_actelion_research_chem_descriptor_flexophore_IMolDistHist','setQuery$com_actelion_research_util_graph_complete_ICompleteGraph'],  function (iMolDistHistQuery) {
if (iMolDistHistQuery.getNumPPNodes$() >= 64) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of query pharmacophore nodes (" + iMolDistHistQuery.getNumPPNodes$() + ") exceeds limit of " + 64 + "." ]);
}var t0=System.nanoTime$();
if (Clazz.instanceOf(iMolDistHistQuery, "com.actelion.research.chem.descriptor.flexophore.MolDistHistViz")) {
this.mdhvQuery=iMolDistHistQuery;
this.mdhvQueryBlurredHist=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz,[iMolDistHistQuery]);
} else if (Clazz.instanceOf(iMolDistHistQuery, "com.actelion.research.chem.descriptor.flexophore.MolDistHist")) {
this.mdhvQuery=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[iMolDistHistQuery]);
this.mdhvQueryBlurredHist=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[iMolDistHistQuery]);
}if ((this.slidingWindowDistHist != null ) && !this.fragmentNodesMapping ) this.slidingWindowDistHist.apply$com_actelion_research_chem_descriptor_flexophore_DistHist(this.mdhvQueryBlurredHist);
this.nodesQuery=iMolDistHistQuery.getNumPPNodes$();
this.arrMandatoryPPPoint=Clazz.array(Boolean.TYPE, [this.nodesQuery]);
for (var i=0; i < this.arrMandatoryPPPoint.length; i++) {
this.arrMandatoryPPPoint[i]=iMolDistHistQuery.isMandatoryPharmacophorePoint$I(i);
}
this.numMandatoryPPPoints=iMolDistHistQuery.getNumMandatoryPharmacophorePoints$();
this.validHelpersQuery=false;
this.resetSimilarityArrays=true;
if (!p$1.checkAtomTypes$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz.apply(this, [this.mdhvQuery])) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Base contains Invalid atom type for similarity calculation " + this.mdhvQuery.getMolDistHist$().toStringNodes$() + "." ]);
}(this.deltaNanoQueryBlur=Long.$add(this.deltaNanoQueryBlur,(Long.$sub(System.nanoTime$(),t0))));
});

Clazz.newMeth(C$, 'checkAtomTypes$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var valid=true;
var liNode=mdhv.getNodes$();
 stop : for (var ppNodeViz, $ppNodeViz = liNode.iterator$(); $ppNodeViz.hasNext$()&&((ppNodeViz=($ppNodeViz.next$())),1);) {
var c=ppNodeViz.getInteractionTypeCount$();
for (var i=0; i < c; i++) {
var type=ppNodeViz.getInteractionType$I(i);
if (!this.nodeSimilarity.isValidType$I(type)) {
valid=false;
break stop;
}}
}
return valid;
}, p$1);

Clazz.newMeth(C$, 'calculateHelpersQuery',  function () {
this.arrRelativeDistanceMatrixQuery=p$1.calculateRelativeDistanceMatrix$com_actelion_research_chem_descriptor_flexophore_IMolDistHist.apply(this, [this.mdhvQueryBlurredHist]);
this.maHelperAdjacencyQuery=Clazz.new_($I$(9,1).c$$DAA,[this.arrRelativeDistanceMatrixQuery]);
var mst=Clazz.new_($I$(10,1).c$$com_actelion_research_calc_Matrix,[this.maHelperAdjacencyQuery]);
var maMST=mst.getMST$();
this.sumDistanceMinSpanTreeQuery=maMST.getSumUpperTriangle$();
this.validHelpersQuery=true;
}, p$1);

Clazz.newMeth(C$, 'calculateHelpersBase',  function () {
this.arrRelativeDistanceMatrixBase=p$1.calculateRelativeDistanceMatrix$com_actelion_research_chem_descriptor_flexophore_IMolDistHist.apply(this, [this.mdhvBaseBlurredHist]);
this.maHelperAdjacencyBase=Clazz.new_($I$(9,1).c$$DAA,[this.arrRelativeDistanceMatrixBase]);
var mst=Clazz.new_($I$(10,1).c$$com_actelion_research_calc_Matrix,[this.maHelperAdjacencyBase]);
var maMST=mst.getMST$();
this.sumDistanceMinSpanTreeBase=maMST.getSumUpperTriangle$();
this.validHelpersBase=true;
}, p$1);

Clazz.newMeth(C$, 'getRatioMinimumSpanningTreeQuery$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
var ratioCovered2Total=0;
var heap=solution.getSizeHeap$();
this.maHelperAdjacencyQuery.set$D(NaN);
for (var i=0; i < heap; i++) {
var indexNode1=solution.getIndexQueryFromHeap$I(i);
for (var j=i + 1; j < heap; j++) {
var indexNode2=solution.getIndexQueryFromHeap$I(j);
this.maHelperAdjacencyQuery.set$I$I$D(indexNode1, indexNode2, this.arrRelativeDistanceMatrixQuery[indexNode1][indexNode2]);
this.maHelperAdjacencyQuery.set$I$I$D(indexNode2, indexNode1, this.arrRelativeDistanceMatrixQuery[indexNode1][indexNode2]);
}
}
var mstSolution=Clazz.new_($I$(10,1).c$$com_actelion_research_calc_Matrix,[this.maHelperAdjacencyQuery]);
var maMST=mstSolution.getMST$();
var sum=maMST.getSumUpperTriangle$();
var sumMSTSquared=sum * sum;
var sumMSTSQuerySquared=this.sumDistanceMinSpanTreeQuery * this.sumDistanceMinSpanTreeQuery;
ratioCovered2Total=Math.min(sumMSTSquared, sumMSTSQuerySquared) / Math.max(sumMSTSquared, sumMSTSQuerySquared);
return ratioCovered2Total;
}, p$1);

Clazz.newMeth(C$, 'getRatioMinimumSpanningTreeBase$com_actelion_research_util_graph_complete_SolutionCompleteGraph',  function (solution) {
var ratioCovered2Total=0;
var heap=solution.getSizeHeap$();
this.maHelperAdjacencyBase.set$D(NaN);
for (var i=0; i < heap; i++) {
var indexNode1=solution.getIndexBaseFromHeap$I(i);
for (var j=i + 1; j < heap; j++) {
var indexNode2=solution.getIndexBaseFromHeap$I(j);
this.maHelperAdjacencyBase.set$I$I$D(indexNode1, indexNode2, this.arrRelativeDistanceMatrixBase[indexNode1][indexNode2]);
this.maHelperAdjacencyBase.set$I$I$D(indexNode2, indexNode1, this.arrRelativeDistanceMatrixBase[indexNode1][indexNode2]);
}
}
var mstSolution=Clazz.new_($I$(10,1).c$$com_actelion_research_calc_Matrix,[this.maHelperAdjacencyBase]);
var maMST=mstSolution.getMST$();
var sum=maMST.getSumUpperTriangle$();
var sumMSTSquared=sum * sum;
var sumMSTSBaseSquared=this.sumDistanceMinSpanTreeBase * this.sumDistanceMinSpanTreeBase;
ratioCovered2Total=Math.min(sumMSTSquared, sumMSTSBaseSquared) / Math.max(sumMSTSquared, sumMSTSBaseSquared);
return ratioCovered2Total;
}, p$1);

Clazz.newMeth(C$, 'calculateRelativeDistanceMatrix$com_actelion_research_chem_descriptor_flexophore_IMolDistHist',  function (mdh) {
var nodes=mdh.getNumPPNodes$();
var arrDist=Clazz.array(Double.TYPE, [nodes, nodes]);
var maxMedianDistanceBin=0;
for (var i=0; i < arrDist.length; i++) {
for (var j=i + 1; j < arrDist.length; j++) {
var medianDistanceBin=p$1.getCenterOfGravityDistanceBin$com_actelion_research_chem_descriptor_flexophore_IMolDistHist$I$I.apply(this, [mdh, i, j]);
arrDist[i][j]=medianDistanceBin;
arrDist[j][i]=medianDistanceBin;
if (medianDistanceBin > maxMedianDistanceBin) {
maxMedianDistanceBin=medianDistanceBin;
}}
}
for (var i=0; i < arrDist.length; i++) {
for (var j=i + 1; j < arrDist.length; j++) {
arrDist[i][j]=arrDist[i][j] / maxMedianDistanceBin;
arrDist[j][i]=arrDist[j][i] / maxMedianDistanceBin;
}
}
return arrDist;
}, p$1);

Clazz.newMeth(C$, 'getCenterOfGravityDistanceBin$com_actelion_research_chem_descriptor_flexophore_IMolDistHist$I$I',  function (mdh, indexNode1, indexNode2) {
var arr=mdh.getDistHist$I$I$BA(indexNode1, indexNode2, this.arrTmpHist);
var sum=0;
for (var i=0; i < arr.length; i++) {
sum+=arr[i];
}
var center=sum / 2.0;
sum=0;
var bin=-1;
for (var i=arr.length - 1; i >= 0; i--) {
sum+=arr[i];
if (sum >= center ) {
bin=i;
break;
}}
return bin;
}, p$1);

Clazz.newMeth(C$, 'getScorePairwiseMapping$I$I$I$I',  function (indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base) {
var score=0;
var simNodePair1=this.getSimilarityNodes$I$I(indexNode1Query, indexNode1Base);
var simNodePair2=this.getSimilarityNodes$I$I(indexNode2Query, indexNode2Base);
var simHists=this.getSimilarityHistogram$I$I$I$I(indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base);
if (this.optimisticHistogramSimilarity) {
if (simHists >= 0.0 ) {
simHists=1.0;
}}if (this.verbose) {
System.out.println$S("simHists " + $I$(6,"format2$Double",[Double.valueOf$D(simHists)]));
}score=simNodePair1 * simNodePair1 * simNodePair2 * simNodePair2 * simHists * simHists ;
return score;
}, p$1);

Clazz.newMeth(C$, 'getSimilarityNodes$I$I',  function (indexNodeQuery, indexNodeBase) {
if (this.arrSimilarityNodes[indexNodeQuery][indexNodeBase] < 0  || this.verbose ) {
var similarity=this.nodeSimilarity.getSimilarity$com_actelion_research_chem_descriptor_flexophore_IPPNode$com_actelion_research_chem_descriptor_flexophore_IPPNode(this.mdhvQueryBlurredHist.getNode$I(indexNodeQuery), this.mdhvBaseBlurredHist.getNode$I(indexNodeBase));
this.arrSimilarityNodes[indexNodeQuery][indexNodeBase]=similarity;
}return this.arrSimilarityNodes[indexNodeQuery][indexNodeBase];
});

Clazz.newMeth(C$, 'getSimilarityHistogram$I$I$I$I',  function (indexNode1Query, indexNode2Query, indexNode1Base, indexNode2Base) {
var indexHistogramQuery=$I$(11).getIndex$I$I$I(indexNode1Query, indexNode2Query, this.nodesQuery);
var indexHistogramBase=$I$(11).getIndex$I$I$I(indexNode1Base, indexNode2Base, this.nodesBase);
if (this.arrSimilarityHistograms[indexHistogramQuery][indexHistogramBase] < 0 ) {
var similarityHistogram=0;
similarityHistogram=$I$(12).getFractionOverlappingBins$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I(this.mdhvQueryBlurredHist, indexNode1Query, indexNode2Query, this.mdhvBaseBlurredHist, indexNode1Base, indexNode2Base);
this.arrSimilarityHistograms[indexHistogramQuery][indexHistogramBase]=similarityHistogram;
}return this.arrSimilarityHistograms[indexHistogramQuery][indexHistogramBase];
});

Clazz.newMeth(C$, 'getSimilarityNodes$com_actelion_research_chem_descriptor_flexophore_IPPNode$com_actelion_research_chem_descriptor_flexophore_IPPNode',  function (query, base) {
return this.nodeSimilarity.getSimilarity$com_actelion_research_chem_descriptor_flexophore_IPPNode$com_actelion_research_chem_descriptor_flexophore_IPPNode(query, base);
});

Clazz.newMeth(C$, 'toStringRecentSimilarityResults$',  function () {
var sb=Clazz.new_($I$(5,1));
sb.append$S("ObjectiveFlexophoreHardMatchUncovered toStringRecentSimilarityResults()");
sb.append$S("avr pairwise mapping " + $I$(6,"format3$Double",[Double.valueOf$D(this.avrPairwiseMappingScaled)]) + "\n" );
sb.append$S("coverage query " + $I$(6,"format3$Double",[Double.valueOf$D(this.coverageQuery)]) + "\n" );
sb.append$S("coverage base " + $I$(6,"format3$Double",[Double.valueOf$D(this.coverageBase)]) + "\n" );
sb.append$S("similarity " + $I$(6,"format3$Double",[Double.valueOf$D(this.similarity)]));
return sb.toString();
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(5,1));
var maSimNodes=Clazz.new_($I$(9,1).c$$FAA,[this.arrSimilarityNodes]);
var rowEnd=-1;
for (var i=0; i < maSimNodes.rows$(); i++) {
if (maSimNodes.get$I$I(i, 0) < 0 ) {
rowEnd=i;
break;
}}
var colEnd=-1;
for (var i=0; i < maSimNodes.cols$(); i++) {
if (maSimNodes.get$I$I(0, i) < 0 ) {
colEnd=i;
break;
}}
for (var i=0; i < rowEnd; i++) {
for (var j=0; j < colEnd; j++) {
sb.append$S($I$(6,"format2$Double",[Double.valueOf$D(maSimNodes.get$I$I(i, j))]));
sb.append$S("  ");
}
sb.append$S("\n");
}
return sb.toString();
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
