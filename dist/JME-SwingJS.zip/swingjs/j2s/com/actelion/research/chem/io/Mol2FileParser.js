(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.text.DecimalFormat','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.AromaticityResolver','java.util.HashMap','java.util.ArrayList','com.actelion.research.chem.Molecule3D','java.util.HashSet','java.util.TreeMap','java.io.LineNumberReader','java.util.StringTokenizer','com.actelion.research.chem.Molecule','java.util.Collections','com.actelion.research.chem.io.AbstractParser']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Mol2FileParser", null, 'com.actelion.research.chem.io.AbstractParser');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isLoadHydrogen=true;
},1);

C$.$fields$=[['Z',['isLoadHydrogen']]
,['O',['NF_PARTIAL_CHARGES','java.text.NumberFormat','hmIndex_CHARGETYPE','java.util.HashMap']]]

Clazz.newMeth(C$, 'addMol$java_util_List$com_actelion_research_chem_Molecule3D$java_util_Set$java_util_Set',  function (res, m, aromaticAtoms, aromaticBonds) {
if (m == null  || m.getAllAtoms$() == 0 ) return;
if (true) {
var mol=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Molecule,[m]);
var bondMap=mol.getHandleHydrogenBondMap$();
var j=0;
Clazz.new_($I$(3,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).locateDelocalizedDoubleBonds$ZA$Z$Z(null, true, true);
for (var i=0; i < mol.getBonds$(); i++) {
m.setBondOrder$I$I(i, mol.getBondOrder$I(bondMap[i]));
}
}p$1.assignCharges$com_actelion_research_chem_Molecule3D.apply(this, [m]);
m.setAllAtomFlag$I$Z(2, true);
res.add$O(m);
}, p$1);

Clazz.newMeth(C$, 'assignCharges$com_actelion_research_chem_Molecule3D',  function (mol) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == 7) if (mol.getOccupiedValence$I(atom) == 4) {
mol.setAtomCharge$I$I(atom, 1);
} else if (mol.getOccupiedValence$I(atom) == 2) {
mol.setAtomCharge$I$I(atom, -1);
}if (mol.getAtomicNo$I(atom) == 8) if (mol.getOccupiedValence$I(atom) == 3) {
mol.setAtomCharge$I$I(atom, 1);
} else if (mol.getOccupiedValence$I(atom) == 1) {
mol.setAtomCharge$I$I(atom, -1);
}if (mol.getAtomicNo$I(atom) == 16) if (mol.getOccupiedValence$I(atom) == 3) {
mol.setAtomCharge$I$I(atom, 1);
} else if (mol.getOccupiedValence$I(atom) == 1) mol.setAtomCharge$I$I(atom, -1);
}
}, p$1);

Clazz.newMeth(C$, 'getChargeType$I',  function (type) {
if (C$.hmIndex_CHARGETYPE == null ) {
C$.hmIndex_CHARGETYPE=Clazz.new_($I$(4,1));
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(0), "NO_CHARGES");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(1), "DEL_RE");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(2), "GASTEIGER");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(3), "GAST_HUCK");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(4), "HUCKEL");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(5), "PULLMAN");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(6), "GAUSS80_CHARGES");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(7), "AMPAC_CHARGES");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(8), "MULLIKEN_CHARGES");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(9), "DICT_CHARGES");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(10), "MMFF94_CHARGES");
C$.hmIndex_CHARGETYPE.put$O$O(Integer.valueOf$I(11), "USER_CHARGES");
}return C$.hmIndex_CHARGETYPE.get$O(Integer.valueOf$I(type));
}, 1);

Clazz.newMeth(C$, 'loadGroup$S$java_io_Reader$I$I',  function (fileName, $in, from, to) {
var res=Clazz.new_($I$(5,1));
var line;
var m=Clazz.new_($I$(6,1));
var aromaticAtoms=Clazz.new_($I$(7,1));
var aromaticBonds=Clazz.new_($I$(7,1));
var nToA=Clazz.new_($I$(8,1));
var reader=Clazz.new_($I$(9,1).c$$java_io_Reader,[$in]);
var state=0;
var lineNo=0;
var count=-1;
while ((line=reader.readLine$()) != null ){
if (line.startsWith$S("@<TRIPOS>")) lineNo=0;
if (line.startsWith$S("@<TRIPOS>MOLECULE")) state=0;
 else if (line.startsWith$S("@<TRIPOS>ATOM")) state=1;
 else if (line.startsWith$S("@<TRIPOS>BOND")) state=2;
 else if (line.startsWith$S("@<TRIPOS>")) state=-1;
 else {
++lineNo;
switch (state) {
case 0:
{
if (lineNo == 1) {
++count;
if (from > count) continue;
if (to >= 0 && to < count ) break;
p$1.addMol$java_util_List$com_actelion_research_chem_Molecule3D$java_util_Set$java_util_Set.apply(this, [res, m, aromaticAtoms, aromaticBonds]);
m=Clazz.new_($I$(6,1));
aromaticAtoms.clear$();
aromaticBonds.clear$();
var molName=line.trim$();
m.setName$S(molName);
}break;
}case 1:
{
try {
var st=Clazz.new_($I$(10,1).c$$S$S,[line, "\t "]);
var n=Integer.parseInt$S(st.nextToken$().trim$());
var atomName=st.nextToken$().trim$();
var x=Double.parseDouble$S(st.nextToken$().trim$());
var y=Double.parseDouble$S(st.nextToken$().trim$());
var z=Double.parseDouble$S(st.nextToken$().trim$());
var atomClass=st.hasMoreTokens$() ? st.nextToken$().trim$() : "";
var chainId=st.hasMoreTokens$() ? st.nextToken$().trim$() : "";
var amino=st.hasMoreTokens$() ? st.nextToken$().trim$() : "";
var charge=st.hasMoreTokens$() ? st.nextToken$().trim$() : "";
var elt=Clazz.new_($I$(10,1).c$$S$S,[atomClass, "."]).nextToken$();
var aromatic=atomClass.endsWith$S(".ar");
var atomicNo=$I$(11).getAtomicNoFromLabel$S(elt);
if (atomicNo < 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["Invalid Atomic Number for " + n + ": " + elt ]);
if (!this.isLoadHydrogen && atomicNo <= 1 ) continue;
var a=m.addAtom$I(atomicNo);
m.setAtomX$I$D(a, x);
m.setAtomY$I$D(a, -y);
m.setAtomZ$I$D(a, -z);
m.setAtomName$I$S(a, atomName);
m.setAtomChainId$I$S(a, chainId);
m.setAtomAmino$I$S(a, amino);
if (aromatic) aromaticAtoms.add$O(Integer.valueOf$I(a));
try {
m.setPartialCharge$I$D(a, Double.parseDouble$S(charge));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
nToA.put$O$O(Integer.valueOf$I(n), Integer.valueOf$I(a));
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
throw Clazz.new_(Clazz.load('Exception').c$$S,["Invalid number at line " + reader.getLineNumber$() + ": " + line ]);
} else {
throw e;
}
}
break;
}case 2:
{
var st=Clazz.new_($I$(10,1).c$$S,[line]);
if (st.countTokens$() < 3) continue;
st.nextToken$();
var n1=Integer.parseInt$S(st.nextToken$());
var n2=Integer.parseInt$S(st.nextToken$());
var o=st.nextToken$();
var i1=nToA.get$O(Integer.valueOf$I(n1));
var i2=nToA.get$O(Integer.valueOf$I(n2));
if (i1 == null  || i2 == null  ) continue;
var order;
if (o.equals$O("ar")) {
order=8;
} else if (o.equals$O("am")) {
order=1;
} else if (o.equals$O("un")) {
continue;
} else if (o.equals$O("nc")) {
continue;
} else if (o.equals$O("du")) {
continue;
} else {
order=Integer.parseInt$S(o);
if (order == 1) {
order=1;
} else if (order == 2) {
order=2;
} else if (order == 3) {
order=4;
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown bond type " + order + "." ]);
}}var a1=i1.intValue$();
var a2=i2.intValue$();
var b=m.addBond$I$I$I(a1, a2, order);
break;
}}
}}
++count;
var bondMap=m.getHandleHydrogenBondMap$();
var atomMap=m.getHandleHydrogenMap$();
var aromaticAtomsMapped=Clazz.new_($I$(7,1));
var aromaticBondsMapped=Clazz.new_($I$(7,1));
aromaticAtoms.stream$().forEach$java_util_function_Consumer(((P$.Mol2FileParser$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "Mol2FileParser$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer','accept$O'],  function (aa) { return (this.$finals$.aromaticAtomsMapped.add$O.apply(this.$finals$.aromaticAtomsMapped, [Integer.valueOf$I(this.$finals$.atomMap[(aa).$c()])]));});
})()
), Clazz.new_(P$.Mol2FileParser$lambda1.$init$,[this, {aromaticAtomsMapped:aromaticAtomsMapped,atomMap:atomMap}])));
aromaticBonds.stream$().forEach$java_util_function_Consumer(((P$.Mol2FileParser$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "Mol2FileParser$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer','accept$O'],  function (ab) { return (this.$finals$.aromaticBondsMapped.add$O.apply(this.$finals$.aromaticBondsMapped, [Integer.valueOf$I(this.$finals$.bondMap[(ab).$c()])]));});
})()
), Clazz.new_(P$.Mol2FileParser$lambda2.$init$,[this, {aromaticBondsMapped:aromaticBondsMapped,bondMap:bondMap}])));
if (from > count) {
} else if (to >= 0 && to < count ) {
} else {
m.ensureHelperArrays$I(7);
p$1.addMol$java_util_List$com_actelion_research_chem_Molecule3D$java_util_Set$java_util_Set.apply(this, [res, m, aromaticAtoms, aromaticBonds]);
}return res;
});

Clazz.newMeth(C$, 'save$com_actelion_research_chem_Molecule3D$java_io_Writer',  function (mol, writer) {
this.save$java_util_List$java_io_Writer($I$(12).singletonList$O(mol), writer);
});

Clazz.newMeth(C$, 'save$java_util_List$java_io_Writer',  function (mols, writer) {
this.save$java_util_List$I$java_io_Writer(mols, 0, writer);
});

Clazz.newMeth(C$, 'save$java_util_List$I$java_io_Writer',  function (mols, chargeType, writer) {
var df=Clazz.new_($I$(1,1).c$$S,["0.0000"]);
for (var mol, $mol = mols.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var nAtoms=0;
var nBonds=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) <= 0) continue;
++nAtoms;
}
for (var i=0; i < mol.getAllBonds$(); i++) {
if (mol.getAtomicNo$I(mol.getBondAtom$I$I(0, i)) <= 0) continue;
if (mol.getAtomicNo$I(mol.getBondAtom$I$I(1, i)) <= 0) continue;
++nBonds;
}
writer.write$S("@<TRIPOS>MOLECULE" + $I$(13).NEWLINE);
writer.write$S(mol.getName$() + $I$(13).NEWLINE);
$I$(13).writeR$java_io_Writer$S$I(writer, "" + nAtoms, 5);
$I$(13).writeR$java_io_Writer$S$I(writer, "" + nBonds, 6);
writer.write$S($I$(13).NEWLINE);
writer.write$S("SMALL" + $I$(13).NEWLINE);
writer.write$S(C$.getChargeType$I(chargeType) + $I$(13).NEWLINE);
writer.write$S("@<TRIPOS>ATOM" + $I$(13).NEWLINE);
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) <= 0) continue;
$I$(13,"writeR$java_io_Writer$S$I",[writer, "" + (i + 1), 7]);
writer.write$S(" ");
var desc=mol.getAtomName$I(i);
if (desc == null  || desc.length$() == 0 ) {
desc="" + $I$(11).cAtomLabel[mol.getAtomicNo$I(i)];
}$I$(13).writeL$java_io_Writer$S$I(writer, desc, 8);
$I$(13,"writeR$java_io_Writer$S$I",[writer, df.format$D(mol.getAtomX$I(i)), 10]);
$I$(13,"writeR$java_io_Writer$S$I",[writer, df.format$D(mol.getAtomY$I(i)), 10]);
$I$(13,"writeR$java_io_Writer$S$I",[writer, df.format$D(mol.getAtomZ$I(i)), 10]);
writer.write$S(" ");
$I$(13,"writeL$java_io_Writer$S$I",[writer, $I$(11).cAtomLabel[mol.getAtomicNo$I(i)] + (mol.isAromaticAtom$I(i) ? ".ar" : ""), 8]);
$I$(13,"writeR$java_io_Writer$S$I",[writer, mol.getAtomChainId$I(i) != null  && mol.getAtomChainId$I(i).length$() > 0  ? mol.getAtomChainId$I(i) : "1", 5]);
writer.write$S("  ");
$I$(13,"writeL$java_io_Writer$S$I",[writer, mol.getAtomAmino$I(i) != null  && mol.getAtomAmino$I(i).length$() > 0  ? mol.getAtomAmino$I(i) : "1", 11]);
writer.write$S(C$.NF_PARTIAL_CHARGES.format$D(mol.getPartialCharge$I(i)));
writer.write$S($I$(13).NEWLINE);
}
writer.write$S("@<TRIPOS>BOND" + $I$(13).NEWLINE);
for (var i=0; i < mol.getAllBonds$(); i++) {
if (mol.getAtomicNo$I(mol.getBondAtom$I$I(0, i)) <= 0) continue;
if (mol.getAtomicNo$I(mol.getBondAtom$I$I(1, i)) <= 0) continue;
$I$(13,"writeR$java_io_Writer$S$I",[writer, "" + (i + 1), 6]);
$I$(13,"writeR$java_io_Writer$S$I",[writer, "" + (mol.getBondAtom$I$I(0, i) + 1), 5]);
$I$(13,"writeR$java_io_Writer$S$I",[writer, "" + (mol.getBondAtom$I$I(1, i) + 1), 5]);
writer.write$S(" ");
$I$(13,"writeL$java_io_Writer$S$I",[writer, "" + mol.getBondOrder$I(i), 5]);
writer.write$S($I$(13).NEWLINE);
}
}
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var res=Clazz.new_(C$).loadGroup$S("c:/mopac11971.mol2");
System.out.println$S("models=" + res.size$() + " atm=" + res.get$I(0).getAllAtoms$() + " " + res.get$I(0).getAtoms$() );
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.NF_PARTIAL_CHARGES=Clazz.new_($I$(1,1).c$$S,[" 0.0000;-0.0000"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
