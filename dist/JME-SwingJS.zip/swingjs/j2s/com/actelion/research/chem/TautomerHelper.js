(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.util.IntArrayComparator','com.actelion.research.chem.Molecule','com.actelion.research.chem.Canonizer','java.util.TreeSet','java.util.ArrayDeque',['com.actelion.research.chem.TautomerHelper','.BondOrders'],'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TautomerHelper", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['BondOrders',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mRegionCount'],'O',['mOriginalMol','com.actelion.research.chem.StereoMolecule','mIsTautomerBond','boolean[]','+mHasFreeValence','mRegionPiCount','int[]','+mRegionDCount','+mRegionTCount','+mAtomRegionNo','+mAtomDCount','+mAtomTCount','mBondOrderIterator','java.util.Iterator','mBondOrderSet','java.util.TreeSet','mBondOrderDeque','java.util.ArrayDeque']]
,['Z',['sSuppressWarning'],'I',['sMaxTautomers']]]

Clazz.newMeth(C$, 'setMaxTautomers$I',  function (maxTautomers) {
C$.sMaxTautomers=maxTautomers;
}, 1);

Clazz.newMeth(C$, 'setSuppressWarning$Z',  function (suppressWarning) {
C$.sSuppressWarning=suppressWarning;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mOriginalMol=mol.getCompactCopy$();
p$1.moveDeuteriumAndTritiumToTableEnd.apply(this, []);
this.mOriginalMol.ensureHelperArrays$I(7);
this.mIsTautomerBond=Clazz.array(Boolean.TYPE, [this.mOriginalMol.getBonds$()]);
this.mHasFreeValence=Clazz.array(Boolean.TYPE, [this.mOriginalMol.getAtoms$()]);
for (var i=0; i < this.mOriginalMol.getAtoms$(); i++) {
var valence=$I$(2,"getAllowedValences$I",[this.mOriginalMol.getAtomicNo$I(i)])[0];
this.mHasFreeValence[i]=(this.mOriginalMol.getNonHydrogenNeighbourCount$I(i) < valence);
}
p$1.createAllTautomers.apply(this, []);
p$1.assignRegionNumbers.apply(this, []);
p$1.countAndRemoveDAndT.apply(this, []);
p$1.compileRegionCounts.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'getNextTautomer$com_actelion_research_chem_StereoMolecule',  function (tautomer) {
if (this.mBondOrderIterator == null ) this.mBondOrderIterator=this.mBondOrderSet.iterator$();
if (!this.mBondOrderIterator.hasNext$()) return null;
if (tautomer != null ) {
tautomer.clear$();
this.mOriginalMol.copyMolecule$com_actelion_research_chem_Molecule(tautomer);
} else {
tautomer=this.mOriginalMol.getCompactCopy$();
}this.mBondOrderIterator.next$().copyToTautomer$com_actelion_research_chem_StereoMolecule(tautomer);
if (this.mAtomDCount != null  || this.mAtomTCount != null  ) {
tautomer.ensureHelperArrays$I(1);
var freeValence=Clazz.array(Integer.TYPE, [tautomer.getAtoms$()]);
for (var atom=0; atom < tautomer.getAtoms$(); atom++) freeValence[atom]=tautomer.getFreeValence$I(atom);

if (this.mAtomDCount != null ) {
var regionDCount=this.mRegionDCount.clone$();
for (var atom=0; atom < tautomer.getAtoms$(); atom++) {
var dCount=Math.min(freeValence[atom], this.mAtomDCount[atom]);
for (var i=0; i < dCount; i++) {
p$1.addHydrogen$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [tautomer, atom, 2]);
--freeValence[atom];
--regionDCount[this.mAtomRegionNo[atom] - 1];
}
}
for (var atom=0; atom < tautomer.getAtoms$(); atom++) {
if (this.mAtomRegionNo[atom] != 0 && regionDCount[this.mAtomRegionNo[atom] - 1] > 0  && tautomer.getAtomPi$I(atom) < this.mOriginalMol.getAtomPi$I(atom)  && freeValence[atom] != 0 ) {
p$1.addHydrogen$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [tautomer, atom, 2]);
--freeValence[atom];
--regionDCount[this.mAtomRegionNo[atom] - 1];
}}
}if (this.mAtomTCount != null ) {
var regionTCount=this.mRegionTCount.clone$();
for (var atom=0; atom < tautomer.getAtoms$(); atom++) {
var tCount=Math.min(freeValence[atom], this.mAtomTCount[atom]);
for (var i=0; i < tCount; i++) {
p$1.addHydrogen$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [tautomer, atom, 3]);
--freeValence[atom];
--regionTCount[this.mAtomRegionNo[atom] - 1];
}
}
for (var atom=0; atom < tautomer.getAtoms$(); atom++) {
if (this.mAtomRegionNo[atom] != 0 && regionTCount[this.mAtomRegionNo[atom] - 1] > 0  && tautomer.getAtomPi$I(atom) < this.mOriginalMol.getAtomPi$I(atom)  && freeValence[atom] != 0 ) {
p$1.addHydrogen$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [tautomer, atom, 3]);
--freeValence[atom];
--regionTCount[this.mAtomRegionNo[atom] - 1];
}}
}}tautomer.ensureHelperArrays$I(15);
for (var bond=0; bond < tautomer.getBonds$(); bond++) if (tautomer.getBondType$I(bond) == 386 && tautomer.getBondParity$I(bond) == 0 ) tautomer.setBondType$I$I(bond, 2);

return tautomer;
});

Clazz.newMeth(C$, 'moveDeuteriumAndTritiumToTableEnd',  function () {
this.mOriginalMol.ensureHelperArrays$I(1);
var lastNonHAtom=this.mOriginalMol.getAtoms$();
do --lastNonHAtom;
 while ((lastNonHAtom >= 0) && this.mOriginalMol.getAtomicNo$I(lastNonHAtom) == 1 );
for (var atom=0; atom < lastNonHAtom; atom++) {
if (this.mOriginalMol.getAtomicNo$I(atom) == 1) {
this.mOriginalMol.swapAtoms$I$I(atom, lastNonHAtom);
do --lastNonHAtom;
 while (this.mOriginalMol.getAtomicNo$I(lastNonHAtom) == 1);
}}
if (lastNonHAtom == this.mOriginalMol.getAtoms$() - 1) return;
var isHydrogenBond=Clazz.array(Boolean.TYPE, [this.mOriginalMol.getBonds$()]);
for (var bond=0; bond < this.mOriginalMol.getBonds$(); bond++) {
var atom1=this.mOriginalMol.getBondAtom$I$I(0, bond);
var atom2=this.mOriginalMol.getBondAtom$I$I(1, bond);
if (this.mOriginalMol.getAtomicNo$I(atom1) == 1 || this.mOriginalMol.getAtomicNo$I(atom2) == 1 ) isHydrogenBond[bond]=true;
}
var lastNonHBond=this.mOriginalMol.getBonds$();
do --lastNonHBond;
 while ((lastNonHBond >= 0) && isHydrogenBond[lastNonHBond] );
for (var bond=0; bond < lastNonHBond; bond++) {
if (isHydrogenBond[bond]) {
this.mOriginalMol.swapBonds$I$I(bond, lastNonHBond);
isHydrogenBond[bond]=false;
do --lastNonHBond;
 while (isHydrogenBond[lastNonHBond]);
}}
}, p$1);

Clazz.newMeth(C$, 'addHydrogen$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, atom, mass) {
var hydrogen=mol.addAtom$I(1);
mol.setAtomMass$I$I(hydrogen, mass);
mol.addBond$I$I$I(atom, hydrogen, 1);
}, p$1);

Clazz.newMeth(C$, 'getTautomerCount$',  function () {
return this.mBondOrderSet.size$();
});

Clazz.newMeth(C$, 'countAndRemoveDAndT',  function () {
for (var bond=0; bond < this.mOriginalMol.getAllBonds$(); bond++) {
for (var i=0; i < 2; i++) {
var atom1=this.mOriginalMol.getBondAtom$I$I(i, bond);
var atom2=this.mOriginalMol.getBondAtom$I$I(1 - i, bond);
if (this.mOriginalMol.getAtomicNo$I(atom1) == 1 && this.mOriginalMol.getAtomMass$I(atom1) > 1  && this.mOriginalMol.getAtomicNo$I(atom2) > 1  && this.mAtomRegionNo[atom2] != 0 ) {
if (this.mOriginalMol.getAtomMass$I(atom1) == 2) {
if (this.mAtomDCount == null ) this.mAtomDCount=Clazz.array(Integer.TYPE, [this.mOriginalMol.getAllAtoms$()]);
++this.mAtomDCount[atom2];
} else {
if (this.mAtomTCount == null ) this.mAtomTCount=Clazz.array(Integer.TYPE, [this.mOriginalMol.getAllAtoms$()]);
++this.mAtomTCount[atom2];
}this.mOriginalMol.markAtomForDeletion$I(atom1);
}}
}
if (this.mAtomDCount != null  || this.mAtomTCount != null  ) this.mOriginalMol.deleteMarkedAtomsAndBonds$();
}, p$1);

Clazz.newMeth(C$, 'getAtomRegionCount$',  function () {
return this.mRegionCount;
});

Clazz.newMeth(C$, 'getAtomRegionNumbers$',  function () {
return this.mAtomRegionNo;
});

Clazz.newMeth(C$, 'assignRegionNumbers',  function () {
this.mAtomRegionNo=Clazz.array(Integer.TYPE, [this.mOriginalMol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [this.mOriginalMol.getAtoms$()]);
var bondWasSeen=Clazz.array(Boolean.TYPE, [this.mOriginalMol.getBonds$()]);
var region=0;
for (var bond=0; bond < this.mOriginalMol.getBonds$(); bond++) {
if (!bondWasSeen[bond] && this.mIsTautomerBond[bond] ) {
++region;
this.mAtomRegionNo[this.mOriginalMol.getBondAtom$I$I(0, bond)]=region;
this.mAtomRegionNo[this.mOriginalMol.getBondAtom$I$I(1, bond)]=region;
bondWasSeen[bond]=true;
for (var i=0; i < 2; i++) {
var atom=this.mOriginalMol.getBondAtom$I$I(i, bond);
this.mAtomRegionNo[atom]=region;
var current=0;
var highest=0;
graphAtom[0]=atom;
while (current <= highest){
for (var j=0; j < this.mOriginalMol.getConnAtoms$I(graphAtom[current]); j++) {
var connBond=this.mOriginalMol.getConnBond$I$I(graphAtom[current], j);
if (!bondWasSeen[connBond] && this.mIsTautomerBond[connBond] ) {
bondWasSeen[connBond]=true;
var connAtom=this.mOriginalMol.getConnAtom$I$I(graphAtom[current], j);
if (this.mAtomRegionNo[connAtom] == 0) {
this.mAtomRegionNo[connAtom]=region;
graphAtom[++highest]=connAtom;
}}}
++current;
}
}
}}
this.mRegionCount=region;
}, p$1);

Clazz.newMeth(C$, 'compileRegionCounts',  function () {
this.mRegionPiCount=Clazz.array(Integer.TYPE, [this.mRegionCount]);
this.mRegionDCount=Clazz.array(Integer.TYPE, [this.mRegionCount]);
this.mRegionTCount=Clazz.array(Integer.TYPE, [this.mRegionCount]);
for (var atom=0; atom < this.mOriginalMol.getAtoms$(); atom++) {
if (this.mAtomRegionNo[atom] != 0) {
var regionIndex=this.mAtomRegionNo[atom] - 1;
if (this.mAtomDCount != null ) this.mRegionDCount[regionIndex]+=this.mAtomDCount[atom];
if (this.mAtomTCount != null ) this.mRegionTCount[regionIndex]+=this.mAtomTCount[atom];
}}
for (var bond=0; bond < this.mOriginalMol.getBonds$(); bond++) {
if (this.mIsTautomerBond[bond] && this.mOriginalMol.getBondOrder$I(bond) == 2 ) {
this.mRegionPiCount[this.mAtomRegionNo[this.mOriginalMol.getBondAtom$I$I(0, bond)] - 1]+=2;
}}
}, p$1);

Clazz.newMeth(C$, 'hasAcidicHydrogen$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAllHydrogens$I(atom) <= 0) return false;
if (mol.isElectronegative$I(atom)) return true;
if (mol.getAtomPi$I(atom) != 0) return false;
return true;
}, p$1);

Clazz.newMeth(C$, 'createGenericTautomer$',  function () {
if (this.mBondOrderSet.size$() == 1) return this.mOriginalMol;
var mol=this.mOriginalMol.getCompactCopy$();
mol.setFragment$Z(true);
mol.ensureHelperArrays$I(7);
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (this.mIsTautomerBond[bond]) {
mol.setBondType$I$I(bond, 1);
mol.setBondQueryFeature$I$I$Z(bond, 3, true);
}}
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (this.mAtomRegionNo[atom] != 0 && this.mOriginalMol.getNonHydrogenNeighbourCount$I(atom) < 4 ) {
mol.convertStereoBondsToSingleBonds$I(atom);
mol.setAtomConfigurationUnknown$I$Z(atom, false);
mol.setAtomESR$I$I$I(atom, 0, -1);
}}
var maxAtom=Clazz.array(Integer.TYPE, [this.mRegionCount]);
var maxRank=Clazz.array(Integer.TYPE, [this.mRegionCount]);
var atomRank=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).getFinalRank$();
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (this.mAtomRegionNo[atom] != 0) {
var regionIndex=this.mAtomRegionNo[atom] - 1;
if (maxRank[regionIndex] < atomRank[atom]) {
maxRank[regionIndex]=atomRank[atom];
maxAtom[regionIndex]=atom;
}}}
for (var i=0; i < this.mRegionCount; i++) {
var label="" + this.mRegionPiCount[i] + "|" + this.mRegionDCount[i] + "|" + this.mRegionTCount[i] ;
mol.setAtomCustomLabel$I$S(maxAtom[i], label);
}
return mol;
});

Clazz.newMeth(C$, 'createAllTautomers',  function () {
this.mBondOrderSet=Clazz.new_($I$(4,1));
this.mBondOrderDeque=Clazz.new_($I$(5,1));
p$1.addTautomerIfNew$com_actelion_research_chem_TautomerHelper_BondOrders.apply(this, [Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[this, null, this.mOriginalMol])]);
var tautomer=this.mOriginalMol.getCompactCopy$();
while (!this.mBondOrderDeque.isEmpty$()){
this.mBondOrderDeque.poll$().copyToTautomer$com_actelion_research_chem_StereoMolecule(tautomer);
p$1.addAllTautomers$com_actelion_research_chem_StereoMolecule.apply(this, [tautomer]);
if (this.mBondOrderSet.size$() >= C$.sMaxTautomers) {
if (!C$.sSuppressWarning) System.out.println$S("Tautomer count exceeds maximum: " + Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[this.mOriginalMol]).getIDCode$());
break;
}}
}, p$1);

Clazz.newMeth(C$, 'addAllTautomers$com_actelion_research_chem_StereoMolecule',  function (mol) {
var bondList=Clazz.new_($I$(7,1));
mol.ensureHelperArrays$I(1);
var isUsedAtom=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var atom1=0; atom1 < mol.getAtoms$(); atom1++) {
if (p$1.isValidHeteroAtom$I.apply(this, [atom1])) {
isUsedAtom[atom1]=true;
for (var i=0; i < mol.getConnAtoms$I(atom1); i++) {
var atom2=mol.getConnAtom$I$I(atom1, i);
var bond12=mol.getConnBond$I$I(atom1, i);
var order12=mol.getConnBondOrder$I$I(atom1, i);
if (mol.getAtomPi$I(atom2) != 0 && mol.getAtomPi$I(atom1) < order12 ) {
isUsedAtom[atom2]=true;
bondList.add$O(Integer.valueOf$I(bond12));
for (var j=0; j < mol.getConnAtoms$I(atom2); j++) {
var atom3=mol.getConnAtom$I$I(atom2, j);
if (!isUsedAtom[atom3]) {
isUsedAtom[atom3]=true;
var bond23=mol.getConnBond$I$I(atom2, j);
var order23=mol.getConnBondOrder$I$I(atom2, j);
if (mol.getAtomPi$I(atom2) + 2 == order12 + order23) {
bondList.add$O(Integer.valueOf$I(bond23));
if (order12 >= order23) {
if (mol.getAtomPi$I(atom3) < order23) {
if (p$1.hasAcidicHydrogen$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom3])) p$1.addVinylogousTautomers$com_actelion_research_chem_StereoMolecule$I$Z$Z$ZA$java_util_ArrayList.apply(this, [mol, atom3, true, false, isUsedAtom, bondList]);
} else {
p$1.addVinylogousTautomers$com_actelion_research_chem_StereoMolecule$I$Z$Z$ZA$java_util_ArrayList.apply(this, [mol, atom3, true, true, isUsedAtom, bondList]);
}}if (order23 >= order12 && p$1.hasAcidicHydrogen$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom1]) ) {
p$1.addVinylogousTautomers$com_actelion_research_chem_StereoMolecule$I$Z$Z$ZA$java_util_ArrayList.apply(this, [mol, atom3, false, false, isUsedAtom, bondList]);
}if (p$1.isValidDonorAtom$I.apply(this, [atom3]) && mol.getAtomPi$I(atom3) < order23 ) {
if (order12 <= 2 && order23 >= 2  && p$1.hasAcidicHydrogen$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom1]) ) {
p$1.addDirectTautomer$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [mol, bond12, bond23]);
}if (order12 >= 2 && order23 <= 2  && p$1.hasAcidicHydrogen$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom3]) ) {
p$1.addDirectTautomer$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [mol, bond23, bond12]);
}}bondList.remove$I(bondList.size$() - 1);
}isUsedAtom[atom3]=false;
}}
bondList.remove$I(bondList.size$() - 1);
isUsedAtom[atom2]=false;
}}
isUsedAtom[atom1]=false;
}}
}, p$1);

Clazz.newMeth(C$, 'isValidDonorAtom$I',  function (atom) {
return this.mHasFreeValence[atom] && (this.mOriginalMol.getAtomicNo$I(atom) == 5 || this.mOriginalMol.getAtomicNo$I(atom) == 6  || this.mOriginalMol.getAtomicNo$I(atom) == 7  || this.mOriginalMol.getAtomicNo$I(atom) == 8  || this.mOriginalMol.getAtomicNo$I(atom) == 16  || this.mOriginalMol.getAtomicNo$I(atom) == 34  || this.mOriginalMol.getAtomicNo$I(atom) == 52 ) ;
}, p$1);

Clazz.newMeth(C$, 'isValidHeteroAtom$I',  function (atom) {
return this.mHasFreeValence[atom] && (this.mOriginalMol.getAtomicNo$I(atom) == 7 || this.mOriginalMol.getAtomicNo$I(atom) == 8  || this.mOriginalMol.getAtomicNo$I(atom) == 16  || this.mOriginalMol.getAtomicNo$I(atom) == 34  || this.mOriginalMol.getAtomicNo$I(atom) == 52 ) ;
}, p$1);

Clazz.newMeth(C$, 'addDirectTautomer$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, bondSToD, bondDToS) {
var bondOrders=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[this, null, mol]);
bondOrders.setBond$I$I(bondSToD, mol.getBondOrder$I(bondSToD) == 1 ? 2 : 3);
bondOrders.setBond$I$I(bondDToS, mol.getBondOrder$I(bondDToS) == 2 ? 1 : 2);
this.mIsTautomerBond[bondSToD]=true;
this.mIsTautomerBond[bondDToS]=true;
p$1.addTautomerIfNew$com_actelion_research_chem_TautomerHelper_BondOrders.apply(this, [bondOrders]);
}, p$1);

Clazz.newMeth(C$, 'addVinylogousTautomers$com_actelion_research_chem_StereoMolecule$I$Z$Z$ZA$java_util_ArrayList',  function (mol, atom1, firstBondIsDouble, thirdBondIsDouble, isUsedAtom, bondList) {
for (var i=0; i < mol.getConnAtoms$I(atom1); i++) {
var atom2=mol.getConnAtom$I$I(atom1, i);
if (!isUsedAtom[atom2]) {
var bond12=mol.getConnBond$I$I(atom1, i);
var order12=mol.getBondOrder$I(bond12);
if ((firstBondIsDouble && order12 >= 2 ) || (!firstBondIsDouble && order12 <= 2 ) ) {
isUsedAtom[atom2]=true;
bondList.add$O(Integer.valueOf$I(bond12));
for (var j=0; j < mol.getConnAtoms$I(atom2); j++) {
var atom3=mol.getConnAtom$I$I(atom2, j);
if (!isUsedAtom[atom3]) {
var bond23=mol.getConnBond$I$I(atom2, j);
var order23=mol.getBondOrder$I(bond23);
if (mol.getAtomPi$I(atom2) + 2 == order12 + order23 && ((firstBondIsDouble && order23 <= 2 ) || (!firstBondIsDouble && order23 >= 2 ) ) ) {
isUsedAtom[atom3]=true;
bondList.add$O(Integer.valueOf$I(bond23));
if (p$1.isValidDonorAtom$I.apply(this, [atom3]) && (!firstBondIsDouble || p$1.hasAcidicHydrogen$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom3]) ) ) {
var bondOrders=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[this, null, mol]);
for (var k=0; k < bondList.size$(); k++) {
var bond=(bondList.get$I(k)).$c();
var makeDouble=(k < 2) ? (!!(firstBondIsDouble ^ (k & 1) == 0)) : (!!(thirdBondIsDouble ^ (k & 1) == 0));
if (makeDouble) bondOrders.setBond$I$I(bond, mol.getBondOrder$I(bond) == 1 ? 2 : 3);
 else bondOrders.setBond$I$I(bond, mol.getBondOrder$I(bond) == 2 ? 1 : 2);
this.mIsTautomerBond[bond]=true;
}
p$1.addTautomerIfNew$com_actelion_research_chem_TautomerHelper_BondOrders.apply(this, [bondOrders]);
} else {
p$1.addVinylogousTautomers$com_actelion_research_chem_StereoMolecule$I$Z$Z$ZA$java_util_ArrayList.apply(this, [mol, atom3, firstBondIsDouble, thirdBondIsDouble, isUsedAtom, bondList]);
}bondList.remove$I(bondList.size$() - 1);
isUsedAtom[atom3]=false;
}}}
bondList.remove$I(bondList.size$() - 1);
isUsedAtom[atom2]=false;
}}}
return false;
}, p$1);

Clazz.newMeth(C$, 'addTautomerIfNew$com_actelion_research_chem_TautomerHelper_BondOrders',  function (bondOrders) {
if (this.mBondOrderSet.add$O(bondOrders)) this.mBondOrderDeque.add$O(bondOrders);
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.sMaxTautomers=100000;
C$.sSuppressWarning=false;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.TautomerHelper, "BondOrders", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['encoding','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.encoding=Clazz.array(Integer.TYPE, [((this.b$['com.actelion.research.chem.TautomerHelper'].mOriginalMol.getBonds$() + 15)/16|0)]);
for (var i=0; i < this.b$['com.actelion.research.chem.TautomerHelper'].mOriginalMol.getBonds$(); i++) this.encoding[i >> 4]|=(Math.min(3, mol.getBondOrder$I(i)) << (2 * (i & 15)));

}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_TautomerHelper_BondOrders','compareTo$O'],  function (o) {
return Clazz.new_($I$(1,1)).compare$IA$IA(this.encoding, o.encoding);
});

Clazz.newMeth(C$, 'setBond$I$I',  function (bond, order) {
var high=bond >> 4;
var shift=2 * (bond & 15);
this.encoding[high]&=~(3 << shift);
this.encoding[high]|=(order << shift);
});

Clazz.newMeth(C$, 'copyToTautomer$com_actelion_research_chem_StereoMolecule',  function (tautomer) {
for (var i=0; i < this.b$['com.actelion.research.chem.TautomerHelper'].mOriginalMol.getBonds$(); i++) {
if (this.b$['com.actelion.research.chem.TautomerHelper'].mIsTautomerBond[i]) {
var bo=3 & (this.encoding[i >> 4] >> (2 * (i & 15)));
tautomer.setBondType$I$I(i, bo == 1 ? 1 : bo == 2 ? (this.b$['com.actelion.research.chem.TautomerHelper'].mIsTautomerBond[i] && !this.b$['com.actelion.research.chem.TautomerHelper'].mOriginalMol.isSmallRingBond$I(i)  ? 386 : 2) : bo == 3 ? 4 : 16);
}}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
