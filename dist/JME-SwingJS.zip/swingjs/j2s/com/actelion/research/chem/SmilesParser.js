(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},p$2={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.SmilesAtomParser',['com.actelion.research.chem.SmilesParser','.THParity','.ParityNeighbour'],'com.actelion.research.util.StringFunctions','com.actelion.research.chem.StereoMolecule','com.actelion.research.util.ArrayUtils','com.actelion.research.chem.reaction.Reaction',['com.actelion.research.chem.SmilesParser','.EnumerationPosition'],'java.util.Arrays','java.util.HashMap','java.util.BitSet','java.util.TreeMap',['com.actelion.research.chem.SmilesParser','.THParity'],'com.actelion.research.chem.Molecule','com.actelion.research.chem.coords.CoordinateInventor','StringBuilder','com.actelion.research.chem.RingCollection','com.actelion.research.chem.IsomericSmilesCreator','com.actelion.research.chem.Canonizer','com.actelion.research.chem.ExtendedMoleculeFunctions']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SmilesParser", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['EnumerationPosition',2],['THParity',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mCreateSmartsWarnings','mMakeHydrogenExplicit','mSingleDotSeparator','mSmartsFeatureFound'],'I',['mMode','mSmartsMode','mAromaticAtoms','mAromaticBonds','mCoordinateMode'],'J',['mRandomSeed'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mIsAromaticBond','boolean[]','mSmartsWarningBuffer','StringBuilder','mEnumerationPositionList','java.util.ArrayList','mapConnectionBonds','java.util.Map','bsAtomHasConnections','java.util.BitSet','mol2SmilesMap','int[]','smiles','byte[]']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (mode) {
;C$.$init$.apply(this);
this.mMode=mode & ~3;
this.mSmartsMode=mode & 3;
this.mSingleDotSeparator=(mode & 32) != 0;
this.mCreateSmartsWarnings=(mode & 64) != 0;
this.mMakeHydrogenExplicit=((mode & 8) != 0);
this.mCoordinateMode=2;
if ((mode & 4) != 0) this.mCoordinateMode|=1;
if (this.mMakeHydrogenExplicit) this.mCoordinateMode&=~2;
}, 1);

Clazz.newMeth(C$, 'setRandomSeed$J',  function (seed) {
this.mRandomSeed=seed;
});

Clazz.newMeth(C$, 'parseMolecule$S',  function (smiles) {
return smiles == null  ? null : this.parseMolecule$BA($I$(4).getBytes$S(smiles));
});

Clazz.newMeth(C$, 'parseMolecule$BA',  function (smiles) {
var mol=Clazz.new_($I$(5,1));
try {
this.parse$com_actelion_research_chem_StereoMolecule$BA(mol, smiles);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
return mol;
});

Clazz.newMeth(C$, 'isReactionSmiles$BA',  function (smiles) {
return C$.isReactionSmiles$BA$IA(smiles, null);
}, 1);

Clazz.newMeth(C$, 'isReactionSmiles$BA$IA',  function (smiles, catalystCountHolder) {
var count=0;
var index=-1;
while (count < 3){
index=$I$(6).indexOf$BA$B$I(smiles, 62, index + 1);
while (index > 0 && smiles[index - 1] == 45 )index=$I$(6).indexOf$BA$B$I(smiles, 62, index + 1);

if (index == -1) break;
++count;
if (catalystCountHolder != null  && count == 1 ) {
catalystCountHolder[0]=0;
if (index + 1 < smiles.length && smiles[index + 1] != 62  ) {
catalystCountHolder[0]=1;
for (var i=index + 1; i < smiles.length && (smiles[i] != 62  || smiles[i - 1] == 45  ) ; i++) if (smiles[i] == 46  && smiles[i - 1] != 46  ) ++catalystCountHolder[0];

}}}
return count == 2;
}, 1);

Clazz.newMeth(C$, 'parseReaction$S',  function (smiles) {
return smiles == null  ? null : this.parseReaction$BA($I$(4).getBytes$S(smiles));
});

Clazz.newMeth(C$, 'parseReaction$BA',  function (smiles) {
var index1=$I$(6).indexOf$BA$B(smiles, 62);
while (index1 > 0 && smiles[index1 - 1] == 45 )index1=$I$(6).indexOf$BA$B$I(smiles, 62, index1 + 1);

var index2=(index1 == -1) ? -1 : $I$(6).indexOf$BA$B$I(smiles, 62, index1 + 1);
while (index2 > 0 && smiles[index2 - 1] == 45 )index2=$I$(6).indexOf$BA$B$I(smiles, 62, index2 + 1);

if (index2 == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["Missing one or both separators (\'>\')."]);
if ($I$(6).indexOf$BA$B$I(smiles, 62, index2 + 1) != -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["Found more than 2 separators (\'>\')."]);
var rxn=Clazz.new_($I$(7,1));
var part=0;
var index=0;
var closingGroupBracketIndex=-1;
while (index < smiles.length){
while (index < smiles.length && smiles[index] == 46  )++index;

if (smiles[index] == 40 ) {
if (closingGroupBracketIndex != -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["Second open group bracket found before closing first one."]);
++index;
var level=0;
for (var i=index; i < smiles.length; i++) {
if (smiles[i] == 40 ) {
++level;
} else if (smiles[i] == 41 ) {
if (level-- == 0) {
closingGroupBracketIndex=i;
break;
}}}
}var end=index;
while (end < smiles.length && smiles[end] != 62   && !(smiles[end] == 46  && ((this.mSingleDotSeparator && closingGroupBracketIndex == -1 ) || closingGroupBracketIndex == end - 1  || end + 1 == smiles.length  || smiles[end + 1] == 46  ) ) )++end;

var molend=end;
if (closingGroupBracketIndex == end - 1) {
--molend;
closingGroupBracketIndex=-1;
}if (index != molend) {
var mol=Clazz.new_($I$(5,1));
this.parse$com_actelion_research_chem_StereoMolecule$BA$I$I(mol, smiles, index, molend);
if (this.mSmartsMode == 1 && this.mSmartsFeatureFound ) return Clazz.new_(C$.c$$I,[this.mMode | 2]).parseReaction$BA(smiles);
if (part == 0) rxn.addReactant$com_actelion_research_chem_StereoMolecule(mol);
 else if (part == 1) rxn.addCatalyst$com_actelion_research_chem_StereoMolecule(mol);
 else rxn.addProduct$com_actelion_research_chem_StereoMolecule(mol);
}index=end;
while (index < smiles.length && smiles[index] == 62  ){
++index;
++part;
}
}
return rxn;
});

Clazz.newMeth(C$, 'getEnumerationPositionList$',  function () {
return this.mEnumerationPositionList;
});

Clazz.newMeth(C$, 'setEnumerationPositionList$java_util_ArrayList',  function (l) {
this.mEnumerationPositionList=l;
});

Clazz.newMeth(C$, 'enumerateSmarts$S',  function (smarts) {
this.mEnumerationPositionList=Clazz.new_($I$(1,1));
this.mSmartsMode=2;
this.mMode|=128;
var smartsList=Clazz.new_($I$(1,1));
smartsList.add$O(smarts);
try {
this.parse$com_actelion_research_chem_StereoMolecule$S(Clazz.new_($I$(5,1)), smarts);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S(e.getMessage$());
} else {
throw e;
}
}
var options=this.mEnumerationPositionList.toArray$OA(Clazz.array($I$(8), [0]));
$I$(9).sort$OA(options);
for (var option, $option = 0, $$option = options; $option<$$option.length&&((option=($$option[$option])),1);$option++) {
var enumeration=Clazz.new_($I$(1,1));
for (var s, $s = smartsList.iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) option.enumerate$com_actelion_research_chem_SmilesParser$BA$java_util_ArrayList(this, $I$(4).getBytes$S(s), enumeration);

smartsList=enumeration;
}
return smartsList.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'getSmartsWarning$',  function () {
return this.mSmartsWarningBuffer == null  ? "" : "Unresolved SMARTS features:" + this.mSmartsWarningBuffer;
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, smiles) {
this.parse$com_actelion_research_chem_StereoMolecule$BA$Z$Z(mol, $I$(4).getBytes$S(smiles), true, true);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$BA',  function (mol, smiles) {
this.parse$com_actelion_research_chem_StereoMolecule$BA$Z$Z(mol, smiles, true, true);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$BA$I$I',  function (mol, smiles, position, endIndex) {
this.parse$com_actelion_research_chem_StereoMolecule$BA$I$I$Z$Z(mol, smiles, position, endIndex, true, true);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$BA$Z$Z',  function (mol, smiles, createCoordinates, readStereoFeatures) {
this.parse$com_actelion_research_chem_StereoMolecule$BA$I$I$Z$Z(mol, smiles, 0, smiles.length, createCoordinates, readStereoFeatures);
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$BA$I$I$Z$Z',  function (mol, smiles, position, endIndex, createCoordinates, readStereoFeatures) {
this.smiles=smiles;
this.mMol=mol;
this.mMol.clear$();
this.mapConnectionBonds=Clazz.new_($I$(10,1));
this.bsAtomHasConnections=Clazz.new_($I$(11,1));
if (this.mSmartsWarningBuffer != null ) this.mSmartsWarningBuffer.setLength$I(0);
this.mAromaticAtoms=0;
this.mSmartsFeatureFound=false;
var allowSmarts=(this.mSmartsMode != 0);
var parityMap=null;
var baseAtom=Clazz.array(Integer.TYPE, [32]);
baseAtom[0]=-1;
var ringClosureAtom=Clazz.array(Integer.TYPE, [16]);
var ringClosurePosition=Clazz.array(Integer.TYPE, [16]);
var ringClosureBondType=Clazz.array(Integer.TYPE, [16]);
var ringClosureBondQueryFeatures=Clazz.array(Integer.TYPE, [16]);
for (var i=0; i < 16; i++) ringClosureAtom[i]=-1;

var atomMass=0;
var fromAtom=-1;
var squareBracketOpen=false;
var isDoubleDigit=false;
var hasLeadingBracket=false;
var bracketLevel=0;
var bondType=1;
var bondQueryFeatures=0;
while (smiles[position] <= 32)++position;

while (position < endIndex){
var theChar=String.fromCharCode(smiles[position++]);
if (Character.isLetter$C(theChar) || theChar == "*"  || theChar == "?"  || (theChar == "!" && allowSmarts  && squareBracketOpen )  || (theChar == "#" && allowSmarts  && squareBracketOpen )  || (theChar == "$" && allowSmarts  && squareBracketOpen ) ) {
var atomParser=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_SmilesParser$I,[this, this.mMode | this.mSmartsMode]);
if (!squareBracketOpen) {
position=atomParser.parseAtomOutsideBrackets$BA$I$I$Z(smiles, position, endIndex, allowSmarts);
} else if ((this.mMode & 128) != 0) {
var ep=Clazz.new_($I$(8,1).c$$I,[this, null, position - 1]);
position=atomParser.parseAtomInsideBrackets$BA$I$I$Z$Z(smiles, position, endIndex, true, true);
if (smiles[position - 1] != 93 ) {
while (smiles[position - 1] != 93 ){
position=atomParser.parseAtomInsideBrackets$BA$I$I$Z$Z(smiles, position + 1, endIndex, true, true);
ep.increase$();
}
this.mEnumerationPositionList.add$O(ep);
}} else {
position=atomParser.parseAtomInsideBrackets$BA$I$I$Z$Z(smiles, position, endIndex, allowSmarts, false);
}squareBracketOpen=false;
if (atomParser.getRecursiveGroup$() != null ) {
fromAtom=baseAtom[bracketLevel];
baseAtom[bracketLevel]=mol.getAllAtoms$();
mol.addMolecule$com_actelion_research_chem_Molecule(atomParser.getRecursiveGroup$());
if (fromAtom != -1 && bondType != 512 ) {
var bond=this.mMol.addBond$I$I$I(fromAtom, fromAtom, bondType);
if (bondQueryFeatures != 0) {
this.mSmartsFeatureFound=true;
this.mMol.setBondQueryFeature$I$I$Z(bond, bondQueryFeatures, true);
this.mMol.adaptBondTypeToQueryFeatures$I(bond);
}}bondType=1;
bondQueryFeatures=0;
continue;
}if (atomParser.atomicNo == -1 && theChar != "?" ) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: unknown element label found. Position:" + (position - 1)]);
if (atomParser.atomQueryFeaturesFound$()) this.mSmartsFeatureFound=true;
var atom=atomParser.addParsedAtom$com_actelion_research_chem_StereoMolecule$C$I(this.mMol, theChar, position);
if (this.mMol.isMarkedAtom$I(atom)) ++this.mAromaticAtoms;
fromAtom=baseAtom[bracketLevel];
if (fromAtom != -1 && bondType != 512 ) {
var bond=this.mMol.addBond$I$I$I(fromAtom, atom, bondType);
if (bondQueryFeatures != 0) {
this.mSmartsFeatureFound=true;
this.mMol.setBondQueryFeature$I$I$Z(bond, bondQueryFeatures, true);
this.mMol.adaptBondTypeToQueryFeatures$I(bond);
}}bondType=1;
bondQueryFeatures=0;
baseAtom[bracketLevel]=atom;
if (atomMass != 0) {
this.mMol.setAtomMass$I$I(atom, atomMass);
atomMass=0;
}if (readStereoFeatures) {
var parity=(parityMap == null ) ? null : parityMap.get$O(Integer.valueOf$I(fromAtom));
if (parity != null ) parity.addNeighbor$I$I$Z(atom, position, atomParser.atomicNo == 1 && this.mMol.getAtomMass$I(atom) == 0 );
if (atomParser.parityFound) {
if (parityMap == null ) parityMap=Clazz.new_($I$(12,1));
var hydrogenCount=(atomParser.explicitHydrogens == 9) ? 0 : atomParser.explicitHydrogens;
parityMap.put$O$O(Integer.valueOf$I(atom), Clazz.new_($I$(13,1).c$$I$I$I$I$I$Z,[this, null, atom, position - 2, fromAtom, hydrogenCount, position - 1, atomParser.isClockwise]));
}}continue;
}if (theChar == ".") {
baseAtom[bracketLevel]=-1;
bondType=512;
continue;
}if (p$2.isBondSymbol$C.apply(this, [theChar])) {
if (squareBracketOpen) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: unexpected bond symbol inside square brackets: '" + theChar + "', position:" + (position - 1) ]);
var excludedBonds=0;
while (p$2.isBondSymbol$C.apply(this, [theChar])){
if (theChar == "!") {
theChar=String.fromCharCode(smiles[position++]);
if (theChar == "@") bondQueryFeatures|=128;
 else if ((theChar == "-" && smiles[position] == 62  ) || (theChar == "<" && smiles[position] == 45  ) ) {
excludedBonds|=16;
++position;
} else if (theChar == "-") excludedBonds|=1;
 else if (theChar == "=") excludedBonds|=2;
 else if (theChar == "#") excludedBonds|=4;
 else if (theChar == "$") excludedBonds|=32;
 else if (theChar == ":") excludedBonds|=8;
 else throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: bond symbol '" + theChar + "' not allowed after '!'. Position:" + (position - 1) ]);
} else {
if (theChar == "@") bondQueryFeatures|=256;
 else if (theChar == "=") bondType=2;
 else if (theChar == "#") bondType=4;
 else if (theChar == "$") bondType=32;
 else if (theChar == ":") bondType=8;
 else if (theChar == "~") bondQueryFeatures|=15;
 else if (theChar == "/") {
if (readStereoFeatures) bondType=257;
} else if (theChar == "\\") {
if (readStereoFeatures) bondType=129;
} else if ((theChar == "-" && smiles[position] == 62  ) || (theChar == "<" && smiles[position] == 45  ) ) {
bondType=16;
++position;
}if (smiles[position] == 44 ) {
bondQueryFeatures|=p$2.bondSymbolToQueryFeature$C.apply(this, [bondType == 16 ? ">" : theChar]);
while (smiles[position] == 44 ){
if ((smiles[position + 1] == 60  && smiles[position + 2] == 45  ) || (smiles[position + 1] == 45  && smiles[position + 2] == 62  ) ) {
bondQueryFeatures|=p$2.bondSymbolToQueryFeature$C.apply(this, [">"]);
position+=3;
} else {
bondQueryFeatures|=p$2.bondSymbolToQueryFeature$C.apply(this, [String.fromCharCode(smiles[position + 1])]);
position+=2;
}}
}}if (smiles[position] == 59 ) {
++position;
theChar=String.fromCharCode(smiles[position++]);
continue;
}if (excludedBonds != 0) bondQueryFeatures|=31 & ~excludedBonds;
break;
}
continue;
}if (theChar <= " ") {
position=endIndex;
continue;
}if (Character.isDigit$C(theChar)) {
var number=theChar.$c() - 48;
if (squareBracketOpen) {
while (position < endIndex && Character.isDigit$I(smiles[position]) ){
number=10 * number + smiles[position] - 48;
++position;
}
atomMass=number;
} else {
var bondTypePosition=isDoubleDigit ? position - 3 : position - 2;
var hasBondType=(smiles[bondTypePosition] == 45  || smiles[bondTypePosition] == 47   || smiles[bondTypePosition] == 92   || smiles[bondTypePosition] == 61   || smiles[bondTypePosition] == 35   || smiles[bondTypePosition] == 36   || smiles[bondTypePosition] == 58   || smiles[bondTypePosition] == 62   || smiles[bondTypePosition] == 126  );
if (isDoubleDigit && position < endIndex  && Character.isDigit$I(smiles[position]) ) {
number=10 * number + smiles[position] - 48;
isDoubleDigit=false;
++position;
}if (number >= ringClosureAtom.length) {
if (number >= 100) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: ringClosureAtom number out of range: " + number]);
var oldSize=ringClosureAtom.length;
var newSize=ringClosureAtom.length;
while (newSize <= number)newSize=Math.min(100, newSize + 16);

ringClosureAtom=$I$(9).copyOf$IA$I(ringClosureAtom, newSize);
ringClosurePosition=$I$(9).copyOf$IA$I(ringClosurePosition, newSize);
ringClosureBondType=$I$(9).copyOf$IA$I(ringClosureBondType, newSize);
ringClosureBondQueryFeatures=$I$(9).copyOf$IA$I(ringClosureBondQueryFeatures, newSize);
for (var i=oldSize; i < newSize; i++) ringClosureAtom[i]=-1;

}if (ringClosureAtom[number] == -1) {
ringClosureAtom[number]=baseAtom[bracketLevel];
ringClosurePosition[number]=position - 1;
ringClosureBondType[number]=hasBondType ? bondType : -1;
ringClosureBondQueryFeatures[number]=hasBondType ? bondQueryFeatures : 0;
} else {
if (ringClosureAtom[number] == baseAtom[bracketLevel]) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: ring closure to same atom"]);
if (readStereoFeatures && parityMap != null  ) {
var parity=parityMap.get$O(Integer.valueOf$I(ringClosureAtom[number]));
if (parity != null ) parity.addNeighbor$I$I$Z(baseAtom[bracketLevel], ringClosurePosition[number], false);
parity=parityMap.get$O(Integer.valueOf$I(baseAtom[bracketLevel]));
if (parity != null ) parity.addNeighbor$I$I$Z(ringClosureAtom[number], position - 1, false);
}if (ringClosureBondType[number] != -1) bondType=ringClosureBondType[number];
 else if (bondType == 257) bondType=129;
 else if (bondType == 129) bondType=257;
var a1=ringClosureAtom[number];
var a2=baseAtom[bracketLevel];
var bond=p$2.addConnection$I$I$I$I$I.apply(this, [a1, a2, bondType, ringClosurePosition[number], position - 1]);
if (ringClosureBondQueryFeatures[number] != 0) bondQueryFeatures=ringClosureBondQueryFeatures[number];
if (bondQueryFeatures != 0) {
this.mSmartsFeatureFound=true;
this.mMol.setBondQueryFeature$I$I$Z(bond, ringClosureBondQueryFeatures[number], true);
this.mMol.adaptBondTypeToQueryFeatures$I(bond);
}ringClosureAtom[number]=-1;
}bondType=1;
bondQueryFeatures=0;
}continue;
}if (theChar == "+") {
throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: '+' found outside brackets. Position:" + (position - 1)]);
}if (theChar == "(") {
if (baseAtom[bracketLevel] == -1) {
hasLeadingBracket=true;
continue;
}++bracketLevel;
if (baseAtom.length == bracketLevel) baseAtom=$I$(9).copyOf$IA$I(baseAtom, baseAtom.length + 32);
baseAtom[bracketLevel]=baseAtom[bracketLevel - 1];
continue;
}if (theChar == ")") {
if (bracketLevel == 0) {
if (!hasLeadingBracket) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: Closing ')' without opening counterpart. Position:" + (position - 1)]);
baseAtom[0]=-1;
hasLeadingBracket=false;
continue;
}--bracketLevel;
continue;
}if (theChar == "[") {
squareBracketOpen=true;
continue;
}if (theChar == "]") {
throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: closing bracket at unexpected position:" + (position - 1)]);
}if (theChar == "%") {
isDoubleDigit=true;
continue;
}throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: unexpected character outside brackets: '" + theChar + "' position:" + (position - 1) ]);
}
if (bondType != 1) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: dangling open bond"]);
for (var rca, $rca = 0, $$rca = ringClosureAtom; $rca<$$rca.length&&((rca=($$rca[$rca])),1);$rca++) if (rca != -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["SmilesParser: dangling ring closure."]);

var handleHydrogenAtomMap=this.mMol.getHandleHydrogenMap$();
this.mMol.setHydrogenProtection$Z(true);
this.mMol.ensureHelperArrays$I(1);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) {
if (this.mMol.getAtomCustomLabel$I(atom) != null ) {
var explicitHydrogen=this.mMol.getAtomCustomLabelBytes$I(atom)[0];
if (this.mSmartsFeatureFound || this.mSmartsMode == 2 ) {
if (explicitHydrogen != 9) {
if (this.mMakeHydrogenExplicit) {
for (var i=0; i < explicitHydrogen; i++) this.mMol.addBond$I$I$I(atom, this.mMol.addAtom$I(1), 1);

} else {
if (explicitHydrogen == 0) this.mMol.setAtomQueryFeature$I$I$Z(atom, 1792, true);
if (explicitHydrogen == 1) this.mMol.setAtomQueryFeature$I$I$Z(atom, 1664, true);
if (explicitHydrogen == 2) this.mMol.setAtomQueryFeature$I$I$Z(atom, 1408, true);
if (explicitHydrogen == 3) this.mMol.setAtomQueryFeature$I$I$Z(atom, 896, true);
}}} else {
if (explicitHydrogen == 9) explicitHydrogen=0;
if (!this.mMol.isMetalAtom$I(atom) && (!this.mMol.isMarkedAtom$I(atom) || (this.mMol.getAtomicNo$I(atom) == 6 && this.mMol.getAtomCharge$I(atom) == 0 ) ) ) {
var valences=$I$(14,"getAllowedValences$I",[this.mMol.getAtomicNo$I(atom)]);
var compatibleValenceFound=false;
var usedValence=this.mMol.getOccupiedValence$I(atom);
usedValence-=this.mMol.getElectronValenceCorrection$I$I(atom, usedValence);
usedValence+=explicitHydrogen;
if (this.mMol.isMarkedAtom$I(atom)) ++usedValence;
for (var valence, $valence = 0, $$valence = valences; $valence<$$valence.length&&((valence=($$valence[$valence])),1);$valence++) {
if (usedValence <= valence) {
compatibleValenceFound=true;
if (valence == usedValence + 2) this.mMol.setAtomRadical$I$I(atom, 48);
 else if (valence == usedValence + 1) this.mMol.setAtomRadical$I$I(atom, 32);
 else if (valence != usedValence || valence != valences[0] ) this.mMol.setAtomAbnormalValence$I$I(atom, usedValence);
break;
}}
if (!compatibleValenceFound) this.mMol.setAtomAbnormalValence$I$I(atom, usedValence);
}if (this.mMakeHydrogenExplicit || !this.mMol.supportsImplicitHydrogen$I(atom) ) for (var i=0; i < explicitHydrogen; i++) this.mMol.addBond$I$I$I(atom, this.mMol.addAtom$I(1), 1);

}} else if (!this.mMakeHydrogenExplicit && (this.mSmartsFeatureFound || this.mSmartsMode == 2 ) ) {
var explicitHydrogen=this.mMol.getExplicitHydrogens$I(atom);
if (explicitHydrogen >= 1) this.mMol.setAtomQueryFeature$I$I$Z(atom, 128, true);
if (explicitHydrogen >= 2) this.mMol.setAtomQueryFeature$I$I$Z(atom, 256, true);
if (explicitHydrogen >= 3) this.mMol.setAtomQueryFeature$I$I$Z(atom, 512, true);
if (explicitHydrogen >= 4) this.mMol.setAtomQueryFeature$I$I$Z(atom, 1024, true);
}}
if (!this.mMakeHydrogenExplicit && (this.mSmartsFeatureFound || this.mSmartsMode == 2 ) ) this.mMol.removeExplicitHydrogens$();
this.mMol.ensureHelperArrays$I(1);
p$2.correctValenceExceededNitrogen.apply(this, []);
p$2.locateAromaticDoubleBonds$Z$Z.apply(this, [allowSmarts, this.mSmartsFeatureFound]);
this.mMol.removeAtomCustomLabels$();
this.mMol.setHydrogenProtection$Z(false);
if (readStereoFeatures) {
p$2.assignKnownEZBondParities.apply(this, []);
if (parityMap != null ) {
for (var parity, $parity = parityMap.values$().iterator$(); $parity.hasNext$()&&((parity=($parity.next$())),1);) this.mMol.setAtomParity$I$I$Z(handleHydrogenAtomMap[parity.mCentralAtom], parity.calculateParity$IA(handleHydrogenAtomMap), false);

this.mMol.setParitiesValid$I(0);
}}this.mMol.setParitiesValid$I(0);
if (createCoordinates) {
var inventor=Clazz.new_($I$(15,1).c$$I,[this.mCoordinateMode]);
if (Long.$ne(this.mRandomSeed,0 )) inventor.setRandomSeed$J(this.mRandomSeed);
inventor.invent$com_actelion_research_chem_StereoMolecule(this.mMol);
if (readStereoFeatures) this.mMol.setUnknownParitiesToExplicitlyUnknown$();
}if (this.mSmartsFeatureFound || this.mSmartsMode == 2 ) {
this.mMol.setFragment$Z(true);
this.mMol.validateAtomQueryFeatures$();
this.mMol.validateBondQueryFeatures$();
}});

Clazz.newMeth(C$, 'addConnection$I$I$I$I$I',  function (a1, a2, bondType, pos1, pos2) {
var bond=this.mMol.addBond$I$I$I(a1, a2, bondType);
this.mapConnectionBonds.put$O$O(a1 + "_" + a2 , Clazz.array(Integer.TYPE, -1, [pos1, pos2]));
this.mapConnectionBonds.put$O$O(a2 + "_" + a1 , Clazz.array(Integer.TYPE, -1, [pos1, pos2]));
this.bsAtomHasConnections.set$I(a1);
this.bsAtomHasConnections.set$I(a2);
return bond;
}, p$2);

Clazz.newMeth(C$, 'isSmarts$',  function () {
return this.mSmartsFeatureFound;
});

Clazz.newMeth(C$, 'isBondSymbol$C',  function (theChar) {
return theChar == "-" || theChar == "="  || theChar == "#"  || theChar == "$"  || theChar == ":"  || theChar == "/"  || theChar == "\\"  || theChar == "<"  || theChar == "~"  || theChar == "!"  || theChar == "@" ;
}, p$2);

Clazz.newMeth(C$, 'bondSymbolToQueryFeature$C',  function (symbol) {
return symbol == "=" ? 2 : symbol == "#" ? 4 : symbol == "$" ? 32 : symbol == ":" ? 8 : symbol == ">" ? 16 : symbol == "~" ? 31 : 1;
}, p$2);

Clazz.newMeth(C$, 'smartsWarning$S',  function (feature) {
if (this.mCreateSmartsWarnings) {
if (this.mSmartsWarningBuffer == null ) this.mSmartsWarningBuffer=Clazz.new_($I$(16,1));
this.mSmartsWarningBuffer.append$S(" ");
this.mSmartsWarningBuffer.append$S(feature);
}});

Clazz.newMeth(C$, 'locateAromaticDoubleBonds$Z$Z',  function (allowSmartsFeatures, smartsFeatureFound) {
this.mMol.ensureHelperArrays$I(1);
this.mIsAromaticBond=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mAromaticBonds=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 8) {
this.mMol.setBondType$I$I(bond, 1);
this.mIsAromaticBond[bond]=true;
++this.mAromaticBonds;
}}
var isAromaticRingAtom=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var ringSet=Clazz.new_($I$(17,1).c$$com_actelion_research_chem_ExtendedMolecule$I,[this.mMol, 3]);
var isAromaticRing=Clazz.array(Boolean.TYPE, [ringSet.getSize$()]);
for (var ring=0; ring < ringSet.getSize$(); ring++) {
var ringAtom=ringSet.getRingAtoms$I(ring);
isAromaticRing[ring]=true;
for (var j, $j = 0, $$j = ringAtom; $j<$$j.length&&((j=($$j[$j])),1);$j++) {
if (!this.mMol.isMarkedAtom$I(j)) {
isAromaticRing[ring]=false;
break;
}}
if (isAromaticRing[ring]) {
for (var j, $j = 0, $$j = ringAtom; $j<$$j.length&&((j=($$j[$j])),1);$j++) isAromaticRingAtom[j]=true;

var ringBond=ringSet.getRingBonds$I(ring);
for (var j, $j = 0, $$j = ringBond; $j<$$j.length&&((j=($$j[$j])),1);$j++) {
if (!this.mIsAromaticBond[j]) {
this.mIsAromaticBond[j]=true;
++this.mAromaticBonds;
}}
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (!this.mIsAromaticBond[bond] && ringSet.getBondRingSize$I(bond) != 0  && this.mMol.isMarkedAtom$I(this.mMol.getBondAtom$I$I(0, bond))  && this.mMol.isMarkedAtom$I(this.mMol.getBondAtom$I$I(1, bond)) ) {
p$2.addLargeAromaticRing$I.apply(this, [bond]);
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (!this.mIsAromaticBond[bond]) {
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
if (!isAromaticRingAtom[atom1] && !isAromaticRingAtom[atom2] && this.mMol.isMarkedAtom$I(atom1) && this.mMol.isMarkedAtom$I(atom2)  ) {
this.mIsAromaticBond[bond]=true;
++this.mAromaticBonds;
}}}
this.mMol.ensureHelperArrays$I(7);
if (this.mSmartsMode == 2 || (this.mSmartsMode == 1 && this.mSmartsFeatureFound ) ) p$2.protectExplicitAromaticBonds.apply(this, []);
var isAromaticBond=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
if (this.mMol.getBonds$() >= 0) System.arraycopy$O$I$O$I$I(this.mIsAromaticBond, 0, isAromaticBond, 0, this.mMol.getBonds$());
for (var ring=0; ring < ringSet.getSize$(); ring++) {
if (isAromaticRing[ring]) {
var ringAtom=ringSet.getRingAtoms$I(ring);
for (var k, $k = 0, $$k = ringAtom; $k<$$k.length&&((k=($$k[$k])),1);$k++) {
if (!p$2.qualifiesForPi$I.apply(this, [k])) {
if (this.mMol.isMarkedAtom$I(k)) {
this.mMol.setAtomMarker$I$Z(k, false);
--this.mAromaticAtoms;
}for (var j=0; j < this.mMol.getConnAtoms$I(k); j++) {
var connBond=this.mMol.getConnBond$I$I(k, j);
if (this.mIsAromaticBond[connBond]) {
this.mIsAromaticBond[connBond]=false;
--this.mAromaticBonds;
}}
}}
}}
p$2.promoteObviousBonds.apply(this, []);
for (var ring=0; ring < ringSet.getSize$(); ring++) {
if (isAromaticRing[ring] && ringSet.getRingSize$I(ring) == 6 ) {
var ringBond=ringSet.getRingBonds$I(ring);
var isFullyDelocalized=true;
for (var bond, $bond = 0, $$bond = ringBond; $bond<$$bond.length&&((bond=($$bond[$bond])),1);$bond++) {
if (!this.mIsAromaticBond[bond]) {
isFullyDelocalized=false;
break;
}}
if (isFullyDelocalized) {
p$2.promoteBond$I.apply(this, [ringBond[0]]);
p$2.promoteBond$I.apply(this, [ringBond[2]]);
p$2.promoteBond$I.apply(this, [ringBond[4]]);
p$2.promoteObviousBonds.apply(this, []);
}}}
var qualifyingBondFound;
for (var qualifyingNo=5; qualifyingNo >= 4; qualifyingNo--) {
do {
qualifyingBondFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsAromaticBond[bond]) {
var aromaticConnBonds=0;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) if (this.mIsAromaticBond[this.mMol.getConnBond$I$I(bondAtom, j)]) ++aromaticConnBonds;

}
if (aromaticConnBonds == qualifyingNo) {
p$2.promoteBond$I.apply(this, [bond]);
p$2.promoteObviousBonds.apply(this, []);
qualifyingBondFound=true;
break;
}}}
} while (qualifyingBondFound);
}
while (this.mAromaticAtoms >= 2)if (!p$2.connectConjugatedRadicalPairs$ZA.apply(this, [isAromaticBond])) break;

if (allowSmartsFeatures) {
if (this.mAromaticAtoms != 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.isMarkedAtom$I(atom)) {
this.mMol.setAtomMarker$I$Z(atom, false);
this.mMol.setAtomQueryFeature$I$I$Z(atom, 2, true);
--this.mAromaticAtoms;
smartsFeatureFound=true;
}}
}if (this.mAromaticBonds != 0) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsAromaticBond[bond]) {
this.mIsAromaticBond[bond]=false;
this.mMol.setBondType$I$I(bond, 8);
--this.mAromaticBonds;
smartsFeatureFound=true;
}}
}} else {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.isMarkedAtom$I(atom) && this.mMol.getImplicitHydrogens$I(atom) != 0 ) {
this.mMol.setAtomMarker$I$Z(atom, false);
this.mMol.setAtomRadical$I$I(atom, 32);
--this.mAromaticAtoms;
}}
}if ((this.mSmartsMode == 0) || (this.mSmartsMode == 1 && !smartsFeatureFound ) ) {
if (this.mAromaticAtoms != 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["Assignment of aromatic double bonds failed"]);
if (this.mAromaticBonds != 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["Assignment of aromatic double bonds failed"]);
}}, p$2);

Clazz.newMeth(C$, 'connectConjugatedRadicalPairs$ZA',  function (isAromaticBond) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.isMarkedAtom$I(atom)) {
var graphLevel=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphParent=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
graphAtom[0]=atom;
graphLevel[atom]=1;
graphParent[atom]=-1;
var current=0;
var highest=0;
while (current <= highest){
var bondOrder=((graphLevel[graphAtom[current]] & 1) == 1) ? 1 : 2;
for (var i=0; i < this.mMol.getConnAtoms$I(graphAtom[current]); i++) {
var bond=this.mMol.getConnBond$I$I(graphAtom[current], i);
if (this.mMol.getBondOrder$I(bond) == bondOrder && isAromaticBond[bond] ) {
var candidate=this.mMol.getConnAtom$I$I(graphAtom[current], i);
if (graphLevel[candidate] == 0) {
if (bondOrder == 1 && this.mMol.isMarkedAtom$I(candidate) ) {
var parent=graphAtom[current];
while (parent != -1){
this.mMol.setBondType$I$I(this.mMol.getBond$I$I(candidate, parent), bondOrder == 1 ? 2 : 1);
bondOrder=3 - bondOrder;
candidate=parent;
parent=graphParent[parent];
}
this.mMol.setAtomMarker$I$Z(atom, false);
this.mMol.setAtomMarker$I$Z(candidate, false);
this.mAromaticAtoms-=2;
return true;
}graphAtom[++highest]=candidate;
graphParent[candidate]=graphAtom[current];
graphLevel[candidate]=graphLevel[graphAtom[current]] + 1;
}}}
++current;
}
}}
return false;
}, p$2);

Clazz.newMeth(C$, 'addLargeAromaticRing$I',  function (bond) {
var graphLevel=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphBond=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphParent=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
graphAtom[0]=atom1;
graphAtom[1]=atom2;
graphBond[0]=-1;
graphBond[1]=bond;
graphLevel[atom1]=1;
graphLevel[atom2]=2;
graphParent[atom1]=-1;
graphParent[atom2]=atom1;
var current=1;
var highest=1;
while (current <= highest && graphLevel[graphAtom[current]] < 15 ){
var parent=graphAtom[current];
for (var i=0; i < this.mMol.getConnAtoms$I(parent); i++) {
var candidate=this.mMol.getConnAtom$I$I(parent, i);
if (candidate != graphParent[parent]) {
var candidateBond=this.mMol.getConnBond$I$I(parent, i);
if (candidate == atom1) {
graphBond[0]=candidateBond;
for (var j=0; j <= highest; j++) {
if (!this.mIsAromaticBond[graphBond[i]]) {
this.mIsAromaticBond[graphBond[i]]=true;
++this.mAromaticBonds;
}}
return;
}if (this.mMol.isMarkedAtom$I(candidate) && graphLevel[candidate] == 0 ) {
++highest;
graphAtom[highest]=candidate;
graphBond[highest]=candidateBond;
graphLevel[candidate]=graphLevel[parent] + 1;
graphParent[candidate]=parent;
}}}
++current;
}
return;
}, p$2);

Clazz.newMeth(C$, 'qualifiesForPi$I',  function (atom) {
if (!$I$(17,"qualifiesAsAromaticAtomicNo$I",[this.mMol.getAtomicNo$I(atom)])) return false;
if (this.mMol.getAtomicNo$I(atom) == 6) {
if (!this.mMol.isMarkedAtom$I(atom)) return false;
if (this.mMol.getAtomCharge$I(atom) > 0) return false;
}var explicitHydrogens=(this.mMol.getAtomCustomLabel$I(atom) == null  || this.mMol.getAtomCustomLabelBytes$I(atom)[0] == 9 ) ? ($b$[0] = 0, $b$[0]) : this.mMol.getAtomCustomLabelBytes$I(atom)[0];
var freeValence=this.mMol.getFreeValence$I(atom) - explicitHydrogens;
if (freeValence < 1) return false;
if (this.mMol.getAtomicNo$I(atom) == 16 || this.mMol.getAtomicNo$I(atom) == 34  || this.mMol.getAtomicNo$I(atom) == 52 ) {
if (this.mMol.getConnAtoms$I(atom) == 2 && this.mMol.getAtomCharge$I(atom) <= 0 ) return false;
return freeValence != 2;
}return true;
}, p$2);

Clazz.newMeth(C$, 'promoteBond$I',  function (bond) {
if (this.mMol.getBondType$I(bond) == 1) this.mMol.setBondType$I$I(bond, 2);
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.isMarkedAtom$I(bondAtom)) {
this.mMol.setAtomMarker$I$Z(bondAtom, false);
--this.mAromaticAtoms;
}for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) {
var connBond=this.mMol.getConnBond$I$I(bondAtom, j);
if (this.mIsAromaticBond[connBond]) {
this.mIsAromaticBond[connBond]=false;
--this.mAromaticBonds;
}}
}
}, p$2);

Clazz.newMeth(C$, 'protectExplicitAromaticBonds',  function () {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsAromaticBond[bond]) {
var isSingleAromaticBond=true;
for (var i=0; i < 2 && isSingleAromaticBond ; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom) && isSingleAromaticBond ; j++) {
if (bond != this.mMol.getConnBond$I$I(bondAtom, j) && this.mIsAromaticBond[this.mMol.getConnBond$I$I(bondAtom, j)] ) isSingleAromaticBond=false;
}
}
if (isSingleAromaticBond) {
this.mMol.setBondType$I$I(bond, 8);
--this.mAromaticBonds;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.isMarkedAtom$I(bondAtom)) {
this.mMol.setAtomMarker$I$Z(bondAtom, false);
--this.mAromaticAtoms;
}}
}}}
}, p$2);

Clazz.newMeth(C$, 'promoteObviousBonds',  function () {
var terminalAromaticBondFound;
do {
terminalAromaticBondFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsAromaticBond[bond]) {
var isTerminalAromaticBond=false;
for (var i=0; i < 2; i++) {
var aromaticNeighbourFound=false;
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) {
if (bond != this.mMol.getConnBond$I$I(bondAtom, j) && this.mIsAromaticBond[this.mMol.getConnBond$I$I(bondAtom, j)] ) {
aromaticNeighbourFound=true;
break;
}}
if (!aromaticNeighbourFound) {
isTerminalAromaticBond=true;
break;
}}
if (isTerminalAromaticBond) {
terminalAromaticBondFound=true;
p$2.promoteBond$I.apply(this, [bond]);
}}}
} while (terminalAromaticBondFound);
}, p$2);

Clazz.newMeth(C$, 'correctValenceExceededNitrogen',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomicNo$I(atom) == 7 && this.mMol.getAtomCharge$I(atom) == 0  && this.mMol.getOccupiedValence$I(atom) > 3  && this.mMol.getAtomPi$I(atom) > 0 ) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var connBond=this.mMol.getConnBond$I$I(atom, i);
if ((this.mMol.getBondOrder$I(connBond) > 1) && this.mMol.isElectronegative$I(connAtom) ) {
if (this.mMol.getBondType$I(connBond) == 4) this.mMol.setBondType$I$I(connBond, 2);
 else this.mMol.setBondType$I$I(connBond, 1);
this.mMol.setAtomCharge$I$I(atom, this.mMol.getAtomCharge$I(atom) + 1);
this.mMol.setAtomCharge$I$I(connAtom, this.mMol.getAtomCharge$I(connAtom) - 1);
this.mMol.setAtomAbnormalValence$I$I(atom, -1);
break;
}}
}}
}, p$2);

Clazz.newMeth(C$, 'assignKnownEZBondParities',  function () {
this.mMol.ensureHelperArrays$I(7);
var paritiesFound=false;
var refAtom=Clazz.array(Integer.TYPE, [2]);
var refBond=Clazz.array(Integer.TYPE, [2]);
var otherAtom=Clazz.array(Integer.TYPE, [2]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (!this.mMol.isSmallRingBond$I(bond) && this.mMol.getBondType$I(bond) == 2 ) {
for (var i=0; i < 2; i++) {
refAtom[i]=-1;
otherAtom[i]=-1;
var atom=this.mMol.getBondAtom$I$I(i, bond);
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) {
var connBond=this.mMol.getConnBond$I$I(atom, j);
if (connBond != bond) {
if (refAtom[i] == -1 && (this.mMol.getBondType$I(connBond) == 257 || this.mMol.getBondType$I(connBond) == 129 ) ) {
refAtom[i]=this.mMol.getConnAtom$I$I(atom, j);
refBond[i]=connBond;
} else {
otherAtom[i]=this.mMol.getConnAtom$I$I(atom, j);
}}}
if (refAtom[i] == -1) break;
}
if (refAtom[0] != -1 && refAtom[1] != -1 ) {
var isZ=this.mMol.getBondType$I(refBond[0]) == this.mMol.getBondType$I(refBond[1]);
for (var i=0; i < 2; i++) if (refAtom[i] == this.mMol.getBondAtom$I$I(0, refBond[i])) isZ=!isZ;

for (var i=0; i < 2; i++) if (otherAtom[i] != -1 && otherAtom[i] < refAtom[i] ) isZ=!isZ;

this.mMol.setBondParity$I$I$Z(bond, isZ ? 2 : 1, false);
paritiesFound=true;
}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(bond) == 257 || this.mMol.getBondType$I(bond) == 129 ) this.mMol.setBondType$I$I(bond, 1);

return paritiesFound;
}, p$2);

Clazz.newMeth(C$, 'testStereo$',  function () {
var data=Clazz.array(String, -2, [Clazz.array(String, -1, ["F/C=C/I", "F/C=C/I"]), Clazz.array(String, -1, ["F/C=C\\I", "F/C=C\\I"]), Clazz.array(String, -1, ["C(=C/I)/F", "F/C=C\\I"]), Clazz.array(String, -1, ["[H]C(/F)=C/I", "F/C=C\\I"]), Clazz.array(String, -1, ["C(=C\\1)/I.F1", "F/C=C/I"]), Clazz.array(String, -1, ["C(=C1)/I.F/1", "F/C=C/I"]), Clazz.array(String, -1, ["C(=C\\F)/1.I1", "F/C=C/I"]), Clazz.array(String, -1, ["C(=C\\F)1.I\\1", "F/C=C/I"]), Clazz.array(String, -1, ["C\\1=C/I.F1", "F/C=C/I"]), Clazz.array(String, -1, ["C1=C/I.F/1", "F/C=C/I"]), Clazz.array(String, -1, ["C(=C\\1)/2.F1.I2", "F/C=C/I"]), Clazz.array(String, -1, ["C/2=C\\1.F1.I2", "F/C=C/I"]), Clazz.array(String, -1, ["C/1=C/C=C/F.I1", "F/C=C/C=C\\I"]), Clazz.array(String, -1, ["C1=C/C=C/F.I\\1", "F/C=C/C=C\\I"]), Clazz.array(String, -1, ["C(/I)=C/C=C/1.F1", "F/C=C/C=C\\I"]), Clazz.array(String, -1, ["C(/I)=C/C=C1.F\\1", "F/C=C/C=C\\I"]), Clazz.array(String, -1, ["[C@](Cl)(F)(I)1.Br1", "F[C@](Cl)(Br)I"]), Clazz.array(String, -1, ["Br[C@](Cl)(I)1.F1", "F[C@](Cl)(Br)I"]), Clazz.array(String, -1, ["[C@H](F)(I)1.Br1", "F[C@H](Br)I"]), Clazz.array(String, -1, ["Br[C@@H](F)1.I1", "F[C@H](Br)I"]), Clazz.array(String, -1, ["C[S@@](CC)=O", "CC[S@](C)=O"]), Clazz.array(String, -1, ["[S@](=O)(C)CC", "CC[S@](C)=O"]), Clazz.array(String, -1, ["F1.OC=[C@]=C1", "OC=[C@]=CF"]), Clazz.array(String, -1, ["OC=[C@]=C1F.[H]1", "OC=[C@]=CF"]), Clazz.array(String, -1, ["[H]C(O)=[C@@]=CF", "OC=[C@]=CF"]), Clazz.array(String, -1, ["C(O)=[C@@]=CF", "OC=[C@]=CF"]), Clazz.array(String, -1, ["OC=[C@@]=C(F)[H]", "OC=[C@]=CF"]), Clazz.array(String, -1, ["CC(F)=[C@@]=CO", "CC(F)=[C@@]=CO"]), Clazz.array(String, -1, ["OC=[C@]=C(C)F", "CC(F)=[C@@]=CO"]), Clazz.array(String, -1, ["OC=[C@]=C(C)F", "CC(F)=[C@@]=CO"]), Clazz.array(String, -1, ["CC(F)=[C@@]=CO", "CC(F)=[C@@]=CO"]), Clazz.array(String, -1, ["CC(F)=[C@]=C(O)[H]", "CC(F)=[C@@]=CO"]), Clazz.array(String, -1, ["CC(F)=[C@]=C(O)Cl", "CC(F)=[C@]=C(O)Cl"]), Clazz.array(String, -1, ["ClC(O)=[C@]=C(F)C", "CC(F)=[C@]=C(O)Cl"]), Clazz.array(String, -1, ["OC(Cl)=[C@]=C(C)F", "CC(F)=[C@]=C(O)Cl"]), Clazz.array(String, -1, ["C1(Cl)=[C@]=C(C)F.O1", "CC(F)=[C@]=C(O)Cl"]), Clazz.array(String, -1, ["C(O)(Cl)=[C@]=C(C)F", "CC(F)=[C@]=C(O)Cl"]), Clazz.array(String, -1, ["[C@](=C(C)(F))=C(O)Cl", "CC(F)=[C@]=C(O)Cl"])]);
var mol=Clazz.new_($I$(5,1));
for (var test, $test = 0, $$test = data; $test<$$test.length&&((test=($$test[$test])),1);$test++) {
try {
Clazz.new_(C$).parse$com_actelion_research_chem_StereoMolecule$S(mol, test[0]);
var smiles=Clazz.new_($I$(18,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).getSmiles$();
System.out.print$S("IN:" + test[0] + " OUT:" + smiles );
if (!test[1].equals$O(smiles)) System.out.println$S(" EXPECTED: " + test[1] + " ERROR!" );
 else System.out.println$S(" OK");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.testStereo$();
System.out.println$S("ID-code equivalence test:");
var data=Clazz.array(String, -2, [Clazz.array(String, -1, ["N[C@@]([H])(C)C(=O)O", "S-alanine", "gGX`BDdwMUM@@"]), Clazz.array(String, -1, ["N[C@@H](C)C(=O)O", "S-alanine", "gGX`BDdwMUM@@"]), Clazz.array(String, -1, ["N[C@H](C(=O)O)C", "S-alanine", "gGX`BDdwMUM@@"]), Clazz.array(String, -1, ["[H][C@](N)(C)C(=O)O", "S-alanine", "gGX`BDdwMUM@@"]), Clazz.array(String, -1, ["[C@H](N)(C)C(=O)O", "S-alanine", "gGX`BDdwMUM@@"]), Clazz.array(String, -1, ["N[C@]([H])(C)C(=O)O", "R-alanine", "gGX`BDdwMUL`@"]), Clazz.array(String, -1, ["N[C@H](C)C(=O)O", "R-alanine", "gGX`BDdwMUL`@"]), Clazz.array(String, -1, ["N[C@@H](C(=O)O)C", "R-alanine", "gGX`BDdwMUL`@"]), Clazz.array(String, -1, ["[H][C@@](N)(C)C(=O)O", "R-alanine", "gGX`BDdwMUL`@"]), Clazz.array(String, -1, ["[C@@H](N)(C)C(=O)O", "R-alanine", "gGX`BDdwMUL`@"]), Clazz.array(String, -1, ["C[C@H]1CCCCO1", "S-Methyl-pyran", "gOq@@eLm]UUH`@"]), Clazz.array(String, -1, ["O1CCCC[C@@H]1C", "S-Methyl-pyran", "gOq@@eLm]UUH`@"]), Clazz.array(String, -1, ["[C@H](F)(B)O", "S-Methyl-oxetan", "gCaDDICTBSURH@"]), Clazz.array(String, -1, ["C1CO[C@H]1C", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["C1CO[C@@H](C)1", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["[C@H]1(C)CCO1", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["[H][C@]1(C)CCO1", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["[H][C@@]1(CCO1)C", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["[C@@]1([H])(C)CCO1", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["[C@]1(C)([H])CCO1", "S-Methyl-oxetan", "gKQ@@eLmUTb@"]), Clazz.array(String, -1, ["C1[C@@H]2COC2=N1", "oxetan-azetin", "gGy@LDimDvfja`@"]), Clazz.array(String, -1, ["CC(C)[C@@]12C[C@@H]1[C@@H](C)C(=O)C2", "alpha-thujone", "dmLH@@RYe~IfyjjjkDaIh@"]), Clazz.array(String, -1, ["CN1CCC[C@H]1c2cccnc2", "Nicotine", "dcm@@@{IDeCEDUSh@UUECP@"]), Clazz.array(String, -1, ["CC[C@H](O1)CC[C@@]12CCCO2", "2S,5R-Chalcogran", "dmLD@@qJZY|fFZjjjdbH`@"]), Clazz.array(String, -1, ["CCCC", "butane", "gC`@Dij@@"]), Clazz.array(String, -1, ["C1C.CC1", "butane", "gC`@Dij@@"]), Clazz.array(String, -1, ["[CH3][CH2][CH2][CH3]", "butane", "gC`@Dij@@"]), Clazz.array(String, -1, ["C-C-C-C", "butane", "gC`@Dij@@"]), Clazz.array(String, -1, ["C12.C1.CC2", "butane", "gC`@Dij@@"]), Clazz.array(String, -1, ["[Na+].[Cl-]", "NaCl", "eDARHm@zd@@"]), Clazz.array(String, -1, ["[Na+]-[Cl-]", "NaCl", "error"]), Clazz.array(String, -1, ["[Na+]1.[Cl-]1", "NaCl", "error"]), Clazz.array(String, -1, ["c1ccccc1", "benzene", "gFp@DiTt@@@"]), Clazz.array(String, -1, ["C1=C-C=C-C=C1", "benzene", "gFp@DiTt@@@"]), Clazz.array(String, -1, ["C1:C:C:C:C:C:1", "benzene", "gFp@DiTt@@@"]), Clazz.array(String, -1, ["c1ccncc1", "pyridine", "gFx@@eJf`@@@"]), Clazz.array(String, -1, ["[nH]1cccc1", "pyrrole", "gKX@@eKcRp@"]), Clazz.array(String, -1, ["N1C=C-C=C1", "pyrrole", "gKX@@eKcRp@"]), Clazz.array(String, -1, ["[H]n1cccc1", "pyrrole", "gKX@@eKcRp@"]), Clazz.array(String, -1, ["[H]n1cccc1", "pyrrole", "gKX@@eKcRp@"]), Clazz.array(String, -1, ["c1cncc1", "pyrrole no [nH]", "error"]), Clazz.array(String, -1, ["[13CH4]", "C13-methane", "fH@FJp@"]), Clazz.array(String, -1, ["[35ClH]", "35-chlorane", "fHdP@qX`"]), Clazz.array(String, -1, ["[35Cl-]", "35-chloride", "fHtPxAbq@"]), Clazz.array(String, -1, ["[Na+].[O-]c1ccccc1", "Na-phenolate", "daxHaHCPBXyAYUn`@@@"]), Clazz.array(String, -1, ["c1cc([O-].[Na+])ccc1", "Na-phenolate", "daxHaHCPBXyAYUn`@@@"]), Clazz.array(String, -1, ["C[C@@](C)(O1)C[C@@H](O)[C@@]1(O2)[C@@H](C)[C@@H]3CC=C4[C@]3(C2)C(=O)C[C@H]5[C@H]4CC[C@@H](C6)[C@]5(C)Cc(n7)c6nc(C[C@@]89(C))c7C[C@@H]8CC[C@@H]%10[C@@H]9C[C@@H](O)[C@@]%11(C)C%10=C[C@H](O%12)[C@]%11(O)[C@H](C)[C@]%12(O%13)[C@H](O)C[C@@]%13(C)CO", "Cephalostatin-1", "gdKe@h@@K`H@XjKHuYlnoP\\bbdRbbVTLbTrJbRaQRRRbTJTRTrfrfTTOBPHtFODPhLNSMdIERYJmShLfs]aqy|uUMUUUUUUE@UUUUMUUUUUUTQUUTPR`nDdQQKB|RIFbiQeARuQt`rSSMNtGS\\ct@@"]), Clazz.array(String, -1, ["OC=[C@]=CF", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["OC([H])=[C@]=CF", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["OC=[C@]=C([H])F", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["F1.OC=[C@]=C1", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["OC=[C@]=C1F.[H]1", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["[H]C(O)=[C@@]=CF", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["C(O)=[C@@]=CF", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["OC=[C@@]=C(F)[H]", "allene-1", "gJQHBIAIVVb`@"]), Clazz.array(String, -1, ["CC(F)=[C@@]=CO", "allene-2", "gGQHJIAIgfZJ@"]), Clazz.array(String, -1, ["OC=[C@]=C(C)F", "allene-2", "gGQHJIAIgfZJ@"]), Clazz.array(String, -1, ["OC=[C@]=C(C)F", "allene-2", "gGQHJIAIgfZJ@"]), Clazz.array(String, -1, ["CC(F)=[C@@]=CO", "allene-2", "gGQHJIAIgfZJ@"]), Clazz.array(String, -1, ["CC(F)=[C@]=C(O)[H]", "allene-2", "gGQHJIAIgfZJ@"]), Clazz.array(String, -1, ["CC(F)=[C@]=C(O)Cl", "allene-3", "gNqDDHbrBS[TmSH@"]), Clazz.array(String, -1, ["ClC(O)=[C@]=C(F)C", "allene-3", "gNqDDHbrBS[TmSH@"]), Clazz.array(String, -1, ["OC(Cl)=[C@]=C(C)F", "allene-3", "gNqDDHbrBS[TmSH@"]), Clazz.array(String, -1, ["C1(Cl)=[C@]=C(C)F.O1", "allene-3", "gNqDDHbrBS[TmSH@"]), Clazz.array(String, -1, ["C(O)(Cl)=[C@]=C(C)F", "allene-3", "gNqDDHbrBS[TmSH@"]), Clazz.array(String, -1, ["[C@](=C(C)(F))=C(O)Cl", "allene-3", "gNqDDHbrBS[TmSH@"])]);
var mol=Clazz.new_($I$(5,1));
for (var test, $test = 0, $$test = data; $test<$$test.length&&((test=($$test[$test])),1);$test++) {
try {
Clazz.new_(C$).parse$com_actelion_research_chem_StereoMolecule$S(mol, test[0]);
var idcode=Clazz.new_($I$(19,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).getIDCode$();
if (test[2].equals$O("error")) System.out.println$S("Should create error! " + test[1] + " smiles:" + test[0] + " idcode:" + idcode );
 else if (!test[2].equals$O(idcode)) System.out.println$S("ERROR! " + test[1] + " smiles:" + test[0] + " is:" + idcode + " must:" + test[2] );
 else {
System.out.println$S("OK " + test[0] + " == " + idcode );
$I$(20).analyzeMolecule$com_actelion_research_chem_StereoMolecule(mol);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!test[2].equals$O("error")) System.out.println$S("ERROR! " + test[1] + " smiles:" + test[0] + " exception:" + e.getMessage$() );
} else {
throw e;
}
}
}
}, 1);
var $b$ = new Int8Array(1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SmilesParser, "EnumerationPosition", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mPosition','mCount']]]

Clazz.newMeth(C$, 'c$$I',  function (position) {
;C$.$init$.apply(this);
this.mPosition=position;
this.mCount=1;
}, 1);

Clazz.newMeth(C$, 'increase$',  function () {
++this.mCount;
});

Clazz.newMeth(C$, 'enumerate$com_actelion_research_chem_SmilesParser$BA$java_util_ArrayList',  function (parser, smarts, enumeration) {
var optionList=Clazz.new_($I$(1,1));
var start=this.mPosition;
var atomParser=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_SmilesParser$I,[parser, this.b$['com.actelion.research.chem.SmilesParser'].mMode | this.b$['com.actelion.research.chem.SmilesParser'].mSmartsMode]);
var end=atomParser.parseAtomInsideBrackets$BA$I$I$Z$Z(smarts, start + 1, smarts.length, true, true) - 1;
if (smarts[end] != 93 ) {
optionList.add$O( String.instantialize(smarts, start, end - start));
while (smarts[end] != 93 ){
start=end + 1;
end=atomParser.parseAtomInsideBrackets$BA$I$I$Z$Z(smarts, start + 1, smarts.length, true, true) - 1;
optionList.add$O( String.instantialize(smarts, start, end - start));
}
}for (var option, $option = optionList.iterator$(); $option.hasNext$()&&((option=($option.next$())),1);) enumeration.add$O( String.instantialize(smarts, 0, this.mPosition) + option +  String.instantialize(smarts, end, smarts.length - end) );

});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_SmilesParser_EnumerationPosition','compareTo$O'],  function (o) {
return Integer.compare$I$I(o.mPosition, this.mPosition);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.SmilesParser, "THParity", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});
C$.$classes$=[['ParityNeighbour',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mIsClockwise','mError'],'I',['mCentralAtom','mCentralAtomPosition'],'O',['mNeighbourList','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$$I$I$I$I$I$Z',  function (centralAtom, centralAtomPosition, fromAtom, explicitHydrogen, hydrogenPosition, isClockwise) {
;C$.$init$.apply(this);
if (explicitHydrogen != 0 && explicitHydrogen != 1 ) {
this.mError=true;
} else {
this.mCentralAtom=centralAtom;
this.mCentralAtomPosition=centralAtomPosition;
this.mIsClockwise=isClockwise;
this.mNeighbourList=Clazz.new_($I$(1,1));
if (fromAtom != -1) this.addNeighbor$I$I$Z(fromAtom, centralAtomPosition - 1, false);
if (fromAtom != -1 && explicitHydrogen == 1 ) this.addNeighbor$I$I$Z(2147483646, centralAtomPosition + 1, false);
}}, 1);

Clazz.newMeth(C$, 'addNeighbor$I$I$Z',  function (atom, position, unused) {
if (!this.mError) {
if (this.mNeighbourList.size$() == 4) {
this.mError=true;
return;
}this.mNeighbourList.add$O(Clazz.new_($I$(3,1).c$$I$I,[this, null, atom, position]));
}});

Clazz.newMeth(C$, 'calculateParity$IA',  function (handleHydrogenAtomMap) {
if (this.mError) return 3;
for (var neighbour, $neighbour = this.mNeighbourList.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$())),1);) if (neighbour.mAtom != 2147483646 && neighbour.mAtom != 2147483647 ) neighbour.mAtom=handleHydrogenAtomMap[neighbour.mAtom];

var isInverse=false;
switch (this.mNeighbourList.size$()) {
case 2:
isInverse=p$1.isInverseOrderAllene$IA.apply(this, [handleHydrogenAtomMap]);
break;
case 3:
this.mNeighbourList.add$O(Clazz.new_($I$(3,1).c$$I$I,[this, null, 2147483647, this.mCentralAtomPosition]));
case 4:
isInverse=p$1.isInverseOrderTH.apply(this, []);
break;
default:
return 3;
}
return (!!(this.mIsClockwise ^ isInverse)) ? 1 : 2;
});

Clazz.newMeth(C$, 'isInverseOrderAllene$IA',  function (smiles2MolMap) {
var inversion=false;
if (this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap == null ) {
this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap=Clazz.array(Integer.TYPE, [smiles2MolMap.length]);
for (var i=this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap.length; --i >= 0; ) {
this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[smiles2MolMap[i]]=i;
}
}inversion=p$1.checkAlleneInversion$IA$I$Z.apply(this, [smiles2MolMap, 0, inversion]);
inversion=p$1.checkAlleneInversion$IA$I$Z.apply(this, [smiles2MolMap, 1, inversion]);
return inversion;
}, p$1);

Clazz.newMeth(C$, 'checkAlleneInversion$IA$I$Z',  function (smiles2MolMap, index, inversion) {
var mMol=this.b$['com.actelion.research.chem.SmilesParser'].mMol;
var a1=this.mNeighbourList.get$I(index);
var smilesAtom=a1.mAtom;
var centerAtom=smiles2MolMap[this.mCentralAtom];
var hasImplicitH=mMol.getImplicitHydrogens$I(smilesAtom) > 0 && mMol.getConnAtoms$I(smilesAtom) == mMol.getAllConnAtoms$I(smilesAtom) ;
var hasConnections=this.b$['com.actelion.research.chem.SmilesParser'].bsAtomHasConnections.get$I(this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[smilesAtom]);
if (!hasImplicitH && !hasConnections ) {
var b=mMol.getConnAtom$I$I(smilesAtom, 2);
if (mMol.getAtomicNo$I(b) == 1) {
b=this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[b];
if (index == 0 ? b > smilesAtom : this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[mMol.getConnAtom$I$I(smilesAtom, 1)] > b) {
inversion=!inversion;
}}return inversion;
}if (hasImplicitH) {
var a2=mMol.getConnAtom$I$I(smilesAtom, index);
var b=this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[a2];
if (b > smilesAtom) {
inversion=!inversion;
if (mMol.getAtomicNo$I(a2) == 1) {
inversion=!inversion;
}}}if (hasConnections) {
var n=mMol.getAllConnAtoms$I(smilesAtom);
var connAtoms=Clazz.array(Integer.TYPE, [n - 1]);
var connBonds=Clazz.array(Integer.TYPE, [n - 1]);
var nConnected=0;
for (var i=0, p=0; i < n; i++) {
var b=mMol.getConnAtom$I$I(smilesAtom, i);
if (b == centerAtom) continue;
connAtoms[p]=b;
var bond=mMol.getBond$I$I(smilesAtom, b);
var positions=this.b$['com.actelion.research.chem.SmilesParser'].mapConnectionBonds.get$O(this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[smilesAtom] + "_" + this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[b] );
connBonds[p++]=(positions == null  ? -1 : bond);
if (positions != null ) ++nConnected;
}
if (hasImplicitH) {
if (connAtoms[0] < smilesAtom) {
inversion=!inversion;
}} else {
switch (nConnected) {
case 1:
if (mMol.getImplicitHydrogens$I(smilesAtom) > 0) {
break;
}var isFirst=(connBonds[0] >= 0);
var connAtom=connAtoms[isFirst ? 0 : 1];
var otherAtom=connAtoms[isFirst ? 1 : 0];
if (otherAtom > smilesAtom) {
if (connAtom > smilesAtom) {
if (mMol.getAtomicNo$I(otherAtom) != 1) {
inversion=!inversion;
}}} else {
if (connAtom < smilesAtom) inversion=!inversion;
}break;
case 2:
var b1=p$1.getOtherAtom$I$I.apply(this, [connBonds[0], smilesAtom]);
var b2=p$1.getOtherAtom$I$I.apply(this, [connBonds[1], smilesAtom]);
var positions1=this.b$['com.actelion.research.chem.SmilesParser'].mapConnectionBonds.get$O(smilesAtom + "_" + this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[b1] );
var positions2=this.b$['com.actelion.research.chem.SmilesParser'].mapConnectionBonds.get$O(smilesAtom + "_" + this.b$['com.actelion.research.chem.SmilesParser'].mol2SmilesMap[b2] );
var p1;
var p2;
var c=this.mCentralAtomPosition;
if (index == 0) {
p1=(positions1[1] < c ? positions1[1] : positions1[0]);
p2=(positions2[1] < c ? positions2[1] : positions2[0]);
} else {
p1=(positions1[0] < c ? positions1[1] : positions1[0]);
p2=(positions2[0] < c ? positions2[1] : positions2[0]);
}if ((p1 < p2) != (b1 < b2) ) {
inversion=!inversion;
}break;
}
}}return inversion;
}, p$1);

Clazz.newMeth(C$, 'getOtherAtom$I$I',  function (b, a) {
return (this.b$['com.actelion.research.chem.SmilesParser'].mMol.mBondAtom[0][b] == a ? this.b$['com.actelion.research.chem.SmilesParser'].mMol.mBondAtom[1][b] : this.b$['com.actelion.research.chem.SmilesParser'].mMol.mBondAtom[0][b]);
}, p$1);

Clazz.newMeth(C$, 'isInverseOrderTH',  function () {
var inversion=false;
for (var i=1; i < this.mNeighbourList.size$(); i++) {
for (var j=0; j < i; j++) {
if (this.mNeighbourList.get$I(j).mAtom > this.mNeighbourList.get$I(i).mAtom) inversion=!inversion;
if (this.mNeighbourList.get$I(j).mPosition > this.mNeighbourList.get$I(i).mPosition) inversion=!inversion;
}
}
return inversion;
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SmilesParser.THParity, "ParityNeighbour", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mAtom','mPosition']]]

Clazz.newMeth(C$, 'c$$I$I',  function (atom, position) {
;C$.$init$.apply(this);
this.mAtom=atom;
this.mPosition=position;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return "[" + (this.mAtom == 2147483646 ? "h" : this.mAtom == 2147483647 ? "lp" : this.b$['com.actelion.research.chem.SmilesParser'].mMol.getAtomLabel$I(this.mAtom)) + this.mPosition + "]" ;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:35 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
