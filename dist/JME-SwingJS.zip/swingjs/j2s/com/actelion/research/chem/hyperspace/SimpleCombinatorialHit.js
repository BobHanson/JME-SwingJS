(function(){var P$=Clazz.newPackage("com.actelion.research.chem.hyperspace"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleCombinatorialHit", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['rxnId'],'O',['synthons','com.actelion.research.chem.hyperspace.SimpleSynthon[][]']]]

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_hyperspace_SimpleSynthonAA',  function (rxnId, synthons) {
;C$.$init$.apply(this);
this.rxnId=rxnId;
this.synthons=synthons;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
