(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','com.actelion.research.chem.descriptor.flexophore.PPNode','StringBuilder','com.actelion.research.calc.ArrayUtilsCalc','java.util.ArrayList','com.actelion.research.util.StringFunctions']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHist", null, 'com.actelion.research.chem.descriptor.flexophore.DistHist', ['java.io.Serializable', 'com.actelion.research.chem.descriptor.flexophore.IMolDistHist']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['finalized'],'B',['modeFlexophore'],'I',['posNode'],'O',['arrNode','byte[]','nodeAtoms','int[][]']]
,['I',['SIZE_BUFFER']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.initHistogramArray$I(0);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (nNodes) {
Clazz.super_(C$, this);
this.initHistogramArray$I(nNodes);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
Clazz.super_(C$, this);
this.initHistogramArray$I(mdh.getNumPPNodes$());
p$1.init.apply(this, []);
mdh.copy$com_actelion_research_chem_descriptor_flexophore_MolDistHist(this);
}, 1);

Clazz.newMeth(C$, 'copy$',  function () {
var copy=Clazz.new_(C$);
this.copy$com_actelion_research_chem_descriptor_flexophore_MolDistHist(copy);
return copy;
});

Clazz.newMeth(C$, 'init',  function () {
this.modeFlexophore=0;
}, p$1);

Clazz.newMeth(C$, 'check$',  function () {
var bOK=true;
var nodes=this.getNumPPNodes$();
for (var i=0; i < nodes; i++) {
var node=this.getNode$I(i);
var ats=node.getInteractionTypeCount$();
for (var j=0; j < ats; j++) {
var inttype=node.getInteractionType$I(j);
var s=$I$(1).getString$I(inttype);
if (s.length$() == 0) {
bOK=false;
if (false) System.err.println$S("Node " + i + " atom " + j + " Interaction type " + inttype + "." );
}}
}
return bOK;
});

Clazz.newMeth(C$, 'copy$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (copy) {
C$.superclazz.prototype.copy$com_actelion_research_chem_descriptor_flexophore_DistHist.apply(this, [copy]);
copy.arrNode=Clazz.array(Byte.TYPE, [this.arrNode.length]);
System.arraycopy$O$I$O$I$I(this.arrNode, 0, copy.arrNode, 0, this.arrNode.length);
copy.posNode=this.posNode;
copy.modeFlexophore=this.modeFlexophore;
copy.realize$();
});

Clazz.newMeth(C$, 'equals$O',  function (o) {
if (!this.equalNodes$O(o)) {
return false;
}var mdh=null;
try {
mdh=o;
} catch (e) {
if (Clazz.exceptionOf(e,"RuntimeException")){
return false;
} else {
throw e;
}
}
var bEQ=true;
for (var i=0; i < this.getNumPPNodes$(); i++) {
for (var j=i + 1; j < this.getNumPPNodes$(); j++) {
var a1=this.getDistHist$I$I(i, j);
var a2=mdh.getDistHist$I$I(i, j);
for (var k=0; k < a2.length; k++) {
if (a1[k] != a2[k]) {
bEQ=false;
break;
}}
}
}
return bEQ;
});

Clazz.newMeth(C$, 'equalNodes$O',  function (o) {
var bEQ=true;
var mdh=null;
try {
mdh=o;
} catch (e) {
if (Clazz.exceptionOf(e,"RuntimeException")){
return false;
} else {
throw e;
}
}
if (this.getNumPPNodes$() != mdh.getNumPPNodes$()) return false;
for (var i=0; i < this.getNumPPNodes$(); i++) {
var n1=this.getNode$I(i);
var n2=mdh.getNode$I(i);
if (!n1.equals$O(n2)) {
bEQ=false;
break;
}}
return bEQ;
});

Clazz.newMeth(C$, 'getModeFlexophore$',  function () {
return this.modeFlexophore;
});

Clazz.newMeth(C$, 'initHistogramArray$I',  function (nNodes) {
C$.superclazz.prototype.initHistogramArray$I.apply(this, [nNodes]);
this.arrNode=Clazz.array(Byte.TYPE, [nNodes * ($I$(2).getNumBytesEntry$() + 1)]);
this.finalized=false;
});

Clazz.newMeth(C$, 'addNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
var arr=node.get$();
var nInteractionTypeCount=($b$[0] = node.getInteractionTypeCount$(), $b$[0]);
var newLen=this.posNode + arr.length + 1 ;
if (this.arrNode.length < newLen) {
var lenBuffer=C$.SIZE_BUFFER;
while (this.arrNode.length + lenBuffer < newLen){
lenBuffer*=2;
}
p$1.resizeNodeArray$I.apply(this, [this.arrNode.length + lenBuffer]);
}this.arrNode[this.posNode++]=nInteractionTypeCount;
System.arraycopy$O$I$O$I$I(arr, 0, this.arrNode, this.posNode, arr.length);
this.posNode+=arr.length;
this.finalized=false;
});

Clazz.newMeth(C$, 'getArrNode$',  function () {
return this.arrNode;
});

Clazz.newMeth(C$, 'setArrNode$BA',  function (arrNode) {
this.arrNode=arrNode;
var pos=0;
while (arrNode[pos] > 0){
pos+=arrNode[pos] * 3 + 1;
if (pos >= arrNode.length) break;
}
});

Clazz.newMeth(C$, 'realize$',  function () {
var size=this.getNumPPNodes$();
if (size == 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["No pharmacophore points in Flexophore."]);
}var pos=p$1.getPositionNode$I.apply(this, [size - 1]);
var len=pos + this.arrNode[pos] * $I$(2).getNumBytesEntry$() + 1;
p$1.resizeNodeArray$I.apply(this, [len]);
if (this.getNumPPNodes$() == 0) return;
this.finalized=true;
});

Clazz.newMeth(C$, 'resizeNodeArray$I',  function (newsize) {
var arr=Clazz.array(Byte.TYPE, [newsize]);
System.arraycopy$O$I$O$I$I(this.arrNode, 0, arr, 0, Math.min(this.arrNode.length, newsize));
this.arrNode=arr;
this.finalized=false;
}, p$1);

Clazz.newMeth(C$, 'getConnAtom$I$I',  function (at, index) {
if (index >= at) ++index;
return index;
});

Clazz.newMeth(C$, 'getNodeAtoms$',  function () {
return this.nodeAtoms;
});

Clazz.newMeth(C$, 'setNodeAtoms$IAA',  function (nodeAtoms) {
this.nodeAtoms=nodeAtoms;
});

Clazz.newMeth(C$, 'hashCode$',  function () {
var s=this.toString();
s=s.replace$CharSequence$CharSequence(" ", "");
return s.hashCode$();
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_([this.toStringNodes$()],$I$(3,1).c$$S);
sb.append$S(this.toStringHists$());
return sb.toString();
});

Clazz.newMeth(C$, 'toStringNodes$',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
sb.append$S(this.getNode$I(i).toString());
if (i < this.getNumPPNodes$() - 1) {
sb.append$S(" ");
} else {
sb.append$S("]");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringNodesElusive$',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
sb.append$S(this.getNode$I(i).toStringElusive$());
if (i < this.getNumPPNodes$() - 1) {
sb.append$S(" ");
} else {
sb.append$S("]");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringNodesLineWise$',  function () {
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < this.getNumPPNodes$(); i++) {
sb.append$S(this.getNode$I(i).toString());
if (i < this.getNumPPNodes$() - 1) {
sb.append$S("\n");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringNodesElusiveLineWise$',  function () {
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < this.getNumPPNodes$(); i++) {
sb.append$S(this.getNode$I(i).toStringElusive$());
if (i < this.getNumPPNodes$() - 1) {
sb.append$S("\n");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringHists$',  function () {
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < this.getNumPPNodes$(); i++) {
for (var j=i + 1; j < this.getNumPPNodes$(); j++) {
var arrHist=this.getDistHist$I$I(i, j);
if (arrHist != null ) sb.append$S($I$(4).toString$BA(arrHist));
}
}
return sb.toString();
});

Clazz.newMeth(C$, 'containsFilledDistHist$',  function () {
if (this.arrDistHists == null  || this.arrDistHists.length == 0 ) {
return false;
}var filled=false;
for (var v, $v = 0, $$v = this.arrDistHists; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
if (v > 0) {
filled=true;
break;
}}
return filled;
});

Clazz.newMeth(C$, 'isFinalized$',  function () {
return this.finalized;
});

Clazz.newMeth(C$, 'getPositionNode$I',  function (index) {
var pos=0;
for (var i=0; i < index; i++) {
pos+=this.arrNode[pos] * $I$(2).getNumBytesEntry$() + 1;
}
return pos;
}, p$1);

Clazz.newMeth(C$, 'getNode$I',  function (index) {
var node=Clazz.new_($I$(2,1));
var pos=p$1.getPositionNode$I.apply(this, [index]);
var len=this.arrNode[pos] * $I$(2).getNumBytesEntry$();
var arr=Clazz.array(Byte.TYPE, [len]);
System.arraycopy$O$I$O$I$I(this.arrNode, pos + 1, arr, 0, len);
node.set$BA$B(arr, this.arrNode[pos]);
node.realize$();
return node;
});

Clazz.newMeth(C$, 'getPPPoints$I',  function (index) {
var pos=p$1.getPositionNode$I.apply(this, [index]);
var nPPPoints=this.arrNode[pos];
return nPPPoints;
});

Clazz.newMeth(C$, 'getSizeBytes$',  function () {
var s=C$.superclazz.prototype.getSizeBytes$.apply(this, []);
s+=this.arrNode.length;
s+=4;
return s;
});

Clazz.newMeth(C$, 'getNumMandatoryPharmacophorePoints$',  function () {
return 0;
});

Clazz.newMeth(C$, 'isMandatoryPharmacophorePoint$I',  function (indexNode) {
return false;
});

Clazz.newMeth(C$, 'getWeightPharmacophorePoint$I',  function (indexNode) {
return 1.0;
});

Clazz.newMeth(C$, 'getNumBytesEntry$',  function () {
return $I$(2).getNumBytesEntry$() + 1;
}, 1);

Clazz.newMeth(C$, 'readNodes$S',  function (strMolDistHist) {
var start=strMolDistHist.indexOf$I("(");
var nodesProcessed=false;
var liPPNode=Clazz.new_($I$(5,1));
while (!nodesProcessed){
var end=$I$(6,"nextClosing$S$I$C$C",[strMolDistHist, start, "(", ")"]);
if (end == -1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error for MolDistHist " + strMolDistHist]);
}var strNode=strMolDistHist.substring$I$I(start + 1, end);
var n=$I$(2).read$S(strNode);
liPPNode.add$O(n);
start=strMolDistHist.indexOf$I$I("(", end);
if (start == -1) {
nodesProcessed=true;
}}
return liPPNode;
}, 1);

Clazz.newMeth(C$, 'readNodes2MDH$S',  function (strMolDistHist) {
var liPPNode=C$.readNodes$S(strMolDistHist);
var size=liPPNode.size$();
var mdh=Clazz.new_(C$.c$$I,[size]);
for (var ppNode, $ppNode = liPPNode.iterator$(); $ppNode.hasNext$()&&((ppNode=($ppNode.next$())),1);) {
mdh.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(ppNode);
}
return mdh;
}, 1);

Clazz.newMeth(C$, 'read$S',  function (strMolDistHist) {
var pattern="[0-9]+";
var liPPNode=C$.readNodes$S(strMolDistHist);
var size=liPPNode.size$();
var mdh=Clazz.new_(C$.c$$I,[size]);
for (var ppNode, $ppNode = liPPNode.iterator$(); $ppNode.hasNext$()&&((ppNode=($ppNode.next$())),1);) {
mdh.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(ppNode);
}
var histsProcessed=false;
var liHist=Clazz.new_($I$(5,1));
var startHist=strMolDistHist.indexOf$S("][");
var nHistograms=(((size * size) - size)/2|0);
if (nHistograms == 0) {
histsProcessed=true;
}while (!histsProcessed){
var endHist=$I$(6).nextClosing$S$I$C$C(strMolDistHist, startHist, "[", "]");
var sub=strMolDistHist.substring$I$I(startHist, endHist);
var li=$I$(6).match$S$S(sub, pattern);
if (li.size$() != 80) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in histogram."]);
}var arr=Clazz.array(Byte.TYPE, [80]);
var cc=0;
for (var p, $p = li.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
var strCount=sub.substring$I$I(p.x, p.y);
arr[cc++]=((Integer.parseInt$S(strCount) & 255)|0);
}
liHist.add$O(arr);
startHist=strMolDistHist.indexOf$I$I("[", endHist);
if (liHist.size$() == nHistograms) {
histsProcessed=true;
}}
var cc=0;
for (var i=0; i < size; i++) {
for (var j=i + 1; j < size; j++) {
mdh.setDistHist$I$I$BA(i, j, liHist.get$I(cc++));
}
}
return mdh;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.SIZE_BUFFER=16 * C$.getNumBytesEntry$();
};
var $b$ = new Int8Array(1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
