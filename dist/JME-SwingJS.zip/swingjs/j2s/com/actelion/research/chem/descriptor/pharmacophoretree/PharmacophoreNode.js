(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),I$=[[0,'java.util.ArrayList','java.util.stream.IntStream','java.util.Base64','com.actelion.research.chem.phesa.EncodeFunctions','StringBuilder','java.util.Arrays','java.util.stream.Collectors']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmacophoreNode");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isRing','isAromatic'],'D',['size','vol'],'I',['role'],'O',['+functionalities','atoms','java.util.List','+weights','+volumes']]
,['O',['FUNCTIONALITY_WEIGHTS','int[]']]]

Clazz.newMeth(C$, 'c$$java_util_List$IAA$DA$I$Z$Z',  function (atoms, atomFunctionalities, atomVolumes, role, isRing, isAromatic) {
;C$.$init$.apply(this);
this.functionalities=Clazz.array(Integer.TYPE, [C$.FUNCTIONALITY_WEIGHTS.length]);
this.atoms=atoms;
this.isRing=isRing;
this.isAromatic=isAromatic;
this.weights=Clazz.new_($I$(1,1));
this.volumes=Clazz.new_($I$(1,1));
this.role=role;
if ((role & 1) == 0) {
this.atoms.stream$().forEach$java_util_function_Consumer(((P$.PharmacophoreNode$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer','accept$O'],  function (a) {
this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].weights.add$O.apply(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].weights, [Double.valueOf$D(1.0)]);
this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].volumes.add$O.apply(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].volumes, [Double.valueOf$D(this.$finals$.atomVolumes[(a).$c()])]);
});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda1.$init$,[this, {atomVolumes:atomVolumes}])));
this.atoms.stream$().forEach$java_util_function_Consumer(((P$.PharmacophoreNode$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer','accept$O'],  function (a) {
var f=this.$finals$.atomFunctionalities[(a).$c()];
$I$(2).range$I$I(0, f.length).forEach$java_util_function_IntConsumer.apply($I$(2).range$I$I(0, f.length), [((P$.PharmacophoreNode$lambda2$3||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda2$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].functionalities[i]+=this.$finals$.f[i]);});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda2$3.$init$,[this, {f:f}]))]);
});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda2.$init$,[this, {atomFunctionalities:atomFunctionalities}])));
this.calculate$();
}}, 1);

Clazz.newMeth(C$, 'c$$java_util_List$IA$java_util_List$java_util_List$I',  function (atoms, functionalities, volumes, weights, role) {
;C$.$init$.apply(this);
this.atoms=atoms;
this.functionalities=functionalities;
this.volumes=volumes;
this.weights=weights;
this.role=role;
this.calculate$();
}, 1);

Clazz.newMeth(C$, 'c$$java_util_List$IAA$DA$Z$Z',  function (atoms, atomFunctionalities, atomVolumes, isRing, isAromatic) {
C$.c$$java_util_List$IAA$DA$I$Z$Z.apply(this, [atoms, atomFunctionalities, atomVolumes, 0, isRing, isAromatic]);
}, 1);

Clazz.newMeth(C$, 'updateWeights$java_util_Map',  function (atomToNodes) {
if ((this.role & 1) == 0) {
$I$(2,"range$I$I",[0, this.atoms.size$()]).forEach$java_util_function_IntConsumer(((P$.PharmacophoreNode$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) {
var a=(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].atoms.get$I.apply(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].atoms, [e])).$c();
var weight=1.0 / this.$finals$.atomToNodes.get$O.apply(this.$finals$.atomToNodes, [Integer.valueOf$I(a)]).size$.apply(this.$finals$.atomToNodes.get$O.apply(this.$finals$.atomToNodes, [Integer.valueOf$I(a)]), []);
this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].weights.set$I$O.apply(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].weights, [e, Double.valueOf$D(weight)]);
});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda3.$init$,[this, {atomToNodes:atomToNodes}])));
this.calculate$();
}});

Clazz.newMeth(C$, 'calculate$',  function () {
this.size=0.0;
this.vol=0.0;
for (var w, $w = this.weights.iterator$(); $w.hasNext$()&&((w=($w.next$()).objectValue$()),1);) {
this.size+=w;
}
this.vol=$I$(2,"range$I$I",[0, this.volumes.size$()]).mapToDouble$java_util_function_IntToDoubleFunction(((P$.PharmacophoreNode$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$I','applyAsDouble$O'],  function (e) { return ((this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].volumes.get$I.apply(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].volumes, [e])).$c() * (this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].weights.get$I.apply(this.b$['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode'].weights, [e])).$c());});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda4.$init$,[this, null]))).sum$();
});

Clazz.newMeth(C$, 'calcStericSim$D$D',  function (sum1, sum2) {
var sim=0.0;
if (sum1 + sum2 < 0.001 ) sim=1.0;
 else {
sim=2 * Math.min(sum1, sum2) / (sum1 + sum2);
}return sim;
}, 1);

Clazz.newMeth(C$, 'calcFeatureSim$IA$IA',  function (features1, features2) {
var sim=0.0;
var nom=0.0;
var denom=0.0;
for (var i=0; i < features1.length; i++) {
var weight=C$.FUNCTIONALITY_WEIGHTS[i];
nom+=weight * Math.min(features1[i], features2[i]);
denom+=weight * (features1[i] + features2[i]);
}
if (denom != 0 ) {
sim=2 * nom / denom;
}return sim;
}, 1);

Clazz.newMeth(C$, 'getSimilarity$java_util_Collection$java_util_Collection$java_util_List$java_util_List',  function (nodes1, nodes2, allNodes1, allNodes2) {
var size1=0.0;
var vol1=0.0;
var sterSim=0.0;
var chemSim=0.0;
var functionalities1=Clazz.array(Integer.TYPE, [C$.FUNCTIONALITY_WEIGHTS.length]);
for (var n, $n = nodes1.iterator$(); $n.hasNext$()&&((n=($n.next$()).intValue$()),1);) {
var node=allNodes1.get$I(n);
size1+=node.size;
vol1+=node.vol;
for (var i=0; i < functionalities1.length; i++) {
functionalities1[i]+=node.functionalities[i];
}
}
var size2=0.0;
var vol2=0.0;
var functionalities2=Clazz.array(Integer.TYPE, [C$.FUNCTIONALITY_WEIGHTS.length]);
for (var n, $n = nodes2.iterator$(); $n.hasNext$()&&((n=($n.next$()).intValue$()),1);) {
var node=allNodes2.get$I(n);
size2+=node.size;
vol2+=node.vol;
for (var i=0; i < functionalities2.length; i++) {
functionalities2[i]+=node.functionalities[i];
}
}
if (size1 / size2 > 2.0  || size1 / size2 < (0.5)  ) {
sterSim=0.0;
chemSim=0.0;
} else {
sterSim=0.5 * C$.calcStericSim$D$D(size1, size2) + 0.5 * C$.calcStericSim$D$D(vol1, vol2);
chemSim=C$.calcFeatureSim$IA$IA(functionalities1, functionalities2);
}if (nodes1.size$() == 1 && nodes2.size$() == 1 ) {
var n1=allNodes1.get$I((nodes1.toArray$()[0]).$c());
var n2=allNodes2.get$I((nodes2.toArray$()[0]).$c());
if (n1.isLinkNode$() && n2.isLinkNode$() ) {
sterSim=1.0;
chemSim=1.0;
}}return (0.30000000000000004) * sterSim + 0.7 * chemSim;
}, 1);

Clazz.newMeth(C$, 'getSimilarity$java_util_Collection$java_util_Collection',  function (nodes1, nodes2) {
var size1=0.0;
var vol1=0.0;
var sterSim=0.0;
var chemSim=0.0;
var functionalities1=Clazz.array(Integer.TYPE, [C$.FUNCTIONALITY_WEIGHTS.length]);
for (var node, $node = nodes1.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
size1+=node.size;
vol1+=node.vol;
for (var i=0; i < functionalities1.length; i++) {
functionalities1[i]+=node.functionalities[i];
}
}
var size2=0.0;
var vol2=0.0;
var functionalities2=Clazz.array(Integer.TYPE, [C$.FUNCTIONALITY_WEIGHTS.length]);
for (var node, $node = nodes2.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
size2+=node.size;
vol2+=node.vol;
for (var i=0; i < functionalities2.length; i++) {
functionalities2[i]+=node.functionalities[i];
}
}
if (size1 / size2 > 2.0  || size1 / size2 < (0.5)  ) {
sterSim=0.0;
chemSim=0.0;
} else {
sterSim=0.5 * C$.calcStericSim$D$D(size1, size2) + 0.5 * C$.calcStericSim$D$D(vol1, vol2);
chemSim=C$.calcFeatureSim$IA$IA(functionalities1, functionalities2);
}if (nodes1.size$() == 1 && nodes2.size$() == 1 ) {
if ((nodes1.toArray$()[0]).isLinkNode$() && (nodes2.toArray$()[0]).isLinkNode$() ) {
sterSim=1.0;
chemSim=1.0;
}}return (0.30000000000000004) * sterSim + 0.7 * chemSim;
}, 1);

Clazz.newMeth(C$, 'getAtoms$',  function () {
return this.atoms;
});

Clazz.newMeth(C$, 'getWeights$',  function () {
return this.weights;
});

Clazz.newMeth(C$, 'getFunctionalities$',  function () {
return this.functionalities;
});

Clazz.newMeth(C$, 'getVolumes$',  function () {
return this.weights;
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.size;
});

Clazz.newMeth(C$, 'setFunctionalities$IA',  function (functionalities) {
this.functionalities=functionalities;
});

Clazz.newMeth(C$, 'setVolumes$java_util_List',  function (volumes) {
this.volumes=volumes;
});

Clazz.newMeth(C$, 'setWeights$java_util_List',  function (weights) {
this.weights=weights;
});

Clazz.newMeth(C$, 'setAtoms$java_util_List',  function (atoms) {
this.atoms=atoms;
});

Clazz.newMeth(C$, 'setRole$I',  function (role) {
this.role=role;
});

Clazz.newMeth(C$, 'isLinkNode$',  function () {
var b=(this.role & 6) == 0 ? false : true;
return b;
});

Clazz.newMeth(C$, 'encode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode',  function (node) {
var s1=$I$(3).getEncoder$().encodeToString$BA($I$(4).intArrayToByteArray$IA(node.functionalities));
var s2=$I$(3).getEncoder$().encodeToString$BA($I$(4,"intArrayToByteArray$IA",[node.atoms.stream$().mapToInt$java_util_function_ToIntFunction(((P$.PharmacophoreNode$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (i) { return (i.intValue$.apply(i, []));});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda5.$init$,[this, null]))).toArray$()]));
var s3=$I$(3).getEncoder$().encodeToString$BA($I$(4,"doubleArrayToByteArray$DA",[node.volumes.stream$().mapToDouble$java_util_function_ToDoubleFunction(((P$.PharmacophoreNode$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$Double','applyAsDouble$O'],  function (i) { return (i.doubleValue$.apply(i, []));});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda6.$init$,[this, null]))).toArray$()]));
var s4=$I$(3).getEncoder$().encodeToString$BA($I$(4,"doubleArrayToByteArray$DA",[node.weights.stream$().mapToDouble$java_util_function_ToDoubleFunction(((P$.PharmacophoreNode$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreNode$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$Double','applyAsDouble$O'],  function (i) { return (i.doubleValue$.apply(i, []));});
})()
), Clazz.new_(P$.PharmacophoreNode$lambda7.$init$,[this, null]))).toArray$()]));
var s5=Integer.toString$I(node.role);
var sb=Clazz.new_($I$(5,1));
sb.append$S(s1);
sb.append$S(",");
sb.append$S(s2);
sb.append$S(",");
sb.append$S(s3);
sb.append$S(",");
sb.append$S(s4);
sb.append$S(",");
sb.append$S(s5);
sb.append$S(",");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'decode$S',  function (s) {
var strings=s.split$S(",");
var functionalities=$I$(4,"byteArrayToIntArray$BA",[$I$(3).getDecoder$().decode$S(strings[0])]);
var atoms=$I$(6,"stream$IA",[$I$(4,"byteArrayToIntArray$BA",[$I$(3).getDecoder$().decode$S(strings[1])])]).boxed$().collect$java_util_stream_Collector($I$(7).toList$());
var volumes=$I$(6,"stream$DA",[$I$(4,"byteArrayToDoubleArray$BA",[$I$(3).getDecoder$().decode$S(strings[2])])]).boxed$().collect$java_util_stream_Collector($I$(7).toList$());
var weights=$I$(6,"stream$DA",[$I$(4,"byteArrayToDoubleArray$BA",[$I$(3).getDecoder$().decode$S(strings[3])])]).boxed$().collect$java_util_stream_Collector($I$(7).toList$());
var role=Integer.parseInt$S(strings[4]);
return Clazz.new_(C$.c$$java_util_List$IA$java_util_List$java_util_List$I,[atoms, functionalities, volumes, weights, role]);
}, 1);

Clazz.newMeth(C$, 'isRing$',  function () {
return this.isRing;
});

Clazz.newMeth(C$, 'setRing$Z',  function (isRing) {
this.isRing=isRing;
});

Clazz.newMeth(C$, 'isAromatic$',  function () {
return this.isAromatic;
});

Clazz.newMeth(C$, 'setAromatic$Z',  function (isAromatic) {
this.isAromatic=isAromatic;
});

C$.$static$=function(){C$.$static$=0;
C$.FUNCTIONALITY_WEIGHTS=Clazz.array(Integer.TYPE, -1, [3, 3, 3, 3, 1, 1]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
