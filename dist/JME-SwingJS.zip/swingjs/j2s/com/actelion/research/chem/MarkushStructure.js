(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.coords.CoordinateInventor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MarkushStructure", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mCoreIndex'],'O',['mCoreList','java.util.ArrayList','+mRGroupList','mSubstituent','com.actelion.research.chem.StereoMolecule[][]','mSubstituentCount','int[]','+mSubstituentIndex','mCoreRGroup','int[][]','mSubstituentRGroup','int[][][]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mCoreList=Clazz.new_($I$(1,1));
this.mRGroupList=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMoleculeA$I',  function (fragment, coreCount) {
C$.c$.apply(this, []);
if (fragment != null ) {
for (var i=0; i < coreCount; i++) this.mCoreList.add$O(fragment[i]);

for (var i=coreCount; i < fragment.length; i++) this.mRGroupList.add$O(fragment[i]);

}}, 1);

Clazz.newMeth(C$, 'getCoreStructure$I',  function (no) {
return this.mCoreList.get$I(no);
});

Clazz.newMeth(C$, 'getCoreCount$',  function () {
return this.mCoreList.size$();
});

Clazz.newMeth(C$, 'getRGroup$I',  function (no) {
return this.mRGroupList.get$I(no);
});

Clazz.newMeth(C$, 'getRGroupCount$',  function () {
return this.mRGroupList.size$();
});

Clazz.newMeth(C$, 'addCore$com_actelion_research_chem_StereoMolecule',  function (core) {
this.mCoreList.add$O(core);
});

Clazz.newMeth(C$, 'addRGroup$com_actelion_research_chem_StereoMolecule',  function (substituents) {
this.mRGroupList.add$O(substituents);
});

Clazz.newMeth(C$, 'validate$',  function () {
if (this.mCoreList.size$() == 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["You didn\'t define a core structure."]);
var rGroupFlags=0;
var maxRGroup=-1;
var rGroupCount=0;
this.mCoreRGroup=Clazz.array(Integer.TYPE, [this.mCoreList.size$(), null]);
for (var i=0; i < this.mCoreList.size$() + this.mRGroupList.size$(); i++) {
var mol=(i < this.mCoreList.size$()) ? this.mCoreList.get$I(i) : this.mRGroupList.get$I(i - this.mCoreList.size$());
mol.ensureHelperArrays$I(1);
var rGroupList=Clazz.new_($I$(1,1));
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var rGroupIndex=p$1.getRGroupIndex$I.apply(this, [mol.getAtomicNo$I(atom)]);
if (rGroupIndex != -1) {
if (mol.getConnAtoms$I(atom) != 1) throw Clazz.new_(Clazz.load('Exception').c$$S,["R" + (rGroupIndex + 1) + " has multiple neighbours." ]);
maxRGroup=Math.max(maxRGroup, rGroupIndex);
var flag=(1 << rGroupIndex);
if ((rGroupFlags & flag) == 0) {
rGroupFlags|=flag;
++rGroupCount;
}if (i < this.mCoreList.size$()) rGroupList.add$O( new Integer(rGroupIndex));
}}
if (i < this.mCoreList.size$()) {
this.mCoreRGroup[i]=Clazz.array(Integer.TYPE, [rGroupList.size$()]);
for (var j=0; j < rGroupList.size$(); j++) this.mCoreRGroup[i][j]=rGroupList.get$I(j).intValue$();

}}
if (maxRGroup >= this.mRGroupList.size$()) throw Clazz.new_(Clazz.load('Exception').c$$S,["Not all used R-groups are defined."]);
var warning=null;
if (rGroupCount < this.mRGroupList.size$()) warning="One or more defined R-group(s) are unreferenced.";
this.mSubstituent=Clazz.array($I$(2), [this.mRGroupList.size$(), null]);
this.mSubstituentRGroup=Clazz.array(Integer.TYPE, [this.mRGroupList.size$(), null, null]);
for (var i=0; i < this.mRGroupList.size$(); i++) {
this.mSubstituent[i]=this.mRGroupList.get$I(i).getFragments$();
this.mSubstituentRGroup[i]=Clazz.array(Integer.TYPE, [this.mSubstituent[i].length, null]);
for (var j=0; j < this.mSubstituent[i].length; j++) {
this.mSubstituent[i][j].ensureHelperArrays$I(1);
var attachmentPointFound=false;
var rGroupList=Clazz.new_($I$(1,1));
for (var atom=0; atom < this.mSubstituent[i][j].getAllAtoms$(); atom++) {
if (this.mSubstituent[i][j].getAtomicNo$I(atom) == 0) {
if (attachmentPointFound) throw Clazz.new_(Clazz.load('Exception').c$$S,["Variation " + (j + 1) + " of R" + (i + 1) + " has multiple attachment points." ]);
if (this.mSubstituent[i][j].getConnAtoms$I(atom) != 1) throw Clazz.new_(Clazz.load('Exception').c$$S,["The attachment point of variation " + (j + 1) + " of R" + (i + 1) + " has multiple neighbours." ]);
attachmentPointFound=true;
} else {
var rGroupIndex=p$1.getRGroupIndex$I.apply(this, [this.mSubstituent[i][j].getAtomicNo$I(atom)]);
if (rGroupIndex != -1) rGroupList.add$O( new Integer(rGroupIndex));
}}
if (!attachmentPointFound) throw Clazz.new_(Clazz.load('Exception').c$$S,["Variation " + (j + 1) + " of R" + (i + 1) + " has no attachment point ('?'-atom)." ]);
this.mSubstituentRGroup[i][j]=Clazz.array(Integer.TYPE, [rGroupList.size$()]);
for (var k=0; k < rGroupList.size$(); k++) this.mSubstituentRGroup[i][j][k]=rGroupList.get$I(k).intValue$();

}
}
var rGroupReferenced=0;
for (var i=0; i < this.mCoreRGroup.length; i++) for (var j=0; j < this.mCoreRGroup[i].length; j++) rGroupReferenced|=(1 << this.mCoreRGroup[i][j]);


var rGroupReferencedPreviousLevel=rGroupReferenced;
for (var level=1; level <= 5; level++) {
var rGroupReferencedCurrentLevel=0;
for (var rGroup=0; rGroup <= maxRGroup; rGroup++) {
if ((rGroupReferencedPreviousLevel & (1 << rGroup)) != 0) {
for (var i=0; i < this.mSubstituentRGroup[rGroup].length; i++) {
for (var j=0; j < this.mSubstituentRGroup[rGroup][i].length; j++) {
rGroupReferencedCurrentLevel|=(1 << this.mSubstituentRGroup[rGroup][i][j]);
rGroupReferenced|=(1 << this.mSubstituentRGroup[rGroup][i][j]);
}
}
}}
if (rGroupReferencedCurrentLevel == 0) break;
if (level == 5) throw Clazz.new_(Clazz.load('Exception').c$$S,["R-Groups are recursively definined or maximum depth of indirection (5) exceeded"]);
rGroupReferencedPreviousLevel=rGroupReferencedCurrentLevel;
}
this.mSubstituentCount=Clazz.array(Integer.TYPE, [this.mRGroupList.size$()]);
for (var rGroup=0; rGroup < this.mRGroupList.size$(); rGroup++) this.mSubstituentCount[rGroup]=((rGroupReferenced & (1 << rGroup)) == 0) ? 0 : this.mSubstituent[rGroup].length;

this.mSubstituentIndex=Clazz.array(Integer.TYPE, [this.mRGroupList.size$()]);
this.mCoreIndex=0;
return warning;
});

Clazz.newMeth(C$, 'getNextEnumeration$',  function () {
if (this.mCoreIndex == this.mCoreList.size$()) return null;
var mol=p$1.createCurrentEnumeration.apply(this, []);
var incrementCoreIndex=true;
for (var rGroup=0; rGroup < this.mRGroupList.size$(); rGroup++) {
if (this.mSubstituentCount[rGroup] > 1) {
if (this.mSubstituentIndex[rGroup] + 1 < this.mSubstituentCount[rGroup]) {
++this.mSubstituentIndex[rGroup];
incrementCoreIndex=false;
break;
} else {
this.mSubstituentIndex[rGroup]=0;
}}}
if (incrementCoreIndex) ++this.mCoreIndex;
return mol;
});

Clazz.newMeth(C$, 'getRGroupIndex$I',  function (atomicNo) {
if (atomicNo < 129 || atomicNo > 144 ) return -1;
return (atomicNo >= 142) ? atomicNo - 142 : atomicNo - 126;
}, p$1);

Clazz.newMeth(C$, 'createCurrentEnumeration',  function () {
var mol=Clazz.new_($I$(2,1));
mol.addMolecule$com_actelion_research_chem_Molecule(this.mCoreList.get$I(this.mCoreIndex));
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var rGroup=p$1.getRGroupIndex$I.apply(this, [mol.getAtomicNo$I(atom)]);
if (rGroup != -1) mol.addSubstituent$com_actelion_research_chem_Molecule$I(this.mSubstituent[rGroup][this.mSubstituentIndex[rGroup]], p$1.getAttachmentAtom$com_actelion_research_chem_Molecule$I.apply(this, [mol, atom]));
}
for (var atom=0; atom < mol.getAllAtoms$(); atom++) mol.setAtomSelection$I$Z(atom, p$1.getRGroupIndex$I.apply(this, [mol.getAtomicNo$I(atom)]) != -1);

mol.deleteSelectedAtoms$();
var coreAtoms=this.mCoreList.get$I(this.mCoreIndex).getAllAtoms$() - this.mCoreRGroup[this.mCoreIndex].length;
for (var atom=0; atom < coreAtoms; atom++) mol.setAtomMarker$I$Z(atom, true);

Clazz.new_($I$(3,1).c$$I,[10]).invent$com_actelion_research_chem_StereoMolecule(mol);
return mol;
}, p$1);

Clazz.newMeth(C$, 'getAttachmentAtom$com_actelion_research_chem_Molecule$I',  function (mol, atom) {
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
if (mol.getBondAtom$I$I(0, bond) == atom) return mol.getBondAtom$I$I(1, bond);
if (mol.getBondAtom$I$I(1, bond) == atom) return mol.getBondAtom$I$I(0, bond);
}
return -1;
}, p$1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:38 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
