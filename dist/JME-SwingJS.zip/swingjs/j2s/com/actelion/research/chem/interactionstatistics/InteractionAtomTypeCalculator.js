(function(){var P$=Clazz.newPackage("com.actelion.research.chem.interactionstatistics"),I$=[[0,'StringBuilder',['com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','.AtomPropertyShift'],['com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','.FunctionalGroup'],['com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','.AtomPropertyMask'],'com.actelion.research.chem.PeriodicTable']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InteractionAtomTypeCalculator", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['FunctionalGroup',25],['AtomPropertyMask',25],['AtomPropertyShift',25],['AtomFlagCount',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getFunctionalGroupValue$com_actelion_research_chem_StereoMolecule$I',  function (complex, atom) {
return C$.getFunctionalGroup$com_actelion_research_chem_StereoMolecule$I(complex, atom) << $I$(2).FUNCTIONAL_GROUP_SHIFT.getShift$();
}, 1);

Clazz.newMeth(C$, 'getFunctionalGroup$com_actelion_research_chem_StereoMolecule$I',  function (complex, atom) {
complex.ensureHelperArrays$I(1);
var atomNo=complex.getAtomicNo$I(atom);
var neighbours=0;
var doubleBonds=0;
var tripleBonds=0;
for (var i=0; i < complex.getConnAtoms$I(atom); i++) {
var order=complex.getConnBondOrder$I$I(atom, i);
if (order == 2) ++doubleBonds;
 else if (order == 3) ++tripleBonds;
++neighbours;
}
if (atomNo == 8) {
if (neighbours == 1) {
if (C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 7, -1, 8, -1) > 0) return $I$(3).NITRO.id;
var nPs=C$.getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I(complex, atom, 15, -1);
if (nPs > 0) {
var p=complex.getConnAtom$I$I(atom, 0);
var nPOXs=C$.getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I(complex, p, 8, -1);
var nPORs=C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, p, 8, -1, -1, -1);
var nPOs=nPOXs - nPORs;
if (nPOs == 1) return 0;
 else if (nPOs >= 2) return $I$(3).PHOSPHONATE.id;
}var nSs=C$.getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I(complex, atom, 16, -1);
if (nSs > 0) {
var s=complex.getConnAtom$I$I(atom, 0);
var nSNs=C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 16, -1, 7, 1);
var nSOXs=C$.getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I(complex, s, 8, -1);
var nSORs=C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, s, 8, -1, -1, -1);
var nSOs=nSOXs - nSORs;
if (nSOs > 0 && nSNs > 0 ) return $I$(3).SULFONAMIDE.id;
 else if (nSOs == 1) return $I$(3).SULFOXIDE.id;
 else if (nSOs == 2) return $I$(3).SULFONE.id;
 else if (nSOs == 3) return $I$(3).SULFONATE.id;
}}var nCOs=C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 6, -1, 8, -1);
if (nCOs > 0) {
for (var i=0; i < complex.getConnAtoms$I(atom); i++) {
var aa=complex.getConnAtom$I$I(atom, i);
if (complex.getAtomicNo$I(aa) != 6) continue;
for (var j=0; j < complex.getConnAtoms$I(aa); j++) {
var aaa=complex.getConnAtom$I$I(aa, j);
if (aaa == atom) continue;
 else if (complex.getAtomicNo$I(aaa) == 8) {
var dBds=complex.getBondOrder$I(complex.getBond$I$I(aa, aaa)) > 1 ? 1 : 0;
if (doubleBonds + dBds > 0) {
if (complex.getNonHydrogenNeighbourCount$I(aaa) == 1 && neighbours == 1 ) return $I$(3).CARBOXYL.id;
 else if (complex.getAllConnAtoms$I(aaa) == 1 && neighbours > 1 ) return $I$(3).ESTER.id;
 else if (complex.getAllConnAtoms$I(aaa) > 1 && neighbours == 1 ) return $I$(3).ESTER.id;
}}}
}
}if (doubleBonds < 1 && complex.getNonHydrogenNeighbourCount$I(atom) == 1 ) {
if (C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 6, 1, 6, 2) > 0) {
return $I$(3).ENOL.id;
}}if (doubleBonds == 1) {
if (C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 6, -1, 7, 1) > 0) {
return $I$(3).AMIDE.id;
}}return 0;
} else if (atomNo == 7) {
if (neighbours == 4) return 0;
if (complex.isAromaticAtom$I(atom)) {
if (neighbours <= 2) {
for (var i=0; i < complex.getAllConnAtoms$I(atom); i++) {
var aa=complex.getConnAtom$I$I(atom, i);
if (!complex.isAromaticAtom$I(aa)) continue;
for (var j=0; j < complex.getConnAtoms$I(aa); j++) {
var aaa=complex.getConnAtom$I$I(aa, j);
if (!complex.isAromaticAtom$I(aaa)) continue;
if (aaa == atom) continue;
if (complex.getAtomicNo$I(aaa) == 7 && complex.getConnAtoms$I(aaa) <= 2 ) return $I$(3).N_SP2_TAUT.id;
}
}
}return 0;
} else {
if (C$.getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I(complex, atom, 8, -1) >= 2) return $I$(3).NITRO.id;
if (neighbours == 1 && tripleBonds > 0 ) return 0;
if (C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 6, 1, 8, 2) > 0) {
return $I$(3).AMIDE.id;
}if (C$.getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(complex, atom, 16, 1, 8, 2) > 0) {
return $I$(3).SULFONAMIDE.id;
}var isAmidine=false;
 guanidine : for (var i=0; i < complex.getAllConnAtoms$I(atom); i++) {
var aa=complex.getConnAtom$I$I(atom, i);
if (complex.getAtomicNo$I(aa) == 6 && complex.getConnAtoms$I(aa) == 3  && C$.getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I(complex, aa, 7, 2) > 0 ) {
isAmidine=true;
for (var j=0; j < complex.getAllConnAtoms$I(aa); j++) {
var aaa=complex.getConnAtom$I$I(aa, j);
if (atom == aaa) continue;
if (complex.getAtomicNo$I(aaa) != 7 || complex.isAromaticAtom$I(aaa) ) continue guanidine;
}
return $I$(3).GUANIDINE.id;
}}
if (isAmidine) {
return $I$(3).AMIDINE.id;
}if (doubleBonds == 0 && complex.isFlatNitrogen$I(atom) ) {
return $I$(3).SP2_AMINE.id;
}}}return 0;
}, 1);

Clazz.newMeth(C$, 'getHybridizationValue$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) == 6 || mol.getAtomicNo$I(atom) == 7  || mol.getAtomicNo$I(atom) == 8 ) {
var pi=mol.getAtomPi$I(atom);
var sp=(pi == 2) ? 1 : (pi == 1 || mol.getAtomicNo$I(atom) == 5 ) ? 2 : 3;
return sp << $I$(2).HYBRID_SHIFT.getShift$();
} else return 0;
}, 1);

Clazz.newMeth(C$, 'getAtomicNoValue$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var atomicNo=mol.getAtomicNo$I(atom);
return atomicNo;
}, 1);

Clazz.newMeth(C$, 'getAromValue$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var arom=mol.isAromaticAtom$I(atom) ? 1 : 0;
var type=0;
if (arom > 0) type=$I$(4).AROM.getMask$();
return type;
}, 1);

Clazz.newMeth(C$, 'getStabilizationValue$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var stab=mol.isStabilizedAtom$I(atom) ? 1 : 0;
var type=0;
if (stab > 0) type=$I$(4).STABILIZED.getMask$();
return type;
}, 1);

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_StereoMolecule$I$I$I',  function (mol, a, aaAtomicNo, aaBondOrder) {
var n=0;
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var aa=mol.getConnAtom$I$I(a, i);
var bondOrder=mol.getBondOrder$I(mol.getBond$I$I(a, aa));
if (aaAtomicNo >= 0 && mol.getAtomicNo$I(aa) != aaAtomicNo ) continue;
if (aaBondOrder > 0 && bondOrder != aaBondOrder ) continue;
++n;
}
return n;
}, 1);

Clazz.newMeth(C$, 'getPaths$com_actelion_research_chem_StereoMolecule$I$I$I$I$I',  function (mol, a, aaAtomicNo, aaBondOrder, aaaAtomicNo, aaaBondOrder) {
var n=0;
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var aa=mol.getConnAtom$I$I(a, i);
var bondOrder1=mol.getBondOrder$I(mol.getBond$I$I(a, aa));
if (aaAtomicNo > 0 && mol.getAtomicNo$I(aa) != aaAtomicNo ) continue;
if (aaBondOrder > 0 && bondOrder1 != aaBondOrder ) continue;
for (var j=0; j < mol.getAllConnAtoms$I(aa); j++) {
var aaa=mol.getConnAtom$I$I(aa, j);
if (aaa == a) continue;
var bondOrder2=mol.getBondOrder$I(mol.getBond$I$I(aa, aaa));
if (aaaAtomicNo > 0 && mol.getAtomicNo$I(aaa) != aaaAtomicNo ) continue;
if (aaaBondOrder > 0 && bondOrder2 != aaaBondOrder ) continue;
++n;
}
}
return n;
}, 1);

Clazz.newMeth(C$, 'getAtomType$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var type=0;
type+=C$.getFunctionalGroupValue$com_actelion_research_chem_StereoMolecule$I(mol, atom);
type+=C$.getHybridizationValue$com_actelion_research_chem_StereoMolecule$I(mol, atom);
type+=C$.getStabilizationValue$com_actelion_research_chem_StereoMolecule$I(mol, atom);
type+=C$.getAromValue$com_actelion_research_chem_StereoMolecule$I(mol, atom);
type+=C$.getAtomicNoValue$com_actelion_research_chem_StereoMolecule$I(mol, atom);
return type;
}, 1);

Clazz.newMeth(C$, 'getAtomType$com_actelion_research_chem_interactionstatistics_InteractionAtomTypeCalculator_FunctionalGroup$I$Z$I$Z',  function (fg, atomicNo, isAromatic, hybridization, isStabilized) {
var type=0;
if (fg != null ) {
type+=fg.id << $I$(2).FUNCTIONAL_GROUP_SHIFT.getShift$();
}type+=hybridization << $I$(2).HYBRID_SHIFT.getShift$();
if (isStabilized) type+=$I$(4).STABILIZED.getMask$();
if (isAromatic) type+=$I$(4).AROM.getMask$();
type+=atomicNo;
return type;
}, 1);

Clazz.newMeth(C$, 'getString$I',  function (atomType) {
var sb=Clazz.new_($I$(1,1));
sb.append$S($I$(5,"symbol$I",[atomType & $I$(4).ATOMIC_NO.getMask$()]));
var hybrid=(atomType & $I$(4).HYBRID.getMask$()) >> $I$(2).HYBRID_SHIFT.getShift$();
if (hybrid > 0) {
sb.append$S("." + hybrid);
}var neighbours=(atomType & $I$(4).NONHNEIGHBOURS.getMask$()) >> $I$(2).NEIGHBOURS_SHIFT.getShift$();
sb.append$S("-" + neighbours + "-" );
var stab=(atomType & $I$(4).STABILIZED.getMask$()) > 0 ? ".St" : "";
sb.append$S(stab);
var arom=(atomType & $I$(4).AROM.getMask$()) > 0 ? ".Ar" : "";
sb.append$S(arom);
var fgValue=(atomType & $I$(4).FUNCTIONAL_GROUP.getMask$()) >> $I$(2).FUNCTIONAL_GROUP_SHIFT.getShift$();
for (var fg, $fg = 0, $$fg = $I$(3).values$(); $fg<$$fg.length&&((fg=($$fg[$fg])),1);$fg++) {
if (fg.getId$() == fgValue) {
sb.append$S("(");
sb.append$S(fg.getString$());
sb.append$S(")");
}}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getAtomicNumber$I',  function (atomType) {
return atomType & $I$(4).ATOMIC_NO.getMask$();
}, 1);

Clazz.newMeth(C$, 'isCarbonInteraction$I',  function (atomType) {
var atNo=C$.getAtomicNumber$I(atomType);
return (atNo == 6) ? true : false;
}, 1);

Clazz.newMeth(C$, 'isAromatic$I',  function (atomType) {
return ((atomType & $I$(4).AROM.getMask$()) > 0) ? true : false;
}, 1);

Clazz.newMeth(C$, 'setInteractionTypes$com_actelion_research_chem_Molecule3D',  function (mol) {
for (var i=0; i < mol.getAtoms$(); i++) {
var atomType=C$.getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, i);
mol.setInteractionAtomType$I$I(i, atomType);
}
}, 1);

Clazz.newMeth(C$, 'getGenericDonor$',  function () {
return C$.getAtomType$com_actelion_research_chem_interactionstatistics_InteractionAtomTypeCalculator_FunctionalGroup$I$Z$I$Z(null, 8, false, 3, false);
}, 1);

Clazz.newMeth(C$, 'getGenericAcceptor$',  function () {
return C$.getAtomType$com_actelion_research_chem_interactionstatistics_InteractionAtomTypeCalculator_FunctionalGroup$I$Z$I$Z(null, 8, false, 3, false);
}, 1);

Clazz.newMeth(C$, 'getGenericPosCharge$',  function () {
return C$.getAtomType$com_actelion_research_chem_interactionstatistics_InteractionAtomTypeCalculator_FunctionalGroup$I$Z$I$Z(null, 7, false, 3, false);
}, 1);

Clazz.newMeth(C$, 'getGenericNegCharge$',  function () {
return C$.getAtomType$com_actelion_research_chem_interactionstatistics_InteractionAtomTypeCalculator_FunctionalGroup$I$Z$I$Z($I$(3).CARBOXYL, 8, false, 2, false);
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.InteractionAtomTypeCalculator, "FunctionalGroup", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id'],'S',['s']]]

Clazz.newMeth(C$, 'c$$S$I',  function (s, id) {
;C$.$init$.apply(this);
this.s=s;
this.id=id;
}, 1);

Clazz.newMeth(C$, 'getString$',  function () {
return this.s;
});

Clazz.newMeth(C$, 'getId$',  function () {
return this.id;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["FunctionalGroup{"]);
sb.append$S("s=\'").append$S(this.s).append$C("\'");
sb.append$S(", id=").append$I(this.id);
sb.append$C("}");
return sb.toString();
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$S$I, "NITRO", 0, ["NO2", 1]);
Clazz.newEnumConst($vals, C$.c$$S$I, "ESTER", 1, ["COOR", 2]);
Clazz.newEnumConst($vals, C$.c$$S$I, "CARBOXYL", 2, ["COO", 3]);
Clazz.newEnumConst($vals, C$.c$$S$I, "SULFONAMIDE", 3, ["HNSO2R", 4]);
Clazz.newEnumConst($vals, C$.c$$S$I, "SULFONATE", 4, ["SO3", 5]);
Clazz.newEnumConst($vals, C$.c$$S$I, "PHOSPHONATE", 5, ["PO3", 6]);
Clazz.newEnumConst($vals, C$.c$$S$I, "SULFOXIDE", 6, ["SO", 7]);
Clazz.newEnumConst($vals, C$.c$$S$I, "SULFONE", 7, ["SO2", 8]);
Clazz.newEnumConst($vals, C$.c$$S$I, "AMIDE", 8, ["HNCO", 9]);
Clazz.newEnumConst($vals, C$.c$$S$I, "AMIDINE", 9, ["N=C-N", 10]);
Clazz.newEnumConst($vals, C$.c$$S$I, "GUANIDINE", 10, ["N-C(-N)=N", 11]);
Clazz.newEnumConst($vals, C$.c$$S$I, "N_SP2_TAUT", 11, ["N=C-N(Ar)", 12]);
Clazz.newEnumConst($vals, C$.c$$S$I, "SP2_AMINE", 12, ["C=CNX2", 13]);
Clazz.newEnumConst($vals, C$.c$$S$I, "ENOL", 13, ["C=COH", 14]);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.InteractionAtomTypeCalculator, "AtomPropertyMask", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mask']]]

Clazz.newMeth(C$, 'c$$I',  function (mask) {
;C$.$init$.apply(this);
this.mask=mask;
}, 1);

Clazz.newMeth(C$, 'getMask$',  function () {
return this.mask;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "ATOMIC_NO", 0, [127]);
Clazz.newEnumConst($vals, C$.c$$I, "HYBRID", 1, [384]);
Clazz.newEnumConst($vals, C$.c$$I, "NONHNEIGHBOURS", 2, [3584]);
Clazz.newEnumConst($vals, C$.c$$I, "AROM", 3, [4096]);
Clazz.newEnumConst($vals, C$.c$$I, "STABILIZED", 4, [8192]);
Clazz.newEnumConst($vals, C$.c$$I, "FUNCTIONAL_GROUP", 5, [1032192]);
Clazz.newEnumConst($vals, C$.c$$I, "BASIC", 6, [511]);
Clazz.newEnumConst($vals, C$.c$$I, "EXTENDED", 7, [16383]);
Clazz.newEnumConst($vals, C$.c$$I, "SPECIFIC", 8, [1036287]);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.InteractionAtomTypeCalculator, "AtomPropertyShift", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['shift']]]

Clazz.newMeth(C$, 'c$$I',  function (shift) {
;C$.$init$.apply(this);
this.shift=shift;
}, 1);

Clazz.newMeth(C$, 'getShift$',  function () {
return this.shift;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "HYBRID_SHIFT", 0, [7]);
Clazz.newEnumConst($vals, C$.c$$I, "NEIGHBOURS_SHIFT", 1, [9]);
Clazz.newEnumConst($vals, C$.c$$I, "FUNCTIONAL_GROUP_SHIFT", 2, [16]);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.InteractionAtomTypeCalculator, "AtomFlagCount", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['count']]]

Clazz.newMeth(C$, 'c$$I',  function (count) {
;C$.$init$.apply(this);
this.count=count;
}, 1);

Clazz.newMeth(C$, 'getCount$',  function () {
return this.count;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "FUNC_GROUP_FLAG_COUNT", 0, [20]);
Clazz.newEnumConst($vals, C$.c$$I, "BASIC_ATOM_FLAG_COUNT", 1, [12]);
Clazz.newEnumConst($vals, C$.c$$I, "EXTENDED_ATOM_FLAG_COUNT", 2, [14]);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
