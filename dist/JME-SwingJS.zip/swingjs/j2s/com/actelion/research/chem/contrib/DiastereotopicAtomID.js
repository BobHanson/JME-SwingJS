(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'com.actelion.research.chem.Molecule','com.actelion.research.chem.Canonizer','StringBuilder','com.actelion.research.chem.SortedStringList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DiastereotopicAtomID");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['I',['xAtomicNumber']]]

Clazz.newMeth(C$, 'getAtomIds$com_actelion_research_chem_StereoMolecule',  function (molecule) {
C$.addMissingChirality$com_actelion_research_chem_StereoMolecule(molecule);
var numberAtoms=molecule.getAllAtoms$();
var ids=Clazz.array(String, [numberAtoms]);
var tempMolecule;
for (var iAtom=0; iAtom < numberAtoms; iAtom++) {
tempMolecule=molecule.getCompactCopy$();
C$.changeAtom$com_actelion_research_chem_StereoMolecule$I(tempMolecule, iAtom);
C$.makeRacemic$com_actelion_research_chem_StereoMolecule(tempMolecule);
ids[iAtom]=(Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I,[tempMolecule, 8])).getIDCode$();
}
return ids;
}, 1);

Clazz.newMeth(C$, 'addMissingChirality$com_actelion_research_chem_StereoMolecule$I',  function (molecule, esrType) {
for (var iAtom=0; iAtom < molecule.getAllAtoms$(); iAtom++) {
var tempMolecule=molecule.getCompactCopy$();
C$.changeAtomForStereo$com_actelion_research_chem_StereoMolecule$I(tempMolecule, iAtom);
tempMolecule.ensureHelperArrays$I(15);
for (var i=0; i < tempMolecule.getAtoms$(); i++) {
if (tempMolecule.isAtomStereoCenter$I(i) && tempMolecule.getStereoBond$I(i) == -1 ) {
var stereoBond=tempMolecule.getAtomPreferredStereoBond$I(i);
if (stereoBond != -1) {
molecule.setBondType$I$I(stereoBond, 257);
if (molecule.getBondAtom$I$I(1, stereoBond) == i) {
var connAtom=molecule.getBondAtom$I$I(0, stereoBond);
molecule.setBondAtom$I$I$I(0, stereoBond, i);
molecule.setBondAtom$I$I$I(1, stereoBond, connAtom);
}molecule.setAtomESR$I$I$I(i, esrType, 0);
}}}
}
}, 1);

Clazz.newMeth(C$, 'addMissingChirality$com_actelion_research_chem_StereoMolecule',  function (molecule) {
C$.addMissingChirality$com_actelion_research_chem_StereoMolecule$I(molecule, 1);
}, 1);

Clazz.newMeth(C$, 'changeAtomForStereo$com_actelion_research_chem_StereoMolecule$I',  function (molecule, iAtom) {
molecule.setAtomicNo$I$I(iAtom, C$.xAtomicNumber);
}, 1);

Clazz.newMeth(C$, 'changeAtom$com_actelion_research_chem_StereoMolecule$I',  function (molecule, iAtom) {
molecule.setAtomCustomLabel$I$S(iAtom, molecule.getAtomLabel$I(iAtom) + "*");
if (molecule.getAtomicNo$I(iAtom) == 1) {
molecule.setAtomicNo$I$I(iAtom, C$.xAtomicNumber);
} else {
molecule.setAtomMass$I$I(iAtom, molecule.getAtomMass$I(iAtom) + 5);
}}, 1);

Clazz.newMeth(C$, 'makeRacemic$com_actelion_research_chem_StereoMolecule',  function (molecule) {
molecule.ensureHelperArrays$I(15);
for (var i=0; i < molecule.getAllAtoms$(); i++) {
if (molecule.getAtomParity$I(i) != 0) {
molecule.setAtomESR$I$I$I(i, 1, 0);
}}
}, 1);

Clazz.newMeth(C$, 'test$com_actelion_research_chem_StereoMolecule',  function (molecule) {
var ids=C$.getAtomIds$com_actelion_research_chem_StereoMolecule(molecule);
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < ids.length; i++) sb.append$S(Integer.toString$I(i)).append$S(" - ").append$S(ids[i]).append$S("\n");

return sb.toString();
}, 1);

Clazz.newMeth(C$, 'markDiastereotopicAtoms$com_actelion_research_chem_StereoMolecule',  function (molecule) {
var ids=C$.getAtomIds$com_actelion_research_chem_StereoMolecule(molecule);
var analyzed=Clazz.new_($I$(4,1));
var group=0;
for (var id, $id = 0, $$id = ids; $id<$$id.length&&((id=($$id[$id])),1);$id++) {
System.out.println$S(id + " - " + group );
if (!analyzed.contains$S(id)) {
analyzed.addString$S(id);
for (var iAtom=0; iAtom < ids.length; iAtom++) {
if (id.equals$O(ids[iAtom])) {
molecule.setAtomCustomLabel$I$S(iAtom, Integer.toString$I(group));
}}
++group;
}}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.xAtomicNumber=$I$(1).getAtomicNoFromLabel$S$I("X", 32);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
