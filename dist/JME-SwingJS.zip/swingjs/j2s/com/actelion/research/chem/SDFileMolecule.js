(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.TreeMap','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SDFileMolecule", null, 'com.actelion.research.chem.StereoMolecule', 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.map_=Clazz.new_($I$(1,1));
this.fields_=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['O',['map_','java.util.TreeMap','fields_','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Molecule',  function (m) {
;C$.superclazz.c$$com_actelion_research_chem_Molecule.apply(this,[m]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_SDFileMolecule',  function (m) {
;C$.superclazz.c$$com_actelion_research_chem_Molecule.apply(this,[m]);C$.$init$.apply(this);
this.map_=Clazz.new_($I$(1,1).c$$java_util_SortedMap,[m.map_]);
this.fields_=Clazz.new_($I$(2,1).c$$java_util_Collection,[m.fields_]);
}, 1);

Clazz.newMeth(C$, 'setFieldData$S$S',  function (field, data) {
this.map_.put$O$O(field, data);
if (!this.fields_.contains$O(field)) this.fields_.add$O(field);
});

Clazz.newMeth(C$, 'getFieldData$S',  function (field) {
var o=this.map_.get$O(field);
if (Clazz.instanceOf(o, "java.lang.String")) return o;
return null;
});

Clazz.newMeth(C$, 'moveFieldToStart$S',  function (field) {
if (this.fields_.contains$O(field)) {
this.fields_.remove$O(field);
this.fields_.add$I$O(0, field);
return true;
}return false;
});

Clazz.newMeth(C$, 'getFields$',  function () {
var set=this.fields_;
var res=Clazz.array(String, [set.size$()]);
set.toArray$OA(res);
return res;
});

Clazz.newMeth(C$, 'toString',  function () {
return "SDFileMolecule " + C$.superclazz.prototype.toString.apply(this, []);
});

Clazz.newMeth(C$, 'writeObject$java_io_ObjectOutputStream',  function (stream) {
System.out.println$S("SDFIleMoleucle writeObject");
}, p$1);

Clazz.newMeth(C$, 'readObject$java_io_ObjectInputStream',  function (stream) {
System.out.println$S("SDFIleMoleucle readObject");
}, p$1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:00 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
