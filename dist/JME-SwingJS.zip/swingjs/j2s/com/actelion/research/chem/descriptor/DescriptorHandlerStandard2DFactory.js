(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.DescriptorHandlerLongFFP512','com.actelion.research.chem.descriptor.DescriptorHandlerLongPFP512','com.actelion.research.chem.descriptor.DescriptorHandlerAllFragmentsFP','com.actelion.research.chem.descriptor.DescriptorHandlerLongCFP','com.actelion.research.chem.descriptor.DescriptorHandlerSkeletonSpheres','com.actelion.research.chem.descriptor.DescriptorHandlerFunctionalGroups','com.actelion.research.chem.descriptor.DescriptorHandlerReactionFP']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerStandard2DFactory", null, null, ['com.actelion.research.chem.descriptor.DescriptorConstants', 'com.actelion.research.chem.descriptor.DescriptorHandlerFactory']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['sFactory','com.actelion.research.chem.descriptor.DescriptorHandlerStandard2DFactory']]]

Clazz.newMeth(C$, 'getFactory$',  function () {
if (C$.sFactory == null ) {
{
if (C$.sFactory == null ) C$.sFactory=Clazz.new_(C$);
}}return C$.sFactory;
}, 1);

Clazz.newMeth(C$, 'getDefaultDescriptorHandler$S',  function (shortName) {
if ($I$(1).DESCRIPTOR_FFP512.shortName.equals$O(shortName)) return $I$(2).getDefaultInstance$();
if ($I$(1).DESCRIPTOR_PFP512.shortName.equals$O(shortName)) return $I$(3).getDefaultInstance$();
if ($I$(1).DESCRIPTOR_ALLFRAG.shortName.equals$O(shortName)) return $I$(4).getDefaultInstance$();
if ($I$(1).DESCRIPTOR_HashedCFp.shortName.equals$O(shortName)) return $I$(5).getDefaultInstance$();
if ($I$(1).DESCRIPTOR_SkeletonSpheres.shortName.equals$O(shortName)) return $I$(6).getDefaultInstance$();
if ($I$(1).DESCRIPTOR_OrganicFunctionalGroups.shortName.equals$O(shortName)) return $I$(7).getDefaultInstance$();
if ($I$(1).DESCRIPTOR_ReactionFP.shortName.equals$O(shortName)) return $I$(8).getDefaultInstance$();
return null;
});

Clazz.newMeth(C$, 'create$S',  function (shortName) {
if ($I$(1).DESCRIPTOR_FFP512.shortName.equals$O(shortName)) return Clazz.new_($I$(2,1));
if ($I$(1).DESCRIPTOR_PFP512.shortName.equals$O(shortName)) return Clazz.new_($I$(3,1));
if ($I$(1).DESCRIPTOR_ALLFRAG.shortName.equals$O(shortName)) return Clazz.new_($I$(4,1));
if ($I$(1).DESCRIPTOR_HashedCFp.shortName.equals$O(shortName)) return Clazz.new_($I$(5,1));
if ($I$(1).DESCRIPTOR_SkeletonSpheres.shortName.equals$O(shortName)) return Clazz.new_($I$(6,1));
if ($I$(1).DESCRIPTOR_OrganicFunctionalGroups.shortName.equals$O(shortName)) return Clazz.new_($I$(7,1));
if ($I$(1).DESCRIPTOR_ReactionFP.shortName.equals$O(shortName)) return Clazz.new_($I$(8,1));
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
