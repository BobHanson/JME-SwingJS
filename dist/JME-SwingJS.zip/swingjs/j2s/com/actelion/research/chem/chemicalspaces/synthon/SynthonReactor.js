(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.synthon"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.StereoMolecule','java.util.HashSet','com.actelion.research.chem.coords.CoordinateInventor',['com.actelion.research.chem.chemicalspaces.synthon.SynthonReactor','.SynthonConnector'],'com.actelion.research.chem.MoleculeStandardizer','com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SynthonReactor", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['SynthonConnector',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'react$java_util_List',  function (synthons) {
var buildingBlocks=Clazz.new_($I$(1,1));
synthons.stream$().forEach$java_util_function_Consumer(((P$.SynthonReactor$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (this.$finals$.buildingBlocks.add$O.apply(this.$finals$.buildingBlocks, [Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Molecule,[e])]));});
})()
), Clazz.new_(P$.SynthonReactor$lambda1.$init$,[this, {buildingBlocks:buildingBlocks}])));
buildingBlocks.forEach$java_util_function_Consumer(((P$.SynthonReactor$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (e.ensureHelperArrays$I.apply(e, [31]));});
})()
), Clazz.new_(P$.SynthonReactor$lambda2.$init$,[this, null])));
var rgrps=Clazz.new_($I$(3,1));
for (var m=0; m < buildingBlocks.size$(); m++) {
var bb=buildingBlocks.get$I(m);
Clazz.new_($I$(4,1)).invent$com_actelion_research_chem_StereoMolecule(bb);
for (var a=0; a < bb.getAtoms$(); a++) {
var atomNo=bb.getAtomicNo$I(a);
if (atomNo >= 92) {
rgrps.add$O(Integer.valueOf$I(atomNo - 92 + 1));
}}
}
var prod=null;
for (var i, $i = rgrps.iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
for (var j=0; j < buildingBlocks.size$(); j++) {
var bb1=buildingBlocks.get$I(j);
if (bb1.getAllAtoms$() == 0) continue;
var reacted=false;
for (var connAtom1, $connAtom1 = C$.findConnectorAtoms$I$com_actelion_research_chem_StereoMolecule(i, bb1).iterator$(); $connAtom1.hasNext$()&&((connAtom1=($connAtom1.next$()).intValue$()),1);) {
if (reacted) continue;
if (connAtom1 > -1) {
var sc1=Clazz.new_($I$(5,1));
sc1.connAtom=connAtom1;
sc1.bb=bb1;
sc1.neighbourAtom=bb1.getConnAtom$I$I(connAtom1, 0);
var b1=bb1.getBond$I$I(connAtom1, sc1.neighbourAtom);
sc1.bondType=bb1.getBondType$I(b1);
sc1.bond=b1;
sc1.bondOrder=bb1.getBondOrder$I(b1);
for (var k=0; k < buildingBlocks.size$(); k++) {
var bb2=buildingBlocks.get$I(k);
if (bb2.getAllAtoms$() == 0) continue;
for (var connAtom2, $connAtom2 = C$.findConnectorAtoms$I$com_actelion_research_chem_StereoMolecule(i, bb2).iterator$(); $connAtom2.hasNext$()&&((connAtom2=($connAtom2.next$()).intValue$()),1);) {
if (reacted) continue;
if (j == k && connAtom1 == connAtom2 ) continue;
var sc2=Clazz.new_($I$(5,1));
sc2.connAtom=connAtom2;
sc2.bb=bb2;
sc2.neighbourAtom=bb2.getConnAtom$I$I(connAtom2, 0);
var b2=bb2.getBond$I$I(connAtom2, sc2.neighbourAtom);
sc2.bondType=bb2.getBondType$I(b2);
sc2.bond=b2;
sc2.bondOrder=bb2.getBondOrder$I(b2);
prod=C$.combineSynthons$com_actelion_research_chem_chemicalspaces_synthon_SynthonReactor_SynthonConnector$com_actelion_research_chem_chemicalspaces_synthon_SynthonReactor_SynthonConnector(sc1, sc2);
reacted=true;
}
}
}}
}
}
return prod;
}, 1);

Clazz.newMeth(C$, 'combineSynthons$com_actelion_research_chem_chemicalspaces_synthon_SynthonReactor_SynthonConnector$com_actelion_research_chem_chemicalspaces_synthon_SynthonReactor_SynthonConnector',  function (sc1, sc2) {
var mol=null;
var referenceConnector=null;
var connector=null;
if (sc2.bondType == 257 || sc2.bondType == 129 ) {
referenceConnector=sc2;
connector=sc1;
} else {
referenceConnector=sc1;
connector=sc2;
}var upDownIdentifier=referenceConnector.bb.getBondAtom$I$I(0, referenceConnector.bond) == referenceConnector.connAtom ? -1 : 1;
var u1=referenceConnector.connAtom;
var u2=connector.connAtom;
var a1=referenceConnector.neighbourAtom;
var a2=connector.neighbourAtom;
var newConnectorAtom=-1;
if (referenceConnector.bb === connector.bb ) {
referenceConnector.bb.markAtomForDeletion$I(referenceConnector.connAtom);
referenceConnector.bb.markAtomForDeletion$I(connector.connAtom);
var map=referenceConnector.bb.deleteMarkedAtomsAndBonds$();
referenceConnector.neighbourAtom=map[referenceConnector.neighbourAtom];
connector.neighbourAtom=map[connector.neighbourAtom];
newConnectorAtom=connector.neighbourAtom;
} else {
referenceConnector.bb.markAtomForDeletion$I(u1);
connector.bb.markAtomForDeletion$I(u2);
C$.alignSynthons$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$I$I(referenceConnector.bb, connector.bb, u1, u2, a1, a2);
var map=referenceConnector.bb.deleteMarkedAtomsAndBonds$();
referenceConnector.neighbourAtom=map[referenceConnector.neighbourAtom];
map=connector.bb.deleteMarkedAtomsAndBonds$();
connector.neighbourAtom=map[connector.neighbourAtom];
map=referenceConnector.bb.addMolecule$com_actelion_research_chem_Molecule(connector.bb);
newConnectorAtom=map[connector.neighbourAtom];
}var bond=-1;
if (upDownIdentifier == -1) {
bond=referenceConnector.bb.addBond$I$I(newConnectorAtom, referenceConnector.neighbourAtom);
} else {
bond=referenceConnector.bb.addBond$I$I(referenceConnector.neighbourAtom, newConnectorAtom);
}referenceConnector.bb.setBondOrder$I$I(bond, referenceConnector.bondOrder);
referenceConnector.bb.setBondType$I$I(bond, referenceConnector.bondType);
referenceConnector.bb.ensureHelperArrays$I(31);
Clazz.new_($I$(4,1)).invent$com_actelion_research_chem_StereoMolecule(referenceConnector.bb);
try {
$I$(6).standardize$com_actelion_research_chem_StereoMolecule$I(referenceConnector.bb, 0);
referenceConnector.bb.ensureHelperArrays$I(31);
} catch (e1) {
if (Clazz.exceptionOf(e1,"Exception")){
e1.printStackTrace$();
} else {
throw e1;
}
}
if (referenceConnector.bb !== connector.bb ) {
connector.bb.clear$();
} else {
connector.bb=Clazz.new_($I$(2,1));
}mol=referenceConnector.bb;
return mol;
}, 1);

Clazz.newMeth(C$, 'findConnectorAtoms$I$com_actelion_research_chem_StereoMolecule',  function (rGrp, bb) {
var atoms=Clazz.new_($I$(1,1));
for (var a=0; a < bb.getAtoms$(); a++) {
var atomNo=bb.getAtomicNo$I(a);
if (atomNo >= 92) {
if (atomNo - 92 + 1 == rGrp) {
atoms.add$O(Integer.valueOf$I(a));
}}}
return atoms;
}, 1);

Clazz.newMeth(C$, 'alignSynthons$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$I$I',  function (s1, s2, u1, u2, a1, a2) {
var v1=s1.getCoordinates$I(u1).subC$com_actelion_research_chem_Coordinates(s1.getCoordinates$I(a1));
var v2=s2.getCoordinates$I(a2).subC$com_actelion_research_chem_Coordinates(s2.getCoordinates$I(u2));
v1.unit$();
v2.unit$();
var alpha=Math.acos(v1.dot$com_actelion_research_chem_Coordinates(v2));
var n;
var cross=v1.cross$com_actelion_research_chem_Coordinates(v2);
if (cross.dist$() < 0.001 ) {
n=Clazz.new_($I$(7,1).c$$D$D$D,[0.0, 0.0, 1.0]);
alpha=3.141592653589793;
} else {
n=cross.unit$();
}var t=s1.getCoordinates$I(a1).scaleC$D(-1.0);
for (var a=0; a < s1.getAtoms$(); a++) {
s1.getCoordinates$I(a).add$com_actelion_research_chem_Coordinates(t);
}
t=s2.getCoordinates$I(u2).scaleC$D(-1.0);
for (var a=0; a < s2.getAtoms$(); a++) {
s2.getCoordinates$I(a).add$com_actelion_research_chem_Coordinates(t);
}
for (var a=0; a < s2.getAtoms$(); a++) {
var newCoords=C$.eulerRodrigues$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D(s2.getCoordinates$I(a), n, -alpha);
s2.setAtomX$I$D(a, newCoords.x);
s2.setAtomY$I$D(a, newCoords.y);
s2.setAtomZ$I$D(a, newCoords.z);
}
}, 1);

Clazz.newMeth(C$, 'eulerRodrigues$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D',  function (v, k, theta) {
var c1=v.scaleC$D(Math.cos(theta));
var c2=k.cross$com_actelion_research_chem_Coordinates(v).scale$D(Math.sin(theta));
var c3=k.scaleC$D(k.dot$com_actelion_research_chem_Coordinates(v) * (1 - Math.cos(theta)));
var vNew=c1.addC$com_actelion_research_chem_Coordinates(c2);
vNew.add$com_actelion_research_chem_Coordinates(c3);
return vNew;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SynthonReactor, "SynthonConnector", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['bond','bondOrder','connAtom','neighbourAtom','bondType'],'O',['bb','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
