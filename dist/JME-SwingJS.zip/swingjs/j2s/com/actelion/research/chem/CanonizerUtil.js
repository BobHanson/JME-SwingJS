(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,['com.actelion.research.chem.CanonizerUtil','.IDCODE_TYPE'],['com.actelion.research.chem.CanonizerUtil','.StrongHasher'],'com.actelion.research.chem.Canonizer','com.actelion.research.chem.MoleculeNeutralizer','com.actelion.research.chem.SimpleCanonizer','com.actelion.research.chem.TautomerHelper']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CanonizerUtil", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['IDCODE_TYPE',25],['StrongHasher',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getIDCode$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z',  function (mol, type, largestFragmentOnly) {
switch (type) {
case $I$(1).NORMAL:
return C$.getIDCode$com_actelion_research_chem_StereoMolecule$Z(mol, largestFragmentOnly);
case $I$(1).NOSTEREO:
return C$.getIDCodeNoStereo$com_actelion_research_chem_StereoMolecule$Z(mol, largestFragmentOnly);
case $I$(1).BACKBONE:
return C$.getIDCodeBackBone$com_actelion_research_chem_StereoMolecule$Z(mol, largestFragmentOnly);
case $I$(1).TAUTOMER:
return C$.getIDCodeTautomer$com_actelion_research_chem_StereoMolecule$Z(mol, largestFragmentOnly);
case $I$(1).NOSTEREO_TAUTOMER:
return C$.getIDCodeNoStereoTautomer$com_actelion_research_chem_StereoMolecule$Z(mol, largestFragmentOnly);
default:
break;
}
return null;
}, 1);

Clazz.newMeth(C$, 'getHash$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z',  function (m, type, largestFragmentOnly) {
var code=C$.getIDCode$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z(m, type, largestFragmentOnly);
return code != null  ? $I$(2).hash$S(code) : 0;
}, 1);

Clazz.newMeth(C$, 'getNoStereoHash$com_actelion_research_chem_StereoMolecule$Z',  function (m, largestFragmentOnly) {
var code=C$.getIDCodeNoStereo$com_actelion_research_chem_StereoMolecule$Z(m, largestFragmentOnly);
return code != null  ? $I$(2).hash$S(code) : 0;
}, 1);

Clazz.newMeth(C$, 'getTautomerHash$com_actelion_research_chem_StereoMolecule$Z',  function (m, largestFragmentOnly) {
var code=C$.getIDCodeTautomer$com_actelion_research_chem_StereoMolecule$Z(m, largestFragmentOnly);
return code != null  ? $I$(2).hash$S(code) : 0;
}, 1);

Clazz.newMeth(C$, 'getNoStereoTautomerHash$com_actelion_research_chem_StereoMolecule$Z',  function (m, largestFragmentOnly) {
var code=C$.getIDCodeNoStereoTautomer$com_actelion_research_chem_StereoMolecule$Z(m, largestFragmentOnly);
return code != null  ? $I$(2).hash$S(code) : 0;
}, 1);

Clazz.newMeth(C$, 'getBackboneHash$com_actelion_research_chem_StereoMolecule$Z',  function (m, largestFragmentOnly) {
var code=C$.getIDCodeBackBone$com_actelion_research_chem_StereoMolecule$Z(m, largestFragmentOnly);
return code != null  ? $I$(2).hash$S(code) : 0;
}, 1);

Clazz.newMeth(C$, 'getIDCode$com_actelion_research_chem_StereoMolecule$Z',  function (mol, largestFragmentOnly) {
try {
if (!largestFragmentOnly) return Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).getIDCode$();
mol=mol.getCompactCopy$();
mol.stripSmallFragments$Z(true);
$I$(4).neutralizeChargedMolecule$com_actelion_research_chem_StereoMolecule(mol);
return Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).getIDCode$();
} catch (e) {
System.err.println$S("WARN: getIDCode() " + e);
return null;
}
}, 1);

Clazz.newMeth(C$, 'getIDCodeNoStereo$com_actelion_research_chem_StereoMolecule$Z',  function (mol, largestFragmentOnly) {
try {
mol=mol.getCompactCopy$();
if (largestFragmentOnly) {
mol.stripSmallFragments$Z(true);
$I$(4).neutralizeChargedMolecule$com_actelion_research_chem_StereoMolecule(mol);
}mol.stripStereoInformation$();
return Clazz.new_($I$(5,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).getIDCode$();
} catch (e) {
System.err.println$S("WARN: getIDCodeNoStereo() " + e);
return null;
}
}, 1);

Clazz.newMeth(C$, 'getIDCodeTautomer$com_actelion_research_chem_StereoMolecule$Z',  function (mol, largestFragmentOnly) {
try {
if (largestFragmentOnly) {
mol=mol.getCompactCopy$();
mol.stripSmallFragments$Z(true);
$I$(4).neutralizeChargedMolecule$com_actelion_research_chem_StereoMolecule(mol);
}var genericTautomer=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).createGenericTautomer$();
return Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[genericTautomer, 8]).getIDCode$();
} catch (e) {
System.err.println$S("WARN: getIDCodeTautomer() " + e);
return null;
}
}, 1);

Clazz.newMeth(C$, 'getIDCodeNoStereoTautomer$com_actelion_research_chem_StereoMolecule$Z',  function (mol, largestFragmentOnly) {
try {
mol=mol.getCompactCopy$();
if (largestFragmentOnly) {
mol.stripSmallFragments$Z(true);
$I$(4).neutralizeChargedMolecule$com_actelion_research_chem_StereoMolecule(mol);
}mol.stripStereoInformation$();
var genericTautomer=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).createGenericTautomer$();
return Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[genericTautomer, 8]).getIDCode$();
} catch (e) {
System.err.println$S("WARN: getIDCodeNoStereoTautomer() " + e);
return null;
}
}, 1);

Clazz.newMeth(C$, 'getIDCodeBackBone$com_actelion_research_chem_StereoMolecule$Z',  function (mol, largestFragmentOnly) {
try {
mol=mol.getCompactCopy$();
if (largestFragmentOnly) {
mol.stripSmallFragments$Z(true);
$I$(4).neutralizeChargedMolecule$com_actelion_research_chem_StereoMolecule(mol);
}mol.stripStereoInformation$();
var b=mol.getAllBonds$();
for (var i=0; i < b; i++) mol.setBondType$I$I(i, 1);

return Clazz.new_($I$(5,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).getIDCode$();
} catch (e) {
System.err.println$S("WARN: getIDCodeBackBone() " + e);
return null;
}
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.CanonizerUtil, "IDCODE_TYPE", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "NORMAL", 0, []);
Clazz.newEnumConst($vals, C$.c$, "NOSTEREO", 1, []);
Clazz.newEnumConst($vals, C$.c$, "BACKBONE", 2, []);
Clazz.newEnumConst($vals, C$.c$, "TAUTOMER", 3, []);
Clazz.newEnumConst($vals, C$.c$, "NOSTEREO_TAUTOMER", 4, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CanonizerUtil, "StrongHasher", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['byteTable','long[]']]]

Clazz.newMeth(C$, 'hash$S',  function (cs) {
if (cs == null ) return 1;
var h=[16404380,295263908445,-1];
var hmult=[1464429,456830610145,1];
var ht=C$.byteTable;
for (var i=cs.length$() - 1; i >= 0; i--) {
var ch=cs.charAt$I(i);
h=Long.$xor((Long.$mul(h,[1464429,456830610145,1])),ht[ch.$c() & 255]);
h=Long.$xor((Long.$mul(h,[1464429,456830610145,1])),ht[(ch.$c() >>> 8) & 255]);
}
return h;
}, 1);

C$.$static$=function(){C$.$static$=0;
{
C$.byteTable=Clazz.array(Long.TYPE, [256]);
var h=[11474564,362038672074,1];
for (var i=0; i < 256; i++) {
for (var j=0; j < 31; j++) {
h=Long.$xor((Long.$usr(h,7)),h);
h=Long.$xor((Long.$sl(h,11)),h);
h=Long.$xor((Long.$usr(h,10)),h);
}
C$.byteTable[i]=h;
}
};
};

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
