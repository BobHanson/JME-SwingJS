(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.type"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.forcefield.mmff.RingBoolean']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Atom");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
if (mol.getAtomType$I(atom) > -1) return mol.getAtomType$I(atom);
if (mol.getAtomicNo$I(atom) == 1) return C$.getHydrogenType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom);
 else return C$.getHeavyType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom);
}, 1);

Clazz.newMeth(C$, 'getHeavyType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
if (mol.isAromaticAtom$I(atom)) {
if (C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, atom, 5)) {
var alphaHet=Clazz.new_([mol.getAllAtoms$()],$I$(1,1).c$$I);
var betaHet=Clazz.new_([mol.getAllAtoms$()],$I$(1,1).c$$I);
var alphaBetaSameRing=false;
var isAlphaOS=false;
var isBetaOS=false;
if (mol.getAtomicNo$I(atom) == 6 || mol.getAtomicNo$I(atom) == 7 ) {
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (!C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, nbr, 5)) continue;
if (C$.inSameRing$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, atom, nbr, 5) && (mol.getAtomicNo$I(nbr) == 8 || mol.getAtomicNo$I(nbr) == 16  || mol.getAtomicNo$I(nbr) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 3  && !C$.isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr)  ) ) alphaHet.add$O(Integer.valueOf$I(nbr));
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (nbr2 == atom) continue;
if (!C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, nbr2, 5)) continue;
if (C$.inSameRing$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, atom, nbr2, 5) && (mol.getAtomicNo$I(nbr2) == 8 || mol.getAtomicNo$I(nbr2) == 16  || mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 3  && !C$.isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2)  ) ) betaHet.add$O(Integer.valueOf$I(nbr2));
}
}
for (var alpha, $alpha = alphaHet.iterator$(); $alpha.hasNext$()&&((alpha=($alpha.next$()).intValue$()),1);) if (mol.getAtomicNo$I(alpha) == 8 || mol.getAtomicNo$I(alpha) == 16 ) {
isAlphaOS=true;
break;
}
for (var beta, $beta = betaHet.iterator$(); $beta.hasNext$()&&((beta=($beta.next$()).intValue$()),1);) if (mol.getAtomicNo$I(beta) == 8 || mol.getAtomicNo$I(beta) == 16 ) {
isBetaOS=true;
break;
}
for (var i=0; i < alphaHet.size$(); i++) for (var j=i; j < betaHet.size$(); j++) if (C$.inSameRing$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, (alphaHet.get$I(i)).$c(), (betaHet.get$I(j)).$c(), 5)) {
alphaBetaSameRing=true;
break;
}

}switch (mol.getAtomicNo$I(atom)) {
case 6:
if (betaHet.isEmpty$()) {
var nN=0;
var nFormalCharge=0;
var nIn5Ring=0;
var nIn6Ring=0;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 3 ) {
++nN;
if (mol.getAtomCharge$I(nbr) > 0 && !C$.isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) ) ++nFormalCharge;
if (C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, nbr, 5)) ++nIn5Ring;
if (C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, nbr, 6)) ++nIn6Ring;
}}
if ((nN == 2 && nIn5Ring > 0  || nN == 3 && nIn5Ring == 2  ) && nFormalCharge > 0  && nIn6Ring == 0 ) return 80;
}if (!(!!(alphaHet.isEmpty$() ^ betaHet.isEmpty$()))) {
var surroundedByBenzeneC=true;
var surroundedByArom=true;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) != 6 || !C$.inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, nbr, 6) ) surroundedByBenzeneC=false;
if (C$.inSameRing$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, atom, nbr, 5) && !mol.isAromaticAtom$I(nbr) ) surroundedByArom=false;
}
if (alphaHet.isEmpty$() && betaHet.isEmpty$() && !surroundedByBenzeneC && surroundedByArom  ) return 78;
if (!alphaHet.isEmpty$() && !alphaHet.isEmpty$() && (!alphaBetaSameRing || !isAlphaOS && !isBetaOS  )  ) return 78;
}if (!alphaHet.isEmpty$() && (betaHet.isEmpty$() || isAlphaOS ) ) return 63;
if (!betaHet.isEmpty$() && (alphaHet.isEmpty$() || isBetaOS ) ) return 64;
break;
case 7:
if (C$.isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom)) return 82;
if (alphaHet.isEmpty$() && betaHet.isEmpty$() ) {
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) return 39;
return 76;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) if (!!(alphaHet.isEmpty$() ^ betaHet.isEmpty$())) return 81;
if (!alphaHet.isEmpty$() && (betaHet.isEmpty$() || isAlphaOS ) ) return 65;
if (!betaHet.isEmpty$() && (alphaHet.isEmpty$() || isBetaOS ) ) return 66;
if (!alphaHet.isEmpty$() && !betaHet.isEmpty$() ) return 79;
break;
case 8:
return 59;
case 16:
return 44;
}
}if (C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, atom, 6)) {
switch (mol.getAtomicNo$I(atom)) {
case 6:
return 37;
case 7:
if (C$.isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom)) return 69;
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) return 58;
return 38;
}
}}switch (mol.getAtomicNo$I(atom)) {
case 3:
if (mol.getConnAtoms$I(atom) == 0) return 92;
break;
case 6:
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 4) {
if (mol.getAtomRingSize$I(atom) == 3) return 22;
if (mol.getAtomRingSize$I(atom) == 4) return 20;
return 1;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) {
var nN2=0;
var nN3=0;
var nO=0;
var nS=0;
var doubleBondedElement=0;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2) doubleBondedElement=mol.getAtomicNo$I(nbr);
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 1) {
if (mol.getAtomicNo$I(nbr) == 8) ++nO;
if (mol.getAtomicNo$I(nbr) == 16) ++nS;
} else if (mol.getAtomicNo$I(nbr) == 7) {
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 3) ++nN3;
 else if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 2 && mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 ) ++nN2;
}}
if (nN3 >= 2 && nN2 == 0  && doubleBondedElement == 7 ) {
return 57;
}if (nO == 2 || nS == 2 ) {
return 41;
}if (mol.getAtomRingSize$I(atom) == 4 && doubleBondedElement == 6 ) {
return 30;
}if (doubleBondedElement == 7 || doubleBondedElement == 8  || doubleBondedElement == 15  || doubleBondedElement == 16 ) {
return 3;
}return 2;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 2) {
return 4;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 1) {
return 60;
}break;
case 7:
var nTermOtoN=0;
var isSulfonamideN=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 8 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 1 ) ++nTermOtoN;
if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) >= 3 && (mol.getAtomicNo$I(nbr) == 15 || mol.getAtomicNo$I(nbr) == 16 ) ) {
var nOtoSP=0;
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (mol.getAtomicNo$I(nbr2) == 8 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ++nOtoSP;
}
if (!isSulfonamideN) isSulfonamideN=nOtoSP >= 2;
}}
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 4) {
if (C$.isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom)) return 68;
return 34;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) {
if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) >= 4) {
var doubleCN=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2) {
doubleCN=mol.getAtomicNo$I(nbr) == 7 || mol.getAtomicNo$I(nbr) == 6 ;
if (mol.getAtomicNo$I(nbr) == 6) {
for (var j=0; doubleCN && j < mol.getAllConnAtoms$I(nbr) ; j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (nbr2 == atom) continue;
doubleCN=!(mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 3 );
}
}}}
if (nTermOtoN == 1) return 67;
if (nTermOtoN >= 2) return 45;
if (doubleCN) return 54;
}if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) >= 3) {
var isNCOorNCS=false;
var isNCNplus=false;
var isNGDplus=false;
var isNNNorNNC=false;
var isNbrC=false;
var isNbrBenzeneC=false;
var EdoubledC=0;
var EtripledC=0;
var N2toC=0;
var N3toC=0;
var OtoC=0;
var StoC=0;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 6) {
isNbrC=true;
if (mol.isAromaticAtom$I(nbr) && mol.getAtomRingSize$I(nbr) == 6 ) isNbrBenzeneC=true;
N2toC=0;
N3toC=0;
OtoC=0;
StoC=0;
var nFormalCharge=0;
var inAromatic6Ring=0;
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
var bond=mol.getBond$I$I(nbr, nbr2);
if (mol.getBondOrder$I(bond) == 2 && (mol.getAtomicNo$I(nbr2) == 8 || mol.getAtomicNo$I(nbr2) == 16 ) ) isNCOorNCS=true;
if (mol.getBondOrder$I(bond) == 2 || (mol.isAromaticBond$I(bond) && (mol.getAtomicNo$I(nbr2) == 6 || (mol.getAtomicNo$I(nbr2) == 7 && C$.inRings$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ) ) ) EdoubledC=mol.getAtomicNo$I(nbr2);
if (mol.getBondOrder$I(bond) == 3) EtripledC=mol.getAtomicNo$I(nbr2);
if (mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 3 ) {
if (mol.getAtomCharge$I(nbr2) == 1) ++nFormalCharge;
if (C$.isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, nbr, 6)) ++inAromatic6Ring;
var OtoN3=0;
for (var k=0; k < mol.getAllConnAtoms$I(nbr2); k++) {
var nbr3=mol.getConnAtom$I$I(nbr2, k);
if (mol.getAtomicNo$I(nbr3) == 8) ++OtoN3;
}
if (OtoN3 < 2) ++N3toC;
}if (mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 2  && (mol.getBondOrder$I(bond) == 2 || mol.isAromaticBond$I(bond) ) ) ++N2toC;
if (mol.isAromaticAtom$I(nbr2)) {
if (mol.getAtomicNo$I(nbr2) == 8) ++OtoC;
if (mol.getAtomicNo$I(nbr2) == 16) ++StoC;
}}
if (EdoubledC == 7) {
if (N3toC == 2 && N2toC == 0  && nFormalCharge > 0  && inAromatic6Ring == 0  && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) < 4 ) isNCNplus=true;
if (N3toC == 3) isNGDplus=true;
}} else if (mol.getAtomicNo$I(nbr) == 7) {
var NtoN=0;
var OtoN=0;
var StoN=0;
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
var bond=mol.getBond$I$I(nbr, nbr2);
if (mol.getBondOrder$I(bond) == 2) {
if (mol.getAtomicNo$I(nbr2) == 6) {
for (var k=0; k < mol.getAllConnAtoms$I(nbr2); k++) {
var nbr3=mol.getConnAtom$I$I(nbr2, k);
if (nbr3 == atom) continue;
if (mol.getAtomicNo$I(nbr3) == 7) ++NtoN;
 else if (mol.getAtomicNo$I(nbr3) == 8) ++OtoN;
 else if (mol.getAtomicNo$I(nbr3) == 16) ++StoN;
}
if (NtoN == 0 && OtoN == 0  && StoN == 0  && !isNbrBenzeneC ) isNNNorNNC=true;
}if (mol.getAtomicNo$I(nbr2) == 7 && !isNbrBenzeneC ) isNNNorNNC=true;
}}
}}
if (isNbrC) {
if (EtripledC == 7) isSulfonamideN=true;
if (isNCNplus) return 55;
if (isNGDplus) return 56;
if (!isNCOorNCS && !isSulfonamideN && (OtoC == 0 && StoC == 0  && isNbrBenzeneC  || EdoubledC == 6  || EdoubledC == 7  || EdoubledC == 15  || EtripledC == 6 )  ) return 40;
}if (!isSulfonamideN && (isNCOorNCS || isNNNorNNC ) ) return 10;
}}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 2) {
if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) == 4) {
var isIsonitrile=false;
for (var i=0; !isIsonitrile && i < mol.getAllConnAtoms$I(atom) ; i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
isIsonitrile=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 3;
}
if (isIsonitrile) return 61;
return 53;
}if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) == 3) {
var isNitroso=false;
var isImineOrAzo=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2) {
isNitroso=mol.getAtomicNo$I(nbr) == 8 && nTermOtoN == 1 ;
isImineOrAzo=mol.getAtomicNo$I(nbr) == 6 || mol.getAtomicNo$I(nbr) == 7 ;
}}
if (isNitroso && !isImineOrAzo ) return 46;
if (isImineOrAzo) return 9;
}if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) >= 2) {
var isNSO=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 16) {
var nTermOtoS=0;
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (mol.getAtomicNo$I(nbr2) == 8 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ++nTermOtoS;
}
isNSO=nTermOtoS == 1;
}}
if (isNSO) return 48;
if (!isSulfonamideN) return 62;
}}if (isSulfonamideN) return 43;
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 1) {
var isNSP=false;
var isNAZT=false;
for (var i=0; !isNSP && !isNAZT && i < mol.getAllConnAtoms$I(atom)  ; i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
isNSP=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 3;
if (mol.getAtomicNo$I(nbr) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 2 ) {
for (var j=0; !isNAZT && j < mol.getAllConnAtoms$I(nbr) ; j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
isNAZT=mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 2  || mol.getAtomicNo$I(nbr2) == 6 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 3  ;
}
}}
if (isNSP) return 42;
if (isNAZT) return 47;
}return 8;
case 8:
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) return 49;
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 2) {
if (mol.getOccupiedValence$I(atom) + mol.getImplicitHydrogens$I(atom) == 3) return 51;
var nHtoO=0;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 1) ++nHtoO;
}
if (nHtoO + mol.getImplicitHydrogens$I(atom) == 2) return 70;
return 6;
}if (mol.getConnAtoms$I(atom) <= 1) {
var nNtoS=0;
var nOtoS=0;
var nStoS=0;
var isOxideOtoH=mol.getAllConnAtoms$I(atom) - mol.getConnAtoms$I(atom) + mol.getImplicitHydrogens$I(atom) > 0 ? true : false;
var isCarboxylateO=false;
var isCarbonylO=false;
var isOxideOtoC=false;
var isNitrosoO=false;
var isOxideOtoN=false;
var isNOxideO=false;
var isNitroO=false;
var isThioSulfinateO=false;
var isSulfateO=false;
var isSulfoxideO=false;
var isPhosphateOrPerchlorateO=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
if (isOxideOtoH) break;
if (isCarboxylateO) break;
if (isCarbonylO) break;
if (isOxideOtoC) break;
if (isNitrosoO) break;
if (isOxideOtoN) break;
if (isNOxideO) break;
if (isNitroO) break;
if (isThioSulfinateO) break;
if (isSulfateO) break;
if (isSulfoxideO) break;
if (isPhosphateOrPerchlorateO) break;
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 6 || mol.getAtomicNo$I(nbr) == 7  || mol.getAtomicNo$I(nbr) == 16 ) {
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 2 ) ++nNtoS;
if (mol.getAtomicNo$I(nbr2) == 8 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ++nOtoS;
if (mol.getAtomicNo$I(nbr2) == 16 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ++nStoS;
}
}isOxideOtoH=mol.getAtomicNo$I(nbr) == 1;
if (mol.getAtomicNo$I(nbr) == 6) {
isCarboxylateO=nOtoS == 2;
isCarbonylO=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2;
isOxideOtoC=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 1 && nOtoS == 1 ;
}if (mol.getAtomicNo$I(nbr) == 7) {
isNitrosoO=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2;
if (mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 1 && nOtoS == 1 ) {
isOxideOtoN=C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 2 || mol.getOccupiedValence$I(nbr) + mol.getImplicitHydrogens$I(nbr) == 3 ;
isNOxideO=mol.getOccupiedValence$I(nbr) + mol.getImplicitHydrogens$I(nbr) == 4;
}isNitroO=nOtoS >= 2;
}if (mol.getAtomicNo$I(nbr) == 16) {
isThioSulfinateO=nStoS == 1;
isSulfateO=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 1 || mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 && nOtoS + nNtoS > 1  ;
isSulfoxideO=mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 && nOtoS + nNtoS == 1 ;
}isPhosphateOrPerchlorateO=mol.getAtomicNo$I(nbr) == 15 || mol.getAtomicNo$I(nbr) == 17 ;
}
if (isOxideOtoC || isOxideOtoN || isOxideOtoH  ) return 35;
if (isCarboxylateO || isNitroO || isNOxideO || isThioSulfinateO || isSulfateO || isPhosphateOrPerchlorateO  ) return 32;
if (isCarbonylO || isNitrosoO || isSulfoxideO  ) return 7;
}break;
case 9:
if (mol.getConnAtoms$I(atom) == 1) return 11;
if (mol.getConnAtoms$I(atom) == 0) return 89;
break;
case 11:
if (mol.getConnAtoms$I(atom) == 0) return 93;
break;
case 12:
if (mol.getConnAtoms$I(atom) == 0) return 99;
break;
case 14:
return 19;
case 15:
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 4) return 25;
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3) return 26;
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 2) return 75;
break;
case 16:
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3 || C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 4 ) {
var nONtoS=0;
var nStoS=0;
var isCdoubleS=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 6 && mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 ) isCdoubleS=true;
if ((mol.getConnAtoms$I(nbr) == 1 && mol.getAtomicNo$I(nbr) == 8 ) || (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 2 && mol.getAtomicNo$I(nbr) == 7 ) ) ++nONtoS;
if (mol.getConnAtoms$I(nbr) == 1 && mol.getAtomicNo$I(nbr) == 16 ) ++nStoS;
}
if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 3 && nONtoS == 2  && isCdoubleS  || C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 4 ) return 18;
if ((nONtoS > 0 && nStoS > 0 ) || nONtoS == 2 && !isCdoubleS  ) return 73;
return 17;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 2) {
var isOdoubleS=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 8 && mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 ) isOdoubleS=true;
}
if (isOdoubleS) return 74;
return 15;
}if (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) == 1) {
var nbrTermS=0;
var isCdoubleS=false;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (mol.getAtomicNo$I(nbr2) == 16 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ++nbrTermS;
}
if (mol.getAtomicNo$I(nbr) == 6 && mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 ) isCdoubleS=true;
}
if (isCdoubleS && nbrTermS != 2 ) return 16;
return 72;
}break;
case 17:
if (mol.getConnAtoms$I(atom) == 4) {
var nO=0;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 8) ++nO;
}
if (nO == 4) return 77;
}if (mol.getConnAtoms$I(atom) == 1) return 12;
if (mol.getConnAtoms$I(atom) == 0) return 90;
break;
case 19:
if (mol.getConnAtoms$I(atom) == 0) return 94;
break;
case 20:
if (mol.getConnAtoms$I(atom) == 0) return 96;
break;
case 26:
if (mol.getConnAtoms$I(atom) == 0) {
if (mol.getAtomCharge$I(atom) == 2) return 87;
if (mol.getAtomCharge$I(atom) == 3) return 88;
}break;
case 29:
if (mol.getConnAtoms$I(atom) == 0) {
if (mol.getAtomCharge$I(atom) == 1) return 97;
if (mol.getAtomCharge$I(atom) == 2) return 98;
}break;
case 30:
if (mol.getConnAtoms$I(atom) == 0) return 95;
break;
case 35:
if (mol.getConnAtoms$I(atom) == 1) return 13;
if (mol.getConnAtoms$I(atom) == 0) return 91;
break;
case 53:
if (mol.getConnAtoms$I(atom) == 1) return 14;
break;
}
return 0;
}, 1);

Clazz.newMeth(C$, 'getHydrogenType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
switch (mol.getAtomicNo$I(nbr)) {
case 6:
return 5;
case 7:
switch (C$.getHeavyType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr)) {
case 8:
case 39:
case 62:
case 67:
case 68:
return 23;
case 34:
case 54:
case 55:
case 56:
case 58:
case 81:
return 36;
case 9:
return 27;
default:
return 28;
}
case 8:
switch (C$.getHeavyType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr)) {
case 49:
return 50;
case 51:
return 52;
case 70:
return 31;
case 6:
var isHOCCorHOCN=false;
var isHOCO=false;
var isHOP=false;
var isHOS=false;
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (mol.getAtomicNo$I(nbr2) == 6) {
for (var k=0; k < mol.getAllConnAtoms$I(nbr2); k++) {
var nbr3=mol.getConnAtom$I$I(nbr2, k);
if (nbr3 == nbr) continue;
var bond=mol.getBond$I$I(nbr2, nbr3);
if ((mol.getAtomicNo$I(nbr3) == 6 || mol.getAtomicNo$I(nbr3) == 7 ) && (mol.getBondOrder$I(bond) == 2 || mol.isAromaticBond$I(bond) ) ) isHOCCorHOCN=true;
if (mol.getAtomicNo$I(nbr3) == 8 && mol.getBondOrder$I(bond) == 2 ) isHOCO=true;
}
}if (mol.getAtomicNo$I(nbr2) == 15) isHOP=true;
if (mol.getAtomicNo$I(nbr2) == 16) isHOS=true;
}
if (isHOCO || isHOP ) return 24;
if (isHOCCorHOCN) return 29;
if (isHOS) return 33;
default:
return 21;
}
case 14:
return 5;
case 15:
return 71;
case 16:
return 71;
}
}
return 0;
}, 1);

Clazz.newMeth(C$, 'isAtomNOxide$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, atom) >= 3 ) {
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(nbr) == 8 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr) == 1 ) return true;
}
}return false;
}, 1);

Clazz.newMeth(C$, 'inRings$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
var rings=mol.getRingSet$();
var rc=0;
for (var r=0; r < rings.getSize$(); r++) if (rings.getAtomIndex$I$I(r, atom) >= 0) ++rc;

return rc;
}, 1);

Clazz.newMeth(C$, 'isInAromaticRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (mol, atom, size) {
if (mol.isAromaticAtom$I(atom)) {
var rings=mol.getRingSet$();
for (var r=0; r < rings.getSize$(); r++) {
if (rings.getRingSize$I(r) != size || !rings.isAtomMember$I$I(r, atom) ) continue;
if (mol.ringIsMMFFAromatic$I(r)) return true;
}
}return false;
}, 1);

Clazz.newMeth(C$, 'ringIsMMFFAromatic$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, r) {
var rings=mol.getRingSet$();
if (!rings.isAromatic$I(r)) return $I$(2).FALSE;
if (rings.getRingSize$I(r) == 6) {
for (var a, $a = 0, $$a = rings.getRingAtoms$I(r); $a<$$a.length&&((a=($$a[$a])),1);$a++) {
if (mol.getOccupiedValence$I(a) + mol.getImplicitHydrogens$I(a) != (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, a) + 1)) return $I$(2).FALSE;
}
for (var b, $b = 0, $$b = rings.getRingBonds$I(r); $b<$$b.length&&((b=($$b[$b])),1);$b++) {
var c=Clazz.array(Integer.TYPE, -1, [-1, -1]);
if (mol.getBondOrder$I(b) == 1) {
for (var j=0; j <= 1; j++) {
var atom=mol.getBondAtom$I$I(j, b);
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (!rings.isAtomMember$I$I(r, nbr) && mol.getBondOrder$I(mol.getBond$I$I(atom, nbr)) == 2 ) {
c[j]=nbr;
break;
}}
}
if (c[0] > -1 && c[1] > -1 ) {
for (var ri=0; ri < rings.getSize$(); ri++) {
if (rings.isAtomMember$I$I(ri, c[0]) && rings.isAtomMember$I$I(ri, c[1]) && !mol.isSetRingMMFFAromaticity$I(ri)  ) return $I$(2).NOT_SET;
if (rings.isAtomMember$I$I(ri, c[0]) && rings.isAtomMember$I$I(ri, c[1]) && !mol.ringIsMMFFAromatic$I(ri)  ) return $I$(2).FALSE;
}
}}}
}if (rings.getRingSize$I(r) == 5) {
var passes=1;
for (var a, $a = 0, $$a = rings.getRingAtoms$I(r); $a<$$a.length&&((a=($$a[$a])),1);$a++) {
if (mol.getOccupiedValence$I(a) + mol.getImplicitHydrogens$I(a) == C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, a) && passes > 0 ) {
--passes;
continue;
}if (mol.getOccupiedValence$I(a) + mol.getImplicitHydrogens$I(a) != (C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, a) + 1)) {
return $I$(2).FALSE;
}}
}return $I$(2).TRUE;
}, 1);

Clazz.newMeth(C$, 'degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
return mol.getAllConnAtoms$I(atom) + mol.getImplicitHydrogens$I(atom);
}, 1);

Clazz.newMeth(C$, 'inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (mol, atom, size) {
if (mol.isRingAtom$I(atom)) {
var rings=mol.getRingSet$();
for (var r=0; r < rings.getSize$(); r++) if (rings.getRingSize$I(r) == size && rings.isAtomMember$I$I(r, atom) ) return true;

}return false;
}, 1);

Clazz.newMeth(C$, 'inSameRing$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, size) {
if (!mol.isRingAtom$I(a1) || !mol.isRingAtom$I(a2) ) return false;
var rings=mol.getRingSet$();
for (var r=0; r < rings.getSize$(); r++) if (rings.getRingSize$I(r) == size && rings.isAtomMember$I$I(r, a1)  && rings.isAtomMember$I$I(r, a2) ) return true;

return false;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
