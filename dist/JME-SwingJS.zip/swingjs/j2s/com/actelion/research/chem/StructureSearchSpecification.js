(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.descriptor.DescriptorHelper','java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureSearchSpecification", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['mSimilarityThreshold'],'I',['mSearchType'],'S',['mDescriptorShortName'],'O',['mIDCode','byte[][]','mDescriptor','Object[]']]]

Clazz.newMeth(C$, 'c$$I$BAA$OA$S$F',  function (searchType, idcode, descriptor, descriptorShortName, similarityThreshold) {
;C$.$init$.apply(this);
this.mSearchType=searchType;
this.mIDCode=idcode;
this.mDescriptor=descriptor;
this.mDescriptorShortName=descriptorShortName;
this.mSimilarityThreshold=similarityThreshold;
}, 1);

Clazz.newMeth(C$, 'getStructureCount$',  function () {
return (this.mIDCode == null ) ? 0 : this.mIDCode.length;
});

Clazz.newMeth(C$, 'getIDCode$I',  function (index) {
return this.mIDCode[index];
});

Clazz.newMeth(C$, 'getDescriptor$I',  function (index) {
return (this.mDescriptor == null ) ? null : this.mDescriptor[index];
});

Clazz.newMeth(C$, 'isSimilaritySearch$',  function () {
return (this.mSearchType & 255) == 2;
});

Clazz.newMeth(C$, 'isNoStructureSearch$',  function () {
return (this.mSearchType & 255) == 0;
});

Clazz.newMeth(C$, 'isSubstructureSearch$',  function () {
return (this.mSearchType & 255) == 1;
});

Clazz.newMeth(C$, 'isExactSearch$',  function () {
return (this.mSearchType & 255) == 3;
});

Clazz.newMeth(C$, 'isNoStereoSearch$',  function () {
return (this.mSearchType & 255) == 4;
});

Clazz.newMeth(C$, 'isTautomerSearch$',  function () {
return (this.mSearchType & 255) == 5;
});

Clazz.newMeth(C$, 'isNoStereoTautomerSearch$',  function () {
return (this.mSearchType & 255) == 6;
});

Clazz.newMeth(C$, 'isBackboneSearch$',  function () {
return (this.mSearchType & 255) == 7;
});

Clazz.newMeth(C$, 'isLargestFragmentOnly$',  function () {
return (this.mSearchType & 256) != 0;
});

Clazz.newMeth(C$, 'isSingleMatchOnly$',  function () {
return (this.mSearchType & 512) != 0;
});

Clazz.newMeth(C$, 'removeDescriptors$',  function () {
this.mDescriptor=null;
});

Clazz.newMeth(C$, 'setLargestFragmentOnly$Z',  function (b) {
this.mSearchType&=~256;
if (b) this.mSearchType|=256;
});

Clazz.newMeth(C$, 'setSingleMatchOnly$Z',  function (b) {
this.mSearchType&=~512;
if (b) this.mSearchType|=512;
});

Clazz.newMeth(C$, 'getDescriptorShortName$',  function () {
return this.mDescriptorShortName;
});

Clazz.newMeth(C$, 'getSimilarityThreshold$',  function () {
return this.mSimilarityThreshold;
});

Clazz.newMeth(C$, 'validate$',  function () {
var count=this.getStructureCount$();
if (count == 0) return "No query structures defined.";
for (var i=0; i < count; i++) if (Clazz.new_($I$(1,1).c$$Z,[false]).getAtomCount$BA$I(this.getIDCode$I(i), 0) == 0) return "Empty structure among query structures.";

if (this.isSimilaritySearch$()) {
if (!$I$(2,"isDescriptorShortName$S",[this.getDescriptorShortName$()])) return "No descriptor type defined.";
if (this.getSimilarityThreshold$() < 0.5  || this.getSimilarityThreshold$() > 1.0  ) return "Similarity threshold out of allowed range.";
}return null;
});

Clazz.newMeth(C$, 'toString',  function () {
var type=this.mSearchType & 255;
var typeString=((type == 1) ? "substructure" : (type == 2) ? "similarity/" + this.mDescriptorShortName + "(" + new Float(this.mSimilarityThreshold).toString() + ")"  : (type == 3) ? "exact" : (type == 4) ? "noStereo" : (type == 5) ? "tautomer" : (type == 6) ? "no-stereo tautomer" : (type == 7) ? "backbone" : "undefined") + (((this.mSearchType & 256) != 0) ? "/largestFragmentOnly" : "");
return "type:" + typeString + (this.mIDCode == null  ? " idcodes:null" : this.mIDCode.length == 1 ? " idcode:" + (this.mIDCode[0] == null  ? "null" :  String.instantialize(this.mIDCode[0], $I$(3).UTF_8)) : " idcodeCount:" + this.mIDCode.length) + (this.mDescriptor == null  ? " descriptors:null" : " descriptorCount:" + this.mDescriptor.length) ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
