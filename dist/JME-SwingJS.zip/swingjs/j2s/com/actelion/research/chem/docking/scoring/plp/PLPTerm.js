(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring.plp"),I$=[[0,'java.util.HashMap','com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PLPTerm", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['A','B','C','D','E','F','D_sq'],'I',['recAtom','ligAtom'],'O',['ligand','com.actelion.research.chem.conf.Conformer','+receptor']]
,['O',['HBOND_TERM','java.util.Map','+METAL_TERM','+BURIED_TERM','+NONPOLAR_TERM']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map',  function (receptor, ligand, recAtom, ligAtom, term) {
;C$.$init$.apply(this);
this.A=(term.get$O("A")).valueOf();
this.B=(term.get$O("B")).valueOf();
this.C=(term.get$O("C")).valueOf();
this.D=(term.get$O("D")).valueOf();
this.E=(term.get$O("E")).valueOf();
this.F=(term.get$O("F")).valueOf();
this.D_sq=this.D * this.D;
this.recAtom=recAtom;
this.ligAtom=ligAtom;
this.ligand=ligand;
this.receptor=receptor;
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map',  function (receptor, ligand, recAtom, ligAtom, term) {
return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map,[receptor, ligand, recAtom, ligAtom, term]);
}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var ci=this.receptor.getCoordinates$I(this.recAtom);
var ck=this.ligand.getCoordinates$I(this.ligAtom);
var cr=ci.subC$com_actelion_research_chem_Coordinates(ck);
var r2=cr.distSq$();
var grad=Clazz.new_($I$(2,1));
var energy=0.0;
if (r2 > this.D_sq ) {
energy=0;
} else {
var prefactor=0.0;
var r=Math.sqrt(r2);
if (r < this.A ) {
prefactor=(-this.F / this.A) * (1.0 / r);
grad=cr.scaleC$D(prefactor);
energy=(this.F * (this.A - r)) / this.A;
} else if (r < this.B ) {
prefactor=(this.E / (this.B - this.A)) * (1.0 / r);
grad=cr.scaleC$D(prefactor);
energy=(this.E * (r - this.A)) / (this.B - this.A);
} else if (r < this.C ) {
prefactor=0.0;
grad=cr.scaleC$D(prefactor);
energy=this.E;
} else if (r <= this.D ) {
prefactor=(-this.E / (this.D - this.C)) * (1.0 / r);
grad=cr.scaleC$D(prefactor);
energy=(this.E * (this.D - r)) / (this.D - this.C);
}}gradient[3 * this.ligAtom]-=grad.x;
gradient[3 * this.ligAtom + 1]-=grad.y;
gradient[3 * this.ligAtom + 2]-=grad.z;
return energy;
});

C$.$static$=function(){C$.$static$=0;
C$.HBOND_TERM=Clazz.new_($I$(1,1));
{
C$.HBOND_TERM.put$O$O("A", Double.valueOf$D(2.3));
C$.HBOND_TERM.put$O$O("B", Double.valueOf$D(2.6));
C$.HBOND_TERM.put$O$O("C", Double.valueOf$D(3.1));
C$.HBOND_TERM.put$O$O("D", Double.valueOf$D(3.4));
C$.HBOND_TERM.put$O$O("E", Double.valueOf$D(-1.0));
C$.HBOND_TERM.put$O$O("F", Double.valueOf$D(20.0));
};
C$.METAL_TERM=Clazz.new_($I$(1,1));
{
C$.METAL_TERM.put$O$O("A", Double.valueOf$D(1.4));
C$.METAL_TERM.put$O$O("B", Double.valueOf$D(2.2));
C$.METAL_TERM.put$O$O("C", Double.valueOf$D(2.6));
C$.METAL_TERM.put$O$O("D", Double.valueOf$D(2.8));
C$.METAL_TERM.put$O$O("E", Double.valueOf$D(-1.0));
C$.METAL_TERM.put$O$O("F", Double.valueOf$D(20.0));
};
C$.BURIED_TERM=Clazz.new_($I$(1,1));
{
C$.BURIED_TERM.put$O$O("A", Double.valueOf$D(3.4));
C$.BURIED_TERM.put$O$O("B", Double.valueOf$D(3.6));
C$.BURIED_TERM.put$O$O("C", Double.valueOf$D(4.5));
C$.BURIED_TERM.put$O$O("D", Double.valueOf$D(5.5));
C$.BURIED_TERM.put$O$O("E", Double.valueOf$D(-0.1));
C$.BURIED_TERM.put$O$O("F", Double.valueOf$D(20.0));
};
C$.NONPOLAR_TERM=Clazz.new_($I$(1,1));
{
C$.NONPOLAR_TERM.put$O$O("A", Double.valueOf$D(3.4));
C$.NONPOLAR_TERM.put$O$O("B", Double.valueOf$D(3.6));
C$.NONPOLAR_TERM.put$O$O("C", Double.valueOf$D(4.5));
C$.NONPOLAR_TERM.put$O$O("D", Double.valueOf$D(5.5));
C$.NONPOLAR_TERM.put$O$O("E", Double.valueOf$D(-0.4));
C$.NONPOLAR_TERM.put$O$O("F", Double.valueOf$D(20.0));
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:24 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
