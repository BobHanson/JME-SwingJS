(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),p$1={},I$=[[0,'java.util.HashMap','java.util.ArrayList','com.actelion.research.chem.io.pdb.parser.ProteinSynthesizer','java.util.stream.Collectors','com.actelion.research.chem.io.pdb.parser.AtomRecord','com.actelion.research.chem.io.pdb.parser.Residue','java.util.stream.IntStream']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureAssembler");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['groups','java.util.Map','bondList','java.util.List','+atomRecords','+hetAtomRecords','mols','java.util.Map']]]

Clazz.newMeth(C$, 'c$$java_util_List$java_util_List$java_util_List',  function (bondList, atomRecords, hetAtomRecords) {
;C$.$init$.apply(this);
this.bondList=bondList;
this.atomRecords=atomRecords;
this.hetAtomRecords=hetAtomRecords;
this.groups=Clazz.new_($I$(1,1));
this.mols=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'assemble$',  function () {
p$1.group.apply(this, []);
var protMols=Clazz.new_($I$(2,1));
this.mols.putIfAbsent$O$O("water", Clazz.new_($I$(2,1)));
this.mols.putIfAbsent$O$O("ligand", Clazz.new_($I$(2,1)));
protMols.add$O(p$1.buildProtein.apply(this, []));
this.mols.put$O$O("protein", protMols);
p$1.buildHetResidues.apply(this, []);
this.mols.forEach$java_util_function_BiConsumer(((P$.StructureAssembler$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (k, v) { return (v.forEach$java_util_function_Consumer(((P$.StructureAssembler$lambda1$2||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda1$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_Molecule3D','accept$O'],  function (e) { return (p$1.coupleBonds$com_actelion_research_chem_Molecule3D.apply(this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'], [e]));});
})()
), Clazz.new_(P$.StructureAssembler$lambda1$2.$init$,[this, null]))));});
})()
), Clazz.new_(P$.StructureAssembler$lambda1.$init$,[this, null])));
return this.mols;
});

Clazz.newMeth(C$, 'group',  function () {
this.groups.put$O$O("protein", this.atomRecords);
this.hetAtomRecords.forEach$java_util_function_Consumer(((P$.StructureAssembler$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_io_pdb_parser_AtomRecord','accept$O'],  function (e) {
var s=e.getString$();
if (this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'].groups.get$O(s) != null ) {
var li=this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'].groups.get$O(s);
li.add$O(e);
} else {
var li=Clazz.new_($I$(2,1));
li.add$O(e);
this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'].groups.put$O$O(s, li);
}});
})()
), Clazz.new_(P$.StructureAssembler$lambda2.$init$,[this, null])));
for (var bond, $bond = this.bondList.iterator$(); $bond.hasNext$()&&((bond=($bond.next$())),1);) {
try {
p$1.processBond$IA.apply(this, [bond]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
continue;
} else {
throw e;
}
}
}
}, p$1);

Clazz.newMeth(C$, 'buildProtein',  function () {
var proteinSynthesizer=Clazz.new_($I$(3,1));
var residues_;
var proteinRecords=this.groups.get$O("protein");
residues_=proteinRecords.stream$().collect$java_util_stream_Collector($I$(4,"groupingBy$java_util_function_Function",[(function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.getString$.apply(t,[])});
})()
)); return Clazz.new_(P$.StructureAssembler$lambda3.$init$,[this, null])})($I$(5))]));
var residues=residues_.values$().stream$().map$java_util_function_Function((P$.StructureAssembler$lambda4$||(P$.StructureAssembler$lambda4$=(((P$.StructureAssembler$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_List','apply$O'],  function (v) { return (Clazz.new_($I$(6,1).c$$java_util_List,[v]));});
})()
), Clazz.new_(P$.StructureAssembler$lambda4.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(4).toList$());
residues.sort$java_util_Comparator((P$.StructureAssembler$lambda5$||(P$.StructureAssembler$lambda5$=(((P$.StructureAssembler$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_io_pdb_parser_Residue$com_actelion_research_chem_io_pdb_parser_Residue','compare$O$O'],  function (c1, c2) {
if (!c1.getChainID$().equals$O(c2.getChainID$())) return c1.getChainID$().compareTo$S(c2.getChainID$());
 else {
if (c1.getResnum$() != c2.getResnum$()) return Integer.compare$I$I(c1.getResnum$(), c2.getResnum$());
 else {
return c1.getInsertionCode$().compareTo$S(c2.getInsertionCode$());
}}});
})()
), Clazz.new_(P$.StructureAssembler$lambda5.$init$,[this, null]))))));
var protMols=Clazz.new_($I$(2,1));
for (var residue, $residue = residues.iterator$(); $residue.hasNext$()&&((residue=($residue.next$())),1);) {
var fragment=residue.getMolecule$();
if (fragment.getAtomAmino$I(0).trim$().equals$O("ACT") || fragment.getAtomAmino$I(0).trim$().equals$O("LIG") ) {
this.mols.get$O("ligand").add$O(fragment);
continue;
} else if (fragment.getAtomAmino$I(0).trim$().equals$O("HOH")) {
this.mols.get$O("water").add$O(fragment);
continue;
}var coupled=proteinSynthesizer.addResidue$com_actelion_research_chem_Molecule3D(fragment);
if (coupled) {
if (residue.isTerminal$()) {
protMols.add$O(proteinSynthesizer.retrieveProtein$());
proteinSynthesizer=Clazz.new_($I$(3,1));
} else continue;
} else {
protMols.add$O(proteinSynthesizer.retrieveProtein$());
proteinSynthesizer=Clazz.new_($I$(3,1));
proteinSynthesizer.addResidue$com_actelion_research_chem_Molecule3D(fragment);
}}
var nextMol=proteinSynthesizer.retrieveProtein$();
if (nextMol != null  && !protMols.contains$O(nextMol) ) protMols.add$O(nextMol);
var protein=protMols.stream$().reduce$java_util_function_BinaryOperator((P$.StructureAssembler$lambda6$||(P$.StructureAssembler$lambda6$=(((P$.StructureAssembler$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D','apply$O$O'],  function (mol1, mol2) {
mol1.addMolecule$com_actelion_research_chem_Molecule(mol2);
return mol1;
});
})()
), Clazz.new_(P$.StructureAssembler$lambda6.$init$,[this, null])))))).get$();
return protein;
}, p$1);

Clazz.newMeth(C$, 'buildHetResidues',  function () {
for (var group, $group = this.groups.keySet$().iterator$(); $group.hasNext$()&&((group=($group.next$())),1);) {
if (group.equals$O("protein")) continue;
 else {
var records=this.groups.get$O(group);
var atomGroup=Clazz.new_($I$(6,1).c$$java_util_List,[records]);
var fragment=atomGroup.getMolecule$();
if (fragment.getAtomAmino$I(0).equals$O("HOH")) {
this.mols.putIfAbsent$O$O("water", Clazz.new_($I$(2,1)));
this.mols.get$O("water").add$O(fragment);
} else {
this.mols.putIfAbsent$O$O("ligand", Clazz.new_($I$(2,1)));
this.mols.get$O("ligand").add$O(fragment);
}}}
}, p$1);

Clazz.newMeth(C$, 'coupleBonds$com_actelion_research_chem_Molecule3D',  function (mol) {
for (var bond, $bond = this.bondList.iterator$(); $bond.hasNext$()&&((bond=($bond.next$())),1);) {
var bondedAtoms=Clazz.array(Integer.TYPE, -1, [-1, -1]);
$I$(7,"range$I$I",[0, mol.getAllAtoms$()]).forEach$java_util_function_IntConsumer(((P$.StructureAssembler$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) {
var pdbAtomID=this.$finals$.mol.getAtomSequence$I(e);
if (pdbAtomID == this.$finals$.bond[0]) this.$finals$.bondedAtoms[0]=e;
 else if (pdbAtomID == this.$finals$.bond[1]) this.$finals$.bondedAtoms[1]=e;
});
})()
), Clazz.new_(P$.StructureAssembler$lambda7.$init$,[this, {mol:mol,bond:bond,bondedAtoms:bondedAtoms}])));
if (bondedAtoms[0] != -1 && bondedAtoms[1] != -1 ) mol.addBond$I$I(bondedAtoms[0], bondedAtoms[1]);
}
}, p$1);

Clazz.newMeth(C$, 'processBond$IA',  function (bond) {
var atom1=bond[0];
var atom2=bond[1];
var grps=Clazz.array(String, [2]);
this.groups.forEach$java_util_function_BiConsumer(((P$.StructureAssembler$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (k, v) {
var atoms=v.stream$().map$java_util_function_Function((P$.StructureAssembler$lambda8$9$||(P$.StructureAssembler$lambda8$9$=(((P$.StructureAssembler$lambda8$9||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda8$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_io_pdb_parser_AtomRecord','apply$O'],  function (e) { return (e.getSerialId$());});
})()
), Clazz.new_(P$.StructureAssembler$lambda8$9.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(4).toList$());
if (atoms.contains$O(Integer.valueOf$I(this.$finals$.atom1))) this.$finals$.grps[0]=k;
if (atoms.contains$O(Integer.valueOf$I(this.$finals$.atom2))) this.$finals$.grps[1]=k;
});
})()
), Clazz.new_(P$.StructureAssembler$lambda8.$init$,[this, {atom1:atom1,grps:grps,atom2:atom2}])));
if (grps[0].equals$O(grps[1])) return;
 else {
if (grps[0].equals$O("protein")) {
this.groups.get$O(grps[0]).addAll$java_util_Collection(this.groups.get$O(grps[1]));
this.groups.remove$O(grps[1]);
} else if (grps[1].equals$O("protein")) {
this.groups.get$O(grps[1]).addAll$java_util_Collection(this.groups.get$O(grps[0]));
this.groups.remove$O(grps[0]);
} else {
this.groups.get$O(grps[0]).addAll$java_util_Collection(this.groups.get$O(grps[1]));
this.groups.remove$O(grps[1]);
}}}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:26 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
