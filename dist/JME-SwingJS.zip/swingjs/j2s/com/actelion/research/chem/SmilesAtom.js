(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SmilesAtom");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isSideChainStart','isSideChainEnd'],'I',['atom','bond','parent'],'O',['closureNeighbour','int[]','closureOpens','boolean[]']]]

Clazz.newMeth(C$, 'c$$I$I$I$Z$Z',  function (atom, bond, parent, isSideChainStart, isSideChainEnd) {
;C$.$init$.apply(this);
this.atom=atom;
this.bond=bond;
this.parent=parent;
this.isSideChainStart=isSideChainStart;
this.isSideChainEnd=isSideChainEnd;
}, 1);

Clazz.newMeth(C$, 'isOpeningClosureTo$I',  function (atom) {
if (this.closureNeighbour != null ) for (var i=0; i < this.closureNeighbour.length; i++) if (atom == this.closureNeighbour[i] && this.closureOpens[i] ) return true;

return false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:34 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
