(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphExtractor','com.actelion.research.chem.descriptor.flexophore.generator.ConformerGeneratorStageTries','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.MoleculeStandardizer','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.generator.MultCoordFragIndex','com.actelion.research.chem.Canonizer','com.actelion.research.chem.descriptor.flexophore.ExceptionConformationGenerationFailed','java.util.HashSet','com.actelion.research.chem.ExtendedMoleculeFunctions','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices','com.actelion.research.chem.SSSearcher','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','com.actelion.research.chem.descriptor.flexophore.PPNodeViz','com.actelion.research.calc.ArrayUtilsCalc','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CreatorMolDistHistViz");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.recentException=null;
},1);

C$.$fields$=[['Z',['onlyOneConformer'],'I',['conformationMode'],'J',['seed'],'O',['subGraphExtractor','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphExtractor','recentException','Exception','arrElectronPoorN','com.actelion.research.chem.StereoMolecule[]','conformerGeneratorStageTries','com.actelion.research.chem.descriptor.flexophore.generator.ConformerGeneratorStageTries']]
,['O',['ARR_EXO_N_AROM_IMIDE','String[]','INSTANCE','com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.subGraphExtractor=Clazz.new_($I$(1,1));
this.conformationMode=0;
this.conformerGeneratorStageTries=Clazz.new_($I$(2,1));
var parser=Clazz.new_($I$(3,1));
this.arrElectronPoorN=Clazz.array($I$(4), [C$.ARR_EXO_N_AROM_IMIDE.length]);
for (var i=0; i < C$.ARR_EXO_N_AROM_IMIDE.length; i++) {
var frag=parser.getCompactMolecule$S(C$.ARR_EXO_N_AROM_IMIDE[i]);
frag.ensureHelperArrays$I(7);
this.arrElectronPoorN[i]=frag;
}
}, 1);

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (threadMaster) {
this.conformerGeneratorStageTries.setThreadMaster$com_actelion_research_calc_ThreadMaster(threadMaster);
});

Clazz.newMeth(C$, 'create$com_actelion_research_chem_StereoMolecule',  function (molOrig) {
var mdhv=null;
switch (this.conformationMode) {
case 0:
mdhv=this.createMultipleConformations$com_actelion_research_chem_StereoMolecule$I(molOrig, 200);
break;
case 1:
mdhv=this.createFromGivenConformation$com_actelion_research_chem_StereoMolecule(molOrig);
break;
case 2:
mdhv=this.createMultipleConformations$com_actelion_research_chem_StereoMolecule$I(molOrig, 1);
break;
default:
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Invalid conformation mode"]);
}
return mdhv;
});

Clazz.newMeth(C$, 'getRecentException$',  function () {
return this.recentException;
});

Clazz.newMeth(C$, 'createMultipleConformations$com_actelion_research_chem_StereoMolecule$I',  function (molOrig, nConformations) {
var molStand=molOrig.getCompactCopy$();
$I$(5).standardize$com_actelion_research_chem_StereoMolecule$I(molStand, 3);
molStand.ensureHelperArrays$I(7);
var molInPlace=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[molStand]);
molInPlace.ensureHelperArrays$I(7);
$I$(7).setInteractionTypes$com_actelion_research_chem_Molecule3D(molInPlace);
var successfulInitialization=this.conformerGeneratorStageTries.setMolecule$com_actelion_research_chem_Molecule3D(molInPlace);
if (!successfulInitialization) {
return null;
}var liSubGraphIndices=this.getSubGraphIndices$com_actelion_research_chem_Molecule3D(molInPlace);
var liMultCoordFragIndex=Clazz.new_($I$(8,1));
for (var subGraphIndices, $subGraphIndices = liSubGraphIndices.iterator$(); $subGraphIndices.hasNext$()&&((subGraphIndices=($subGraphIndices.next$())),1);) {
liMultCoordFragIndex.add$O(Clazz.new_([subGraphIndices.getAtomIndices$()],$I$(9,1).c$$IA));
}
var molViz=this.createConformations$com_actelion_research_chem_Molecule3D$java_util_List$I(molInPlace, liMultCoordFragIndex, nConformations);
var nPotentialConformers=this.conformerGeneratorStageTries.getPotentialConformerCount$();
this.onlyOneConformer=false;
if ((nPotentialConformers > 1) && (liMultCoordFragIndex.get$I(0).getCoordinates$().size$() == 1) ) {
if (false) {
System.out.println$S("CreatorCompleteGraph: only one conformer generated.");
System.out.println$S("Seed " + Long.$s(this.seed));
System.out.println$S("Potential conformer count " + nPotentialConformers);
var can=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_StereoMolecule,[molInPlace]);
System.out.println$S(can.getIDCode$());
}this.onlyOneConformer=true;
}var mdhv=C$.create$java_util_List$com_actelion_research_chem_Molecule3D(liMultCoordFragIndex, molViz);
return mdhv;
});

Clazz.newMeth(C$, 'createFromConformerSet$com_actelion_research_chem_conf_ConformerSet',  function (conformerSet) {
var mol=Clazz.new_([conformerSet.iterator$().next$().toMolecule$()],$I$(6,1).c$$com_actelion_research_chem_StereoMolecule);
mol.ensureHelperArrays$I(7);
$I$(7).setInteractionTypes$com_actelion_research_chem_Molecule3D(mol);
var liSGI=this.getSubGraphIndices$com_actelion_research_chem_Molecule3D(mol);
var liMultCoordFragIndex=Clazz.new_($I$(8,1));
for (var subGraphIndices, $subGraphIndices = liSGI.iterator$(); $subGraphIndices.hasNext$()&&((subGraphIndices=($subGraphIndices.next$())),1);) {
liMultCoordFragIndex.add$O(Clazz.new_([subGraphIndices.getAtomIndices$()],$I$(9,1).c$$IA));
}
var it=conformerSet.iterator$();
while (it.hasNext$()){
var c=it.next$();
var molConf=Clazz.new_([c.toMolecule$()],$I$(6,1).c$$com_actelion_research_chem_StereoMolecule);
molConf.ensureHelperArrays$I(7);
C$.calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List(molConf, liMultCoordFragIndex);
}
var molViz=C$.createPharmacophorePoints$com_actelion_research_chem_Molecule3D$java_util_List(mol, liMultCoordFragIndex);
return C$.create$java_util_List$com_actelion_research_chem_Molecule3D(liMultCoordFragIndex, molViz);
});

Clazz.newMeth(C$, 'getSubGraphIndices$com_actelion_research_chem_Molecule3D',  function (molInPlace) {
var liSubGraphIndices=this.subGraphExtractor.extract$com_actelion_research_chem_StereoMolecule(molInPlace);
liSubGraphIndices=C$.handleCarbonConnected2Hetero$java_util_List$com_actelion_research_chem_StereoMolecule(liSubGraphIndices, molInPlace);
liSubGraphIndices=this.removeExoCyclicElectronPoorN$java_util_List$com_actelion_research_chem_StereoMolecule(liSubGraphIndices, molInPlace);
return liSubGraphIndices;
});

Clazz.newMeth(C$, 'getPotentialConformerCount$',  function () {
return this.conformerGeneratorStageTries.getPotentialConformerCount$();
});

Clazz.newMeth(C$, 'createConformations$com_actelion_research_chem_Molecule3D$java_util_List$I',  function (molInPlace, liMultCoordFragIndex, nConformations) {
var nAtoms=molInPlace.getAtoms$();
var ccConformationsGenerated=0;
var molViz=null;
for (var i=0; i < nConformations; i++) {
var conformerGenerated=false;
try {
conformerGenerated=this.conformerGeneratorStageTries.generateConformerAndSetCoordinates$I$com_actelion_research_chem_Molecule3D(nAtoms, molInPlace);
} catch (e) {
if (Clazz.exceptionOf(e,"com.actelion.research.chem.descriptor.flexophore.generator.ExceptionTimeOutConformerGeneration")){
System.err.println$S("CreatorMolDistHistViz: ExceptionTimeOutConformerGeneration for idcode " + molInPlace.getIDCode$() + ", hence generated " + ccConformationsGenerated + " conformers." );
break;
} else {
throw e;
}
}
if (!conformerGenerated) {
break;
}++ccConformationsGenerated;
C$.calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List(molInPlace, liMultCoordFragIndex);
if (i == 0) {
molViz=C$.createPharmacophorePoints$com_actelion_research_chem_Molecule3D$java_util_List(molInPlace, liMultCoordFragIndex);
}}
if (ccConformationsGenerated == 0) {
throw Clazz.new_($I$(11,1).c$$S,["Impossible to generate one conformer!"]);
}return molViz;
});

Clazz.newMeth(C$, 'handleCarbonConnected2Hetero$java_util_List$com_actelion_research_chem_StereoMolecule',  function (liSubGraphIndices, molInPlace) {
var liSubGraphIndicesProcessed=Clazz.new_($I$(8,1));
for (var sgi, $sgi = liSubGraphIndices.iterator$(); $sgi.hasNext$()&&((sgi=($sgi.next$())),1);) {
var arrIndexAtomFragment=sgi.getAtomIndices$();
var hsIndexAtom2Remove=Clazz.new_($I$(12,1));
for (var indexAtFrag, $indexAtFrag = 0, $$indexAtFrag = arrIndexAtomFragment; $indexAtFrag<$$indexAtFrag.length&&((indexAtFrag=($$indexAtFrag[$indexAtFrag])),1);$indexAtFrag++) {
if ($I$(13).isCarbonConnected2Hetero$com_actelion_research_chem_StereoMolecule$I(molInPlace, indexAtFrag)) {
if ($I$(13).isIsolatedCarbon$com_actelion_research_chem_StereoMolecule$I$IA(molInPlace, indexAtFrag, arrIndexAtomFragment)) {
hsIndexAtom2Remove.add$O(Integer.valueOf$I(indexAtFrag));
}}}
var sgiProcessed=Clazz.new_($I$(14,1));
if (hsIndexAtom2Remove.size$() > 0) {
for (var indexAtFrag, $indexAtFrag = 0, $$indexAtFrag = arrIndexAtomFragment; $indexAtFrag<$$indexAtFrag.length&&((indexAtFrag=($$indexAtFrag[$indexAtFrag])),1);$indexAtFrag++) {
if (!hsIndexAtom2Remove.contains$O(Integer.valueOf$I(indexAtFrag))) {
sgiProcessed.addIndex$I(indexAtFrag);
}}
} else {
sgiProcessed.addIndex$IA(arrIndexAtomFragment);
}if (sgiProcessed.getNumIndices$() > 0) liSubGraphIndicesProcessed.add$O(sgiProcessed);
}
return liSubGraphIndicesProcessed;
}, 1);

Clazz.newMeth(C$, 'removeExoCyclicElectronPoorN$java_util_List$com_actelion_research_chem_StereoMolecule',  function (liSubGraphIndices, molInPlace) {
var liElectronPoorN=p$1.getElectronPoorN$com_actelion_research_chem_StereoMolecule.apply(this, [molInPlace]);
var arrMatchAtom=Clazz.array(Boolean.TYPE, [molInPlace.getAtoms$()]);
for (var indexAt, $indexAt = liElectronPoorN.iterator$(); $indexAt.hasNext$()&&((indexAt=($indexAt.next$()).intValue$()),1);) {
arrMatchAtom[indexAt]=true;
}
var liSubGraphIndicesProcessed=Clazz.new_($I$(8,1));
for (var sgi, $sgi = liSubGraphIndices.iterator$(); $sgi.hasNext$()&&((sgi=($sgi.next$())),1);) {
var arrIndexAtomFragment=sgi.getAtomIndices$();
var hsIndexAtom2Remove=Clazz.new_($I$(12,1));
for (var indexAtFrag, $indexAtFrag = 0, $$indexAtFrag = arrIndexAtomFragment; $indexAtFrag<$$indexAtFrag.length&&((indexAtFrag=($$indexAtFrag[$indexAtFrag])),1);$indexAtFrag++) {
if (arrMatchAtom[indexAtFrag]) {
hsIndexAtom2Remove.add$O(Integer.valueOf$I(indexAtFrag));
}}
var sgiProcessed=Clazz.new_($I$(14,1));
if (hsIndexAtom2Remove.size$() > 0) {
for (var indexAtFrag, $indexAtFrag = 0, $$indexAtFrag = arrIndexAtomFragment; $indexAtFrag<$$indexAtFrag.length&&((indexAtFrag=($$indexAtFrag[$indexAtFrag])),1);$indexAtFrag++) {
if (!hsIndexAtom2Remove.contains$O(Integer.valueOf$I(indexAtFrag))) {
sgiProcessed.addIndex$I(indexAtFrag);
}}
} else {
sgiProcessed.addIndex$IA(arrIndexAtomFragment);
}if (sgiProcessed.getNumIndices$() > 0) liSubGraphIndicesProcessed.add$O(sgiProcessed);
}
return liSubGraphIndicesProcessed;
});

Clazz.newMeth(C$, 'getElectronPoorN$com_actelion_research_chem_StereoMolecule',  function (molInPlace) {
var liElectronPoorN=Clazz.new_($I$(8,1));
var ssSearcher=Clazz.new_($I$(15,1));
ssSearcher.setMolecule$com_actelion_research_chem_StereoMolecule(molInPlace);
for (var i=0; i < this.arrElectronPoorN.length; i++) {
ssSearcher.setFragment$com_actelion_research_chem_StereoMolecule(this.arrElectronPoorN[i]);
var numFrags=ssSearcher.findFragmentInMolecule$I$I(4, 12);
if (numFrags > 0) {
var li=ssSearcher.getMatchList$();
for (var arrIndex, $arrIndex = li.iterator$(); $arrIndex.hasNext$()&&((arrIndex=($arrIndex.next$())),1);) {
for (var j=0; j < arrIndex.length; j++) {
var indAt=arrIndex[j];
var atNo=molInPlace.getAtomicNo$I(indAt);
if (atNo == 7) {
if (!molInPlace.isAromaticAtom$I(indAt)) {
liElectronPoorN.add$O(Integer.valueOf$I(indAt));
}}}
}
}}
return liElectronPoorN;
}, p$1);

Clazz.newMeth(C$, 'create$java_util_List$com_actelion_research_chem_Molecule3D',  function (liMultCoordFragIndex, molecule3D) {
var molDistHistViz=Clazz.new_([liMultCoordFragIndex.size$(), molecule3D],$I$(16,1).c$$I$com_actelion_research_chem_Molecule3D);
var liPPNodeViz=Clazz.new_($I$(8,1));
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
var mcfi=liMultCoordFragIndex.get$I(i);
var arrIndexAtomFrag=mcfi.getArrIndexFrag$();
var ppNodeViz=Clazz.new_($I$(17,1));
ppNodeViz.setIndex$I(i);
ppNodeViz.setCoordinates$com_actelion_research_chem_Coordinates(liMultCoordFragIndex.get$I(i).getCoordinates$().get$I(0));
for (var index, $index = 0, $$index = arrIndexAtomFrag; $index<$$index.length&&((index=($$index[$index])),1);$index++) {
var interactionType=molecule3D.getInteractionAtomType$I(index);
ppNodeViz.add$I(interactionType);
ppNodeViz.addIndexOriginalAtom$I(index);
}
liPPNodeViz.add$O(ppNodeViz);
}
molDistHistViz.set$java_util_List(liPPNodeViz);
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
for (var j=i + 1; j < liMultCoordFragIndex.size$(); j++) {
var arrDistHist=$I$(9,"getDistHist$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex",[liMultCoordFragIndex.get$I(i), liMultCoordFragIndex.get$I(j)]);
molDistHistViz.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
molDistHistViz.realize$();
return molDistHistViz;
}, 1);

Clazz.newMeth(C$, 'addFlexophoreDistanceHistograms$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var molecule=mdhv.getMolecule$();
var liMultCoordFragIndex=Clazz.new_($I$(8,1));
for (var node, $node = mdhv.getNodes$().iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
liMultCoordFragIndex.add$O(Clazz.new_([node.getArrayIndexOriginalAtoms$()],$I$(9,1).c$$IA));
}
this.conformerGeneratorStageTries.setMolecule$com_actelion_research_chem_Molecule3D(molecule);
var ccConformationsGenerated=0;
for (var i=0; i < 200; i++) {
var conformerGenerated=false;
try {
conformerGenerated=this.conformerGeneratorStageTries.generateConformerAndSetCoordinates$I$com_actelion_research_chem_Molecule3D(molecule.getAtoms$(), molecule);
} catch (e) {
if (Clazz.exceptionOf(e,"com.actelion.research.chem.descriptor.flexophore.generator.ExceptionTimeOutConformerGeneration")){
System.err.println$S("CreatorMolDistHistViz: ExceptionTimeOutConformerGeneration for idcode " + molecule.getIDCode$() + ", hence generated " + ccConformationsGenerated + " conformers." );
break;
} else {
throw e;
}
}
if (!conformerGenerated) {
break;
}++ccConformationsGenerated;
C$.calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List(molecule, liMultCoordFragIndex);
}
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
for (var j=i + 1; j < liMultCoordFragIndex.size$(); j++) {
var arrDistHist=$I$(9,"getDistHist$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex",[liMultCoordFragIndex.get$I(i), liMultCoordFragIndex.get$I(j)]);
mdhv.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
});

Clazz.newMeth(C$, 'createWithoutCoordinates$com_actelion_research_chem_Molecule3D',  function (molecule3D) {
$I$(7).setInteractionTypes$com_actelion_research_chem_Molecule3D(molecule3D);
var sgis=this.getSubGraphIndices$com_actelion_research_chem_Molecule3D(molecule3D);
return C$.createWithoutCoordinates$java_util_List$com_actelion_research_chem_Molecule3D(sgis, molecule3D);
});

Clazz.newMeth(C$, 'createWithoutCoordinates$com_actelion_research_chem_Molecule3D$IA',  function (molecule3D, indices2consider) {
$I$(7).setInteractionTypes$com_actelion_research_chem_Molecule3D(molecule3D);
var sgis=this.getSubGraphIndices$com_actelion_research_chem_Molecule3D(molecule3D);
var sgis2consider=Clazz.new_($I$(8,1));
for (var sgi, $sgi = sgis.iterator$(); $sgi.hasNext$()&&((sgi=($sgi.next$())),1);) {
if ($I$(18,"containsAll$IA$IA",[indices2consider, sgi.getAtomIndices$()])) {
sgis2consider.add$O(sgi);
}}
return C$.createWithoutCoordinates$java_util_List$com_actelion_research_chem_Molecule3D(sgis2consider, molecule3D);
});

Clazz.newMeth(C$, 'createWithoutCoordinates$java_util_List$com_actelion_research_chem_Molecule3D',  function (liMultCoordFragIndex, molecule3D) {
var molDistHistViz=Clazz.new_([liMultCoordFragIndex.size$(), molecule3D],$I$(16,1).c$$I$com_actelion_research_chem_Molecule3D);
var liPPNodeViz=Clazz.new_($I$(8,1));
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
var sgi=liMultCoordFragIndex.get$I(i);
var arrIndexAtomFrag=sgi.getAtomIndices$();
var ppNodeViz=Clazz.new_($I$(17,1));
ppNodeViz.setIndex$I(i);
for (var index, $index = 0, $$index = arrIndexAtomFrag; $index<$$index.length&&((index=($$index[$index])),1);$index++) {
var interactionType=molecule3D.getInteractionAtomType$I(index);
ppNodeViz.add$I(interactionType);
ppNodeViz.addIndexOriginalAtom$I(index);
}
liPPNodeViz.add$O(ppNodeViz);
}
molDistHistViz.set$java_util_List(liPPNodeViz);
var arrHistPercent=Clazz.array(Byte.TYPE, [80]);
$I$(19).fill$BA$B(arrHistPercent, 1);
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
for (var j=i + 1; j < liMultCoordFragIndex.size$(); j++) {
molDistHistViz.setDistHist$I$I$BA(i, j, arrHistPercent);
}
}
molDistHistViz.realize$();
return molDistHistViz;
}, 1);

Clazz.newMeth(C$, 'createPharmacophorePoints$com_actelion_research_chem_Molecule3D$java_util_List',  function (molecule3D, liMultCoordFragIndex) {
var molCenter=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule3D,[molecule3D]);
molCenter.ensureHelperArrays$I(7);
for (var multCoordFragIndex, $multCoordFragIndex = liMultCoordFragIndex.iterator$(); $multCoordFragIndex.hasNext$()&&((multCoordFragIndex=($multCoordFragIndex.next$())),1);) {
var arrAtomIndexList=multCoordFragIndex.getArrIndexFrag$();
var coordCenter=molCenter.getCenterOfGravity$IA(arrAtomIndexList);
for (var at=0; at < arrAtomIndexList.length; at++) {
var interactionType=molCenter.getInteractionAtomType$I(arrAtomIndexList[at]);
if (interactionType == -1) {
continue;
}var iAtomicNo=molCenter.getAtomicNo$I(arrAtomIndexList[at]);
molCenter.setAtomFlag$I$I$Z(arrAtomIndexList[at], 8, true);
var indexOriginalAtom=arrAtomIndexList[at];
var indexAtm=molCenter.addAtom$I(iAtomicNo);
molCenter.setInteractionAtomType$I$I(indexAtm, interactionType);
var sOrigIndex=Integer.toString$I(indexOriginalAtom);
molCenter.setAtomChainId$I$S(indexAtm, sOrigIndex);
molCenter.setCoordinates$I$com_actelion_research_chem_Coordinates(indexAtm, coordCenter);
molCenter.setAtomFlag$I$I$Z(indexAtm, 16, true);
molCenter.setPPP$I$IA(indexAtm, arrAtomIndexList);
}
}
molCenter.ensureHelperArrays$I(7);
return molCenter;
}, 1);

Clazz.newMeth(C$, 'isOnlyOneConformer$',  function () {
return this.onlyOneConformer;
});

Clazz.newMeth(C$, 'createFromGivenConformation$com_actelion_research_chem_StereoMolecule',  function (molOrig) {
var molStart=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[molOrig]);
molStart.ensureHelperArrays$I(7);
$I$(7).setInteractionTypes$com_actelion_research_chem_Molecule3D(molStart);
var molInPlace=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule3D,[molStart]);
molInPlace.ensureHelperArrays$I(7);
var liSubGraphIndices=this.getSubGraphIndices$com_actelion_research_chem_Molecule3D(molInPlace);
var liMultCoordFragIndex=Clazz.new_($I$(8,1));
for (var subGraphIndices, $subGraphIndices = liSubGraphIndices.iterator$(); $subGraphIndices.hasNext$()&&((subGraphIndices=($subGraphIndices.next$())),1);) {
liMultCoordFragIndex.add$O(Clazz.new_([subGraphIndices.getAtomIndices$()],$I$(9,1).c$$IA));
}
C$.calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List(molStart, liMultCoordFragIndex);
var mdhv=C$.create$java_util_List$com_actelion_research_chem_Molecule3D(liMultCoordFragIndex, molStart);
return mdhv;
});

Clazz.newMeth(C$, 'calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List',  function (molecule3D, liMultCoordFragIndex) {
for (var multCoordFragIndex, $multCoordFragIndex = liMultCoordFragIndex.iterator$(); $multCoordFragIndex.hasNext$()&&((multCoordFragIndex=($multCoordFragIndex.next$())),1);) {
var arrAtomIndexList=multCoordFragIndex.getArrIndexFrag$();
var coordCenter=molecule3D.getCenterOfGravity$IA(arrAtomIndexList);
multCoordFragIndex.addCoord$com_actelion_research_chem_Coordinates(coordCenter);
}
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.ARR_EXO_N_AROM_IMIDE=Clazz.array(String, -1, ["eMPARVCjK|X`", "gO|@AfeJih@PA@"]);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
