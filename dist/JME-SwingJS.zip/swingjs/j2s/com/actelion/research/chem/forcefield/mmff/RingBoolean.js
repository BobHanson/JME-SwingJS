(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*e*/var C$=Clazz.newClass(P$, "RingBoolean", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "TRUE", 0, []);
Clazz.newEnumConst($vals, C$.c$, "FALSE", 1, []);
Clazz.newEnumConst($vals, C$.c$, "NOT_SET", 2, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
