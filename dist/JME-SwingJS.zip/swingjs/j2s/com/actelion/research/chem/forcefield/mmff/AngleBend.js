(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AngleBend", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isLinear'],'D',['ka','theta0'],'I',['a1','a2','a3']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (table, mol, a1, a2, a3) {
;C$.$init$.apply(this);
this.a1=a1;
this.a2=a2;
this.a3=a3;
this.isLinear=table.atom.linear$I(mol.getAtomType$I(a2));
this.theta0=table.angle.theta$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
this.ka=table.angle.ka$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var theta=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).angle$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]));
var angle=Math.toDegrees(theta) - this.theta0;
var cb=-0.006981317;
var c2=0.043844346773450435;
if (this.isLinear) return 143.9325 * this.ka * (1.0 + Math.cos(theta)) ;
return 0.5 * 0.043844346773450435 * this.ka * angle * angle * (1.0 + -0.006981317 * angle) ;
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var r0=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).normalise$();
var r1=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]).normalise$();
var dist0=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).length$();
var dist1=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]).length$();
var cosTheta=r0.cosAngle$com_actelion_research_chem_forcefield_mmff_Vector3(r1);
var sinThetaSq=1.0 - cosTheta * cosTheta;
var sinTheta=1.0E-8;
if (sinThetaSq > 0.0 ) sinTheta=Math.sqrt(sinThetaSq);
var angleTerm=57.29577951308232 * Math.acos(cosTheta) - this.theta0;
var cb=-0.006981317;
var c2=0.043844346773450435;
var dE_dTheta=57.29577951308232 * c2 * this.ka * angleTerm * (1.0 + 1.5 * cb * angleTerm ) ;
if (this.isLinear) dE_dTheta=-143.9325 * this.ka * sinTheta ;
var dCos_dS=Clazz.array(Double.TYPE, -1, [1.0 / dist0 * (r1.x - cosTheta * r0.x), 1.0 / dist0 * (r1.y - cosTheta * r0.y), 1.0 / dist0 * (r1.z - cosTheta * r0.z), 1.0 / dist1 * (r0.x - cosTheta * r1.x), 1.0 / dist1 * (r0.y - cosTheta * r1.y), 1.0 / dist1 * (r0.z - cosTheta * r1.z)]);
grad[3 * this.a1]+=dE_dTheta * dCos_dS[0] / (-sinTheta);
grad[3 * this.a1 + 1]+=dE_dTheta * dCos_dS[1] / (-sinTheta);
grad[3 * this.a1 + 2]+=dE_dTheta * dCos_dS[2] / (-sinTheta);
grad[3 * this.a2]+=dE_dTheta * (-dCos_dS[0] - dCos_dS[3]) / (-sinTheta);
grad[3 * this.a2 + 1]+=dE_dTheta * (-dCos_dS[1] - dCos_dS[4]) / (-sinTheta);
grad[3 * this.a2 + 2]+=dE_dTheta * (-dCos_dS[2] - dCos_dS[5]) / (-sinTheta);
grad[3 * this.a3]+=dE_dTheta * dCos_dS[3] / (-sinTheta);
grad[3 * this.a3 + 1]+=dE_dTheta * dCos_dS[4] / (-sinTheta);
grad[3 * this.a3 + 2]+=dE_dTheta * dCos_dS[5] / (-sinTheta);
});

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (t, mol) {
var angles=Clazz.new_($I$(2,1));
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (mol.getAllConnAtoms$I(atom) > 1) {
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr_i=mol.getConnAtom$I$I(atom, i);
for (var k=i + 1; k < mol.getAllConnAtoms$I(atom); k++) {
var nbr_k=mol.getConnAtom$I$I(atom, k);
angles.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I,[t, mol, nbr_i, atom, nbr_k]));
}
}
}}
return angles;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
