(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.entity"),I$=[[0,'StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomIndexLinkerId");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atomIndexConnectionFlexophorePoint','atomIndexFirstLinkerAtom','linkerId']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (atomIndexConnectionFlexophorePoint, atomIndexFirstLinkerAtom, linkerId) {
;C$.$init$.apply(this);
this.atomIndexConnectionFlexophorePoint=atomIndexConnectionFlexophorePoint;
this.atomIndexFirstLinkerAtom=atomIndexFirstLinkerAtom;
this.linkerId=linkerId;
}, 1);

Clazz.newMeth(C$, 'getAtomIndexConnectionFlexophorePoint$',  function () {
return this.atomIndexConnectionFlexophorePoint;
});

Clazz.newMeth(C$, 'setAtomIndexConnectionFlexophorePoint$I',  function (atomIndexConnectionFlexophorePoint) {
this.atomIndexConnectionFlexophorePoint=atomIndexConnectionFlexophorePoint;
});

Clazz.newMeth(C$, 'getAtomIndexFirstLinkerAtom$',  function () {
return this.atomIndexFirstLinkerAtom;
});

Clazz.newMeth(C$, 'setAtomIndexFirstLinkerAtom$I',  function (atomIndexFirstLinkerAtom) {
this.atomIndexFirstLinkerAtom=atomIndexFirstLinkerAtom;
});

Clazz.newMeth(C$, 'getLinkerId$',  function () {
return this.linkerId;
});

Clazz.newMeth(C$, 'setLinkerId$I',  function (linkerId) {
this.linkerId=linkerId;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$S("AtomIndexLinkerId [atomIndexConnectionFlexophorePoint=");
sb.append$I(this.atomIndexConnectionFlexophorePoint);
sb.append$S(", atomIndexFirstLinkerAtom=");
sb.append$I(this.atomIndexFirstLinkerAtom);
sb.append$S(", linkerId=");
sb.append$I(this.linkerId);
sb.append$S("]");
return sb.toString();
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:22 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
