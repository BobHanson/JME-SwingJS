(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.converter"),I$=[[0,'com.actelion.research.chem.Molecule3D','java.util.stream.IntStream','java.util.Optional','StringBuilder','com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AminoAcidLabeled");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name','abbreviation'],'O',['mol','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$S$S',  function (mol, name, abbreviation) {
;C$.$init$.apply(this);
this.mol=mol;
this.name=name;
this.abbreviation=abbreviation;
}, 1);

Clazz.newMeth(C$, 'createResidue$java_util_Map',  function (recordMap) {
var residue;
var aminoAcid=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[this.mol]);
try {
if (this.mol.getAtoms$() - recordMap.size$() != 1) {
throw Clazz.new_(Clazz.load('RuntimeException'));
}$I$(2,"range$I$I",[0, this.mol.getAtoms$()]).forEach$java_util_function_IntConsumer(((P$.AminoAcidLabeled$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "AminoAcidLabeled$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (atom) {
var customLabel=$I$(3,"ofNullable$O",[this.b$['com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled'].mol.getAtomCustomLabel$I.apply(this.b$['com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled'].mol, [atom])]);
var sb=Clazz.new_([customLabel.orElse$O.apply(customLabel, [" "])],$I$(4,1).c$$S);
sb.setCharAt$I$C.apply(sb, [0, this.b$['com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled'].mol.getAtomLabel$I.apply(this.b$['com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled'].mol, [atom]).charAt$I.apply(this.b$['com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled'].mol.getAtomLabel$I.apply(this.b$['com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled'].mol, [atom]), [0])]);
var record=this.$finals$.recordMap.get$O.apply(this.$finals$.recordMap, [sb.toString.apply(sb, [])]);
var coords3d=Clazz.new_([record.getX$.apply(record, []), record.getY$.apply(record, []), record.getZ$.apply(record, [])],$I$(5,1).c$$D$D$D);
this.$finals$.aminoAcid.setAtomName$I$S.apply(this.$finals$.aminoAcid, [atom, record.getAtomName$.apply(record, [])]);
this.$finals$.aminoAcid.setAtomAmino$I$S.apply(this.$finals$.aminoAcid, [atom, record.getResName$.apply(record, [])]);
this.$finals$.aminoAcid.setAtomSequence$I$I.apply(this.$finals$.aminoAcid, [atom, record.getSerialId$.apply(record, [])]);
this.$finals$.aminoAcid.setResSequence$I$I.apply(this.$finals$.aminoAcid, [atom, record.getResNum$.apply(record, [])]);
this.$finals$.aminoAcid.setAtomAmino$I$S.apply(this.$finals$.aminoAcid, [atom, record.getResName$.apply(record, [])]);
this.$finals$.aminoAcid.setAtomChainId$I$S.apply(this.$finals$.aminoAcid, [atom, record.getChainID$.apply(record, [])]);
this.$finals$.aminoAcid.setAtomX$I$D.apply(this.$finals$.aminoAcid, [atom, coords3d.x]);
this.$finals$.aminoAcid.setAtomY$I$D.apply(this.$finals$.aminoAcid, [atom, coords3d.y]);
this.$finals$.aminoAcid.setAtomZ$I$D.apply(this.$finals$.aminoAcid, [atom, coords3d.z]);
});
})()
), Clazz.new_(P$.AminoAcidLabeled$lambda1.$init$,[this, {recordMap:recordMap,aminoAcid:aminoAcid}])));
residue=aminoAcid;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
residue=null;
} else {
throw e;
}
}
return residue;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(4,1).c$$S,["AminoAcidLabeled{"]);
sb.append$S("name=\'").append$S(this.name).append$C("\'");
sb.append$S(", abbreviation=\'").append$S(this.abbreviation).append$C("\'");
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
