(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.io.BufferedReader','java.io.FileReader','java.util.ArrayList','java.util.TreeMap','java.util.Properties','com.actelion.research.chem.descriptor.DescriptorConstants']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ODEFileParser", null, 'com.actelion.research.chem.io.CompoundFileParser', ['com.actelion.research.chem.io.CompoundTableConstants', 'com.actelion.research.chem.descriptor.DescriptorConstants']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mIDCodeColumn','mCoordinateColumn','mIndexColumn','mOutdatedIndexColumn'],'S',['mIDCodeColumnName','mCoordinateColumnName','mFragFpColumnName'],'O',['$mReader','java.io.BufferedReader','mFieldName','String[]','+mFieldData','mFieldIndex','int[]']]]

Clazz.newMeth(C$, 'c$$S',  function (fileName) {
Clazz.super_(C$, this);
try {
this.$mReader=Clazz.new_([Clazz.new_($I$(2,1).c$$S,[fileName])],$I$(1,1).c$$java_io_Reader);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.FileNotFoundException")){
} else {
throw e;
}
}
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File',  function (file) {
Clazz.super_(C$, this);
try {
this.$mReader=Clazz.new_([Clazz.new_($I$(2,1).c$$java_io_File,[file])],$I$(1,1).c$$java_io_Reader);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.FileNotFoundException")){
} else {
throw e;
}
}
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_Reader',  function (reader) {
Clazz.super_(C$, this);
this.$mReader=Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.mIDCodeColumn=-1;
this.mCoordinateColumn=-1;
this.mIndexColumn=-1;
this.mOutdatedIndexColumn=-1;
var columnNameList=Clazz.new_($I$(3,1));
var columnIndexList=Clazz.new_($I$(3,1));
var header=null;
if (this.$mReader != null ) try {
header=this.$mReader.readLine$();
if (header != null  && header.equals$O("<datawarrior-fileinfo>") ) {
header=this.$mReader.readLine$();
while (header != null  && !header.equals$O("</datawarrior-fileinfo>") )header=this.$mReader.readLine$();

header=this.$mReader.readLine$();
}if (header != null  && header.equals$O("<column properties>") ) {
var columnProperties=Clazz.new_($I$(4,1));
header=this.$mReader.readLine$();
var properties=null;
var columnName=null;
while (header != null  && !header.equals$O("</column properties>") ){
if (header.startsWith$S("<columnName")) {
columnName=C$.extractValue$S(header);
properties=Clazz.new_($I$(5,1));
} else if (header.startsWith$S("<columnProperty")) {
var keyAndValue=C$.extractValue$S(header);
if (keyAndValue.equals$O("isIDCode\ttrue") || keyAndValue.equals$O("specialType\tidcode") ) {
this.mIDCodeColumnName=columnName;
} else {
var index=keyAndValue.indexOf$I("\t");
properties.put$O$O(keyAndValue.substring$I$I(0, index), keyAndValue.substring$I(index + 1));
}}header=this.$mReader.readLine$();
if (header.startsWith$S("<columnName") || header.equals$O("</column properties>") ) {
columnProperties.put$O$O(columnName, properties);
}}
if (this.mIDCodeColumnName != null ) {
for (var key, $key = columnProperties.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
var props=columnProperties.get$O(key);
if ("idcoordinates2D".equals$O(props.get$O("specialType")) && this.mIDCodeColumnName.equals$O(props.get$O("parent")) ) this.mCoordinateColumnName=key;
 else if ($I$(6).DESCRIPTOR_FFP512.shortName.equals$O(props.get$O("specialType")) && "1.2.1".equals$O(props.get$O("version")) && this.mIDCodeColumnName.equals$O(props.get$O("parent"))  ) this.mFragFpColumnName=key;
}
}header=this.$mReader.readLine$();
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
if (header == null ) {
this.$mReader=null;
return;
}var fromIndex=0;
var toIndex=0;
var sourceColumn=0;
do {
var columnName;
toIndex=header.indexOf$I$I("\t", fromIndex);
if (toIndex == -1) {
columnName=header.substring$I(fromIndex);
} else {
columnName=header.substring$I$I(fromIndex, toIndex);
fromIndex=toIndex + 1;
}if (this.mIDCodeColumn == -1 && columnName.equals$O(this.mIDCodeColumnName) ) this.mIDCodeColumn=sourceColumn;
 else if (this.mCoordinateColumn == -1 && columnName.equals$O(this.mCoordinateColumnName) ) this.mCoordinateColumn=sourceColumn;
 else if (this.mIndexColumn == -1 && columnName.equals$O(this.mFragFpColumnName) ) this.mIndexColumn=sourceColumn;
 else if (columnName.equalsIgnoreCase$S("idcode") && this.mIDCodeColumn == -1 ) this.mIDCodeColumn=sourceColumn;
 else if (columnName.equalsIgnoreCase$S("idcoordinates") && this.mCoordinateColumn == -1 ) this.mCoordinateColumn=sourceColumn;
 else if (columnName.startsWith$S("fingerprint") && this.mIndexColumn == -1 ) {
if (columnName.endsWith$S("1.2.1")) this.mIndexColumn=sourceColumn;
 else this.mOutdatedIndexColumn=sourceColumn;
}if (sourceColumn != this.mIDCodeColumn && sourceColumn != this.mCoordinateColumn  && sourceColumn != this.mIndexColumn  && sourceColumn != this.mOutdatedIndexColumn ) {
columnNameList.add$O(columnName);
columnIndexList.add$O( new Integer(sourceColumn));
}++sourceColumn;
} while (toIndex != -1);
this.mFieldName=Clazz.array(String, [columnNameList.size$()]);
this.mFieldIndex=Clazz.array(Integer.TYPE, [columnNameList.size$()]);
for (var i=0; i < columnNameList.size$(); i++) {
this.mFieldName[i]=columnNameList.get$I(i);
this.mFieldIndex[i]=(columnIndexList.get$I(i)).intValue$();
}
this.mFieldData=Clazz.array(String, [sourceColumn]);
}, p$1);

Clazz.newMeth(C$, 'getFieldNames$',  function () {
return this.mFieldName;
});

Clazz.newMeth(C$, 'advanceToNext$',  function () {
return this.moreRecordsAvailable$();
});

Clazz.newMeth(C$, 'getMoleculeName$',  function () {
return null;
});

Clazz.newMeth(C$, 'getRowCount$',  function () {
return -1;
});

Clazz.newMeth(C$, 'moreRecordsAvailable$',  function () {
if (this.$mReader == null ) return false;
var line=null;
try {
line=this.$mReader.readLine$();
if (line == null  || line.equals$O("<datawarrior properties>")  || line.equals$O("<column properties>")  || line.equals$O("<hitlist data>")  || line.equals$O("<detail data>") ) {
this.$mReader.close$();
return false;
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return false;
} else {
throw e;
}
}
var column=0;
var index1=0;
var index2=line.indexOf$I("\t");
while (index2 != -1){
this.mFieldData[column]=line.substring$I$I(index1, index2);
++column;
index1=index2 + 1;
index2=line.indexOf$I$I("\t", index1);
}
this.mFieldData[column]=line.substring$I(index1);
return true;
});

Clazz.newMeth(C$, 'getIDCode$',  function () {
if (this.mIDCodeColumn == -1) return null;
var s=this.mFieldData[this.mIDCodeColumn];
return (s == null  || s.length$() == 0 ) ? null : s;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
if (this.mCoordinateColumn == -1) return null;
var s=this.mFieldData[this.mCoordinateColumn];
return (s == null  || s.length$() == 0 ) ? null : s;
});

Clazz.newMeth(C$, 'getIndex$',  function () {
if (this.mIndexColumn == -1) return null;
var s=this.mFieldData[this.mIndexColumn];
return (s == null  || s.length$() == 0 ) ? null : s;
});

Clazz.newMeth(C$, 'getFieldData$I',  function (no) {
return this.mFieldData[this.mFieldIndex[no]];
});

Clazz.newMeth(C$, 'extractValue$S',  function (theLine) {
var index1=theLine.indexOf$S("=\"") + 2;
var index2=theLine.indexOf$S$I("\"", index1);
return theLine.substring$I$I(index1, index2);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
