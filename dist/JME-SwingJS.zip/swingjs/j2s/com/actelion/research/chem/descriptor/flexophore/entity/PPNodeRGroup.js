(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.entity"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PPNodeRGroup", null, 'com.actelion.research.chem.descriptor.flexophore.PPNode');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['idcode','coordinates']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_PPNode$S',  function (node, idcode) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_PPNode.apply(this,[node]);C$.$init$.apply(this);
this.idcode=idcode;
}, 1);

Clazz.newMeth(C$, 'getIdCode$',  function () {
return this.idcode;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
return this.coordinates;
});

Clazz.newMeth(C$, 'setIdCode$S',  function (idcode) {
this.idcode=idcode;
});

Clazz.newMeth(C$, 'set$S$S',  function (idcode, coordinates) {
this.idcode=idcode;
this.coordinates=coordinates;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
