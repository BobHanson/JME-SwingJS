(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.StereoMolecule','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ScaffoldHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createMurckoScaffold$com_actelion_research_chem_StereoMolecule$Z',  function (mol, skeletonOnly) {
var isScaffoldMember=C$.findMurckoScaffold$com_actelion_research_chem_StereoMolecule(mol);
if (isScaffoldMember == null ) {
mol.deleteMolecule$();
return;
}for (var atom=0; atom < mol.getAtoms$(); atom++) if (!isScaffoldMember[atom]) mol.markAtomForDeletion$I(atom);

mol.deleteMarkedAtomsAndBonds$();
if (skeletonOnly) C$.makeSkeleton$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'getMurckoScaffold$com_actelion_research_chem_StereoMolecule$Z',  function (mol, skeletonOnly) {
var isScaffoldMember=C$.findMurckoScaffold$com_actelion_research_chem_StereoMolecule(mol);
if (isScaffoldMember == null ) return null;
var scaffold=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(1,1).c$$I$I);
mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(scaffold, isScaffoldMember, false, null);
if (skeletonOnly) C$.makeSkeleton$com_actelion_research_chem_StereoMolecule(scaffold);
return scaffold;
}, 1);

Clazz.newMeth(C$, 'makeSkeleton$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var bond=0; bond < mol.getAllBonds$(); bond++) mol.setBondType$I$I(bond, 1);

for (var atom=0; atom < mol.getAllAtoms$(); atom++) mol.setAtomicNo$I$I(atom, 6);

}, 1);

Clazz.newMeth(C$, 'findMurckoScaffold$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
if (mol.getRingSet$().getSize$() == 0) return null;
var isMember=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.isRingAtom$I(atom)) isMember[atom]=true;

var found;
do {
found=false;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (isMember[atom] && mol.getConnAtoms$I(atom) > 2 ) {
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var connAtom=mol.getConnAtom$I$I(atom, i);
if (!isMember[connAtom]) {
C$.addShortestPathToMember$com_actelion_research_chem_StereoMolecule$I$I$ZA(mol, atom, connAtom, isMember);
}}
}}
} while (found);
do {
found=false;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (isMember[atom] && mol.getAtomPi$I(atom) != 0 ) {
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var connAtom=mol.getConnAtom$I$I(atom, i);
if (!isMember[connAtom] && mol.getConnBondOrder$I$I(atom, i) > 1 ) {
isMember[connAtom]=true;
found=!!(found|((connAtom < atom)));
}}
}}
} while (found);
return isMember;
}, 1);

Clazz.newMeth(C$, 'addShortestPathToMember$com_actelion_research_chem_StereoMolecule$I$I$ZA',  function (mol, atom1, atom2, isMember) {
var parentAtom=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
$I$(2).fill$IA$I(parentAtom, -1);
graphAtom[0]=atom2;
parentAtom[atom1]=-2;
parentAtom[atom2]=atom1;
var current=0;
var highest=0;
while (current <= highest){
for (var i=0; i < mol.getConnAtoms$I(graphAtom[current]); i++) {
var candidate=mol.getConnAtom$I$I(graphAtom[current], i);
if (parentAtom[candidate] == -1) {
if (isMember[candidate]) {
var atom=graphAtom[current];
while (!isMember[atom]){
isMember[atom]=true;
atom=parentAtom[atom];
}
return;
}graphAtom[++highest]=candidate;
parentAtom[candidate]=graphAtom[current];
}}
++current;
}
}, 1);

Clazz.newMeth(C$, 'createMostCentralRingSystem$com_actelion_research_chem_StereoMolecule',  function (mol) {
var isScaffoldMember=C$.findMostCentralRingSystem$com_actelion_research_chem_StereoMolecule(mol);
if (isScaffoldMember == null ) {
mol.deleteMolecule$();
return;
}for (var atom=0; atom < mol.getAtoms$(); atom++) if (!isScaffoldMember[atom]) mol.markAtomForDeletion$I(atom);

mol.deleteMarkedAtomsAndBonds$();
}, 1);

Clazz.newMeth(C$, 'getMostCentralRingSystem$com_actelion_research_chem_StereoMolecule',  function (mol) {
var isScaffoldMember=C$.findMostCentralRingSystem$com_actelion_research_chem_StereoMolecule(mol);
if (isScaffoldMember == null ) return null;
var scaffold=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(1,1).c$$I$I);
mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(scaffold, isScaffoldMember, false, null);
return scaffold;
}, 1);

Clazz.newMeth(C$, 'findMostCentralRingSystem$com_actelion_research_chem_StereoMolecule',  function (mol) {
var isCuttableBond=C$.findCuttableBonds$com_actelion_research_chem_StereoMolecule(mol);
if (isCuttableBond == null ) return null;
var fragmentNo=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
var fragmentCount=mol.getFragmentNumbers$IA$ZA$Z(fragmentNo, isCuttableBond, false);
var fragmentDistanceSum=Clazz.array(Float.TYPE, [fragmentCount]);
var fragmentAtomCount=Clazz.array(Integer.TYPE, [fragmentCount]);
var fragmentContainsRing=Clazz.array(Boolean.TYPE, [fragmentCount]);
var meanAtomDistance=mol.getAverageTopologicalAtomDistance$();
for (var atom=0; atom < mol.getAtoms$(); atom++) {
fragmentDistanceSum[fragmentNo[atom]]+=meanAtomDistance[atom];
++fragmentAtomCount[fragmentNo[atom]];
if (mol.isRingAtom$I(atom)) fragmentContainsRing[fragmentNo[atom]]=true;
}
var minSum=1.7976931348623157E308;
var minFragment=-1;
for (var i=0; i < fragmentCount; i++) {
if (fragmentContainsRing[i] && minSum > fragmentDistanceSum[i] / fragmentAtomCount[i]  ) {
minSum=fragmentDistanceSum[i] / fragmentAtomCount[i];
minFragment=i;
}}
var isFragmentMember=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var atom=0; atom < mol.getAtoms$(); atom++) isFragmentMember[atom]=(fragmentNo[atom] == minFragment);

return isFragmentMember;
}, 1);

Clazz.newMeth(C$, 'findCuttableBonds$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
if (mol.getRingSet$().getSize$() == 0) return null;
var isCuttableBond=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (!mol.isRingBond$I(bond) && (mol.isRingAtom$I(mol.getBondAtom$I$I(0, bond)) || mol.isRingAtom$I(mol.getBondAtom$I$I(1, bond)) ) ) isCuttableBond[bond]=true;
}
return isCuttableBond;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
