(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ConstantsFlexophoreGenerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['I',['MAX_VAL_INTERACTION_TYPE'],'O',['FILTER07_','double[]','+FILTER05_','+FILTER']]]

Clazz.newMeth(C$, 'getResolution$',  function () {
return 0.5;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.MAX_VAL_INTERACTION_TYPE=(Math.pow(2, 24)|0) - 1;
C$.FILTER07_=Clazz.array(Double.TYPE, -1, [0.125, 0.125, 0.125, 0.25, 0.125, 0.125, 0.125]);
C$.FILTER05_=Clazz.array(Double.TYPE, -1, [0.125, 0.25, 0.25, 0.25, 0.125]);
C$.FILTER=C$.FILTER07_;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
