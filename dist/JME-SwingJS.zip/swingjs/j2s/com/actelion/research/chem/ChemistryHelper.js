(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.gui.generic.GenericRectangle','com.actelion.research.chem.ExtendedMolecule',['java.awt.geom.Rectangle2D','.Double']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemistryHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getReactionType$com_actelion_research_chem_reaction_Reaction',  function (r) {
var mols=r.getMolecules$();
var nr=r.getReactants$();
var np=r.getProducts$();
if (mols == 0) return 0;
 else if (nr == 0) return 2;
 else if (np == 0) return 1;
 else return 3;
}, 1);

Clazz.newMeth(C$, 'getBoundingRect$com_actelion_research_chem_reaction_Reaction$Z',  function (r, includearrows) {
var res=null;
if (r == null ) return null;
var nr=r.getReactants$();
var np=r.getProducts$();
var m=r.getMolecules$();
var width=0;
var avgwidth=0;
for (var i=0; i < m; i++) {
var mol=r.getMolecule$I(i);
var nb=mol.getAllBonds$();
var d=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(mol);
if (res == null ) {
if (d != null  && nb > 0 ) {
res=d;
width+=d.getWidth$();
} else {
}} else {
if (d != null  && nb > 0 ) {
res=res.union$com_actelion_research_gui_generic_GenericRectangle(d);
width+=d.getWidth$();
} else {
}}}
if (includearrows && nr == 0  && m > 0 ) {
avgwidth=width / m;
res=Clazz.new_([res.getX$() - avgwidth, res.getY$(), res.getWidth$() + avgwidth, res.getHeight$()],$I$(1,1).c$$D$D$D$D);
} else if (includearrows && np == 0  && m > 0 ) {
avgwidth=width / m;
res=Clazz.new_([res.getX$(), res.getY$(), res.getWidth$() + avgwidth, res.getHeight$()],$I$(1,1).c$$D$D$D$D);
}return res;
}, 1);

Clazz.newMeth(C$, 'getBoundingRect$com_actelion_research_chem_ExtendedMolecule',  function (m) {
var xmax=4.9E-324;
var ymax=4.9E-324;
var xmin=1.7976931348623157E308;
var ymin=1.7976931348623157E308;
if (m == null ) return null;
var na=m.getAllAtoms$();
var bl=0;
bl=m.getAverageBondLength$();
for (var i=0; i < na; i++) {
xmax=Math.max(xmax, m.getAtomX$I(i));
xmin=Math.min(xmin, m.getAtomX$I(i));
ymax=Math.max(ymax, m.getAtomY$I(i));
ymin=Math.min(ymin, m.getAtomY$I(i));
}
return (na > 0) ? Clazz.new_([xmin, ymin, Math.max(xmax - xmin, bl), Math.max(ymax - ymin, bl)],$I$(1,1).c$$D$D$D$D) : null;
}, 1);

Clazz.newMeth(C$, 'getAverageBondLength$com_actelion_research_chem_reaction_Reaction',  function (r) {
var rn=r.getMolecules$();
var avg=0;
var t=0;
for (var i=0; i < rn; i++) {
var molecule=r.getMolecule$I(i);
if (molecule.getAllAtoms$() > 1) t+=molecule.getAverageBondLength$();
}
if (rn > 0) return t / rn;
 else return 0;
}, 1);

Clazz.newMeth(C$, 'setAverageBondLength$com_actelion_research_chem_reaction_Reaction$D',  function (rxn, bndlen) {
var dx=0;
var len=rxn.getMolecules$();
for (var fragment=0; fragment < len; fragment++) {
var m=rxn.getMolecule$I(fragment);
dx=m.getAverageBondLength$();
var scale=bndlen / dx;
C$.transformMolecule$com_actelion_research_chem_Molecule$D$D$D(m, 0, 0, scale);
}
}, 1);

Clazz.newMeth(C$, 'getReactantsBoundingRect$com_actelion_research_chem_reaction_Reaction',  function (r) {
if (r == null ) throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["Cannot pass null reaction"]);
var rn=r.getReactants$();
var rc=null;
for (var i=0; i < rn; i++) {
var rt=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(r.getReactant$I(i));
if (rc != null  && rt != null  ) {
var tmp=rc.union$com_actelion_research_gui_generic_GenericRectangle(rt);
rc=Clazz.new_([tmp.getX$(), tmp.getY$(), tmp.getWidth$(), tmp.getHeight$()],$I$(1,1).c$$D$D$D$D);
} else rc=rt;
}
return rc;
}, 1);

Clazz.newMeth(C$, 'getArrowBoundingRect$com_actelion_research_chem_reaction_Reaction',  function (r) {
var rr=C$.getReactantsBoundingRect$com_actelion_research_chem_reaction_Reaction(r);
var rp=C$.getProductsBoundingRect$com_actelion_research_chem_reaction_Reaction(r);
if (rr != null  && rp != null  ) {
var union=rr.union$com_actelion_research_gui_generic_GenericRectangle(rp);
var y=union.getHeight$() / 2 + union.getY$();
var rx=rr.x + rr.width;
var px=rp.x;
return Clazz.new_([rx < px  ? rx : px, y, Math.abs(px - rx), 0],$I$(1,1).c$$D$D$D$D);
} else if (rr != null ) {
var y=rr.getHeight$() / 2 + rr.getY$();
var rx=rr.x + rr.width;
var width=rr.getWidth$();
return Clazz.new_($I$(1,1).c$$D$D$D$D,[rx, y, width, 0]);
} else if (rp != null ) {
var y=rp.getHeight$() / 2 + rp.getY$();
var width=0;
var rx=rp.x;
return Clazz.new_($I$(1,1).c$$D$D$D$D,[rx, y, width, 0]);
} else {
return Clazz.new_($I$(1,1).c$$D$D$D$D,[0, 0, 0, 0]);
}}, 1);

Clazz.newMeth(C$, 'getDiffRect$com_actelion_research_gui_generic_GenericRectangle$com_actelion_research_gui_generic_GenericRectangle',  function (rr, rp) {
if (rr != null  && rp != null  ) {
var union=rr.union$com_actelion_research_gui_generic_GenericRectangle(rp);
var y=union.y;
var rx=rr.x + rr.width;
var px=rp.x;
var ry=union.y;
var py=union.y + union.height;
var res=Clazz.new_([rx < px  ? rx : px, ry < py  ? ry : py, Math.abs(px - rx), Math.abs(py - ry)],$I$(1,1).c$$D$D$D$D);
return res;
} else {
return null;
}}, 1);

Clazz.newMeth(C$, 'scaleTo$com_actelion_research_gui_generic_GenericRectangle$D$D',  function (src, width, height) {
var x=(src.getWidth$() - width) / 2 + src.getX$();
var y=(src.getHeight$() - height) / 2 + src.getY$();
return Clazz.new_($I$(1,1).c$$D$D$D$D,[x, y, width, height]);
}, 1);

Clazz.newMeth(C$, 'getProductsBoundingRect$com_actelion_research_chem_reaction_Reaction',  function (r) {
if (r == null ) throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["Cannot pass null reaction"]);
var rn=r.getProducts$();
var rc=null;
for (var i=0; i < rn; i++) {
var rt=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(r.getProduct$I(i));
if (rc != null  && rt != null  ) rc=rc.union$com_actelion_research_gui_generic_GenericRectangle(rt);
 else rc=rt;
}
return rc;
}, 1);

Clazz.newMeth(C$, 'transformReaction$com_actelion_research_chem_reaction_Reaction$D$D$D',  function (r, offsetx, offsety, scale) {
var mols=r.getMolecules$();
for (var i=0; i < mols; i++) {
C$.transformMolecule$com_actelion_research_chem_Molecule$D$D$D(r.getMolecule$I(i), offsetx, offsety, scale);
}
}, 1);

Clazz.newMeth(C$, 'transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D',  function (mols, offsetx, offsety, scale) {
if (mols != null ) {
for (var m, $m = 0, $$m = mols; $m<$$m.length&&((m=($$m[$m])),1);$m++) {
C$.transformMolecule$com_actelion_research_chem_Molecule$D$D$D(m, offsetx, offsety, scale);
}
}}, 1);

Clazz.newMeth(C$, 'transformMolecule$com_actelion_research_chem_Molecule$D$D$D',  function (m, offsetx, offsety, scale) {
var atoms=m.getAllAtoms$();
for (var i=0; i < atoms; i++) {
m.setAtomX$I$D(i, (m.getAtomX$I(i) + offsetx) * scale);
m.setAtomY$I$D(i, (m.getAtomY$I(i) + offsety) * scale);
}
}, 1);

Clazz.newMeth(C$, 'scaleIntoF$com_actelion_research_chem_reaction_Reaction$D$D$D$D$D',  function (reaction, x, y, width, height, arrowSize) {
var rr=C$.getBoundingRect$com_actelion_research_chem_reaction_Reaction$Z(reaction, true);
if (rr != null ) {
var cx=-rr.x;
var cy=-rr.y;
C$.transformReaction$com_actelion_research_chem_reaction_Reaction$D$D$D(reaction, cx, cy, 1);
rr=C$.getBoundingRect$com_actelion_research_chem_reaction_Reaction$Z(reaction, true);
var sumWidth=rr.getWidth$();
var sumHeight=rr.getHeight$();
var scH=width / sumWidth;
var scV=height / sumHeight;
var scale=scH;
if (scH > scV ) scale=scV;
C$.transformReaction$com_actelion_research_chem_reaction_Reaction$D$D$D(reaction, 0, 0, scH);
}}, 1);

Clazz.newMeth(C$, 'scaleInto$com_actelion_research_chem_reaction_Reaction$D$D$D$D$D',  function (reaction, x, y, width, height, arrowSize) {
if (width > arrowSize * 2 ) {
var reactants=C$.getReactants$com_actelion_research_chem_reaction_Reaction(reaction);
var products=C$.getProducts$com_actelion_research_chem_reaction_Reaction(reaction);
var sumWidth=0;
var sumHeight=0;
var numMols=reaction.getMolecules$();
for (var i=0; i < numMols; i++) {
var m=reaction.getMolecule$I(i);
if (m.getAllAtoms$() > 1) {
var r=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(m);
if (r != null ) {
sumHeight+=r.getHeight$();
sumWidth+=r.getWidth$();
}}}
if (sumHeight == 0  || sumWidth == 0  ) return;
var scH=width / sumWidth;
var scV=height / sumHeight;
var scale=scH;
if (scH > scV ) scale=scV;
var avbl=C$.getAverageBondLength$com_actelion_research_chem_reaction_Reaction(reaction);
var w=(width - arrowSize) / 2;
var h=height;
scale=Math.min(24 / avbl, scale);
{
var rb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(reactants);
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(reactants, 0, 0, scale);
rb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(reactants);
var dx=x - rb.x + (w - rb.getWidth$()) / 2;
var dy=y - rb.y + (h - rb.getHeight$()) / 2;
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(reactants, dx, dy, 1);
}{
var pb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(products);
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(products, 0, 0, scale);
pb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(products);
var dx=x + w + arrowSize  - pb.x + (w - pb.getWidth$()) / 2;
var dy=y - pb.y + (h - pb.getHeight$()) / 2;
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(products, dx, dy, 1);
}}}, 1);

Clazz.newMeth(C$, 'scaleIntoOld$com_actelion_research_chem_reaction_Reaction$D$D$D$D$D',  function (reaction, x, y, width, height, arrowSize) {
if (width > arrowSize * 2 ) {
var reactants=C$.getReactants$com_actelion_research_chem_reaction_Reaction(reaction);
var products=C$.getProducts$com_actelion_research_chem_reaction_Reaction(reaction);
var rb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(reactants);
var pb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(products);
System.out.printf$S$OA("Reactants bounds %s %s %s\n", Clazz.array(java.lang.Object, -1, [Double.valueOf$D(width), Double.valueOf$D(rb.getWidth$()), Integer.valueOf$I(reactants.length)]));
System.out.printf$S$OA("Product bounds %s %s\n", Clazz.array(java.lang.Object, -1, [Double.valueOf$D(height), Double.valueOf$D(pb.getHeight$())]));
var w=(width - arrowSize) / 2;
var h=height;
var scaleHorizontal=w / Math.max(rb.getWidth$(), pb.getWidth$());
var scaleVertical=h / Math.max(rb.getHeight$(), pb.getHeight$());
System.out.printf$S$OA("Scaling %f vs %f\n", Clazz.array(java.lang.Object, -1, [Double.valueOf$D(scaleHorizontal), Double.valueOf$D(scaleVertical)]));
var scale;
if (scaleHorizontal < scaleVertical ) {
scale=w / Math.max(rb.getWidth$(), pb.getWidth$());
} else {
scale=h / Math.max(rb.getHeight$(), pb.getHeight$());
}var avbl=C$.getAverageBondLength$com_actelion_research_chem_reaction_Reaction(reaction);
scale=Math.min(24 / avbl, scale);
{
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(reactants, 0, 0, scale);
rb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(reactants);
var dx=x - rb.x + (w - rb.getWidth$()) / 2;
var dy=y - rb.y + (h - rb.getHeight$()) / 2;
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(reactants, dx, dy, 1);
}{
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(products, 0, 0, scale);
pb=C$.getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA(products);
var dx=x + w + arrowSize  - pb.x + (w - pb.getWidth$()) / 2;
var dy=y - pb.y + (h - pb.getHeight$()) / 2;
C$.transformMolecules$com_actelion_research_chem_MoleculeA$D$D$D(products, dx, dy, 1);
}}}, 1);

Clazz.newMeth(C$, 'getReactants$com_actelion_research_chem_reaction_Reaction',  function (r) {
var ret=Clazz.array($I$(2), [r.getReactants$()]);
for (var i=0; i < ret.length; i++) {
ret[i]=r.getReactant$I(i);
}
return ret;
}, 1);

Clazz.newMeth(C$, 'getProducts$com_actelion_research_chem_reaction_Reaction',  function (r) {
var ret=Clazz.array($I$(2), [r.getProducts$()]);
for (var i=0; i < ret.length; i++) {
ret[i]=r.getProduct$I(i);
}
return ret;
}, 1);

Clazz.newMeth(C$, 'getBoundingRect$com_actelion_research_chem_ExtendedMoleculeA',  function (mols) {
if (mols == null  || mols.length == 0 ) {
return Clazz.new_($I$(1,1).c$$D$D$D$D,[0, 0, 0, 0]);
}var r=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(mols[0]);
for (var i=1; i < mols.length; i++) {
var t=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(mols[i]);
if (t != null ) {
if (r == null ) r=t;
 else r=r.union$com_actelion_research_gui_generic_GenericRectangle(C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(mols[i]));
}}
if (r == null ) r=Clazz.new_($I$(1,1).c$$D$D$D$D,[0, 0, 0, 0]);
return r;
}, 1);

Clazz.newMeth(C$, 'arrangeReaction$com_actelion_research_chem_reaction_Reaction$java_awt_Dimension',  function (rxn, size) {
var cx=0;
var cy=0;
if (rxn != null ) {
var len=rxn.getMolecules$();
if (len > 0) {
var avBndLen=C$.getAverageBondLength$com_actelion_research_chem_reaction_Reaction(rxn);
C$.setAverageBondLength$com_actelion_research_chem_reaction_Reaction$D(rxn, avBndLen);
for (var fragment=0; fragment < len; fragment++) {
var m=rxn.getMolecule$I(fragment);
var rc=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(m);
if (rc != null ) {
cx+=rc.width;
cy+=rc.height;
}}
var rxnBounding=C$.getArrowBoundingRect$com_actelion_research_chem_reaction_Reaction(rxn);
var plus=Math.max(0, len - 2);
var plusWidth=(size.width/(len + plus + 1 ) / 2 |0);
var dx=cx / len;
cx=cx + plus * dx / 2 + rxnBounding.getWidth$();
cx+=(cx / len);
var avY=cy / len;
var rb=Clazz.new_($I$(3,1).c$$D$D$D$D,[0, 0, size.width, size.height]);
var scalex=rb.width / cx;
var scaley=rb.height / avY;
var scale=Math.min(scalex, scaley);
var offsetx=0;
for (var fragment=0; fragment < len; fragment++) {
var m=rxn.getMolecule$I(fragment);
C$.transformMolecule$com_actelion_research_chem_Molecule$D$D$D(m, 0, 0, scale);
var rectBefore=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(m);
if (rectBefore != null  && rb != null  ) {
var offsety=(rb.height - rectBefore.height) / 2;
var moveX=-rectBefore.x + offsetx;
var moveY=-rectBefore.y + offsety;
C$.transformMolecule$com_actelion_research_chem_Molecule$D$D$D(m, moveX, moveY, 1);
var db=C$.getBoundingRect$com_actelion_research_chem_ExtendedMolecule(m);
if (fragment == rxn.getReactants$() - 1) {
offsetx+=(db.width + plusWidth * 2);
} else {
offsetx+=(db.width + plusWidth);
}}}
}}}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:34 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
