(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PPNodeVizMultCoord", null, 'com.actelion.research.chem.descriptor.flexophore.PPNodeViz');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['multCoordFragIndex','com.actelion.research.chem.descriptor.flexophore.generator.MultCoordFragIndex']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex',  function (node, multCoordFragIndex) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz.apply(this,[node]);C$.$init$.apply(this);
this.multCoordFragIndex=multCoordFragIndex;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:52 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
