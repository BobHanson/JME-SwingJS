(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionDetail");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mAlkyneAtomCount'],'S',['mID'],'O',['mFragment','com.actelion.research.chem.StereoMolecule','mCentralAtom','int[]','+mRearAtom','+mRefAtom','+mToFragmentAtom','+mToMoleculeAtom']]
,['O',['SYMMETRY','int[][]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mFragment=Clazz.new_($I$(1,1).c$$I$I,[24, 29]);
this.mToMoleculeAtom=Clazz.array(Integer.TYPE, [24]);
this.mCentralAtom=Clazz.array(Integer.TYPE, [2]);
this.mRearAtom=Clazz.array(Integer.TYPE, [2]);
this.mRefAtom=Clazz.array(Integer.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'isValid$',  function () {
return this.mID != null ;
});

Clazz.newMeth(C$, 'getID$',  function () {
return this.mID;
});

Clazz.newMeth(C$, 'getCentralAtom$I',  function (no) {
return this.mCentralAtom[no];
});

Clazz.newMeth(C$, 'getRearAtom$I',  function (no) {
return this.mRearAtom[no];
});

Clazz.newMeth(C$, 'getReferenceAtom$I',  function (no) {
return this.mRefAtom[no];
});

Clazz.newMeth(C$, 'getAlkyneAtomCount$',  function () {
return this.mAlkyneAtomCount;
});

Clazz.newMeth(C$, 'getFragment$',  function () {
return this.mFragment;
});

Clazz.newMeth(C$, 'classify$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
this.mFragment.clear$();
this.mID=null;
mol.ensureHelperArrays$I(63);
if (mol.getBondOrder$I(bond) != 1 || mol.isAromaticBond$I(bond) ) return false;
if (mol.getAtomicNo$I(mol.getBondAtom$I$I(0, bond)) == 1 || mol.getAtomicNo$I(mol.getBondAtom$I$I(1, bond)) == 1 ) return false;
var isSmallRingBond=mol.isSmallRingBond$I(bond);
if (isSmallRingBond && mol.getBondRingSize$I(bond) < 6 ) return false;
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
this.mAlkyneAtomCount=0;
for (var i=0; i < 2; i++) {
this.mCentralAtom[i]=mol.getBondAtom$I$I(i, bond);
this.mRearAtom[i]=mol.getBondAtom$I$I(1 - i, bond);
while (mol.getAtomPi$I(this.mCentralAtom[i]) == 2 && mol.getNonHydrogenNeighbourCount$I(this.mCentralAtom[i]) == 2  && mol.getAtomicNo$I(this.mCentralAtom[i]) < 10 ){
for (var j=0; j < mol.getConnAtoms$I(this.mCentralAtom[i]); j++) {
var connAtom=mol.getConnAtom$I$I(this.mCentralAtom[i], j);
if (connAtom != this.mRearAtom[i] && mol.getAtomicNo$I(connAtom) != 1 ) {
if (mol.getConnAtoms$I(connAtom) == 1 || this.mAlkyneAtomCount == 16 ) return false;
atomMask[this.mCentralAtom[i]]=true;
this.mRearAtom[i]=this.mCentralAtom[i];
this.mCentralAtom[i]=connAtom;
++this.mAlkyneAtomCount;
break;
}}
}
var nonHNeighbours=mol.getNonHydrogenNeighbourCount$I(this.mCentralAtom[i]);
if (nonHNeighbours > 4 || nonHNeighbours == 1 ) return false;
atomMask[this.mCentralAtom[i]]=true;
}
for (var i=0; i < 2; i++) {
for (var j=0; j < mol.getConnAtoms$I(this.mCentralAtom[i]); j++) {
var connAtom=mol.getConnAtom$I$I(this.mCentralAtom[i], j);
if (mol.getAtomicNo$I(connAtom) != 1) atomMask[connAtom]=true;
}
}
this.mToFragmentAtom=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(this.mFragment, atomMask, true, this.mToFragmentAtom);
for (var i=0; i < this.mToFragmentAtom.length; i++) if (this.mToFragmentAtom[i] != -1) this.mToMoleculeAtom[this.mToFragmentAtom[i]]=i;

this.mFragment.setFragment$Z(true);
if (isSmallRingBond) {
var bondInFragment=this.mFragment.getBond$I$I(this.mToFragmentAtom[this.mCentralAtom[0]], this.mToFragmentAtom[this.mCentralAtom[1]]);
if (bondInFragment != -1) {
this.mFragment.setBondQueryFeature$I$I$Z(bondInFragment, 256, true);
var ringSet=mol.getRingSet$();
for (var ringNo=0; ringNo < ringSet.getSize$(); ringNo++) {
if (ringSet.isBondMember$I$I(ringNo, bond)) {
for (var i=0; i < 2; i++) {
for (var j=0; j < mol.getConnAtoms$I(this.mCentralAtom[i]); j++) {
var connAtom=mol.getConnAtom$I$I(this.mCentralAtom[i], j);
if (connAtom != this.mRearAtom[i]) {
if (ringSet.isAtomMember$I$I(ringNo, connAtom) && mol.getAtomicNo$I(connAtom) != 1 ) {
this.mFragment.setBondQueryFeature$I$I$Z(this.mFragment.getBond$I$I(this.mToFragmentAtom[this.mCentralAtom[i]], this.mToFragmentAtom[connAtom]), 256, true);
break;
}}}
}
}}
}}for (var i=0; i < 2; i++) {
if (mol.isFlatNitrogen$I(this.mCentralAtom[i])) this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[this.mCentralAtom[i]], 268435456, true);
var delocalizedBondFound=false;
for (var j=0; j < mol.getConnAtoms$I(this.mCentralAtom[i]); j++) {
var connAtom=mol.getConnAtom$I$I(this.mCentralAtom[i], j);
if (connAtom != this.mRearAtom[i] && mol.getAtomicNo$I(connAtom) != 1 ) {
var fragBond=this.mFragment.getBond$I$I(this.mToFragmentAtom[this.mCentralAtom[i]], this.mToFragmentAtom[connAtom]);
if (this.mFragment.getBondType$I(fragBond) == 8) {
delocalizedBondFound=true;
} else if (mol.getAtomicNo$I(connAtom) == 6 && !mol.isAromaticAtom$I(this.mCentralAtom[i]) ) {
var feature=mol.isAromaticAtom$I(connAtom) ? 2 : 4;
this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[connAtom], feature, true);
}var connBond=mol.getConnBond$I$I(this.mCentralAtom[i], j);
var ringSize=mol.getBondRingSize$I(connBond);
if (ringSize == 3 || ringSize == 4 ) this.mFragment.setBondQueryFeature$I$I$Z(fragBond, ringSize << 17, true);
if (mol.isAromaticBond$I(connBond) || mol.getConnBondOrder$I$I(this.mCentralAtom[i], j) == 2 ) {
var nonHNeighbours=mol.getNonHydrogenNeighbourCount$I(connAtom);
var hasZ=(nonHNeighbours == 3);
if (!hasZ && nonHNeighbours == 2  && !mol.isRingAtom$I(connAtom) ) hasZ=(mol.getZNeighbour$I$I(this.mCentralAtom[1 - i], connBond) != -1);
if (hasZ) {
var feature=(3014656);
this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[connAtom], feature, true);
} else if (mol.isAromaticBond$I(connBond)) {
var feature=(3538944);
this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[connAtom], feature, true);
}}if (mol.getConnBondOrder$I$I(this.mCentralAtom[i], j) == 1) {
if (mol.getNonHydrogenNeighbourCount$I(connAtom) == 4) {
var feature=(1966080);
this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[connAtom], feature, true);
} else if (mol.getAtomicNo$I(connAtom) == 6) {
this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[connAtom], 2097152, true);
}}}}
if (!delocalizedBondFound) {
if (mol.isAromaticAtom$I(this.mCentralAtom[i])) this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[this.mCentralAtom[i]], 2, true);
 else this.mFragment.setAtomQueryFeature$I$J$Z(this.mToFragmentAtom[this.mCentralAtom[i]], 4, true);
}}
this.mFragment.ensureHelperArrays$I(191);
for (var i=0; i < 2; i++) {
var fragmentAtom=this.mToFragmentAtom[this.mCentralAtom[i]];
if (this.mFragment.getAtomParity$I(fragmentAtom) == 3) {
if (mol.getAtomParity$I(this.mCentralAtom[i]) == 3) {
return false;
} else {
var preferredBond=this.mFragment.getAtomPreferredStereoBond$I(fragmentAtom);
this.mFragment.setBondType$I$I(preferredBond, 257);
if (this.mFragment.getBondAtom$I$I(0, preferredBond) != fragmentAtom) {
this.mFragment.setBondAtom$I$I$I(1, preferredBond, this.mFragment.getBondAtom$I$I(0, preferredBond));
this.mFragment.setBondAtom$I$I$I(0, preferredBond, fragmentAtom);
}this.mFragment.ensureHelperArrays$I(191);
}}}
var fatom1=this.mToFragmentAtom[this.mCentralAtom[0]];
var fatom2=this.mToFragmentAtom[this.mCentralAtom[1]];
var ratom1=this.mToFragmentAtom[this.mRearAtom[0]];
var ratom2=this.mToFragmentAtom[this.mRearAtom[1]];
var esrType1=this.mFragment.getAtomESRType$I(fatom1);
var esrType2=this.mFragment.getAtomESRType$I(fatom2);
if (this.mFragment.isAtomStereoCenter$I(fatom1) && this.mFragment.isAtomStereoCenter$I(fatom2) ) {
if ((esrType1 != 0 || esrType2 != 0 ) && (esrType1 != esrType2 || this.mFragment.getAtomESRGroup$I(fatom1) != this.mFragment.getAtomESRGroup$I(fatom2) ) ) return false;
}var esrTypeChanged=false;
if (this.mFragment.isAtomStereoCenter$I(fatom1) && esrType1 != 0 ) {
this.mFragment.setAtomESR$I$I$I(fatom1, 0, -1);
esrTypeChanged=true;
}if (this.mFragment.isAtomStereoCenter$I(fatom2) && esrType2 != 0 ) {
this.mFragment.setAtomESR$I$I$I(fatom2, 0, -1);
esrTypeChanged=true;
}if (esrTypeChanged) this.mFragment.ensureHelperArrays$I(191);
var rank1=this.mFragment.getSymmetryRank$I(fatom1);
var rank2=this.mFragment.getSymmetryRank$I(fatom2);
if (rank1 < rank2) {
var temp=this.mCentralAtom[0];
this.mCentralAtom[0]=this.mCentralAtom[1];
this.mCentralAtom[1]=temp;
temp=this.mRearAtom[0];
this.mRearAtom[0]=this.mRearAtom[1];
this.mRearAtom[1]=temp;
temp=fatom1;
fatom1=fatom2;
fatom2=temp;
temp=ratom1;
ratom1=ratom2;
ratom2=temp;
}var isInverted=false;
if (this.mFragment.isAtomStereoCenter$I(fatom1) || this.mFragment.isAtomStereoCenter$I(fatom2) ) {
if (this.mFragment.isAtomStereoCenter$I(fatom1)) {
isInverted=(this.mFragment.getAbsoluteAtomParity$I(fatom1) == 1);
} else if (this.mFragment.isAtomStereoCenter$I(fatom2)) {
isInverted=(this.mFragment.getAbsoluteAtomParity$I(fatom2) == 1);
}if (isInverted) {
for (var atom=0; atom < this.mFragment.getAllAtoms$(); atom++) this.mFragment.setAtomX$I$D(atom, -this.mFragment.getAtomX$I(atom));

this.mFragment.ensureHelperArrays$I(191);
}}var fconn1=p$1.getReferenceNeighbor$I$I.apply(this, [fatom1, ratom1]);
var fconn2=p$1.getReferenceNeighbor$I$I.apply(this, [fatom2, ratom2]);
this.mRefAtom[0]=(fconn1 == -1) ? -1 : this.mToMoleculeAtom[fconn1];
this.mRefAtom[1]=(fconn2 == -1) ? -1 : this.mToMoleculeAtom[fconn2];
var idcode=this.mFragment.getIDCode$();
if (idcode == null ) return false;
var halfSymmetry1=p$1.getHalfSymmetry$I$I.apply(this, [fatom1, ratom1]);
var halfSymmetry2=p$1.getHalfSymmetry$I$I.apply(this, [fatom2, ratom2]);
var symmetryType;
if (halfSymmetry1 == 0 && halfSymmetry2 == 0  && (this.mFragment.getChirality$() & ~65535) == 131072 ) symmetryType=2;
 else symmetryType=C$.SYMMETRY[halfSymmetry1][halfSymmetry2];
var symmetryID=(symmetryType == 0) ? (isInverted ? "<" : ">") : (symmetryType == 1) ? (isInverted ? "-" : "+") : (symmetryType == 3) ? "=" : "";
this.mID=idcode + symmetryID;
return true;
});

Clazz.newMeth(C$, 'getReferenceNeighbor$I$I',  function (atom, remoteBondAtom) {
var maxConn=-1;
var maxRank=-1;
var symConn=-1;
var connHandled=Clazz.array(Boolean.TYPE, [this.mFragment.getConnAtoms$I(atom)]);
for (var i=0; i < this.mFragment.getConnAtoms$I(atom); i++) {
if (!connHandled[i]) {
var conn=this.mFragment.getConnAtom$I$I(atom, i);
if (conn != remoteBondAtom) {
var connRank=this.mFragment.getSymmetryRank$I(conn);
if (maxRank < connRank) {
var equalRankFound=false;
for (var j=i + 1; j < this.mFragment.getConnAtoms$I(atom); j++) {
var candidate=this.mFragment.getConnAtom$I$I(atom, j);
if (candidate != remoteBondAtom && this.mFragment.getSymmetryRank$I(candidate) == connRank ) {
connHandled[j]=true;
if (equalRankFound) return conn;
equalRankFound=true;
}}
if (!equalRankFound) {
maxRank=connRank;
maxConn=conn;
} else {
symConn=conn;
}}}}}
if (maxConn == -1) if (p$1.isFlatAtom$I.apply(this, [atom])) return symConn;
return maxConn;
}, p$1);

Clazz.newMeth(C$, 'isFlatAtom$I',  function (atom) {
return (this.mFragment.getAtomPi$I(atom) == 1 && this.mFragment.getAtomicNo$I(atom) < 10 ) || this.mFragment.isAromaticAtom$I(atom) || this.mFragment.isFlatNitrogen$I(atom)  ;
}, p$1);

Clazz.newMeth(C$, 'getHalfSymmetry$I$I',  function (atom, rearAtom) {
if (this.mFragment.getConnAtoms$I(atom) == 2) return 1;
var connAtom=p$1.getTerminalAtoms$I$I.apply(this, [atom, rearAtom]);
if (this.mFragment.getConnAtoms$I(atom) == 3) {
if (this.mFragment.getSymmetryRank$I(connAtom[0]) == this.mFragment.getSymmetryRank$I(connAtom[1])) return p$1.isFlatAtom$I.apply(this, [atom]) ? 2 : 1;
 else return p$1.isFlatAtom$I.apply(this, [atom]) ? 1 : 0;
}if (this.mFragment.getConnAtoms$I(atom) == 4) {
for (var i=0; i < connAtom.length; i++) {
var rank=this.mFragment.getSymmetryRank$I(connAtom[i]);
for (var j=i + 1; j < connAtom.length; j++) if (rank == this.mFragment.getSymmetryRank$I(connAtom[j])) return 1;

}
}return 0;
}, p$1);

Clazz.newMeth(C$, 'getTerminalAtoms$I$I',  function (atom, rearAtom) {
var index=0;
var connAtom=Clazz.array(Integer.TYPE, [this.mFragment.getConnAtoms$I(atom) - 1]);
for (var i=0; i < this.mFragment.getConnAtoms$I(atom); i++) if (this.mFragment.getConnAtom$I$I(atom, i) != rearAtom) connAtom[index++]=this.mFragment.getConnAtom$I$I(atom, i);

return connAtom;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.SYMMETRY=Clazz.array(Integer.TYPE, -2, [Clazz.array(Integer.TYPE, -1, [0, 0, 1]), Clazz.array(Integer.TYPE, -1, [0, 2, 3]), Clazz.array(Integer.TYPE, -1, [1, 3, 3])]);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:19 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
