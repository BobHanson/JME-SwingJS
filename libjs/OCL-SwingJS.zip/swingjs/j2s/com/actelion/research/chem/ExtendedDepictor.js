(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.DepictorTransformation','com.actelion.research.gui.generic.GenericDepictor','java.awt.Point','com.actelion.research.gui.generic.GenericRectangle','com.actelion.research.chem.DrawingObjectList','com.actelion.research.chem.reaction.ReactionArrow']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExtendedDepictor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mReactionLayoutNeeded'],'I',['mDisplayMode','mReactantCount','mMarkushCoreCount','mChemistryType','mFragmentNoColor','mDefaultAVBL'],'O',['mMolecule','com.actelion.research.chem.StereoMolecule[]','+mCatalyst','mReaction','com.actelion.research.chem.reaction.Reaction','mDepictor','com.actelion.research.gui.generic.GenericDepictor[]','+mCatalystDepictor','mDrawingObjectList','com.actelion.research.chem.DrawingObjectList','mTransformation','com.actelion.research.chem.DepictorTransformation']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_DrawingObjectList',  function (mol, drawingObjectList) {
;C$.$init$.apply(this);
if (mol != null ) {
this.mMolecule=Clazz.array($I$(1), [1]);
this.mMolecule[0]=mol;
}this.mChemistryType=0;
this.mDrawingObjectList=drawingObjectList;
p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMoleculeA$com_actelion_research_chem_DrawingObjectList',  function (mol, drawingObjectList) {
;C$.$init$.apply(this);
this.mMolecule=mol;
this.mChemistryType=0;
this.mDrawingObjectList=drawingObjectList;
p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMoleculeA$I$com_actelion_research_chem_DrawingObjectList',  function (mol, markushCoreCount, drawingObjectList) {
;C$.$init$.apply(this);
this.mMolecule=mol;
this.mChemistryType=2;
this.mDrawingObjectList=drawingObjectList;
this.mMarkushCoreCount=markushCoreCount;
p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_DrawingObjectList$Z',  function (reaction, drawingObjectList, layoutReaction) {
;C$.$init$.apply(this);
this.mReaction=reaction;
if (reaction != null ) {
this.mMolecule=Clazz.array($I$(1), [reaction.getMolecules$()]);
for (var i=0; i < reaction.getMolecules$(); i++) this.mMolecule[i]=reaction.getMolecule$I(i);

this.mReactantCount=reaction.getReactants$();
this.mCatalyst=Clazz.array($I$(1), [reaction.getCatalysts$()]);
for (var i=0; i < reaction.getCatalysts$(); i++) this.mCatalyst[i]=reaction.getCatalyst$I(i);

this.mReactionLayoutNeeded=layoutReaction;
}this.mChemistryType=1;
this.mDrawingObjectList=drawingObjectList;
p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'isFragment$',  function () {
if (this.mChemistryType == 1) return this.mReaction == null  ? false : this.mReaction.isFragment$();
if (this.mMolecule == null ) return false;
for (var mol, $mol = 0, $$mol = this.mMolecule; $mol<$$mol.length&&((mol=($$mol[$mol])),1);$mol++) if (mol.isFragment$()) return true;

return false;
});

Clazz.newMeth(C$, 'initialize',  function () {
this.mTransformation=Clazz.new_($I$(2,1));
if (this.mMolecule != null ) {
this.mDepictor=Clazz.array($I$(3), [this.mMolecule.length]);
for (var i=0; i < this.mMolecule.length; i++) this.mDepictor[i]=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[this.mMolecule[i]]);

}if (this.mCatalyst != null ) {
this.mCatalystDepictor=Clazz.array($I$(3), [this.mCatalyst.length]);
for (var i=0; i < this.mCatalyst.length; i++) this.mCatalystDepictor[i]=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[this.mCatalyst[i]]);

}this.mDefaultAVBL=24;
}, p$1);

Clazz.newMeth(C$, 'setDisplayMode$I',  function (displayMode) {
this.mDisplayMode=displayMode;
});

Clazz.newMeth(C$, 'setDefaultAVBL$I',  function (avbl) {
this.mDefaultAVBL=avbl;
});

Clazz.newMeth(C$, 'setFactorTextSize$D',  function (factor) {
if (this.mDepictor != null ) for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setFactorTextSize$D(factor);

});

Clazz.newMeth(C$, 'setFragmentNoColor$I',  function (argb) {
this.mFragmentNoColor=argb;
});

Clazz.newMeth(C$, 'getMoleculeCount$',  function () {
return this.mMolecule == null  ? 0 : this.mMolecule.length;
});

Clazz.newMeth(C$, 'getMolecule$I',  function (i) {
return this.mMolecule[i];
});

Clazz.newMeth(C$, 'getReaction$',  function () {
return this.mReaction;
});

Clazz.newMeth(C$, 'getMoleculeDepictor$I',  function (i) {
return this.mDepictor[i];
});

Clazz.newMeth(C$, 'setForegroundColor$java_awt_Color$java_awt_Color',  function (foreGround, background) {
this.setForegroundColor$I$I(foreGround.getRGB$(), background.getRGB$());
});

Clazz.newMeth(C$, 'setForegroundColor$I$I',  function (foreground, background) {
if (this.mDepictor != null ) for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setForegroundColor$I$I(foreground, background);

if (this.mCatalystDepictor != null ) for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setForegroundColor$I$I(foreground, background);

});

Clazz.newMeth(C$, 'setOverruleColor$java_awt_Color$java_awt_Color',  function (foreground, background) {
if (this.mDepictor != null ) for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setOverruleColor$java_awt_Color$java_awt_Color(foreground, background);

if (this.mCatalystDepictor != null ) for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setOverruleColor$java_awt_Color$java_awt_Color(foreground, background);

});

Clazz.newMeth(C$, 'setOverruleColor$I$I',  function (foreground, background) {
if (this.mDepictor != null ) for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setOverruleColor$I$I(foreground, background);

if (this.mCatalystDepictor != null ) for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.setOverruleColor$I$I(foreground, background);

});

Clazz.newMeth(C$, 'paint$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
var saveRGB=context.getRGB$();
var fontSize=context.getFontSize$();
try {
this.paintFragmentNumbers$com_actelion_research_gui_generic_GenericDrawContext(context);
this.paintStructures$com_actelion_research_gui_generic_GenericDrawContext(context);
this.paintDrawingObjects$com_actelion_research_gui_generic_GenericDrawContext(context);
} finally {
context.setRGB$I(saveRGB);
context.setFont$I$Z$Z(fontSize, false, false);
}
});

Clazz.newMeth(C$, 'paintFragmentNumbers$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
if (this.mFragmentNoColor != 0 && this.mMolecule != null  ) {
var averageBondLength=p$1.calculateAverageBondLength.apply(this, []);
context.setRGB$I(this.mFragmentNoColor);
context.setFont$I$Z$Z(((1.6 * averageBondLength)|0), true, false);
for (var i=0; i < this.mMolecule.length; i++) {
if (this.mMolecule[i].getAllAtoms$() != 0) {
var cog=Clazz.new_($I$(4,1));
for (var atom=0; atom < this.mMolecule[i].getAllAtoms$(); atom++) {
cog.x=(cog.x+(this.mMolecule[i].getAtomX$I(atom))|0);
cog.y=(cog.y+(this.mMolecule[i].getAtomY$I(atom))|0);
}
cog.x=(cog.x/(this.mMolecule[i].getAllAtoms$())|0);
cog.y=(cog.y/(this.mMolecule[i].getAllAtoms$())|0);
cog.x=(this.mDepictor[i].getTransformation$().transformX$D(cog.x)|0);
cog.y=(this.mDepictor[i].getTransformation$().transformY$D(cog.y)|0);
var str=(this.mChemistryType == 0) ? "" + (i + 1) : (this.mChemistryType == 2) ? ((i < this.mMarkushCoreCount) ? "" + String.fromCharCode((65 + i)) : "R" + (i + 1 - this.mMarkushCoreCount)) : (this.mChemistryType == 1) ? ((i < this.mReactantCount) ? "" + String.fromCharCode((65 + i)) : "P" + (i + 1 - this.mReactantCount)) : "?" + (i + 1);
context.drawCenteredString$D$D$S(cog.x, cog.y, str);
}}
}});

Clazz.newMeth(C$, 'paintStructures$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
if (this.mDepictor != null ) {
for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) {
d.setDisplayMode$I(this.mDisplayMode);
d.paint$O(context);
}
}if (this.mCatalystDepictor != null ) {
for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) {
d.paint$O(context);
}
}});

Clazz.newMeth(C$, 'paintDrawingObjects$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
if (this.mDrawingObjectList != null ) {
for (var object, $object = this.mDrawingObjectList.iterator$(); $object.hasNext$()&&((object=($object.next$())),1);) {
object.draw$com_actelion_research_gui_generic_GenericDrawContext$com_actelion_research_chem_DepictorTransformation(context, this.mTransformation);
}
}});

Clazz.newMeth(C$, 'updateCoords$com_actelion_research_gui_generic_GenericDrawContext$com_actelion_research_gui_generic_GenericRectangle$I',  function (context, viewRect, mode) {
this.validateView$com_actelion_research_gui_generic_GenericDrawContext$com_actelion_research_gui_generic_GenericRectangle$I(context, viewRect, mode);
if (this.mTransformation.isVoidTransformation$()) {
return null;
} else {
if (this.mMolecule != null ) for (var mol, $mol = 0, $$mol = this.mMolecule; $mol<$$mol.length&&((mol=($$mol[$mol])),1);$mol++) this.mTransformation.applyTo$com_actelion_research_chem_Molecule(mol);

if (this.mDrawingObjectList != null ) for (var o, $o = this.mDrawingObjectList.iterator$(); $o.hasNext$()&&((o=($o.next$())),1);) this.mTransformation.applyTo$com_actelion_research_chem_AbstractDrawingObject(o);

if (this.mDepictor != null ) for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.getTransformation$().clear$();

if (this.mCatalystDepictor != null ) for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.getTransformation$().clear$();

var t=this.mTransformation;
this.mTransformation=Clazz.new_($I$(2,1));
return t;
}});

Clazz.newMeth(C$, 'validateView$com_actelion_research_gui_generic_GenericDrawContext$com_actelion_research_gui_generic_GenericRectangle$I',  function (context, viewRect, mode) {
if (this.mReactionLayoutNeeded) p$1.layoutReaction$com_actelion_research_gui_generic_GenericDrawContext.apply(this, [context]);
var boundingRect=null;
if (this.mDepictor != null ) {
for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) {
d.validateView$O$com_actelion_research_gui_generic_GenericRectangle$I(context, null, 0);
boundingRect=(boundingRect == null ) ? d.getBoundingRect$() : boundingRect.union$com_actelion_research_gui_generic_GenericRectangle(d.getBoundingRect$());
}
}if (this.mCatalystDepictor != null ) {
for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) {
d.validateView$O$com_actelion_research_gui_generic_GenericRectangle$I(context, null, 0);
boundingRect=(boundingRect == null ) ? d.getBoundingRect$() : boundingRect.union$com_actelion_research_gui_generic_GenericRectangle(d.getBoundingRect$());
}
}if (this.mDrawingObjectList != null ) {
for (var o, $o = this.mDrawingObjectList.iterator$(); $o.hasNext$()&&((o=($o.next$())),1);) {
var objectBounds=o.getBoundingRect$com_actelion_research_gui_generic_GenericDrawContext(context);
this.mTransformation.applyTo$com_actelion_research_gui_generic_GenericRectangle(objectBounds);
boundingRect=(boundingRect == null ) ? objectBounds : boundingRect.union$com_actelion_research_gui_generic_GenericRectangle(objectBounds);
}
}if (boundingRect == null ) return null;
var avbl=p$1.calculateAverageBondLength.apply(this, []);
var t=Clazz.new_($I$(2,1).c$$com_actelion_research_gui_generic_GenericRectangle$com_actelion_research_gui_generic_GenericRectangle$D$I,[boundingRect, viewRect, avbl, mode]);
if (!t.isVoidTransformation$()) {
t.applyTo$com_actelion_research_chem_DepictorTransformation(this.mTransformation);
if (this.mDepictor != null ) for (var d, $d = 0, $$d = this.mDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.applyTransformation$com_actelion_research_chem_DepictorTransformation(t);

if (this.mCatalystDepictor != null ) for (var d, $d = 0, $$d = this.mCatalystDepictor; $d<$$d.length&&((d=($$d[$d])),1);$d++) d.applyTransformation$com_actelion_research_chem_DepictorTransformation(t);

return t;
}return null;
});

Clazz.newMeth(C$, 'calculateAverageBondLength',  function () {
var averageBondLength=0.0;
var bondCount=0;
if (this.mMolecule != null ) {
for (var i=0; i < this.mMolecule.length; i++) {
if (this.mMolecule[i].getAllAtoms$() != 0) {
if (this.mMolecule[i].getAllBonds$() != 0) {
averageBondLength+=this.mDepictor[i].getTransformation$().getScaling$() * this.mMolecule[i].getAllBonds$() * this.mMolecule[i].getAverageBondLength$() ;
bondCount+=this.mMolecule[i].getAllBonds$();
} else {
averageBondLength+=this.mDepictor[i].getTransformation$().getScaling$() * this.mMolecule[i].getAverageBondLength$();
++bondCount;
}}}
}return (bondCount == 0) ? this.mDefaultAVBL : this.mTransformation.getScaling$() * averageBondLength / bondCount;
}, p$1);

Clazz.newMeth(C$, 'layoutReaction$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
var boundingRect=Clazz.array($I$(5), [this.mMolecule.length]);
var totalWidth=0.0;
var totalHeight=0.0;
for (var i=0; i < this.mMolecule.length; i++) {
this.mDepictor[i].validateView$O$com_actelion_research_gui_generic_GenericRectangle$I(context, null, 65536);
boundingRect[i]=this.mDepictor[i].getBoundingRect$();
totalWidth+=boundingRect[i].width;
totalHeight=Math.max(totalHeight, boundingRect[i].height);
}
var catalystScale=0.7;
var catalystSpacing=12.0;
var catalystBoundingRect=Clazz.array($I$(5), [this.mCatalyst.length]);
var totalCatalystWidth=0.0;
var totalCatalystHeight=0.0;
for (var i=0; i < this.mCatalyst.length; i++) {
this.mCatalystDepictor[i].validateView$O$com_actelion_research_gui_generic_GenericRectangle$I(context, null, 65552);
catalystBoundingRect[i]=this.mCatalystDepictor[i].getBoundingRect$();
totalCatalystWidth=Math.max(totalCatalystWidth, catalystBoundingRect[i].width);
totalCatalystHeight+=catalystBoundingRect[i].height + catalystSpacing;
}
var spacing=36.0;
var arrowWidth=Math.max(48, totalCatalystWidth + 24);
totalHeight=Math.max(totalHeight, 24 + 2 * totalCatalystHeight);
var arrow=-1;
if (this.mDrawingObjectList == null ) {
this.mDrawingObjectList=Clazz.new_($I$(6,1));
this.mDrawingObjectList.add$O(Clazz.new_($I$(7,1)));
arrow=0;
} else {
for (var i=0; i < this.mDrawingObjectList.size$(); i++) {
if (Clazz.instanceOf(this.mDrawingObjectList.get$I(i), "com.actelion.research.chem.reaction.ReactionArrow")) {
arrow=i;
break;
}}
if (arrow == -1) {
arrow=this.mDrawingObjectList.size$();
this.mDrawingObjectList.add$O(Clazz.new_($I$(7,1)));
}}var rawX=0.5 * spacing;
for (var i=0; i < this.mMolecule.length; i++) {
if (i == this.mReactantCount) {
(this.mDrawingObjectList.get$I(arrow)).setCoordinates$D$D$D$D(rawX - spacing / 2, totalHeight / 2, rawX - spacing / 2 + arrowWidth, totalHeight / 2);
var catX=rawX + 0.5 * (24 - spacing);
var catY=0.5 * (totalHeight - catalystSpacing) - totalCatalystHeight;
for (var j=0; j < this.mCatalyst.length; j++) {
var dx=catX + 0.5 * (totalCatalystWidth - catalystBoundingRect[j].width) - catalystBoundingRect[j].x;
var dy=catY - catalystBoundingRect[j].y;
this.mCatalystDepictor[j].applyTransformation$com_actelion_research_chem_DepictorTransformation(Clazz.new_($I$(2,1).c$$D$D$D,[1.0, dx, dy]));
catY+=catalystSpacing + catalystBoundingRect[j].height;
}
rawX+=arrowWidth;
}var dx=rawX - boundingRect[i].x;
var dy=0.5 * (totalHeight - boundingRect[i].height) - boundingRect[i].y;
this.mDepictor[i].applyTransformation$com_actelion_research_chem_DepictorTransformation(Clazz.new_($I$(2,1).c$$D$D$D,[1.0, dx, dy]));
rawX+=spacing + boundingRect[i].width;
}
this.mReactionLayoutNeeded=false;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
