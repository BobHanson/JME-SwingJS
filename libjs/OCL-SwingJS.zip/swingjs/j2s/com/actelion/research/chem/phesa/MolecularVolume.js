(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.phesa.AtomicGaussian','com.actelion.research.chem.phesa.pharmacophore.pp.PPGaussian','com.actelion.research.chem.phesa.VolumeGaussian','com.actelion.research.chem.Coordinates','com.actelion.research.chem.alignment3d.transformation.ExponentialMap','com.actelion.research.chem.phesa.ShapeVolume','com.actelion.research.chem.phesa.pharmacophore.IonizableGroupDetector','com.actelion.research.chem.phesa.pharmacophore.PharmacophoreCalculator','com.actelion.research.calc.Matrix','StringBuilder','com.actelion.research.util.EncoderFloatingPointNumbers']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolecularVolume", null, 'com.actelion.research.chem.phesa.ShapeVolume');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['volumeGaussians','java.util.ArrayList','+hydrogens']]]

Clazz.newMeth(C$, 'c$$java_util_List$java_util_List$java_util_List$java_util_List',  function (atomicGaussiansInp, ppGaussiansInp, volGaussians, hydrogenCoords) {
Clazz.super_(C$, this);
this.atomicGaussians=Clazz.new_($I$(1,1));
for (var ag, $ag = atomicGaussiansInp.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
this.atomicGaussians.add$O(Clazz.new_($I$(2,1).c$$com_actelion_research_chem_phesa_AtomicGaussian,[ag]));
}
this.ppGaussians=Clazz.new_($I$(1,1));
for (var pg, $pg = ppGaussiansInp.iterator$(); $pg.hasNext$()&&((pg=($pg.next$())),1);) {
this.ppGaussians.add$O(Clazz.new_($I$(3,1).c$$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian,[pg]));
}
this.hydrogens=Clazz.new_($I$(1,1));
for (var hydrogen, $hydrogen = hydrogenCoords.iterator$(); $hydrogen.hasNext$()&&((hydrogen=($hydrogen.next$())),1);) {
this.hydrogens.add$O(hydrogen);
}
this.volumeGaussians=Clazz.new_($I$(1,1));
for (var eg, $eg = volGaussians.iterator$(); $eg.hasNext$()&&((eg=($eg.next$())),1);) {
this.volumeGaussians.add$O(Clazz.new_($I$(4,1).c$$com_actelion_research_chem_phesa_VolumeGaussian,[eg]));
}
this.calcCOM$();
}, 1);

Clazz.newMeth(C$, 'updateCOM$',  function () {
this.calcCOM$();
});

Clazz.newMeth(C$, 'updateAtomIndeces$java_util_List$IA',  function (gaussians, map) {
for (var gaussian, $gaussian = gaussians.iterator$(); $gaussian.hasNext$()&&((gaussian=($gaussian.next$())),1);) gaussian.updateAtomIndeces$IA(map);

}, p$1);

Clazz.newMeth(C$, 'updateAtomIndeces$IA',  function (map) {
p$1.updateAtomIndeces$java_util_List$IA.apply(this, [this.ppGaussians, map]);
p$1.updateAtomIndeces$java_util_List$IA.apply(this, [this.atomicGaussians, map]);
p$1.updateAtomIndeces$java_util_List$IA.apply(this, [this.volumeGaussians, map]);
});

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
Clazz.super_(C$, this);
this.hydrogens=Clazz.new_($I$(1,1));
this.volumeGaussians=Clazz.new_($I$(1,1));
p$1.calc$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
p$1.calcPPVolume$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
this.calcCOM$();
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_MolecularVolume$com_actelion_research_chem_conf_Conformer',  function (original, conf) {
C$.c$$com_actelion_research_chem_phesa_MolecularVolume.apply(this, [original]);
this.update$com_actelion_research_chem_conf_Conformer(conf);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_MolecularVolume',  function (original) {
Clazz.super_(C$, this);
this.atomicGaussians=Clazz.new_($I$(1,1));
this.ppGaussians=Clazz.new_($I$(1,1));
this.volumeGaussians=Clazz.new_($I$(1,1));
for (var ag, $ag = original.getAtomicGaussians$().iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
this.atomicGaussians.add$O(Clazz.new_($I$(2,1).c$$com_actelion_research_chem_phesa_AtomicGaussian,[ag]));
}
for (var pg, $pg = original.getPPGaussians$().iterator$(); $pg.hasNext$()&&((pg=($pg.next$())),1);) {
this.ppGaussians.add$O(Clazz.new_($I$(3,1).c$$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian,[pg]));
}
this.hydrogens=Clazz.new_($I$(1,1));
for (var hydrogen, $hydrogen = original.hydrogens.iterator$(); $hydrogen.hasNext$()&&((hydrogen=($hydrogen.next$())),1);) {
this.hydrogens.add$O(Clazz.new_($I$(5,1).c$$com_actelion_research_chem_Coordinates,[hydrogen]));
}
for (var eg, $eg = original.volumeGaussians.iterator$(); $eg.hasNext$()&&((eg=($eg.next$())),1);) {
this.volumeGaussians.add$O(Clazz.new_($I$(4,1).c$$com_actelion_research_chem_phesa_VolumeGaussian,[eg]));
}
this.com=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_Coordinates,[original.com]);
}, 1);

Clazz.newMeth(C$, 'getSelfAtomOverlap$',  function () {
var Vtot=0.0;
for (var at, $at = this.atomicGaussians.iterator$(); $at.hasNext$()&&((at=($at.next$())),1);) {
for (var at2, $at2 = this.atomicGaussians.iterator$(); $at2.hasNext$()&&((at2=($at2.next$())),1);) {
Vtot+=at.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D(at2);
}
for (var vg, $vg = this.volumeGaussians.iterator$(); $vg.hasNext$()&&((vg=($vg.next$())),1);) {
if (vg.getRole$() != 1) continue;
Vtot+=vg.getRole$() * at.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D(vg);
}
}
for (var vg, $vg = this.volumeGaussians.iterator$(); $vg.hasNext$()&&((vg=($vg.next$())),1);) {
if (vg.getRole$() != 1) continue;
for (var vg2, $vg2 = this.volumeGaussians.iterator$(); $vg2.hasNext$()&&((vg2=($vg2.next$())),1);) {
if (vg2.getRole$() != 1) continue;
Vtot+=vg2.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D(vg);
}
}
return Vtot;
});

Clazz.newMeth(C$, 'getTotalAtomOverlap$DA$com_actelion_research_chem_phesa_MolecularVolume',  function (transform, fitVol) {
var result=Clazz.array(Double.TYPE, [2]);
var eMap=Clazz.new_($I$(6,1).c$$D$D$D,[transform[0], transform[1], transform[2]]);
var Vtot=0.0;
var Vvol=0.0;
var com=fitVol.getCOM$();
var rotMatrix=eMap.toQuaternion$().getRotMatrix$().getArray$();
var fitGaussians=fitVol.atomicGaussians;
var fitCenterModCoords=Clazz.array($I$(5), [fitGaussians.size$()]);
for (var k=0; k < fitGaussians.size$(); k++) {
var center=Clazz.new_([fitGaussians.get$I(k).getCenter$()],$I$(5,1).c$$com_actelion_research_chem_Coordinates);
center.sub$com_actelion_research_chem_Coordinates(com);
center.rotate$DAA(rotMatrix);
center.add$com_actelion_research_chem_Coordinates(com);
center.x+=transform[3];
center.y+=transform[4];
center.z+=transform[5];
fitCenterModCoords[k]=center;
}
for (var refAt, $refAt = this.atomicGaussians.iterator$(); $refAt.hasNext$()&&((refAt=($refAt.next$())),1);) {
var index=0;
for (var fitAt, $fitAt = fitVol.atomicGaussians.iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
Vtot+=refAt.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_Coordinates$D(fitAt, fitCenterModCoords[index], 10.0);
index+=1;
}
}
for (var refVol, $refVol = this.volumeGaussians.iterator$(); $refVol.hasNext$()&&((refVol=($refVol.next$())),1);) {
var index=0;
for (var fitAt, $fitAt = fitVol.atomicGaussians.iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
var overlap=refVol.getRole$() * refVol.getVolumeOverlap$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_Coordinates$D(fitAt, fitCenterModCoords[index], 10.0);
Vtot+=overlap;
Vvol+=overlap;
index+=1;
}
}
if (Vtot < 0 ) Vtot=0.0;
result[0]=Vtot;
result[1]=Vvol;
return result;
});

Clazz.newMeth(C$, 'calc$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.atomicGaussians=Clazz.new_($I$(1,1));
var nrOfAtoms=mol.getAllAtoms$();
for (var i=0; i < nrOfAtoms; i++) {
if (mol.getAtomicNo$I(i) == 1) {
this.hydrogens.add$O(Clazz.new_([mol.getCoordinates$I(i)],$I$(5,1).c$$com_actelion_research_chem_Coordinates));
continue;
} else if (mol.getAtomicNo$I(i) == 0) {
var coords=Clazz.new_([mol.getCoordinates$I(i)],$I$(5,1).c$$com_actelion_research_chem_Coordinates);
var atomicGaussian=Clazz.new_($I$(2,1).c$$I$I$com_actelion_research_chem_Coordinates,[i, 6, coords]);
atomicGaussian.setWeight$D(0.0);
this.atomicGaussians.add$O(atomicGaussian);
} else {
var coords=Clazz.new_([mol.getCoordinates$I(i)],$I$(5,1).c$$com_actelion_research_chem_Coordinates);
var atomicGaussian=Clazz.new_([i, mol.getAtomicNo$I(i), coords],$I$(2,1).c$$I$I$com_actelion_research_chem_Coordinates);
this.atomicGaussians.add$O(atomicGaussian);
}}
}, p$1);

Clazz.newMeth(C$, 'rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis',  function (a) {
C$.superclazz.prototype.rotate180DegreeAroundAxis$com_actelion_research_chem_phesa_PheSAAlignment_axis.apply(this, [a]);
$I$(7).rotateGaussians180DegreeAroundAxis$java_util_List$com_actelion_research_chem_phesa_PheSAAlignment_axis(this.volumeGaussians, a);
});

Clazz.newMeth(C$, 'calcPPVolume$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.ppGaussians=Clazz.new_($I$(1,1));
var ppPoints=Clazz.new_($I$(1,1));
var detector=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
ppPoints.addAll$java_util_Collection(detector.detect$());
ppPoints.addAll$java_util_Collection($I$(9).getPharmacophorePoints$com_actelion_research_chem_StereoMolecule(mol));
for (var ppPoint, $ppPoint = ppPoints.iterator$(); $ppPoint.hasNext$()&&((ppPoint=($ppPoint.next$())),1);) this.ppGaussians.add$O(Clazz.new_($I$(3,1).c$$I$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint,[6, ppPoint]));

}, p$1);

Clazz.newMeth(C$, 'calcCOM$',  function () {
var volume=0.0;
var comX=0.0;
var comY=0.0;
var comZ=0.0;
for (var atGauss, $atGauss = this.atomicGaussians.iterator$(); $atGauss.hasNext$()&&((atGauss=($atGauss.next$())),1);) {
volume+=atGauss.getVolume$();
comX+=atGauss.getCenter$().x * atGauss.getVolume$();
comY+=atGauss.getCenter$().y * atGauss.getVolume$();
comZ+=atGauss.getCenter$().z * atGauss.getVolume$();
}
for (var volGauss, $volGauss = this.volumeGaussians.iterator$(); $volGauss.hasNext$()&&((volGauss=($volGauss.next$())),1);) {
volume+=volGauss.getRole$() * volGauss.getVolume$();
comX+=volGauss.getRole$() * volGauss.getCenter$().x * volGauss.getVolume$() ;
comY+=volGauss.getRole$() * volGauss.getCenter$().y * volGauss.getVolume$() ;
comZ+=volGauss.getRole$() * volGauss.getCenter$().z * volGauss.getVolume$() ;
}
comX=comX / volume;
comY=comY / volume;
comZ=comZ / volume;
this.com=Clazz.new_($I$(5,1).c$$D$D$D,[comX, comY, comZ]);
});

Clazz.newMeth(C$, 'getCovarianceMatrix$',  function () {
var massMatrix=Clazz.new_($I$(10,1).c$$I$I,[3, 3]);
var volume=0.0;
for (var ag, $ag = this.atomicGaussians.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
volume+=ag.getVolume$();
var value=ag.getVolume$() * ag.getCenter$().x * ag.getCenter$().x ;
massMatrix.addToElement$I$I$D(0, 0, value);
value=ag.getVolume$() * ag.getCenter$().x * ag.getCenter$().y ;
massMatrix.addToElement$I$I$D(0, 1, value);
value=ag.getVolume$() * ag.getCenter$().x * ag.getCenter$().z ;
massMatrix.addToElement$I$I$D(0, 2, value);
value=ag.getVolume$() * ag.getCenter$().y * ag.getCenter$().y ;
massMatrix.addToElement$I$I$D(1, 1, value);
value=ag.getVolume$() * ag.getCenter$().y * ag.getCenter$().z ;
massMatrix.addToElement$I$I$D(1, 2, value);
value=ag.getVolume$() * ag.getCenter$().z * ag.getCenter$().z ;
massMatrix.addToElement$I$I$D(2, 2, value);
}
for (var vg, $vg = this.volumeGaussians.iterator$(); $vg.hasNext$()&&((vg=($vg.next$())),1);) {
volume+=vg.getRole$() * vg.getVolume$();
var value=vg.getRole$() * vg.getVolume$() * vg.getCenter$().x * vg.getCenter$().x ;
massMatrix.addToElement$I$I$D(0, 0, value);
value=vg.getRole$() * vg.getVolume$() * vg.getCenter$().x * vg.getCenter$().y ;
massMatrix.addToElement$I$I$D(0, 1, value);
value=vg.getRole$() * vg.getVolume$() * vg.getCenter$().x * vg.getCenter$().z ;
massMatrix.addToElement$I$I$D(0, 2, value);
value=vg.getRole$() * vg.getVolume$() * vg.getCenter$().y * vg.getCenter$().y ;
massMatrix.addToElement$I$I$D(1, 1, value);
value=vg.getRole$() * vg.getVolume$() * vg.getCenter$().y * vg.getCenter$().z ;
massMatrix.addToElement$I$I$D(1, 2, value);
value=vg.getRole$() * vg.getVolume$() * vg.getCenter$().z * vg.getCenter$().z ;
massMatrix.addToElement$I$I$D(2, 2, value);
}
massMatrix.set$I$I$D(0, 0, massMatrix.get$I$I(0, 0) / volume);
massMatrix.set$I$I$D(0, 1, massMatrix.get$I$I(0, 1) / volume);
massMatrix.set$I$I$D(0, 2, massMatrix.get$I$I(0, 2) / volume);
massMatrix.set$I$I$D(1, 1, massMatrix.get$I$I(1, 1) / volume);
massMatrix.set$I$I$D(1, 2, massMatrix.get$I$I(1, 2) / volume);
massMatrix.set$I$I$D(2, 2, massMatrix.get$I$I(2, 2) / volume);
massMatrix.set$I$I$D(1, 0, massMatrix.get$I$I(0, 1));
massMatrix.set$I$I$D(2, 0, massMatrix.get$I$I(0, 2));
massMatrix.set$I$I$D(2, 1, massMatrix.get$I$I(1, 2));
return massMatrix;
});

Clazz.newMeth(C$, 'getVolumeGaussians$',  function () {
return this.volumeGaussians;
});

Clazz.newMeth(C$, 'transformGaussians$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transform) {
C$.superclazz.prototype.transformGaussians$com_actelion_research_chem_alignment3d_transformation_Transformation.apply(this, [transform]);
$I$(7).transformGaussians$java_util_List$com_actelion_research_chem_alignment3d_transformation_Transformation(this.volumeGaussians, transform);
});

Clazz.newMeth(C$, 'getHydrogens$',  function () {
return this.hydrogens;
});

Clazz.newMeth(C$, 'updateHydrogens$com_actelion_research_chem_StereoMolecule',  function (mol) {
var h=0;
for (var i=mol.getAtoms$(); i < mol.getAllAtoms$(); i++) {
this.hydrogens.get$I(h).set$com_actelion_research_chem_Coordinates(Clazz.new_([mol.getCoordinates$I(i)],$I$(5,1).c$$com_actelion_research_chem_Coordinates));
++h;
}
}, p$1);

Clazz.newMeth(C$, 'updateHydrogens$com_actelion_research_chem_conf_Conformer',  function (conf) {
var h=0;
for (var i=conf.getMolecule$().getAtoms$(); i < conf.getMolecule$().getAllAtoms$(); i++) {
this.hydrogens.get$I(h).set$com_actelion_research_chem_Coordinates(Clazz.new_([conf.getCoordinates$I(i)],$I$(5,1).c$$com_actelion_research_chem_Coordinates));
++h;
}
}, p$1);

Clazz.newMeth(C$, 'update$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getAtomicGaussians$(), mol.getAtomCoordinates$());
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getPPGaussians$(), mol.getAtomCoordinates$());
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getVolumeGaussians$(), mol.getAtomCoordinates$());
p$1.updateHydrogens$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
});

Clazz.newMeth(C$, 'update$com_actelion_research_chem_conf_Conformer',  function (conf) {
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getAtomicGaussians$(), conf.getCoordinates$());
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getPPGaussians$(), conf.getCoordinates$());
this.updateCoordinates$java_util_List$com_actelion_research_chem_CoordinatesA(this.getVolumeGaussians$(), conf.getCoordinates$());
p$1.updateHydrogens$com_actelion_research_chem_conf_Conformer.apply(this, [conf]);
});

Clazz.newMeth(C$, 'createCanonicalOrientation$com_actelion_research_chem_conf_Conformer',  function (conf) {
var rotMat=C$.superclazz.prototype.createCanonicalOrientation$com_actelion_research_chem_conf_Conformer.apply(this, [conf]);
for (var vg, $vg = this.getVolumeGaussians$().iterator$(); $vg.hasNext$()&&((vg=($vg.next$())),1);) vg.rotateShift$com_actelion_research_calc_Matrix(rotMat);

return rotMat;
});

Clazz.newMeth(C$, 'translateToCOM$com_actelion_research_chem_Coordinates',  function (com) {
for (var ag, $ag = this.getAtomicGaussians$().iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
ag.getCenter$().sub$com_actelion_research_chem_Coordinates(com);
}
for (var pg, $pg = this.getPPGaussians$().iterator$(); $pg.hasNext$()&&((pg=($pg.next$())),1);) {
pg.getCenter$().sub$com_actelion_research_chem_Coordinates(com);
}
for (var vg, $vg = this.getVolumeGaussians$().iterator$(); $vg.hasNext$()&&((vg=($vg.next$())),1);) {
vg.translateRef$com_actelion_research_chem_Coordinates(com.scaleC$D(-1.0));
}
for (var hydrogen, $hydrogen = this.getHydrogens$().iterator$(); $hydrogen.hasNext$()&&((hydrogen=($hydrogen.next$())),1);) {
hydrogen.sub$com_actelion_research_chem_Coordinates(com);
}
this.calcCOM$();
});

Clazz.newMeth(C$, 'encodeFull$',  function () {
var molVolString=Clazz.new_($I$(11,1));
molVolString.append$S(Integer.toString$I(this.atomicGaussians.size$()));
molVolString.append$S("  ");
for (var ag, $ag = this.atomicGaussians.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
molVolString.append$S(ag.encode$());
molVolString.append$S("  ");
}
molVolString.append$S(Integer.toString$I(this.ppGaussians.size$()));
molVolString.append$S("  ");
for (var pg, $pg = this.ppGaussians.iterator$(); $pg.hasNext$()&&((pg=($pg.next$())),1);) {
molVolString.append$S(pg.encode$().trim$());
molVolString.append$S("  ");
}
molVolString.append$S(Integer.toString$I(this.volumeGaussians.size$()));
molVolString.append$S("  ");
for (var vg, $vg = this.volumeGaussians.iterator$(); $vg.hasNext$()&&((vg=($vg.next$())),1);) {
molVolString.append$S(vg.encode$());
molVolString.append$S("  ");
}
var hydrogenCoords=Clazz.array(Double.TYPE, [3 * this.hydrogens.size$()]);
for (var i=0; i < this.hydrogens.size$(); i++) {
hydrogenCoords[3 * i]=this.hydrogens.get$I(i).x;
hydrogenCoords[3 * i + 1]=this.hydrogens.get$I(i).y;
hydrogenCoords[3 * i + 2]=this.hydrogens.get$I(i).z;
}
molVolString.append$S($I$(12).encode$DA$I(hydrogenCoords, 13));
return molVolString.toString();
});

Clazz.newMeth(C$, 'encodeCoordsOnly$',  function () {
var molVolString=Clazz.new_($I$(11,1));
var coords=Clazz.array(Double.TYPE, [3 * this.atomicGaussians.size$()]);
for (var i=0; i < this.atomicGaussians.size$(); i++) {
coords[3 * i]=this.atomicGaussians.get$I(i).getCenter$().x;
coords[3 * i + 1]=this.atomicGaussians.get$I(i).getCenter$().y;
coords[3 * i + 2]=this.atomicGaussians.get$I(i).getCenter$().z;
}
molVolString.append$S($I$(12).encode$DA$I(coords, 13));
molVolString.append$S("  ");
coords=Clazz.array(Double.TYPE, [3 * this.ppGaussians.size$()]);
for (var i=0; i < this.ppGaussians.size$(); i++) {
coords[3 * i]=this.ppGaussians.get$I(i).getCenter$().x;
coords[3 * i + 1]=this.ppGaussians.get$I(i).getCenter$().y;
coords[3 * i + 2]=this.ppGaussians.get$I(i).getCenter$().z;
}
molVolString.append$S($I$(12).encode$DA$I(coords, 13));
molVolString.append$S("  ");
coords=Clazz.array(Double.TYPE, [3 * this.ppGaussians.size$()]);
for (var i=0; i < this.ppGaussians.size$(); i++) {
coords[3 * i]=this.ppGaussians.get$I(i).getPharmacophorePoint$().getDirectionality$().x;
coords[3 * i + 1]=this.ppGaussians.get$I(i).getPharmacophorePoint$().getDirectionality$().y;
coords[3 * i + 2]=this.ppGaussians.get$I(i).getPharmacophorePoint$().getDirectionality$().z;
}
molVolString.append$S($I$(12).encode$DA$I(coords, 13));
molVolString.append$S("  ");
coords=Clazz.array(Double.TYPE, [3 * this.volumeGaussians.size$()]);
for (var i=0; i < this.volumeGaussians.size$(); i++) {
coords[3 * i]=this.volumeGaussians.get$I(i).getReferenceVector$().x;
coords[3 * i + 1]=this.volumeGaussians.get$I(i).getReferenceVector$().y;
coords[3 * i + 2]=this.volumeGaussians.get$I(i).getReferenceVector$().z;
}
molVolString.append$S($I$(12).encode$DA$I(coords, 13));
molVolString.append$S("  ");
coords=Clazz.array(Double.TYPE, [3 * this.volumeGaussians.size$()]);
for (var i=0; i < this.volumeGaussians.size$(); i++) {
coords[3 * i]=this.volumeGaussians.get$I(i).getShiftVector$().x;
coords[3 * i + 1]=this.volumeGaussians.get$I(i).getShiftVector$().y;
coords[3 * i + 2]=this.volumeGaussians.get$I(i).getShiftVector$().z;
}
molVolString.append$S($I$(12).encode$DA$I(coords, 13));
molVolString.append$S("  ");
var hydrogenCoords=Clazz.array(Double.TYPE, [3 * this.hydrogens.size$()]);
for (var i=0; i < this.hydrogens.size$(); i++) {
hydrogenCoords[3 * i]=this.hydrogens.get$I(i).x;
hydrogenCoords[3 * i + 1]=this.hydrogens.get$I(i).y;
hydrogenCoords[3 * i + 2]=this.hydrogens.get$I(i).z;
}
molVolString.append$S($I$(12).encode$DA$I(hydrogenCoords, 13));
return molVolString.toString();
});

Clazz.newMeth(C$, 'decodeCoordsOnly$S$com_actelion_research_chem_phesa_MolecularVolume',  function (string, reference) {
var referenceAtomicGaussians=reference.getAtomicGaussians$();
var referencePPGaussians=reference.getPPGaussians$();
var referenceVolGaussians=reference.getVolumeGaussians$();
var splitString=string.split$S("  ");
var atomicGaussiansCoords=$I$(12).decode$S(splitString[0]);
var ppGaussiansCoords=$I$(12).decode$S(splitString[1]);
var ppGaussiansDirectionalities=$I$(12).decode$S(splitString[2]);
var volumeGaussiansRefCoords=$I$(12).decode$S(splitString[3]);
var volumeGaussiansShiftCoords=$I$(12).decode$S(splitString[4]);
var hydrogensCoords=$I$(12).decode$S(splitString[5]);
var atomicGaussians=Clazz.new_($I$(1,1));
var ppGaussians=Clazz.new_($I$(1,1));
var volumeGaussians=Clazz.new_($I$(1,1));
var hydrogens=Clazz.new_($I$(1,1));
var nrOfAtomicGaussians=(atomicGaussiansCoords.length/3|0);
var nrOfHydrogens=(hydrogensCoords.length/3|0);
var nrOfPPGaussians=(ppGaussiansCoords.length/3|0);
var nrOfVolumeGaussians=(volumeGaussiansRefCoords.length/3|0);
for (var i=0; i < nrOfAtomicGaussians; i++) {
var coords=Clazz.new_($I$(5,1).c$$D$D$D,[atomicGaussiansCoords[i * 3], atomicGaussiansCoords[i * 3 + 1], atomicGaussiansCoords[i * 3 + 2]]);
var at=Clazz.new_([referenceAtomicGaussians.get$I(i)],$I$(2,1).c$$com_actelion_research_chem_phesa_AtomicGaussian);
at.setCenter$com_actelion_research_chem_Coordinates(coords);
atomicGaussians.add$O(at);
}
for (var i=0; i < nrOfPPGaussians; i++) {
var coords=Clazz.new_($I$(5,1).c$$D$D$D,[ppGaussiansCoords[i * 3], ppGaussiansCoords[i * 3 + 1], ppGaussiansCoords[i * 3 + 2]]);
var pp=Clazz.new_([referencePPGaussians.get$I(i)],$I$(3,1).c$$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian);
pp.setCenter$com_actelion_research_chem_Coordinates(Clazz.new_($I$(5,1).c$$D$D$D,[coords.x, coords.y, coords.z]));
var directionality=Clazz.new_($I$(5,1).c$$D$D$D,[ppGaussiansDirectionalities[i * 3], ppGaussiansDirectionalities[i * 3 + 1], ppGaussiansDirectionalities[i * 3 + 2]]);
pp.getPharmacophorePoint$().setDirectionality$com_actelion_research_chem_Coordinates(directionality);
ppGaussians.add$O(pp);
}
for (var i=0; i < nrOfVolumeGaussians; i++) {
var coords=Clazz.new_($I$(5,1).c$$D$D$D,[volumeGaussiansRefCoords[i * 3], volumeGaussiansRefCoords[i * 3 + 1], volumeGaussiansRefCoords[i * 3 + 2]]);
var vg=Clazz.new_([referenceVolGaussians.get$I(i)],$I$(4,1).c$$com_actelion_research_chem_phesa_VolumeGaussian);
vg.setReferenceVector$com_actelion_research_chem_Coordinates(Clazz.new_($I$(5,1).c$$D$D$D,[coords.x, coords.y, coords.z]));
var shift=Clazz.new_($I$(5,1).c$$D$D$D,[volumeGaussiansShiftCoords[i * 3], volumeGaussiansShiftCoords[i * 3 + 1], volumeGaussiansShiftCoords[i * 3 + 2]]);
vg.setShiftVector$com_actelion_research_chem_Coordinates(shift);
volumeGaussians.add$O(vg);
}
for (var i=0; i < nrOfHydrogens; i++) {
hydrogens.add$O(Clazz.new_($I$(5,1).c$$D$D$D,[hydrogensCoords[i * 3], hydrogensCoords[i * 3 + 1], hydrogensCoords[i * 3 + 2]]));
}
return Clazz.new_(C$.c$$java_util_List$java_util_List$java_util_List$java_util_List,[atomicGaussians, ppGaussians, volumeGaussians, hydrogens]);
}, 1);

Clazz.newMeth(C$, 'decodeFull$S$com_actelion_research_chem_StereoMolecule',  function (string, refMol) {
var splitString=string.split$S("  ");
var nrOfAtomicGaussians=(Integer.decode$S(splitString[0].trim$())).$c();
var firstIndex=1;
var lastIndex=1 + nrOfAtomicGaussians;
var atomicGaussians=Clazz.new_($I$(1,1));
var ppGaussians=Clazz.new_($I$(1,1));
var volumeGaussians=Clazz.new_($I$(1,1));
var hydrogens=Clazz.new_($I$(1,1));
for (var i=firstIndex; i < lastIndex; i++) {
atomicGaussians.add$O($I$(2,"fromString$S",[splitString[i].trim$()]));
}
var nrOfPPGaussians=(Integer.decode$S(splitString[lastIndex])).$c();
firstIndex=lastIndex + 1;
lastIndex=firstIndex + nrOfPPGaussians;
for (var i=firstIndex; i < lastIndex; i++) {
ppGaussians.add$O($I$(3).fromString$S$com_actelion_research_chem_StereoMolecule(splitString[i], refMol));
}
var nrOfVolumeGaussians=(Integer.decode$S(splitString[lastIndex])).$c();
firstIndex=lastIndex + 1;
lastIndex=firstIndex + nrOfVolumeGaussians;
for (var i=firstIndex; i < lastIndex; i++) {
volumeGaussians.add$O($I$(4).fromString$S$com_actelion_research_chem_StereoMolecule(splitString[i], refMol));
}
var coords=$I$(12).decode$S(splitString[splitString.length - 1]);
var nrOfHydrogens=(coords.length/3|0);
for (var i=0; i < nrOfHydrogens; i++) {
hydrogens.add$O(Clazz.new_($I$(5,1).c$$D$D$D,[coords[i * 3], coords[i * 3 + 1], coords[i * 3 + 2]]));
}
return Clazz.new_(C$.c$$java_util_List$java_util_List$java_util_List$java_util_List,[atomicGaussians, ppGaussians, volumeGaussians, hydrogens]);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
