(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring.idoscore"),I$=[[0,'com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InteractionTerm", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['energy','factor'],'O',['ligand','com.actelion.research.chem.conf.Conformer','+receptor','atoms','int[]','f','com.actelion.research.chem.interactionstatistics.SplineFunction']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$IA$com_actelion_research_chem_interactionstatistics_SplineFunction$D',  function (receptor, ligand, atoms, f, factor) {
;C$.$init$.apply(this);
this.receptor=receptor;
this.ligand=ligand;
this.f=f;
this.factor=factor;
this.atoms=atoms;
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$IA$IA',  function (receptor, ligand, p, l, receptorAtomTypes, ligandAtomTypes) {
var f=$I$(1).getInstance$().getFunction$I$I(receptorAtomTypes[p], ligandAtomTypes[l]);
if (f == null ) {
return null;
}return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$IA$com_actelion_research_chem_interactionstatistics_SplineFunction$D,[receptor, ligand, Clazz.array(Integer.TYPE, -1, [p, l]), f, 1.0]);
}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var ci=this.receptor.getCoordinates$I(this.atoms[0]);
var ck=this.ligand.getCoordinates$I(this.atoms[1]);
var cr=ci.subC$com_actelion_research_chem_Coordinates(ck);
var rik2=cr.distSq$();
var rik=0.0;
if (rik2 > 33.64 ) {
this.energy=0;
} else {
var de=0;
rik=Math.sqrt(rik2);
var grad=this.f.getFGValue$D(rik);
this.energy=this.factor * grad[0];
if (gradient != null ) de=this.factor * grad[1];
if (gradient != null ) {
var deddt=(rik <= 1  ? -10 : de) / rik;
cr.scale$D(deddt);
gradient[3 * this.atoms[1]]-=cr.x;
gradient[3 * this.atoms[1] + 1]-=cr.y;
gradient[3 * this.atoms[1] + 2]-=cr.z;
}}return this.energy;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:22 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
