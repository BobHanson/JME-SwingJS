(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[[0,'com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.coords.CoordinateInventor','com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FlexophoreCreateFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'create$S',  function (idcode) {
var parser=Clazz.new_($I$(1,1));
var mol=parser.getCompactMolecule$S(idcode);
var coordinateInventor=Clazz.new_($I$(2,1));
coordinateInventor.invent$com_actelion_research_chem_StereoMolecule(mol);
return C$.createDescriptor$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'create$S$S',  function (idcode, coord) {
var parser=Clazz.new_($I$(1,1));
var mol=parser.getCompactMolecule$S$S(idcode, coord);
if (coord == null ) {
var coordinateInventor=Clazz.new_($I$(2,1));
coordinateInventor.invent$com_actelion_research_chem_StereoMolecule(mol);
}return C$.createDescriptor$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_util_datamodel_IDCodeCoord',  function (idcodeCoord) {
return C$.create$S$S(idcodeCoord.getIdcode$(), idcodeCoord.getCoordinates$());
}, 1);

Clazz.newMeth(C$, 'createDescriptor$com_actelion_research_chem_StereoMolecule',  function (mol) {
var fragBiggest=mol;
fragBiggest.stripSmallFragments$();
fragBiggest.ensureHelperArrays$I(31);
var mdh=null;
try {
mdh=$I$(3).getInstance$().create$com_actelion_research_chem_StereoMolecule(mol);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
return mdh;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
