(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'java.text.DecimalFormat','java.util.HashSet','StringBuilder','java.util.ArrayList','java.util.Collections','com.actelion.research.calc.ArrayUtilsCalc']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MDHFeature", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index','counter1','counter2'],'O',['mdhvFeature','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','hsMatchingIndex1','java.util.HashSet','+hsMatchingIndex2']]
,['O',['NF','java.text.NumberFormat']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$I',  function (mdhvFeature, index) {
;C$.$init$.apply(this);
p$1.init.apply(this, []);
this.mdhvFeature=mdhvFeature;
this.index=index;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhvFeature) {
;C$.$init$.apply(this);
p$1.init.apply(this, []);
this.mdhvFeature=mdhvFeature;
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.hsMatchingIndex1=Clazz.new_($I$(2,1));
this.hsMatchingIndex2=Clazz.new_($I$(2,1));
}, p$1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_descriptor_flexophore_MDHFeature','compareTo$O'],  function (m) {
if (this.counter1 > m.counter1) return 1;
if (this.counter1 < m.counter1) return -1;
 else return 0;
});

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'getCounter1$',  function () {
return this.counter1;
});

Clazz.newMeth(C$, 'getCounter2$',  function () {
return this.counter2;
});

Clazz.newMeth(C$, 'getMdhvFeature$',  function () {
return this.mdhvFeature;
});

Clazz.newMeth(C$, 'increaseClass1$I',  function (index) {
++this.counter1;
if (!this.hsMatchingIndex1.add$O(Integer.valueOf$I(index))) throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Index " + index + " is already in active list." ]);
});

Clazz.newMeth(C$, 'increaseClass2$I',  function (index) {
++this.counter2;
if (!this.hsMatchingIndex2.add$O(Integer.valueOf$I(index))) throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Index " + index + " is already in inactive list." ]);
});

Clazz.newMeth(C$, 'getRatioClass1Class2$',  function () {
if (this.counter2 == 0) {
return Infinity;
}return (this.counter1) / (this.counter2);
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$I(this.index);
var ratioRisk=-1;
if (this.counter1 == 0 && this.counter2 == 0 ) {
ratioRisk=-1;
} else if (this.counter2 == 0) {
ratioRisk=this.counter1;
} else {
ratioRisk=this.getRatioClass1Class2$();
}sb.append$S(" risk\t" + this.counter1 + ", no risk\t" + this.counter2 + ", ratio\t" + C$.NF.format$D(ratioRisk) );
return sb.toString();
});

Clazz.newMeth(C$, 'toStringListClass1$',  function () {
var li=Clazz.new_($I$(4,1).c$$java_util_Collection,[this.hsMatchingIndex1]);
$I$(5).sort$java_util_List(li);
return $I$(6).toString$java_util_Collection(li);
});

Clazz.newMeth(C$, 'toStringListClass2$',  function () {
var li=Clazz.new_($I$(4,1).c$$java_util_Collection,[this.hsMatchingIndex2]);
$I$(5).sort$java_util_List(li);
return $I$(6).toString$java_util_Collection(li);
});

C$.$static$=function(){C$.$static$=0;
C$.NF=Clazz.new_($I$(1,1).c$$S,["0.0000"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
