(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MolDistHistVizFrag", null, 'com.actelion.research.chem.descriptor.flexophore.MolDistHistViz');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrIndexParentNodes','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (length) {
;C$.superclazz.c$$I.apply(this,[length]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_Molecule3D',  function (length, ff) {
;C$.superclazz.c$$I$com_actelion_research_chem_Molecule3D.apply(this,[length, ff]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistVizFrag',  function (mdhvf) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz.apply(this,[mdhvf]);C$.$init$.apply(this);
if (mdhvf.arrIndexParentNodes != null ) {
this.arrIndexParentNodes=Clazz.array(Integer.TYPE, [mdhvf.arrIndexParentNodes.length]);
System.arraycopy$O$I$O$I$I(mdhvf.arrIndexParentNodes, 0, this.arrIndexParentNodes, 0, mdhvf.arrIndexParentNodes.length);
}}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist.apply(this,[mdh]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getArrIndexParentNodes$',  function () {
return this.arrIndexParentNodes;
});

Clazz.newMeth(C$, 'copy$',  function () {
var mdhvf=Clazz.new_(C$.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistVizFrag,[this]);
if (this.arrIndexParentNodes != null ) {
var arr=Clazz.array(Integer.TYPE, [this.arrIndexParentNodes.length]);
System.arraycopy$O$I$O$I$I(this.arrIndexParentNodes, 0, arr, 0, this.arrIndexParentNodes.length);
mdhvf.setArrIndexParentNodes$IA(arr);
}return mdhvf;
});

Clazz.newMeth(C$, 'setArrIndexParentNodes$IA',  function (arrIndexParentNodes) {
this.arrIndexParentNodes=arrIndexParentNodes;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
