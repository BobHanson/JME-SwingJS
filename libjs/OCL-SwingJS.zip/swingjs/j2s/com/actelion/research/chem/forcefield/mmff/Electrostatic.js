(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3',['com.actelion.research.chem.forcefield.mmff.Separation','.Relation'],'java.util.ArrayList','com.actelion.research.chem.forcefield.mmff.type.Charge','com.actelion.research.chem.forcefield.mmff.SortedPair']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Electrostatic", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['distModel'],'D',['charge_term'],'I',['a1','a2'],'O',['mol','com.actelion.research.chem.forcefield.mmff.MMFFMolecule','rel','com.actelion.research.chem.forcefield.mmff.Separation.Relation']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$com_actelion_research_chem_forcefield_mmff_Separation_Relation$D$D$Z$D',  function (mol, a1, a2, rel, chge1, chge2, distModel, dielConst) {
;C$.$init$.apply(this);
this.mol=mol;
this.a1=a1;
this.a2=a2;
this.rel=rel;
this.distModel=distModel;
this.charge_term=chge1 * chge2 / dielConst;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$com_actelion_research_chem_forcefield_mmff_Separation_Relation$D$D',  function (mol, a1, a2, rel, chge1, chge2) {
C$.c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$com_actelion_research_chem_forcefield_mmff_Separation_Relation$D$D$Z$D.apply(this, [mol, a1, a2, rel, chge1, chge2, false, 1.0]);
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var dist=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a1, this.a2]).length$();
var corr_dist=dist + 0.05;
var diel=332.0716;
if (this.distModel) corr_dist*=corr_dist;
return diel * this.charge_term / corr_dist * (this.rel === $I$(2).ONE_FOUR  ? 0.75 : 1.0);
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var dist=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a1, this.a2]).length$();
var corr_dist=dist + 0.05;
corr_dist*=(this.distModel ? corr_dist * corr_dist : corr_dist);
var dE_dr=-332.0716 * (this.distModel ? 2.0 : 1.0) * this.charge_term  / corr_dist * (this.rel === $I$(2).ONE_FOUR  ? 0.75 : 1.0);
for (var i=0; i < 3; i++) {
var dGrad=0.02;
if (dist > 0.0 ) dGrad=dE_dr * (pos[3 * this.a1 + i] - pos[3 * this.a2 + i]) / dist;
grad[3 * this.a1 + i]+=dGrad;
grad[3 * this.a2 + i]-=dGrad;
}
});

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$com_actelion_research_chem_forcefield_mmff_Separation$D$Z$D',  function (table, mol, sep, nonbondedCutoff, dielModel, dielConst) {
var eles=Clazz.new_($I$(3,1));
var charges=$I$(4).getCharges$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(table, mol);
for (var i=0; i < mol.getAllAtoms$(); i++) {
for (var j=0; j < i + 1; j++) {
var relation=sep.get$com_actelion_research_chem_forcefield_mmff_SortedPair(Clazz.new_($I$(5,1).c$$I$I,[i, j]));
if ((relation === $I$(2).ONE_FOUR  || relation === $I$(2).ONE_X  ) && Math.abs(charges[i]) > 1.0E-5   && Math.abs(charges[j]) > 1.0E-5  ) {
if (Clazz.new_($I$(1,1).c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I,[mol, i, j]).length$() < nonbondedCutoff ) {
eles.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$com_actelion_research_chem_forcefield_mmff_Separation_Relation$D$D$Z$D,[mol, i, j, relation, charges[i], charges[j], dielModel, dielConst]));
}}}
}
return eles;
}, 1);

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$com_actelion_research_chem_forcefield_mmff_Separation',  function (table, mol, sep) {
return C$.findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$com_actelion_research_chem_forcefield_mmff_Separation$D$Z$D(table, mol, sep, 100.0, false, 1.0);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:22 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
