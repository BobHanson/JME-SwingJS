(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),I$=[[0,'com.actelion.research.chem.phesa.EncodeFunctions','java.util.Base64','StringBuilder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Translation", null, null, 'com.actelion.research.chem.alignment3d.transformation.Transformation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['translation','double[]']]]

Clazz.newMeth(C$, 'c$$DA',  function (translation) {
;C$.$init$.apply(this);
this.translation=translation;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Coordinates',  function (translation) {
;C$.$init$.apply(this);
this.translation=Clazz.array(Double.TYPE, [3]);
this.translation[0]=translation.x;
this.translation[1]=translation.y;
this.translation[2]=translation.z;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D',  function (x, y, z) {
;C$.$init$.apply(this);
this.translation=Clazz.array(Double.TYPE, [3]);
this.translation[0]=x;
this.translation[1]=y;
this.translation[2]=z;
}, 1);

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_Coordinates',  function (coords) {
coords.add$D$D$D(this.translation[0], this.translation[1], this.translation[2]);
});

Clazz.newMeth(C$, 'apply$DA',  function (coords) {
coords[0]+=this.translation[0];
coords[1]+=this.translation[1];
coords[2]+=this.translation[2];
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
var t=$I$(1,"byteArrayToDoubleArray$BA",[$I$(2).getDecoder$().decode$S(s)]);
return Clazz.new_(C$.c$$DA,[t]);
}, 1);

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(2).getEncoder$();
var sb=Clazz.new_($I$(3,1));
sb.append$S("t");
sb.append$S(" ");
sb.append$S(encoder.encodeToString$BA($I$(1).doubleArrayToByteArray$DA(this.translation)));
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:19 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
