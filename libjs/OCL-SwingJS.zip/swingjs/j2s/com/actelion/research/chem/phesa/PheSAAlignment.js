(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'java.util.Base64','StringBuilder','com.actelion.research.chem.Canonizer','com.actelion.research.chem.phesa.EncodeFunctions','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IDCodeParserWithoutCoordinateInvention','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.phesa.MolecularVolume','java.util.stream.IntStream','com.actelion.research.chem.phesa.PheSAAlignment',['com.actelion.research.chem.phesa.PheSAAlignment','.axis'],['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.SimilarityMode'],'com.actelion.research.chem.phesa.EvaluableOverlap','com.actelion.research.chem.optimization.OptimizerLBFGS','com.actelion.research.chem.alignment3d.transformation.ExponentialMap','com.actelion.research.chem.alignment3d.transformation.Translation','com.actelion.research.chem.alignment3d.transformation.TransformationSequence','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PheSAAlignment", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['axis',25],['PheSAResult',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['ppWeight'],'O',['refMolGauss','com.actelion.research.chem.phesa.ShapeVolume','+molGauss']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D',  function (refMol, mol, ppWeight) {
;C$.$init$.apply(this);
this.ppWeight=ppWeight;
this.refMolGauss=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[refMol]);
this.molGauss=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (refMol, mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D.apply(this, [refMol, mol, 0.5]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_MolecularVolume$com_actelion_research_chem_phesa_MolecularVolume',  function (refMolGauss, molGauss) {
C$.c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_phesa_ShapeVolume$D.apply(this, [refMolGauss, molGauss, 0.5]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_phesa_ShapeVolume$D',  function (refMolGauss, molGauss, ppWeight) {
;C$.$init$.apply(this);
this.ppWeight=ppWeight;
this.refMolGauss=refMolGauss;
this.molGauss=molGauss;
}, 1);

Clazz.newMeth(C$, 'getRefMolGauss$',  function () {
return this.refMolGauss;
});

Clazz.newMeth(C$, 'getMolGauss$',  function () {
return this.molGauss;
});

Clazz.newMeth(C$, 'rotateMolAroundAxis180$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_phesa_PheSAAlignment_axis',  function (conf, a) {
$I$(9,"range$I$I",[0, conf.getSize$()]).forEach$java_util_function_IntConsumer(((P$.PheSAAlignment$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PheSAAlignment$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) {
var coords=this.$finals$.conf.getCoordinates$I(i);
$I$(10).rotateCoordsAroundAxis180$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_PheSAAlignment_axis(coords, this.$finals$.a);
});
})()
), Clazz.new_(P$.PheSAAlignment$lambda1.$init$,[this, {a:a,conf:conf}])));
}, 1);

Clazz.newMeth(C$, 'rotateCoordsAroundAxis180$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_PheSAAlignment_axis',  function (coords, a) {
if (a === $I$(11).X ) {
coords.y=-coords.y;
coords.z=-coords.z;
} else if (a === $I$(11).Y ) {
coords.x=-coords.x;
coords.z=-coords.z;
} else {
coords.x=-coords.x;
coords.y=-coords.y;
}}, 1);

Clazz.newMeth(C$, 'initialTransform$I',  function (mode) {
var transforms1=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [3.14, 0.0, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 3.14, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 0.0, 3.14, 0.0, 0.0, 0.0])]);
var transforms2=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [3.14, 0.0, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 3.14, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 0.0, 3.14, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [1.57, 0.0, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 1.57, 0.0, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [0.0, 0.0, 1.57, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [-1.21, -1.21, 1.21, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [-1.21, 1.21, -1.21, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [1.21, 1.21, -1.21, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [-1.21, -1.21, -1.21, 0.0, 0.0, 0.0]), Clazz.array(Double.TYPE, -1, [1.21, -1.21, -1.21, 0.0, 0.0, 0.0])]);
switch (mode) {
case 1:
return transforms1;
case 2:
return transforms2;
default:
var transform=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0])]);
return transform;
}
}, 1);

Clazz.newMeth(C$, 'getSelfAtomOverlapRef$',  function () {
return this.refMolGauss.getSelfAtomOverlap$();
});

Clazz.newMeth(C$, 'getSelfAtomOverlapFit$',  function () {
return this.molGauss.getSelfAtomOverlap$();
});

Clazz.newMeth(C$, 'getSelfPPOverlapRef$',  function () {
return this.refMolGauss.getSelfPPOverlap$();
});

Clazz.newMeth(C$, 'getSelfPPOverlapFit$',  function () {
return this.molGauss.getSelfPPOverlap$();
});

Clazz.newMeth(C$, 'rotateMol$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_alignment3d_transformation_Quaternion$DA',  function (conf, rotor, transl) {
var normFactor=1 / rotor.normSquared$();
var nrOfAtoms=conf.getSize$();
for (var i=0; i < nrOfAtoms; i++) {
var coords=conf.getCoordinates$I(i);
var m=rotor.getRotMatrix$().getArray$();
coords.rotate$DAA(m);
coords.scale$D(normFactor);
coords.add$D$D$D(transl[0], transl[1], transl[2]);
}
}, 1);

Clazz.newMeth(C$, 'rotateMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_alignment3d_transformation_Quaternion$DA',  function (mol, rotor, transl) {
var normFactor=1 / rotor.normSquared$();
var nrOfAtoms=mol.getAllAtoms$();
for (var i=0; i < nrOfAtoms; i++) {
var coords=mol.getCoordinates$I(i);
var m=rotor.getRotMatrix$().getArray$();
coords.rotate$DAA(m);
coords.scale$D(normFactor);
coords.add$D$D$D(transl[0], transl[1], transl[2]);
}
}, 1);

Clazz.newMeth(C$, 'rotateMol$com_actelion_research_chem_StereoMolecule$DAA',  function (mol, m) {
var nrOfAtoms=mol.getAllAtoms$();
for (var i=0; i < nrOfAtoms; i++) {
var coords=mol.getCoordinates$I(i);
coords.rotate$DAA(m);
}
}, 1);

Clazz.newMeth(C$, 'rotateMol$com_actelion_research_chem_conf_Conformer$DAA',  function (conf, m) {
var nrOfAtoms=conf.getMolecule$().getAllAtoms$();
for (var i=0; i < nrOfAtoms; i++) {
var coords=conf.getCoordinates$I(i);
coords.rotate$DAA(m);
}
}, 1);

Clazz.newMeth(C$, 'translateMol$com_actelion_research_chem_StereoMolecule$DA',  function (mol, translate) {
var nrOfAtoms=mol.getAllAtoms$();
for (var i=0; i < nrOfAtoms; i++) {
var coords=mol.getCoordinates$I(i);
coords.x+=translate[0];
coords.y+=translate[1];
coords.z+=translate[2];
}
}, 1);

Clazz.newMeth(C$, 'multiplyMatrix$DAA$DAA$DAA',  function (r, s, rs) {
rs[0][0]=r[0][0] * s[0][0] + r[0][1] * s[1][0] + r[0][2] * s[2][0];
rs[0][1]=r[0][0] * s[0][1] + r[0][1] * s[1][1] + r[0][2] * s[2][1];
rs[0][2]=r[0][0] * s[0][2] + r[0][1] * s[1][2] + r[0][2] * s[2][2];
rs[1][0]=r[1][0] * s[0][0] + r[1][1] * s[1][0] + r[1][2] * s[2][0];
rs[1][1]=r[1][0] * s[0][1] + r[1][1] * s[1][1] + r[1][2] * s[2][1];
rs[1][2]=r[1][0] * s[0][2] + r[1][1] * s[1][2] + r[1][2] * s[2][2];
rs[2][0]=r[2][0] * s[0][0] + r[2][1] * s[1][0] + r[2][2] * s[2][0];
rs[2][1]=r[2][0] * s[0][1] + r[2][1] * s[1][1] + r[2][2] * s[2][1];
rs[2][2]=r[2][0] * s[0][2] + r[2][1] * s[1][2] + r[2][2] * s[2][2];
}, 1);

Clazz.newMeth(C$, 'multiplyInverseMatrix$DAA$DAA$DAA',  function (r, s, rs) {
rs[0][0]=r[0][0] * s[0][0] + r[0][1] * s[0][1] + r[0][2] * s[0][2];
rs[0][1]=r[0][0] * s[1][0] + r[0][1] * s[1][1] + r[0][2] * s[1][2];
rs[0][2]=r[0][0] * s[2][0] + r[0][1] * s[2][1] + r[0][2] * s[2][2];
rs[1][0]=r[1][0] * s[0][0] + r[1][1] * s[0][1] + r[1][2] * s[0][2];
rs[1][1]=r[1][0] * s[1][0] + r[1][1] * s[1][1] + r[1][2] * s[1][2];
rs[1][2]=r[1][0] * s[2][0] + r[1][1] * s[2][1] + r[1][2] * s[2][2];
rs[2][0]=r[2][0] * s[0][0] + r[2][1] * s[0][1] + r[2][2] * s[0][2];
rs[2][1]=r[2][0] * s[1][0] + r[2][1] * s[1][1] + r[2][2] * s[1][2];
rs[2][2]=r[2][0] * s[2][0] + r[2][1] * s[2][1] + r[2][2] * s[2][2];
}, 1);

Clazz.newMeth(C$, 'getRotationMatrix$D$com_actelion_research_chem_Coordinates$DAA',  function (theta, axis, r) {
var x=axis.x;
var y=axis.y;
var z=axis.z;
var c=Math.cos(theta);
var s=Math.sin(theta);
var t=1 - c;
r[0][0]=c + x * x * t ;
r[1][0]=x * y * t  - z * s;
r[2][0]=x * z * t  + y * s;
r[0][1]=x * y * t  + z * s;
r[1][1]=c + y * y * t ;
r[2][1]=y * z * t  - x * s;
r[0][2]=z * x * t  - y * s;
r[1][2]=z * y * t  + x * s;
r[2][2]=c + z * z * t ;
}, 1);

Clazz.newMeth(C$, 'findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence',  function (initialTransforms, optimizedTransform) {
return this.findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z(initialTransforms, optimizedTransform, true);
});

Clazz.newMeth(C$, 'findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z',  function (initialTransforms, optimizedTransform, optimize) {
return this.findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode(initialTransforms, optimizedTransform, optimize, $I$(12).TANIMOTO);
});

Clazz.newMeth(C$, 'findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode',  function (initialTransforms, optimizedTransform, optimize, simMode) {
var tversky=true;
if (simMode === $I$(12).TANIMOTO ) tversky=false;
var tverskyCoeff=simMode === $I$(12).TVERSKY  ? 0.95 : 0.050000000000000044;
var Oaa=this.getSelfAtomOverlapRef$();
var Obb=this.getSelfAtomOverlapFit$();
var ppOaa=this.getSelfPPOverlapRef$();
var ppObb=this.getSelfPPOverlapFit$();
var eval=Clazz.new_([this, Clazz.array(Double.TYPE, [6]), this.ppWeight],$I$(13,1).c$$com_actelion_research_chem_phesa_PheSAAlignment$DA$D);
var opt=Clazz.new_($I$(14,1).c$$I$D,[200, 0.001]);
var maxSimilarity=0.0;
var maxPPSimilarity=0.0;
var maxVolSimilarity=0.0;
var maxShapeSimilarity=0.0;
var bestTransform=Clazz.array(Double.TYPE, [6]);
for (var transform, $transform = 0, $$transform = initialTransforms; $transform<$$transform.length&&((transform=($$transform[$transform])),1);$transform++) {
var ppSimilarity=0.0;
var atomSimilarity=0.0;
var volSimilarity=0.0;
var currentTransform;
eval.setState$DA(transform);
if (optimize) {
currentTransform=opt.optimize$com_actelion_research_chem_optimization_Evaluable(eval);
} else currentTransform=transform;
var atomOverlap=0.0;
var ppOverlap=0.0;
var similarity=0.0;
ppOverlap=this.refMolGauss.getTotalPPOverlap$DA$com_actelion_research_chem_phesa_ShapeVolume(currentTransform, this.molGauss);
if (this.getRefMolGauss$().getPPGaussians$().size$() == 0 && this.getMolGauss$().getPPGaussians$().size$() == 0 ) ppSimilarity=1.0;
 else {
if (tversky) ppSimilarity=ppOverlap / (tverskyCoeff * ppObb + (1.0 - tverskyCoeff) * ppOaa);
 else ppSimilarity=(ppOverlap / (ppOaa + ppObb - ppOverlap));
}var correctionFactor=this.refMolGauss.getPPGaussians$().size$() / this.refMolGauss.getPPGaussians$().stream$().mapToDouble$java_util_function_ToDoubleFunction((P$.PheSAAlignment$lambda2$||(P$.PheSAAlignment$lambda2$=(((P$.PheSAAlignment$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "PheSAAlignment$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian','applyAsDouble$O'],  function (g) { return (g.getWeight$());});
})()
), Clazz.new_(P$.PheSAAlignment$lambda2.$init$,[this, null])))))).sum$();
ppSimilarity*=correctionFactor;
if (ppSimilarity > 1.0 ) ppSimilarity=1.0;
var result=this.refMolGauss.getTotalAtomOverlap$DA$com_actelion_research_chem_phesa_ShapeVolume(currentTransform, this.molGauss);
atomOverlap=result[0];
var additionalVolOverlap=result[1];
if (tversky) atomSimilarity=atomOverlap / (tverskyCoeff * Obb + (1.0 - tverskyCoeff) * Oaa);
 else atomSimilarity=atomOverlap / (Oaa + Obb - atomOverlap);
if (!tversky && atomSimilarity > 1.0  ) atomSimilarity=1.0;
volSimilarity=(additionalVolOverlap / atomOverlap);
similarity=(1.0 - this.ppWeight) * atomSimilarity + this.ppWeight * ppSimilarity;
if (similarity > maxSimilarity ) {
maxSimilarity=similarity;
maxVolSimilarity=volSimilarity;
maxShapeSimilarity=atomSimilarity;
maxPPSimilarity=ppSimilarity;
bestTransform=currentTransform;
}}
var eMap=Clazz.new_($I$(15,1).c$$D$D$D,[bestTransform[0], bestTransform[1], bestTransform[2]]);
var rotor=eMap.toQuaternion$();
var translate=Clazz.new_([Clazz.array(Double.TYPE, -1, [bestTransform[3], bestTransform[4], bestTransform[5]])],$I$(16,1).c$$DA);
var transformation=Clazz.new_($I$(17,1).c$$com_actelion_research_chem_alignment3d_transformation_Quaternion,[rotor]);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(translate);
for (var trans, $trans = transformation.getTransformations$().iterator$(); $trans.hasNext$()&&((trans=($trans.next$())),1);) optimizedTransform.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans);

if (!tversky && maxSimilarity > 1.0  ) maxSimilarity=1.0;
return $I$(18,"stream$DA",[Clazz.array(Double.TYPE, -1, [maxSimilarity, maxPPSimilarity, maxShapeSimilarity, maxVolSimilarity])]).toArray$();
});
;
(function(){/*e*/var C$=Clazz.newClass(P$.PheSAAlignment, "axis", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "X", 0, []);
Clazz.newEnumConst($vals, C$.c$, "Y", 1, []);
Clazz.newEnumConst($vals, C$.c$, "Z", 2, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.PheSAAlignment, "PheSAResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['sim'],'O',['refMol','com.actelion.research.chem.StereoMolecule','+fitMol','+fitInput','contributions','double[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D',  function (refMol, fitInput, fitMol, sim) {
;C$.$init$.apply(this);
this.refMol=refMol;
this.fitMol=fitMol;
this.sim=sim;
this.contributions=Clazz.array(Double.TYPE, [4]);
this.fitInput=fitInput;
}, 1);

Clazz.newMeth(C$, 'setFitInput$com_actelion_research_chem_StereoMolecule',  function (fitInput) {
this.fitInput=fitInput;
});

Clazz.newMeth(C$, 'getRefMol$',  function () {
return this.refMol;
});

Clazz.newMeth(C$, 'getFitMol$',  function () {
return this.fitMol;
});

Clazz.newMeth(C$, 'getSim$',  function () {
return this.sim;
});

Clazz.newMeth(C$, 'setContributions$DA',  function (contributions) {
this.contributions=contributions;
});

Clazz.newMeth(C$, 'getContributions$',  function () {
return this.contributions;
});

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(1).getEncoder$();
var sb=Clazz.new_($I$(2,1));
var can=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[this.refMol, 64]);
var idcoords=can.getEncodedCoordinates$Z(true);
var idcode=can.getIDCode$();
sb.append$S(idcode);
sb.append$S(";");
sb.append$S(idcoords);
sb.append$S(";");
var can2=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[this.fitMol, 64]);
var idcoords2=can2.getEncodedCoordinates$Z(true);
var idcode2=can2.getIDCode$();
sb.append$S(idcode2);
sb.append$S(";");
sb.append$S(idcoords2);
sb.append$S(";");
sb.append$S(encoder.encodeToString$BA($I$(4).doubleToByteArray$D(this.sim)));
sb.append$S(";");
sb.append$S(encoder.encodeToString$BA($I$(4).doubleArrayToByteArray$DA(this.contributions)));
sb.append$S(";");
sb.append$S(this.fitInput.getIDCode$());
return sb.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (resultString) {
var decoder=$I$(1).getDecoder$();
var s=resultString.split$S(";");
var idcode=s[0];
var idcoords=s[1];
var refMol=Clazz.new_($I$(5,1));
var parser=Clazz.new_($I$(6,1));
parser.parse$com_actelion_research_chem_StereoMolecule$S$S(refMol, idcode, idcoords);
refMol.ensureHelperArrays$I(31);
idcode=s[2];
idcoords=s[3];
var fitMol=Clazz.new_($I$(5,1));
parser=Clazz.new_($I$(6,1));
parser.parse$com_actelion_research_chem_StereoMolecule$S$S(fitMol, idcode, idcoords);
fitMol.ensureHelperArrays$I(31);
var sim=$I$(4,"byteArrayToDouble$BA",[decoder.decode$BA(s[4].getBytes$())]);
var contributions=$I$(4,"byteArrayToDoubleArray$BA",[decoder.decode$BA(s[5].getBytes$())]);
var fitInput=Clazz.new_($I$(5,1));
Clazz.new_($I$(7,1)).parse$com_actelion_research_chem_StereoMolecule$S(fitInput, s[6]);
var pheSAResult=Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D,[refMol, fitInput, fitMol, sim]);
pheSAResult.setContributions$DA(contributions);
return pheSAResult;
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_phesa_PheSAAlignment_PheSAResult','compareTo$O'],  function (o) {
return Double.compare$D$D(this.sim, o.sim);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:28 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
