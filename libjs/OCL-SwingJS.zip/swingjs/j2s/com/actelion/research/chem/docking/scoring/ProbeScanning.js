(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.conf.Conformer','java.util.ArrayList','java.util.HashSet','java.util.HashMap','com.actelion.research.chem.docking.scoring.ChemPLP',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality'],['com.actelion.research.chem.docking.scoring.ProbeScanning','.HBProbeTerm'],'com.actelion.research.chem.docking.scoring.plp.PLPTerm','com.actelion.research.chem.docking.scoring.plp.REPTerm','java.util.stream.IntStream','com.actelion.research.chem.docking.scoring.chemscore.SimpleMetalTerm']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ProbeScanning", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Probe',9],['HBProbeTerm',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['probeType','com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint.Functionality','receptorAcceptors','java.util.Set','+receptorDonorHs','receptorDonorHPos','java.util.Map','+receptorAcceptorNeg','receptorMetals','java.util.Set','+receptorDonors','+ligandAcceptors','+ligandDonors','ligandDonorPos','java.util.Map','+ligandAcceptorNeg','receptor','com.actelion.research.chem.StereoMolecule','receptorConf','com.actelion.research.chem.conf.Conformer','probe','com.actelion.research.chem.docking.scoring.ProbeScanning.Probe','plp','java.util.List','+chemscoreMetal','+chemscoreHbond','bindingSiteAtoms','java.util.Set']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid',  function (receptor, bindingSiteAtoms, grid) {
;C$.$init$.apply(this);
this.bindingSiteAtoms=bindingSiteAtoms;
this.receptorConf=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[receptor]);
this.receptorAcceptors=Clazz.new_($I$(4,1));
this.receptorDonorHs=Clazz.new_($I$(4,1));
this.receptorDonorHPos=Clazz.new_($I$(5,1));
this.receptorAcceptorNeg=Clazz.new_($I$(5,1));
this.receptorMetals=Clazz.new_($I$(4,1));
this.receptorDonors=Clazz.new_($I$(4,1));
this.receptor=receptor;
$I$(6).identifyHBondFunctionality$com_actelion_research_chem_StereoMolecule$java_util_Set$java_util_Set$java_util_Set$java_util_Set$java_util_Map$java_util_Map(receptor, this.receptorAcceptors, this.receptorDonorHs, this.receptorDonors, this.receptorMetals, this.receptorAcceptorNeg, this.receptorDonorHPos);
}, 1);

Clazz.newMeth(C$, 'init$com_actelion_research_chem_docking_scoring_ProbeScanning_Probe',  function (probe) {
this.probe=probe;
this.plp=Clazz.new_($I$(3,1));
this.chemscoreHbond=Clazz.new_($I$(3,1));
this.chemscoreMetal=Clazz.new_($I$(3,1));
this.ligandAcceptors=Clazz.new_($I$(4,1));
this.ligandDonors=Clazz.new_($I$(4,1));
this.ligandDonorPos=Clazz.new_($I$(5,1));
this.ligandAcceptorNeg=Clazz.new_($I$(5,1));
var type=probe.type;
switch (type) {
case $I$(7).ACCEPTOR:
this.ligandAcceptors.add$O(Integer.valueOf$I(0));
break;
case $I$(7).DONOR:
this.ligandDonors.add$O(Integer.valueOf$I(0));
break;
case $I$(7).NEG_CHARGE:
this.ligandAcceptorNeg.put$O$O(Integer.valueOf$I(0), Double.valueOf$D(1.0));
this.ligandAcceptors.add$O(Integer.valueOf$I(0));
break;
case $I$(7).POS_CHARGE:
this.ligandDonorPos.put$O$O(Integer.valueOf$I(0), Double.valueOf$D(1.0));
this.ligandDonors.add$O(Integer.valueOf$I(0));
break;
default:
break;
}
for (var p, $p = this.bindingSiteAtoms.iterator$(); $p.hasNext$()&&((p=($p.next$()).intValue$()),1);) {
if (this.receptor.getAtomicNo$I(p) == 1) {
if (this.receptorDonorHs.contains$O(Integer.valueOf$I(p))) {
var d=this.receptor.getConnAtom$I$I(p, 0);
var chargedP=this.receptorDonorHPos.keySet$().contains$O(Integer.valueOf$I(p));
for (var l, $l = this.ligandAcceptors.iterator$(); $l.hasNext$()&&((l=($l.next$()).intValue$()),1);) {
var acceptorNeighbours=Clazz.array(Integer.TYPE, [0]);
var chargedL=this.ligandAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(l));
var scale=1.0;
if (chargedP && chargedL ) scale=2.0;
var hbTerm=$I$(8).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D(this.receptorConf, probe.probeConf, l, d, p, true, false, acceptorNeighbours, scale);
this.chemscoreHbond.add$O(hbTerm);
}
}} else {
if (this.receptorDonors.contains$O(Integer.valueOf$I(p))) {
for (var l=0; l < probe.probeConf.getMolecule$().getAtoms$(); l++) {
if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).HBOND_TERM]);
this.plp.add$O(plpTerm);
} else if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var repTerm=$I$(10).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I(this.receptorConf, probe.probeConf, p, l);
this.plp.add$O(repTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
}}
} else if (this.receptorAcceptors.contains$O(Integer.valueOf$I(p))) {
var acceptorNeighbours=$I$(11,"range$I$I",[0, this.receptor.getConnAtoms$I(p)]).map$java_util_function_IntUnaryOperator(((P$.ProbeScanning$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ProbeScanning$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntUnaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$I','applyAsInt$O'],  function (i) { return (this.b$['com.actelion.research.chem.docking.scoring.ProbeScanning'].receptor.getConnAtom$I$I.apply(this.b$['com.actelion.research.chem.docking.scoring.ProbeScanning'].receptor, [this.$finals$.p, i]));});
})()
), Clazz.new_(P$.ProbeScanning$lambda1.$init$,[this, {p:p}]))).toArray$();
var chargedP=this.receptorAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(p));
for (var l=0; l < probe.probeConf.getMolecule$().getAtoms$(); l++) {
if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var chargedL=this.ligandDonorPos.keySet$().contains$O(Integer.valueOf$I(l));
var scale=1.0;
if (chargedP && chargedL ) scale=2.0;
var hbTerm=$I$(8).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D(this.receptorConf, probe.probeConf, p, l, -1, false, true, acceptorNeighbours, scale);
this.chemscoreHbond.add$O(hbTerm);
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).HBOND_TERM]);
this.plp.add$O(plpTerm);
} else if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var repTerm=$I$(10).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I(this.receptorConf, probe.probeConf, p, l);
this.plp.add$O(repTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
}}
} else if (this.receptorMetals.contains$O(Integer.valueOf$I(p))) {
for (var l=0; l < probe.probeConf.getMolecule$().getAtoms$(); l++) {
if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var repTerm=$I$(10).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I(this.receptorConf, probe.probeConf, p, l);
this.plp.add$O(repTerm);
} else if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).METAL_TERM]);
this.plp.add$O(plpTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
}}
for (var l, $l = this.ligandAcceptors.iterator$(); $l.hasNext$()&&((l=($l.next$()).intValue$()),1);) {
var scale=1.0;
if (this.ligandAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(l))) scale=2.0;
var acceptorNeighbours=Clazz.array(Integer.TYPE, [0]);
var metTerm=$I$(12).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$IA$D(this.receptorConf, probe.probeConf, l, p, acceptorNeighbours, scale);
this.chemscoreMetal.add$O(metTerm);
}
} else {
for (var l=0; l < probe.probeConf.getMolecule$().getAtoms$(); l++) {
if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
} else if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, probe.probeConf, p, l, $I$(9).NONPOLAR_TERM]);
this.plp.add$O(plpTerm);
}}
}}}
});

Clazz.newMeth(C$, 'getScore$',  function () {
var energy=0.0;
var grad=Clazz.array(Double.TYPE, [3]);
for (var term, $term = this.chemscoreHbond.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getEnergy$();

for (var term, $term = this.chemscoreMetal.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

for (var term, $term = this.plp.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

return energy;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.ProbeScanning, "Probe", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['probeConf','com.actelion.research.chem.conf.Conformer','type','com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint.Functionality']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality',  function (c, type) {
;C$.$init$.apply(this);
var probeMol=Clazz.new_($I$(1,1));
probeMol.addAtom$I(6);
probeMol.ensureHelperArrays$I(1);
this.probeConf=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[probeMol]);
this.probeConf.setCoordinates$I$com_actelion_research_chem_Coordinates(0, c);
this.type=type;
}, 1);

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_Coordinates',  function (c) {
this.probeConf.setCoordinates$I$com_actelion_research_chem_Coordinates(0, c);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.ProbeScanning, "HBProbeTerm", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isProbeAcceptor','isProbeDonor'],'D',['scale'],'I',['acceptor','donor','hydrogen'],'O',['receptor','com.actelion.research.chem.conf.Conformer','+probe','acceptorNeighbours','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D',  function (receptor, probe, acceptor, donor, hydrogen, isProbeAcceptor, isProbeDonor, acceptorNeighbours, scale) {
;C$.$init$.apply(this);
this.receptor=receptor;
this.probe=probe;
this.acceptor=acceptor;
this.donor=donor;
this.hydrogen=hydrogen;
this.scale=scale;
this.isProbeAcceptor=isProbeAcceptor;
this.isProbeDonor=isProbeDonor;
this.acceptorNeighbours=acceptorNeighbours;
Clazz.assert(C$, this, function(){return (isProbeAcceptor != isProbeDonor )});
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D',  function (receptor, ligand, acceptor, donor, hydrogen, isProbeAcceptor, isProbeDonor, acceptorNeighbours, scale) {
return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D,[receptor, ligand, acceptor, donor, hydrogen, isProbeAcceptor, isProbeDonor, acceptorNeighbours, scale]);
}, 1);

Clazz.newMeth(C$, 'getDistTerm',  function () {
var a;
var h;
var energy=0.0;
if (this.isProbeAcceptor) a=this.probe.getCoordinates$I(this.acceptor);
 else a=this.receptor.getCoordinates$I(this.acceptor);
if (this.isProbeDonor) {
var d=this.probe.getCoordinates$I(this.donor);
var v=a.subC$com_actelion_research_chem_Coordinates(d);
var scale=1.0 / v.dist$();
h=d.addC$com_actelion_research_chem_Coordinates(v.scaleC$D(scale));
Clazz.assert(C$, this, function(){return (h.subC$com_actelion_research_chem_Coordinates(d).dist$() - 1.0 < 0.001 )});
} else {
h=this.receptor.getCoordinates$I(this.hydrogen);
}var r=a.subC$com_actelion_research_chem_Coordinates(h);
var d=r.dist$();
var distTerm=d - 1.85;
if (distTerm < 0 ) distTerm=-distTerm;
if (distTerm < 0.25 ) {
energy=1.0;
} else if (distTerm > 0.65 ) {
energy=0.0;
} else {
energy=(0.65 - distTerm) / (0.4);
}return energy;
}, p$1);

Clazz.newMeth(C$, 'getAngleTerm$I$I$I$Z$Z$Z$D$D$D',  function (a1, a2, a3, isLigAtomA1, isLigAtomA2, isLigAtomA3, x0, x1, x2) {
var b=Clazz.array(Boolean.TYPE, -1, [isLigAtomA1, isLigAtomA2, isLigAtomA3]);
var sum=0;
for (var bool, $bool = 0, $$bool = b; $bool<$$bool.length&&((bool=($$bool[$bool])),1);$bool++) {
if (bool) ++sum;
}
var energy=0.0;
if (sum == 2) energy=1.0;
 else {
var c1;
var c2;
var c3;
if (isLigAtomA1) c1=this.probe.getCoordinates$I(a1);
 else c1=this.receptor.getCoordinates$I(a1);
if (isLigAtomA2) c2=this.probe.getCoordinates$I(a2);
 else c2=this.receptor.getCoordinates$I(a2);
if (isLigAtomA3) c3=this.probe.getCoordinates$I(a3);
 else c3=this.receptor.getCoordinates$I(a3);
var r0=c1.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var r1=c3.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var cosTheta=r0.cosAngle$com_actelion_research_chem_Coordinates(r1);
var angleTerm=Math.acos(cosTheta) - x0;
if (angleTerm < 0 ) {
angleTerm=-angleTerm;
}if (angleTerm < x1 ) energy=1.0;
 else if (angleTerm > x2 ) energy=0.0;
 else {
energy=(x2 - angleTerm) / (x2 - x1);
}}return energy;
}, p$1);

Clazz.newMeth(C$, 'getEnergy$',  function () {
var energies=Clazz.new_($I$(3,1));
var energy=0.0;
energy=p$1.getDistTerm.apply(this, []);
if (energy != 0.0 ) {
energies.add$O(Double.valueOf$D(energy));
energy=p$1.getAngleTerm$I$I$I$Z$Z$Z$D$D$D.apply(this, [this.donor, this.hydrogen, this.acceptor, this.isProbeDonor, this.isProbeDonor, this.isProbeAcceptor, 3.141592653589793, 0.5235987755982988, 1.3962634015954636]);
energies.add$O(Double.valueOf$D(energy));
if (this.isProbeAcceptor) {
energy=p$1.getAngleTerm$I$I$I$Z$Z$Z$D$D$D.apply(this, [-1, this.acceptor, this.hydrogen, this.isProbeAcceptor, this.isProbeAcceptor, this.isProbeDonor, 3.141592653589793, 1.3962634015954636, 1.7453292519943295]);
energies.add$O(Double.valueOf$D(energy));
} else {
for (var aa, $aa = 0, $$aa = this.acceptorNeighbours; $aa<$$aa.length&&((aa=($$aa[$aa])),1);$aa++) {
energy=p$1.getAngleTerm$I$I$I$Z$Z$Z$D$D$D.apply(this, [aa, this.acceptor, this.donor, this.isProbeAcceptor, this.isProbeAcceptor, this.isProbeDonor, 3.141592653589793, 1.3962634015954636, 1.7453292519943295]);
energies.add$O(Double.valueOf$D(energy));
}
}} else energies.add$O(Double.valueOf$D(0.0));
var totEnergy=this.scale * -3.0;
for (var eng, $eng = energies.iterator$(); $eng.hasNext$()&&((eng=($eng.next$()).objectValue$()),1);) totEnergy*=eng;

return totEnergy;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:22 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
