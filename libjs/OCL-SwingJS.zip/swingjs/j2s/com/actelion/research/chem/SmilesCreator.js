(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={};
/*c*/var C$=Clazz.newClass(P$, "SmilesCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mVisitedMolAtoms','mRingClosures','mDisconnections'],'S',['mSmiles'],'O',['mMol','com.actelion.research.chem.ExtendedMolecule','mMolAtomIsSmiAtom','int[]','mVisitedMolAtom','boolean[]','+mVisitedMolBond','mSmiAtomStr','String[]']]]

Clazz.newMeth(C$, 'generateSmiles$com_actelion_research_chem_ExtendedMolecule',  function (inMol) {
var atoms;
var bonds;
var i;
var visitedAllAtoms=false;
this.mMol=inMol;
this.mMol.ensureHelperArrays$I(15);
atoms=this.mMol.getAtoms$();
bonds=this.mMol.getBonds$();
this.mVisitedMolBond=Clazz.array(Boolean.TYPE, [bonds]);
for (i=0; i < bonds; ++i) this.mVisitedMolBond[i]=false;

this.mVisitedMolAtom=Clazz.array(Boolean.TYPE, [atoms]);
this.mMolAtomIsSmiAtom=Clazz.array(Integer.TYPE, [atoms]);
for (i=0; i < atoms; ++i) {
this.mVisitedMolAtom[i]=false;
this.mMolAtomIsSmiAtom[i]=-1;
}
this.mSmiAtomStr=Clazz.array(String, [3 * atoms]);
this.mVisitedMolAtoms=0;
this.mRingClosures=0;
this.mDisconnections=0;
while (visitedAllAtoms == false ){
for (i=0; i < atoms; ++i) {
if (this.mVisitedMolAtom[i] == false ) {
if (this.mDisconnections > 0) this.mSmiAtomStr[this.mVisitedMolAtoms++]=".";
p$1.visitMolAtom$I$I.apply(this, [i, -1]);
++this.mDisconnections;
break;
}}
if (i == atoms) visitedAllAtoms=true;
}
this.mSmiles="";
for (i=0; i < this.mVisitedMolAtoms; ++i) this.mSmiles+=this.mSmiAtomStr[i];

return (this.mSmiles);
});

Clazz.newMeth(C$, 'visitMolAtom$I$I',  function (molAtom, molBond) {
var addBracket=true;
var atomCharge;
var atomIsotope;
var atomicNo;
var branchesToVisit=0;
var connAtom;
var connAtoms;
var connBond;
var currentSmiAtom;
var i;
var implicitHs;
var skippedConnAtoms=0;
var atomLabel;
currentSmiAtom=this.mVisitedMolAtoms;
this.mMolAtomIsSmiAtom[molAtom]=currentSmiAtom;
atomicNo=this.mMol.getAtomicNo$I(molAtom);
atomLabel=this.mMol.getAtomLabel$I(molAtom);
atomCharge=this.mMol.getAtomCharge$I(molAtom);
atomIsotope=this.mMol.getAtomMass$I(molAtom);
connAtoms=this.mMol.getConnAtoms$I(molAtom);
if (atomCharge == 0 && atomIsotope == 0  && p$1.isOrganic$I.apply(this, [atomicNo]) ) addBracket=false;
this.mSmiAtomStr[currentSmiAtom]="";
if (molBond != -1) {
switch (this.mMol.getBondOrder$I(molBond)) {
case 0:
this.mSmiAtomStr[currentSmiAtom]+="~";
break;
case 2:
this.mSmiAtomStr[currentSmiAtom]+="=";
break;
case 3:
this.mSmiAtomStr[currentSmiAtom]+="#";
break;
}
}if (addBracket == true ) this.mSmiAtomStr[currentSmiAtom]+="[";
if (atomIsotope != 0) this.mSmiAtomStr[currentSmiAtom]+=java.lang.Integer.toString$I(atomIsotope);
this.mSmiAtomStr[currentSmiAtom]+=atomLabel;
if (addBracket == true ) {
if (0 < (implicitHs=this.mMol.getImplicitHydrogens$I(molAtom))) {
this.mSmiAtomStr[currentSmiAtom]+="H";
if (1 < implicitHs) this.mSmiAtomStr[currentSmiAtom]+=implicitHs;
}}if (atomCharge != 0) {
if (atomCharge > 0) this.mSmiAtomStr[currentSmiAtom]+="+";
 else this.mSmiAtomStr[currentSmiAtom]+="-";
if (Math.abs(atomCharge) > 1) this.mSmiAtomStr[currentSmiAtom]+=java.lang.Integer.toString$I(Math.abs(atomCharge));
}if (addBracket == true ) this.mSmiAtomStr[currentSmiAtom]+="]";
if (molBond != -1) this.mVisitedMolBond[molBond]=true;
this.mVisitedMolAtom[molAtom]=true;
++this.mVisitedMolAtoms;
for (i=0; i < connAtoms; ++i) if (this.mVisitedMolBond[this.mMol.getConnBond$I$I(molAtom, i)] == false ) ++branchesToVisit;

for (i=0; i < connAtoms; ++i) {
connAtom=this.mMol.getConnAtom$I$I(molAtom, i);
connBond=this.mMol.getConnBond$I$I(molAtom, i);
if (this.mVisitedMolBond[connBond] == true ) {
++skippedConnAtoms;
continue;
}if (this.mVisitedMolAtom[connAtom] == true ) {
++this.mRingClosures;
this.mVisitedMolBond[connBond]=true;
switch (this.mMol.getBondOrder$I(connBond)) {
case 0:
this.mSmiAtomStr[this.mMolAtomIsSmiAtom[connAtom]]+="~";
this.mSmiAtomStr[currentSmiAtom]+="~";
break;
case 2:
this.mSmiAtomStr[this.mMolAtomIsSmiAtom[connAtom]]+="=";
this.mSmiAtomStr[currentSmiAtom]+="=";
break;
case 3:
this.mSmiAtomStr[this.mMolAtomIsSmiAtom[connAtom]]+="#";
this.mSmiAtomStr[currentSmiAtom]+="3";
break;
}
if (this.mRingClosures > 9) {
this.mSmiAtomStr[this.mMolAtomIsSmiAtom[connAtom]]+="%";
this.mSmiAtomStr[currentSmiAtom]+="%";
}this.mSmiAtomStr[this.mMolAtomIsSmiAtom[connAtom]]+=java.lang.Integer.toString$I(this.mRingClosures);
this.mSmiAtomStr[currentSmiAtom]+=java.lang.Integer.toString$I(this.mRingClosures);
continue;
}if (i - skippedConnAtoms < branchesToVisit - 1) this.mSmiAtomStr[this.mVisitedMolAtoms++]="(";
p$1.visitMolAtom$I$I.apply(this, [connAtom, connBond]);
if (i - skippedConnAtoms < branchesToVisit - 1) this.mSmiAtomStr[this.mVisitedMolAtoms++]=")";
}
}, p$1);

Clazz.newMeth(C$, 'isOrganic$I',  function (atomicNo) {
switch (atomicNo) {
case 5:
case 6:
case 7:
case 8:
case 9:
case 15:
case 16:
case 17:
case 35:
case 53:
return (true);
default:
return (false);
}
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
