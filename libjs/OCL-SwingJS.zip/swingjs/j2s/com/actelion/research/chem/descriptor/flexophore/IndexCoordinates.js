(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IndexCoordinates");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index','indexOriginalAtom'],'O',['coord','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$com_actelion_research_chem_Coordinates',  function (index, indexOriginalAtom, coord) {
;C$.$init$.apply(this);
this.index=index;
this.indexOriginalAtom=indexOriginalAtom;
this.coord=coord;
}, 1);

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'setIndex$I',  function (index) {
this.index=index;
});

Clazz.newMeth(C$, 'getIndexOriginalAtom$',  function () {
return this.indexOriginalAtom;
});

Clazz.newMeth(C$, 'setIndexOriginalAtom$I',  function (indexOriginalAtom) {
this.indexOriginalAtom=indexOriginalAtom;
});

Clazz.newMeth(C$, 'getCoord$',  function () {
return this.coord;
});

Clazz.newMeth(C$, 'setCoord$com_actelion_research_chem_Coordinates',  function (coord) {
this.coord=coord;
});

Clazz.newMeth(C$, 'toString',  function () {
var builder=Clazz.new_($I$(1,1));
builder.append$S("IndexCoordinates [index=");
builder.append$I(this.index);
builder.append$S(", index orig=");
builder.append$I(this.indexOriginalAtom);
builder.append$S(", coord=");
builder.append$O(this.coord);
builder.append$S("]");
return builder.toString();
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
