(function(){var P$=Clazz.newPackage("com.actelion.research.calc.distance"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DistanceMetrics");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getJaccard$IA$IA',  function (a1, a2) {
var sumMax=0;
var sumMin=0;
for (var i=0; i < a1.length; i++) {
sumMax+=Math.max(a1[i], a2[i]);
sumMin+=Math.min(a1[i], a2[i]);
}
return sumMin / sumMax;
}, 1);

Clazz.newMeth(C$, 'getCosine$DA$DA',  function (vectorA, vectorB) {
var dotProduct=0.0;
var normA=0.0;
var normB=0.0;
for (var i=0; i < vectorA.length; i++) {
dotProduct+=vectorA[i] * vectorB[i];
normA+=vectorA[i] * vectorA[i];
normB+=vectorB[i] * vectorB[i];
}
return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:14 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
