(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),I$=[[0,'com.actelion.research.calc.regression.svm.ParameterSVM','com.actelion.research.calc.regression.svm.SVMParameterHelper','java.util.ArrayList','java.util.Collections','com.actelion.research.calc.regression.svm.AnalyticalParameterCalculatorSVM','com.actelion.research.calc.Matrix','org.machinelearning.svm.libsvm.svm_problem','com.actelion.research.calc.regression.svm.Matrix2SVMNodeConverter','com.actelion.research.util.datamodel.DoubleArray','com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.CorrelationCalculator','com.actelion.research.util.Formatter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SVMRegression", null, 'com.actelion.research.calc.regression.ARegressionMethod', 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['modelSVM','org.machinelearning.svm.libsvm.svm_model']]
,['Z',['VERBOSE']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_([$I$(2).regressionEpsilonSVR$()],$I$(1,1).c$$org_machinelearning_svm_libsvm_svm_parameter));
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_svm_ParameterSVM',  function (parameterSVM) {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterSVM);
}, 1);

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndex) {
if (this.parameterRegressionMethod.getSvmParameter$().degree == -1) {
var modelXYIndexAnalytical=null;
var rows=modelXYIndex.X.rows$();
if (rows > 1000) {
var liIndex=Clazz.new_($I$(3,1).c$$I,[rows]);
for (var i=0; i < rows; i++) {
liIndex.add$O(Integer.valueOf$I(i));
}
$I$(4).shuffle$java_util_List(liIndex);
var liIndexSub=Clazz.new_([liIndex.subList$I$I(0, 1000)],$I$(3,1).c$$java_util_Collection);
modelXYIndexAnalytical=modelXYIndex.sub$java_util_List(liIndexSub);
} else {
modelXYIndexAnalytical=modelXYIndex;
}var parameterSVM=$I$(5).calculate$com_actelion_research_util_datamodel_ModelXYIndex(modelXYIndexAnalytical);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterSVM);
}var rows=modelXYIndex.X.rows$();
var colsY=modelXYIndex.Y.cols$();
if (colsY != 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only one y column allowed!"]);
}var YHat=Clazz.new_($I$(6,1).c$$I$I,[rows, colsY]);
var svm_problem=Clazz.new_($I$(7,1));
svm_problem.l=rows;
svm_problem.x=$I$(8).convert$com_actelion_research_calc_Matrix(modelXYIndex.X);
if (this.getParameter$().getGamma$() <= 0 ) {
this.getParameter$().setGamma$D(1.0 / modelXYIndex.X.cols$());
}var failed=false;
try {
var arrY=modelXYIndex.Y.getColAsDouble$I(0);
var daY=Clazz.new_($I$(9,1).c$$DA,[arrY]);
svm_problem.y=arrY;
var error_msg=$I$(10,"svm_check_parameter$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter",[svm_problem, this.getParameter$().getSvmParameter$()]);
if (error_msg != null ) {
System.err.print$S("SVMRegressionMultiY svm_check_parameter error: " + error_msg + "\n" );
failed=true;
}var pg=this.getProgressController$();
this.modelSVM=$I$(10,"svm_train$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$com_actelion_research_calc_ProgressController",[svm_problem, this.getParameter$().getSvmParameter$(), pg]);
if (pg != null ) {
pg.startProgress$S$I$I("Calculate train data fit", 0, rows);
}var daYHat=Clazz.new_($I$(9,1).c$$I,[rows]);
for (var j=0; j < rows; j++) {
var yHat=$I$(10).svm_predict$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA(this.modelSVM, svm_problem.x[j]);
daYHat.add$D(yHat);
YHat.set$I$I$D(j, 0, yHat);
if (pg != null ) {
pg.updateProgress$I(j);
if (pg.threadMustDie$()) {
failed=true;
break;
}}}
if (C$.VERBOSE) {
var r=Clazz.new_($I$(11,1)).calculateCorrelation$com_actelion_research_calc_INumericalDataColumn$com_actelion_research_calc_INumericalDataColumn$I(daY, daYHat, 0);
var r2=r * r;
System.out.println$S("SVMRegressionMultiY model r2 " + $I$(12,"format4$Double",[Double.valueOf$D(r2)]) + "." );
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
if (C$.VERBOSE) System.err.println$S("SVMRegressionMultiY break.");
failed=true;
} else {
throw e;
}
}
if (failed) {
YHat=null;
}return YHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
var rows=X.rows$();
var YHat=Clazz.new_($I$(6,1).c$$I$I,[rows, 1]);
var svm_problem=Clazz.new_($I$(7,1));
svm_problem.l=rows;
svm_problem.x=$I$(8).convert$com_actelion_research_calc_Matrix(X);
for (var j=0; j < rows; j++) {
var yHat=$I$(10).svm_predict$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA(this.modelSVM, svm_problem.x[j]);
YHat.set$I$I$D(j, 0, yHat);
}
return YHat;
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var yHat;
{
var svm_problem=Clazz.new_($I$(7,1));
svm_problem.l=1;
svm_problem.x=$I$(8).convertSingleRow$DA(arrRow);
yHat=$I$(10).svm_predict$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA(this.modelSVM, svm_problem.x[0]);
}return yHat;
});

Clazz.newMeth(C$, 'setNu$D',  function (nu) {
this.getParameter$().setNu$D(nu);
});

Clazz.newMeth(C$, 'setGamma$D',  function (gamma) {
this.getParameter$().setGamma$D(gamma);
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_svm_SVMRegression','compareTo$O'],  function (o) {
return this.getParameter$().compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod(o.getParameter$());
});

C$.$static$=function(){C$.$static$=0;
C$.VERBOSE=false;
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
