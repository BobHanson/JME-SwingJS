(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls"),I$=[[0,'com.actelion.research.calc.regression.linear.pls.ParameterPLS','com.actelion.research.calc.regression.linear.pls.SimPLS','com.actelion.research.calc.Matrix','com.actelion.research.calc.regression.ModelError']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PLSRegressionModelCalculator", null, 'com.actelion.research.calc.regression.ARegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['simPLS','com.actelion.research.calc.regression.linear.pls.SimPLS','B','com.actelion.research.calc.Matrix','+Xvar','+YHat','+X','+Y','+XtrainPreprocessed','+YtrainPreprocessed']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1).c$$I,[15]));
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_linear_pls_ParameterPLS',  function (parameterPLS) {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterPLS);
}, 1);

Clazz.newMeth(C$, 'setCenterData$Z',  function (centerData) {
this.getParameter$().setCenterData$Z(centerData);
});

Clazz.newMeth(C$, 'setFactors$I',  function (factors) {
this.getParameter$().setFactors$I(factors);
});

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (dataXYTrain) {
this.X=dataXYTrain.X;
this.Y=dataXYTrain.Y;
this.XtrainPreprocessed=dataXYTrain.X;
this.YtrainPreprocessed=dataXYTrain.Y;
if (this.getParameter$().isCenterData$()) {
this.XtrainPreprocessed=dataXYTrain.X.getCenteredMatrix$();
this.YtrainPreprocessed=dataXYTrain.Y.getCenteredMatrix$();
} else {
}this.simPLS=Clazz.new_($I$(2,1));
this.simPLS.simPlsSave$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I(this.XtrainPreprocessed, this.YtrainPreprocessed, this.getParameter$().getFactors$());
var R=this.simPLS.getR$();
if (R.cols$() == 1 && R.rows$() == 1  && R.get$I$I(0, 0) == 0  ) {
System.out.println$S("RegressionModelCalculator R = 0.");
}var Q=this.simPLS.getQ$();
this.B=R.multiply$Z$Z$com_actelion_research_calc_Matrix(false, true, Q);
this.Xvar=this.XtrainPreprocessed.getVarianceCols$();
this.YHat=$I$(2).invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(this.B, this.X, dataXYTrain.X, this.Y);
return this.YHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (Xtest) {
var YHatTest=$I$(2).invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(this.B, this.X, Xtest, this.Y);
return YHatTest;
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var YHatTest=$I$(2,"invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[this.B, this.X, Clazz.new_($I$(3,1).c$$Z$DA,[true, arrRow]), this.Y]);
return YHatTest.get$I$I(0, 0);
});

Clazz.newMeth(C$, 'calculateYHat$BA',  function (arrRow) {
var YHatTest=$I$(2,"invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[this.B, this.X, Clazz.new_($I$(3,1).c$$Z$BA,[true, arrRow]), this.Y]);
return YHatTest.get$I$I(0, 0);
});

Clazz.newMeth(C$, 'calculateYHat$IA',  function (arrRow) {
var YHatTest=$I$(2,"invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[this.B, this.X, Clazz.new_($I$(3,1).c$$Z$IA,[true, arrRow]), this.Y]);
return YHatTest.get$I$I(0, 0);
});

Clazz.newMeth(C$, 'calculateYHatWithoutDeCentering$com_actelion_research_calc_Matrix',  function (Xtest) {
var YHatTest=$I$(2).invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(this.B, Xtest);
return YHatTest;
});

Clazz.newMeth(C$, 'calculateModelErrorTest$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (Xtest, Ytest) {
var YHatTest=$I$(2).invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(this.B, this.XtrainPreprocessed, Xtest, this.YtrainPreprocessed);
return $I$(4).calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Ytest, YHatTest);
});

Clazz.newMeth(C$, 'getB$',  function () {
return this.B;
});

Clazz.newMeth(C$, 'getXvar$',  function () {
return this.Xvar;
});

Clazz.newMeth(C$, 'getYHat$',  function () {
return this.YHat;
});

Clazz.newMeth(C$, 'getT$com_actelion_research_calc_Matrix',  function (XPreprocessed) {
return this.simPLS.getT$com_actelion_research_calc_Matrix(XPreprocessed);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
