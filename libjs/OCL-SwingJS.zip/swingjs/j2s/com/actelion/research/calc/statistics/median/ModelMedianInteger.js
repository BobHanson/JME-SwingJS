(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics.median"),I$=[[0,'StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelMedianInteger");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['lowerQuartile','median','upperQuartile','id','size']]]

Clazz.newMeth(C$, 'range$',  function () {
return this.upperQuartile - this.lowerQuartile;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$I(this.lowerQuartile);
sb.append$S("\t");
sb.append$I(this.median);
sb.append$S("\t");
sb.append$I(this.upperQuartile);
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
