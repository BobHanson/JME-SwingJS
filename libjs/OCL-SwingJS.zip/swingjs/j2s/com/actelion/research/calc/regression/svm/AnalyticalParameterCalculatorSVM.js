(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),I$=[[0,'com.actelion.research.util.datamodel.DoubleArray','com.actelion.research.calc.statistics.StatisticsOverview','com.actelion.research.util.Formatter','com.actelion.research.calc.regression.knn.KNNRegression','com.actelion.research.calc.regression.ModelError','com.actelion.research.calc.regression.svm.SVMParameterHelper','com.actelion.research.calc.regression.svm.ParameterSVM']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AnalyticalParameterCalculatorSVM");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'calculate$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYTrain) {
System.out.println$S("AnalyticalParameterCalculatorSVM");
if (modelXYTrain.Y.cols$() != 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only single col allowed for Y!"]);
}var rows=modelXYTrain.X.rows$();
System.out.println$S("Rows X train " + (rows|0));
var daY=Clazz.new_([modelXYTrain.Y.getColAsDouble$I(0)],$I$(1,1).c$$DA);
var statisticsOverview=Clazz.new_($I$(2,1).c$$com_actelion_research_util_datamodel_DoubleArray,[daY]);
var modelStatisticsOverviewY=statisticsOverview.evaluate$();
var sigmaY=modelStatisticsOverviewY.sdv;
System.out.println$S("Sigma in y " + $I$(3,"format3$Double",[Double.valueOf$D(sigmaY)]));
var avr=modelStatisticsOverviewY.avr;
System.out.println$S("Average in y " + $I$(3,"format3$Double",[Double.valueOf$D(avr)]));
var C=Math.max(Math.abs(avr - sigmaY * 3), Math.abs(avr + sigmaY * 3));
System.out.println$S("C " + $I$(3,"format3$Double",[Double.valueOf$D(C)]));
var knnRegression=Clazz.new_($I$(4,1));
var k=3;
knnRegression.setNeighbours$I(3);
var yHat=knnRegression.createModel$com_actelion_research_util_datamodel_ModelXYIndex(modelXYTrain);
var modelErrorKNN=$I$(5).calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(modelXYTrain.Y, yHat);
var sigmaSquaredYHat=1.0 / rows * modelErrorKNN.errSumSquared;
System.out.println$S("Sigma squared y hat " + $I$(3,"format3$Double",[Double.valueOf$D(sigmaSquaredYHat)]));
var tau=3;
var epsilon=3.0 * Math.sqrt(sigmaSquaredYHat) * Math.sqrt(Math.log(rows) / rows) ;
System.out.println$S("Epsilon " + $I$(3,"format3$Double",[Double.valueOf$D(epsilon)]));
var gamma=1.0 / modelXYTrain.X.cols$();
System.out.println$S("Gamma " + $I$(3,"format4$Double",[Double.valueOf$D(gamma)]));
var kernelType=2;
var svmParameter=$I$(6).regressionEpsilonSVR$();
svmParameter.kernel_type=kernelType;
svmParameter.eps=epsilon;
svmParameter.C=C;
svmParameter.gamma=gamma;
svmParameter.degree=0;
var parameterSVM=Clazz.new_($I$(7,1).c$$org_machinelearning_svm_libsvm_svm_parameter,[svmParameter]);
return parameterSVM;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
