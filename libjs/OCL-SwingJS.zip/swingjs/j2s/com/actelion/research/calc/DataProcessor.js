(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DataProcessor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mVerbose'],'O',['mListener','java.util.ArrayList','mThreadMaster','com.actelion.research.calc.ThreadMaster']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mListener=Clazz.new_($I$(1,1));
this.mVerbose=true;
}, 1);

Clazz.newMeth(C$, 'addProgressListener$com_actelion_research_calc_ProgressListener',  function (l) {
this.mListener.add$O(l);
});

Clazz.newMeth(C$, 'removeProgressListener$com_actelion_research_calc_ProgressListener',  function (l) {
this.mListener.remove$O(l);
});

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (t) {
this.mThreadMaster=t;
});

Clazz.newMeth(C$, 'startProgress$S$I$I',  function (message, min, max) {
if (this.mListener.size$() == 0 && this.mVerbose ) System.out.println$S(message);
for (var i=0; i < this.mListener.size$(); i++) this.mListener.get$I(i).startProgress$S$I$I(message, min, max);

});

Clazz.newMeth(C$, 'updateProgress$I',  function (value) {
for (var i=0; i < this.mListener.size$(); i++) this.mListener.get$I(i).updateProgress$I(value);

});

Clazz.newMeth(C$, 'stopProgress$S',  function (message) {
if (this.mListener.size$() == 0 && this.mVerbose ) System.out.println$S(message);
for (var i=0; i < this.mListener.size$(); i++) this.mListener.get$I(i).stopProgress$();

});

Clazz.newMeth(C$, 'threadMustDie$',  function () {
return (this.mThreadMaster == null ) ? false : this.mThreadMaster.threadMustDie$();
});

Clazz.newMeth(C$, 'setVerbose$Z',  function (verbose) {
this.mVerbose=verbose;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:14 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
