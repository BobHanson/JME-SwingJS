(function(){var P$=Clazz.newPackage("org.jmol.modelkit"),p$1={},I$=[[0,'javajs.util.V3d','javajs.util.P3d','javajs.util.MeasureD',['org.jmol.modelkit.ModelKit','.Constraint'],'org.jmol.i18n.GT','javajs.util.BS','javajs.util.PT','org.jmol.util.BSUtil','org.jmol.util.Elements','org.jmol.script.SV','org.jmol.util.SimpleUnitCell','org.jmol.modelset.ModelSet','org.jmol.viewer.Viewer','java.util.Hashtable','javajs.util.SB','javajs.util.Lst','org.jmol.util.Logger','org.jmol.util.Edge','org.jmol.util.Escape','java.util.Arrays','org.jmol.modelset.AtomCollection','javajs.util.Qd']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelKit", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Constraint',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.state=0;
this.atomHoverLabel="C";
this.bondHoverLabel=$I$(5).$$S("increase order");
this.currentModelIndex=-1;
this.lastElementType="C";
this.bsHighlight=Clazz.new_($I$(6,1));
this.bondIndex=-1;
this.bondAtomIndex1=-1;
this.bondAtomIndex2=-1;
this.screenXY=Clazz.array(Integer.TYPE, [2]);
this.showSymopInfo=true;
this.addXtalHydrogens=true;
this.clickToSetElement=true;
this.autoBond=false;
this.pickAtomAssignType="C";
this.pickBondAssignType="p";
this.centerAtomIndex=-1;
this.secondAtomIndex=-1;
this.lastCenter="0 0 0";
this.lastOffset="0 0 0";
this.atomIndexSphere=-1;
},1);

C$.$fields$=[['Z',['isPickAtomAssignCharge','isRotateBond','showSymopInfo','hasUnitCell','alertedNoEdit','wasRotating','addXtalHydrogens','clickToSetElement','autoBond'],'C',['pickBondAssignType'],'D',['centerDistance'],'I',['state','currentModelIndex','bondIndex','bondAtomIndex1','bondAtomIndex2','branchAtomIndex','centerAtomIndex','secondAtomIndex','iatom0','atomIndexSphere'],'S',['atomHoverLabel','bondHoverLabel','lastElementType','pickAtomAssignType','drawData','drawScript','lastCenter','lastOffset','xtalHoverLabel'],'O',['vwr','org.jmol.viewer.Viewer','menu','org.jmol.modelkit.ModelKitPopup','allOperators','String[]','lastModelSet','org.jmol.modelset.ModelSet','bsHighlight','javajs.util.BS','+bsRotateBranch','screenXY','int[]','centerPoint','javajs.util.P3d','+spherePoint','+viewOffset','symop','java.lang.Object','a0','org.jmol.modelset.Atom','+a3','constraint','org.jmol.modelkit.ModelKit.Constraint','atomConstraints','org.jmol.modelkit.ModelKit.Constraint[]']]
,['I',['GET','GET_CREATE','GET_DELETE'],'O',['locked','org.jmol.modelkit.ModelKit.Constraint','+none','Pt000','javajs.util.P3d']]]

Clazz.newMeth(C$, 'checkOption$C$S',  function (type, value) {
var check=null;
switch (type.$c()) {
case 77:
check=";view;edit;molecular;";
break;
case 83:
check=";none;applylocal;retainlocal;applyfull;";
break;
case 85:
check=";packed;extend;";
break;
case 66:
check=";autobond;hidden;showsymopinfo;clicktosetelement;addhydrogen;addhydrogens;";
break;
}
return (check != null  && $I$(7).isOneOf$S$S(value, check) );
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setMenu$org_jmol_modelkit_ModelKitPopup',  function (menu) {
this.menu=menu;
this.vwr=menu.vwr;
menu.modelkit=this;
this.initializeForModel$();
});

Clazz.newMeth(C$, 'initializeForModel$',  function () {
this.resetBondFields$();
this.allOperators=null;
this.currentModelIndex=-999;
this.iatom0=0;
this.atomIndexSphere=this.centerAtomIndex=this.secondAtomIndex=-1;
this.centerPoint=this.spherePoint=null;
this.symop=null;
this.setDefaultState$I(0);
});

Clazz.newMeth(C$, 'showMenu$I$I',  function (x, y) {
this.menu.jpiShow$I$I(x, y);
});

Clazz.newMeth(C$, 'getDefaultModel$',  function () {
return (this.addXtalHydrogens ? "5\n\nC 0 0 0\nH .63 .63 .63\nH -.63 -.63 .63\nH -.63 .63 -.63\nH .63 -.63 -.63" : "1\n\nC 0 0 0\n");
});

Clazz.newMeth(C$, 'updateMenu$',  function () {
this.menu.jpiUpdateComputedMenus$();
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.menu.jpiDispose$();
this.menu.modelkit=null;
this.menu=null;
this.vwr=null;
});

Clazz.newMeth(C$, 'isPickAtomAssignCharge$',  function () {
return this.isPickAtomAssignCharge;
});

Clazz.newMeth(C$, 'isHidden$',  function () {
return this.menu.hidden;
});

Clazz.newMeth(C$, 'getActiveMenu$',  function () {
return this.menu.activeMenu;
});

Clazz.newMeth(C$, 'getRotateBondIndex$',  function () {
return (this.getMKState$() == 0 && this.isRotateBond  ? this.bondIndex : -1);
});

Clazz.newMeth(C$, 'getProperty$S',  function (name) {
name=name.toLowerCase$().intern$();
if (name === "exists" ) return Boolean.TRUE;
if (name === "constraint" ) {
return this.constraint;
}if (name === "ismolecular" ) {
return Boolean.valueOf$Z(this.getMKState$() == 0);
}if (name === "alloperators" ) {
return this.allOperators;
}if (name === "data" ) {
return p$1.getinfo.apply(this, []);
}return this.setProperty$S$O(name, null);
});

Clazz.newMeth(C$, 'setProperty$S$O',  function (key, value) {
try {
if (this.vwr == null ) return null;
key=key.toLowerCase$().intern$();
if (key === "hoverlabel" ) {
return p$1.getHoverLabel$I.apply(this, [(value).intValue$()]);
}if (key === "branchatomclicked" ) {
if (this.isRotateBond && !this.vwr.acm.isHoverable$() ) p$1.setBranchAtom$I$Z.apply(this, [(value).intValue$(), true]);
return null;
}if (key === "branchatomdragged" ) {
if (this.isRotateBond) p$1.setBranchAtom$I$Z.apply(this, [(value).intValue$(), true]);
return null;
}if (key === "hidemenu" ) {
this.menu.hidePopup$();
return null;
}if (key === "constraint" ) {
this.constraint=null;
this.clearAtomConstraints$();
var o=value;
if (o != null ) {
var v1=o[0];
var v2=o[1];
var plane=o[2];
if (v1 != null  && v2 != null  ) {
this.constraint=Clazz.new_([null, 4, Clazz.array(java.lang.Object, -1, [v1, v2])],$I$(4,1).c$$javajs_util_P3d$I$OA);
} else if (plane != null ) {
this.constraint=Clazz.new_([null, 5, Clazz.array(java.lang.Object, -1, [plane])],$I$(4,1).c$$javajs_util_P3d$I$OA);
} else if (v1 != null ) this.constraint=Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[null, 6, null]);
}return null;
}if (key === "reset" ) {
return null;
}if (key === "atompickingmode" ) {
if ($I$(7).isOneOf$S$S(value, ";identify;off;")) {
this.exitBondRotation$S(null);
this.vwr.setBooleanProperty$S$Z("bondPicking", false);
this.vwr.acm.exitMeasurementMode$S("modelkit");
}if ("dragatom".equals$O(value)) {
this.setHoverLabel$S$S("atomMenu", C$.getText$S("dragAtom"));
}return null;
}if (key === "bondpickingmode" ) {
if (value.equals$O("deletebond")) {
this.exitBondRotation$S(C$.getText$S("bondTo0"));
} else if (value.equals$O("identifybond")) {
this.exitBondRotation$S("");
}return null;
}if (key === "bondatomindex" ) {
var i=(value).intValue$();
if (i != this.bondAtomIndex2) this.bondAtomIndex1=i;
this.bsRotateBranch=null;
return null;
}if (key === "highlight" ) {
if (value == null ) this.bsHighlight=Clazz.new_($I$(6,1));
 else this.bsHighlight=value;
return null;
}if (key === "mode" ) {
var isEdit=("edit".equals$O(value));
this.setMKState$I("view".equals$O(value) ? 1 : isEdit ? 2 : 0);
if (isEdit) this.addXtalHydrogens=false;
return null;
}if (key === "symmetry" ) {
this.setDefaultState$I(2);
key=(value).toLowerCase$().intern$();
this.setSymEdit$I(key === "applylocal"  ? 32 : key === "retainlocal"  ? 64 : key === "applyfull"  ? 128 : 0);
p$1.showXtalSymmetry.apply(this, []);
return null;
}if (key === "unitcell" ) {
var isPacked="packed".equals$O(value);
this.setUnitCell$I(isPacked ? 0 : 256);
this.viewOffset=(isPacked ? C$.Pt000 : null);
return null;
}if (key === "center" ) {
this.setDefaultState$I(1);
this.centerPoint=value;
this.lastCenter=new Double(this.centerPoint.x).toString() + " " + new Double(this.centerPoint.y).toString() + " " + new Double(this.centerPoint.z).toString() ;
this.centerAtomIndex=(Clazz.instanceOf(this.centerPoint, "org.jmol.modelset.Atom") ? (this.centerPoint).i : -1);
this.atomIndexSphere=-1;
this.secondAtomIndex=-1;
p$1.processAtomClick$I.apply(this, [this.centerAtomIndex]);
return null;
}if (key === "scriptassignbond" ) {
p$1.appRunScript$S.apply(this, ["modelkit assign bond [{" + value + "}] \"" + this.pickBondAssignType + "\"" ]);
return null;
}if (key === "addhydrogen"  || key === "addhydrogens"  ) {
if (value != null ) this.addXtalHydrogens=C$.isTrue$O(value);
return Boolean.valueOf$Z(this.addXtalHydrogens);
}if (key === "autobond" ) {
if (value != null ) this.autoBond=C$.isTrue$O(value);
return Boolean.valueOf$Z(this.autoBond);
}if (key === "clicktosetelement" ) {
if (value != null ) this.clickToSetElement=C$.isTrue$O(value);
return Boolean.valueOf$Z(this.clickToSetElement);
}if (key === "hidden" ) {
if (value != null ) {
this.menu.hidden=C$.isTrue$O(value);
if (this.menu.hidden) this.menu.hidePopup$();
this.vwr.setBooleanProperty$S$Z("modelkitMode", true);
}return Boolean.valueOf$Z(this.menu.hidden);
}if (key === "showsymopinfo" ) {
if (value != null ) this.showSymopInfo=C$.isTrue$O(value);
return Boolean.valueOf$Z(this.showSymopInfo);
}if (key === "symop" ) {
this.setDefaultState$I(1);
if (value != null ) {
if (key === "hoverlabel" ) {
return p$1.getHoverLabel$I.apply(this, [(value).intValue$()]);
}this.symop=value;
p$1.showSymop$O.apply(this, [this.symop]);
}return this.symop;
}if (key === "atomtype" ) {
this.wasRotating=this.isRotateBond;
this.isRotateBond=false;
if (value != null ) {
this.pickAtomAssignType=value;
this.isPickAtomAssignCharge=(this.pickAtomAssignType.equalsIgnoreCase$S("pl") || this.pickAtomAssignType.equalsIgnoreCase$S("mi") );
if (this.isPickAtomAssignCharge) {
this.setHoverLabel$S$S("atomMenu", C$.getText$S(this.pickAtomAssignType.equalsIgnoreCase$S("mi") ? "decCharge" : "incCharge"));
} else if ("X".equals$O(this.pickAtomAssignType)) {
this.setHoverLabel$S$S("atomMenu", C$.getText$S("delAtom"));
} else if (this.pickAtomAssignType.equals$O("Xx")) {
this.setHoverLabel$S$S("atomMenu", C$.getText$S("dragBond"));
} else {
this.setHoverLabel$S$S("atomMenu", "Click or click+drag to bond or for a new " + this.pickAtomAssignType);
this.lastElementType=this.pickAtomAssignType;
}}return this.pickAtomAssignType;
}if (key === "bondtype" ) {
if (value != null ) {
var s=(value).substring$I$I(0, 1).toLowerCase$();
if (" 0123456pm".indexOf$S(s) > 0) {
this.pickBondAssignType=s.charAt$I(0);
this.setHoverLabel$S$S("bondMenu", C$.getText$S(this.pickBondAssignType == "m" ? "decBond" : this.pickBondAssignType == "p" ? "incBond" : "bondTo" + s));
}this.isRotateBond=false;
}return "" + this.pickBondAssignType;
}if (key === "bondindex" ) {
if (value != null ) {
p$1.setBondIndex$I$Z.apply(this, [(value).intValue$(), false]);
}return (this.bondIndex < 0 ? null : Integer.valueOf$I(this.bondIndex));
}if (key === "rotatebondindex" ) {
if (value != null ) {
p$1.setBondIndex$I$Z.apply(this, [(value).intValue$(), true]);
}return (this.bondIndex < 0 ? null : Integer.valueOf$I(this.bondIndex));
}if (key === "offset" ) {
if (value === "none" ) {
this.viewOffset=null;
} else if (value != null ) {
this.viewOffset=(Clazz.instanceOf(value, "javajs.util.P3d") ? value : C$.pointFromTriad$S(value.toString()));
if (this.viewOffset != null ) this.setSymViewState$I(8);
}p$1.showXtalSymmetry.apply(this, []);
return this.viewOffset;
}if (key === "screenxy" ) {
if (value != null ) {
this.screenXY=value;
this.vwr.acm.exitMeasurementMode$S("modelkit");
}return this.screenXY;
}if (key === "invariant" ) {
var iatom=(Clazz.instanceOf(value, "javajs.util.BS") ? (value).nextSetBit$I(0) : -1);
var atom=this.vwr.ms.getAtom$I(iatom);
return (atom == null  ? null : this.vwr.getSymmetryInfo$I$S$I$javajs_util_P3d$javajs_util_P3d$javajs_util_P3d$I$S$D$I$I(iatom, null, -1, null, atom, atom, 1275068418, null, 0, 0, 0));
}if (key === "distance" ) {
this.setDefaultState$I(2);
var d=(value == null  ? NaN : Clazz.instanceOf(value, "java.lang.Double") ? (value).doubleValue$() : $I$(7).parseDouble$S(value));
if (!Double.isNaN$D(d)) {
C$.notImplemented$S("setProperty: distance");
this.centerDistance=d;
}return Double.valueOf$D(this.centerDistance);
}if (key === "point" ) {
if (value != null ) {
C$.notImplemented$S("setProperty: point");
this.setDefaultState$I(2);
this.spherePoint=value;
this.atomIndexSphere=(Clazz.instanceOf(this.spherePoint, "org.jmol.modelset.Atom") ? (this.spherePoint).i : -1);
}return this.spherePoint;
}if (key === "addconstraint" ) {
C$.notImplemented$S("setProperty: addConstraint");
return null;
}if (key === "removeconstraint" ) {
C$.notImplemented$S("setProperty: removeConstraint");
return null;
}if (key === "removeallconstraints" ) {
C$.notImplemented$S("setProperty: removeAllConstraints");
return null;
}System.err.println$S("ModelKit.setProperty? " + key + " " + value );
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return "?";
} else {
throw e;
}
}
return null;
});

Clazz.newMeth(C$, 'setBondMeasure$I$org_jmol_modelset_MeasurementPending',  function (bi, mp) {
if (this.branchAtomIndex < 0) return null;
var b=this.vwr.ms.bo[bi];
var a1=b.atom1;
var a2=b.atom2;
this.a0=this.a3=null;
if (a1.getCovalentBondCount$() == 1 || a2.getCovalentBondCount$() == 1 ) return null;
mp.addPoint$I$org_jmol_util_Point3fi$Z((this.a0=p$1.getOtherAtomIndex$org_jmol_modelset_Atom$org_jmol_modelset_Atom.apply(this, [a1, a2])).i, null, true);
mp.addPoint$I$org_jmol_util_Point3fi$Z(a1.i, null, true);
mp.addPoint$I$org_jmol_util_Point3fi$Z(a2.i, null, true);
mp.addPoint$I$org_jmol_util_Point3fi$Z((this.a3=p$1.getOtherAtomIndex$org_jmol_modelset_Atom$org_jmol_modelset_Atom.apply(this, [a2, a1])).i, null, true);
mp.mad=50;
mp.inFront=true;
return mp;
});

Clazz.newMeth(C$, 'actionRotateBond$I$I$I$I$Z',  function (deltaX, deltaY, x, y, forceFull) {
if (this.bondIndex < 0) return;
var bsBranch=this.bsRotateBranch;
var atomFix;
var atomMove;
var ms=this.vwr.ms;
var b=ms.bo[this.bondIndex];
if (forceFull) {
bsBranch=null;
this.branchAtomIndex=-1;
}if (bsBranch == null ) {
atomMove=(this.branchAtomIndex == b.atom1.i ? b.atom1 : b.atom2);
atomFix=(atomMove === b.atom1  ? b.atom2 : b.atom1);
this.vwr.undoMoveActionClear$I$I$Z(atomFix.i, 2, true);
if (this.branchAtomIndex >= 0) bsBranch=this.vwr.getBranchBitSet$I$I$Z(atomMove.i, atomFix.i, true);
if (bsBranch != null ) for (var n=0, i=atomFix.bonds.length; --i >= 0; ) {
if (bsBranch.get$I(atomFix.getBondedAtomIndex$I(i)) && ++n == 2 ) {
bsBranch=null;
break;
}}
if (bsBranch == null ) {
bsBranch=ms.getMoleculeBitSetForAtom$I(atomFix.i);
forceFull=true;
}this.bsRotateBranch=bsBranch;
this.bondAtomIndex1=atomFix.i;
this.bondAtomIndex2=atomMove.i;
} else {
atomFix=ms.at[this.bondAtomIndex1];
atomMove=ms.at[this.bondAtomIndex2];
}if (forceFull) this.bsRotateBranch=null;
var v1=$I$(1).new3$D$D$D(atomMove.sX - atomFix.sX, atomMove.sY - atomFix.sY, 0);
v1.scale$D(1.0 / v1.length$());
var v2=$I$(1).new3$D$D$D(deltaX, deltaY, 0);
v1.cross$javajs_util_T3d$javajs_util_T3d(v1, v2);
var f=(v1.z > 0  ? 1 : -1);
var degrees=f * (((v2.length$()|0)/2|0) + 1);
if (!forceFull && this.a0 != null  ) {
var ang0=$I$(3).computeTorsion$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d$Z(this.a0, b.atom1, b.atom2, this.a3, true);
var ang1=Long.$ival(Math.round$D(ang0 + degrees));
degrees=ang1 - ang0;
}var bs=$I$(8).copy$javajs_util_BS(bsBranch);
bs.andNot$javajs_util_BS(this.vwr.slm.getMotionFixedAtoms$());
this.vwr.rotateAboutPointsInternal$org_jmol_api_JmolScriptEvaluator$javajs_util_P3d$javajs_util_P3d$D$D$Z$javajs_util_BS$javajs_util_V3d$javajs_util_Lst$DA$javajs_util_M4d(null, atomFix, atomMove, 0, degrees, false, bs, null, null, null, null);
});

Clazz.newMeth(C$, 'handleAssignNew$org_jmol_viewer_MouseState$org_jmol_viewer_MouseState$org_jmol_modelset_MeasurementPending$I$I',  function (pressed, dragged, mp, dragAtomIndex, key) {
var inRange=pressed.inRange$I$I$I(10, dragged.x, dragged.y);
if (inRange) {
dragged.x=pressed.x;
dragged.y=pressed.y;
}if (mp != null  && p$1.handleDragAtom$org_jmol_viewer_MouseState$org_jmol_viewer_MouseState$IA.apply(this, [pressed, dragged, mp.countPlusIndices]) ) return true;
var atomType=(key < 0 ? this.pickAtomAssignType : C$.keyToElement$I(key));
if (atomType == null ) return false;
var isCharge=this.isPickAtomAssignCharge;
if (mp != null  && mp.count == 2 ) {
this.vwr.undoMoveActionClear$I$I$Z(-1, 4146, true);
var atoms=mp.getMeasurementScript$S$Z(" ", false);
if ((mp.getAtom$I(1)).isBonded$org_jmol_modelset_Atom(mp.getAtom$I(2))) {
p$1.appRunScript$S.apply(this, ["modelkit assign bond " + atoms + "'p'" ]);
} else {
p$1.appRunScript$S.apply(this, ["modelkit connect " + atoms]);
}} else {
if (atomType.equals$O("Xx")) {
atomType=this.lastElementType;
}if (inRange) {
var s="modelkit assign atom ({" + dragAtomIndex + "}) \"" + atomType + "\" true" ;
if (isCharge) {
s+=";{atomindex=" + dragAtomIndex + "}.label='%C'; " ;
this.vwr.undoMoveActionClear$I$I$Z(dragAtomIndex, 4, true);
} else {
this.vwr.undoMoveActionClear$I$I$Z(-1, 4146, true);
}p$1.appRunScript$S.apply(this, [s]);
} else if (!isCharge) {
this.vwr.undoMoveActionClear$I$I$Z(-1, 4146, true);
var a=this.vwr.ms.at[dragAtomIndex];
if (a.getElementNumber$() == 1) {
this.assignAtomClick$I$S$javajs_util_P3d(dragAtomIndex, "X", null);
} else {
var x=dragged.x;
var y=dragged.y;
if (this.vwr.antialiased) {
x<<=1;
y<<=1;
}var ptNew=$I$(2).new3$D$D$D(x, y, a.sZ);
this.vwr.tm.unTransformPoint$javajs_util_T3d$javajs_util_T3d(ptNew, ptNew);
this.assignAtomClick$I$S$javajs_util_P3d(dragAtomIndex, atomType, ptNew);
}}}return true;
});

Clazz.newMeth(C$, 'keyToElement$I',  function (key) {
var ch1=(key & 255);
var ch2=(key >> 8) & 255;
var element="" + String.fromCharCode(ch1) + (ch2 == 0 ? "" : ("" + String.fromCharCode(ch2)).toLowerCase$()) ;
var n=$I$(9).elementNumberFromSymbol$S$Z(element, true);
return (n == 0 ? null : element);
}, 1);

Clazz.newMeth(C$, 'isXtalState$',  function () {
return ((this.state & 3) != 0);
});

Clazz.newMeth(C$, 'setMKState$I',  function (bits) {
this.state=(this.state & ~3) | (this.hasUnitCell ? bits : 0);
});

Clazz.newMeth(C$, 'getMKState$',  function () {
return this.state & 3;
});

Clazz.newMeth(C$, 'setSymEdit$I',  function (bits) {
this.state=(this.state & ~224) | bits;
});

Clazz.newMeth(C$, 'getSymEditState$',  function () {
return this.state & 224;
});

Clazz.newMeth(C$, 'setSymViewState$I',  function (bits) {
this.state=(this.state & ~28) | bits;
});

Clazz.newMeth(C$, 'getSymViewState$',  function () {
return this.state & 28;
});

Clazz.newMeth(C$, 'setUnitCell$I',  function (bits) {
this.state=(this.state & ~1792) | bits;
});

Clazz.newMeth(C$, 'getUnitCellState$',  function () {
return this.state & 1792;
});

Clazz.newMeth(C$, 'exitBondRotation$S',  function (text) {
this.wasRotating=this.isRotateBond;
this.isRotateBond=false;
if (text != null ) this.bondHoverLabel=text;
this.vwr.highlight$javajs_util_BS(null);
});

Clazz.newMeth(C$, 'resetBondFields$',  function () {
this.bsRotateBranch=null;
this.branchAtomIndex=this.bondAtomIndex1=this.bondAtomIndex2=-1;
});

Clazz.newMeth(C$, 'processXtalClick$S$S',  function (id, action) {
if (this.processSymop$S$Z(id, false)) return;
action=action.intern$();
if (action.startsWith$S("mkmode_")) {
if (!this.alertedNoEdit && action === "mkmode_edit"  ) {
this.alertedNoEdit=true;
this.vwr.alert$S("ModelKit xtal edit has not been implemented");
return;
}p$1.processModeClick$S.apply(this, [action]);
} else if (action.startsWith$S("mksel_")) {
p$1.processSelClick$S.apply(this, [action]);
} else if (action.startsWith$S("mkselop_")) {
while (action != null )action=p$1.processSelOpClick$S.apply(this, [action]);

} else if (action.startsWith$S("mksymmetry_")) {
p$1.processSymClick$S.apply(this, [action]);
} else if (action.startsWith$S("mkunitcell_")) {
p$1.processUCClick$S.apply(this, [action]);
} else {
C$.notImplemented$S("XTAL click " + action);
}this.menu.updateAllXtalMenuOptions$();
});

Clazz.newMeth(C$, 'processSymop$S$Z',  function (id, isFocus) {
var pt=id.indexOf$S(".mkop_");
if (pt >= 0) {
var op=this.symop;
this.symop=Integer.valueOf$S(id.substring$I(pt + 6));
p$1.showSymop$O.apply(this, [this.symop]);
if (isFocus) this.symop=op;
return true;
}return false;
});

Clazz.newMeth(C$, 'setDefaultState$I',  function (mode) {
if (!this.hasUnitCell) mode=0;
if (!this.hasUnitCell || this.isXtalState$() != this.hasUnitCell  ) {
this.setMKState$I(mode);
switch (mode) {
case 0:
break;
case 1:
if (this.getSymViewState$() == 0) this.setSymViewState$I(8);
break;
case 2:
break;
}
}});

Clazz.newMeth(C$, 'getAllOperators$',  function () {
if (this.allOperators != null ) return this.allOperators;
var data=p$1.runScriptBuffered$S.apply(this, ["show symop"]);
this.allOperators=$I$(7,"split$S$S",[data.trim$().replace$C$C("\t", " "), "\n"]);
return this.allOperators;
});

Clazz.newMeth(C$, 'setHasUnitCell$',  function () {
return this.hasUnitCell=(this.vwr.getOperativeSymmetry$() != null );
});

Clazz.newMeth(C$, 'checkNewModel$',  function () {
var isNew=false;
if (this.vwr.ms !== this.lastModelSet ) {
this.lastModelSet=this.vwr.ms;
isNew=true;
}this.currentModelIndex=Math.max(this.vwr.am.cmi, 0);
this.iatom0=this.vwr.ms.am[this.currentModelIndex].firstAtomIndex;
return isNew;
});

Clazz.newMeth(C$, 'getSymopText$',  function () {
return (this.symop == null  || this.allOperators == null   ? null : Clazz.instanceOf(this.symop, "java.lang.Integer") ? this.allOperators[(this.symop).intValue$() - 1] : this.symop.toString());
});

Clazz.newMeth(C$, 'getCenterText$',  function () {
return (this.centerAtomIndex < 0 && this.centerPoint == null   ? null : this.centerAtomIndex >= 0 ? this.vwr.getAtomInfo$I(this.centerAtomIndex) : this.centerPoint.toString());
});

Clazz.newMeth(C$, 'resetAtomPickType$',  function () {
this.setProperty$S$O("atomType", this.lastElementType);
});

Clazz.newMeth(C$, 'setHoverLabel$S$S',  function (mode, text) {
if (text == null ) return;
if (mode == "bondMenu") {
this.bondHoverLabel=text;
} else if (mode == "atomMenu") {
this.atomHoverLabel=text;
} else if (mode == "xtalMenu") {
this.xtalHoverLabel=this.atomHoverLabel=text;
}});

Clazz.newMeth(C$, 'getElementFromUser$',  function () {
var element=p$1.promptUser$S$S.apply(this, [$I$(5).$$S("Element?"), ""]);
return (element == null  || $I$(9).elementNumberFromSymbol$S$Z(element, true) == 0  ? null : element);
});

Clazz.newMeth(C$, 'processMKPropertyItem$S$Z',  function (name, TF) {
name=name.substring$I(2);
var pt=name.indexOf$S("_");
if (pt > 0) {
this.setProperty$S$O(name.substring$I$I(0, pt), name.substring$I(pt + 1));
} else {
this.setProperty$S$O(name, Boolean.valueOf$Z(TF));
}});

Clazz.newMeth(C$, 'assignAtom$I$S$Z$Z$Z$javajs_util_BS',  function (atomIndex, type, autoBond, addHsAndBond, isClick, bsAtoms) {
if (isClick) {
if (this.vwr.isModelkitPickingRotateBond$()) {
this.bondAtomIndex1=atomIndex;
return -1;
}if (p$1.processAtomClick$I.apply(this, [atomIndex]) || !this.clickToSetElement && this.vwr.ms.getAtom$I(atomIndex).getElementNumber$() != 1  ) return -1;
}if (bsAtoms != null ) {
var n=-1;
for (var i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
n=p$1.assignAtom$I$S$Z$Z$Z$javajs_util_BS.apply(this, [i, type, autoBond, addHsAndBond, isClick, null]);
}
return n;
}var atom=this.vwr.ms.at[atomIndex];
if (atom == null ) return -1;
this.vwr.ms.clearDB$I(atomIndex);
if (type == null ) type="C";
var bs=Clazz.new_($I$(6,1));
var wasH=(atom.getElementNumber$() == 1);
var atomicNumber=("PlMiX".indexOf$S(type) >= 0 ? -1 : type.equals$O("Xx") ? 0 : $I$(7,"isUpperCase$C",[type.charAt$I(0)]) ? $I$(9).elementNumberFromSymbol$S$Z(type, true) : -1);
var isDelete=false;
if (atomicNumber >= 0) {
var doTaint=(atomicNumber > 1 || !addHsAndBond );
this.vwr.ms.setElement$org_jmol_modelset_Atom$I$Z(atom, atomicNumber, doTaint);
this.vwr.shm.setShapeSizeBs$I$I$org_jmol_atomdata_RadiusData$javajs_util_BS(0, 0, this.vwr.rd, $I$(8).newAndSetBit$I(atomIndex));
this.vwr.ms.setAtomName$I$S$Z(atomIndex, type + atom.getAtomNumber$(), doTaint);
if (this.vwr.getBoolean$I(603983903)) this.vwr.ms.am[atom.mi].isModelKit=true;
if (!this.vwr.ms.am[atom.mi].isModelKit || atomicNumber > 1 ) this.vwr.ms.taintAtom$I$I(atomIndex, 0);
} else if (type.toLowerCase$().equals$O("pl")) {
atom.setFormalCharge$I(atom.getFormalCharge$() + 1);
} else if (type.toLowerCase$().equals$O("mi")) {
atom.setFormalCharge$I(atom.getFormalCharge$() - 1);
} else if (type.equals$O("X")) {
isDelete=true;
} else if (!type.equals$O(".") || !this.addXtalHydrogens ) {
return -1;
}if (!addHsAndBond && !isDelete ) return atomicNumber;
if (!wasH) this.vwr.ms.removeUnnecessaryBonds$org_jmol_modelset_Atom$Z(atom, isDelete);
var dx=0;
if (atom.getCovalentBondCount$() == 1) {
if (atomicNumber == 1) {
dx=1.0;
} else {
dx=1.5;
}}if (dx != 0 ) {
var v=$I$(1,"newVsub$javajs_util_T3d$javajs_util_T3d",[atom, this.vwr.ms.at[atom.getBondedAtomIndex$I(0)]]);
var d=v.length$();
v.normalize$();
v.scale$D(dx - d);
this.vwr.ms.setAtomCoordRelative$I$D$D$D(atomIndex, v.x, v.y, v.z);
}var bsA=$I$(8).newAndSetBit$I(atomIndex);
if (isDelete) {
this.vwr.deleteAtoms$javajs_util_BS$Z(bsA, false);
}if (atomicNumber != 1 && autoBond ) {
this.vwr.ms.validateBspf$Z(false);
bs=this.vwr.ms.getAtomsWithinRadius$D$javajs_util_BS$Z$org_jmol_atomdata_RadiusData$javajs_util_BS(1.0, bsA, false, null, null);
bs.andNot$javajs_util_BS(bsA);
if (bs.nextSetBit$I(0) >= 0) this.vwr.deleteAtoms$javajs_util_BS$Z(bs, false);
bs=this.vwr.getModelUndeletedAtomsBitSet$I(atom.mi);
bs.andNot$javajs_util_BS(this.vwr.ms.getAtomBitsMDa$I$O$javajs_util_BS(1612709900, null, Clazz.new_($I$(6,1))));
this.vwr.ms.makeConnections2$D$D$I$I$javajs_util_BS$javajs_util_BS$javajs_util_BS$Z$Z$D$javajs_util_SB(0.1, 1.8, 1, 1073741904, bsA, bs, null, false, false, 0, null);
}if (this.addXtalHydrogens) this.vwr.addHydrogens$javajs_util_BS$I(bsA, 1);
return atomicNumber;
}, p$1);

Clazz.newMeth(C$, 'cmdAssignSpaceGroup$javajs_util_BS$S$I',  function (bs, name, mi) {
var isP1=(name.equalsIgnoreCase$S("P1") || name.equals$O("1") );
var isDefined=(!isP1 && name.length$() > 0 );
this.clearAtomConstraints$();
try {
if (bs != null  && bs.isEmpty$() ) return "";
var bsAtoms=(mi < 0 ? this.vwr.getThisModelAtoms$() : this.vwr.getModelUndeletedAtomsBitSet$I(mi));
var bsCell=(isP1 ? bsAtoms : $I$(10,"getBitSet$org_jmol_script_SV$Z",[this.vwr.evaluateExpressionAsVariable$O("{within(unitcell)}"), true]));
if (bs == null ) {
bs=bsAtoms;
}if (bs != null ) {
bsAtoms.and$javajs_util_BS(bs);
if (!isP1) bsAtoms.and$javajs_util_BS(bsCell);
}var noAtoms=bsAtoms.isEmpty$();
if (mi < 0) mi=(noAtoms ? 0 : this.vwr.ms.at[bsAtoms.nextSetBit$I(0)].getModelIndex$());
var sym=this.vwr.getOperativeSymmetry$();
if (sym == null ) sym=this.vwr.getSymTemp$().setUnitCell$DA$Z(Clazz.array(Double.TYPE, -1, [10, 10, 10, 90, 90, 90]), false);
var m=sym.getUnitCellMultiplier$();
if (m != null  && m.z == 1  ) {
m.z=0;
}var supercell;
var oabc;
var ita;
var basis;
var sg=null;
var sgInfo=(noAtoms || isP1  ? null : this.vwr.findSpaceGroup$javajs_util_BS$S$DA$Z$Z(isDefined ? null : bsAtoms, isDefined ? name : null, sym.getUnitCellParams$(), false, true));
if (sgInfo == null ) {
name="P1";
supercell=$I$(2).new3$D$D$D(1, 1, 1);
oabc=sym.getUnitCellVectors$();
ita="1";
basis=null;
} else {
supercell=sgInfo.get$O("supercell");
oabc=sgInfo.get$O("unitcell");
name=sgInfo.get$O("name");
ita=sgInfo.get$O("itaFull");
basis=sgInfo.get$O("basis");
sg=sgInfo.remove$O("sg");
}sym.getUnitCelld$javajs_util_T3dA$Z$S(oabc, false, null);
sym.setSpaceGroupTo$O(sg == null  ? ita : sg);
sym.setSpaceGroupName$S(name);
if (basis == null ) basis=sym.removeDuplicates$org_jmol_modelset_ModelSet$javajs_util_BS$Z(this.vwr.ms, bsAtoms, true);
this.vwr.ms.setSpaceGroup$I$org_jmol_api_SymmetryInterface$javajs_util_BS(mi, sym, basis);
var pt=$I$(11).ptToIJK$javajs_util_T3d$I(supercell, 1);
$I$(12).setUnitCellOffset$org_jmol_api_SymmetryInterface$javajs_util_T3d$I(sym, pt, 0);
return name + " basis=" + basis ;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!$I$(13).isJS) e.printStackTrace$();
return e.getMessage$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'cmdAssignDeleteAtoms$javajs_util_BS',  function (bs) {
this.clearAtomConstraints$();
bs.and$javajs_util_BS(this.vwr.getThisModelAtoms$());
bs=this.vwr.ms.getSymmetryEquivAtoms$javajs_util_BS(bs);
if (!bs.isEmpty$()) this.vwr.deleteAtoms$javajs_util_BS$Z(bs, false);
return bs.cardinality$();
});

Clazz.newMeth(C$, 'setBondIndex$I$Z',  function (index, isRotate) {
if (!isRotate && this.vwr.isModelkitPickingRotateBond$() ) {
this.setProperty$S$O("rotateBondIndex", Integer.valueOf$I(index));
return;
}var haveBond=(this.bondIndex >= 0);
if (!haveBond && index < 0 ) return;
if (index < 0) {
this.resetBondFields$();
return;
}this.bsRotateBranch=null;
this.branchAtomIndex=-1;
this.bondIndex=index;
this.isRotateBond=isRotate;
this.bondAtomIndex1=this.vwr.ms.bo[index].getAtomIndex1$();
this.bondAtomIndex2=this.vwr.ms.bo[index].getAtomIndex2$();
this.menu.setActiveMenu$S("bondMenu");
}, p$1);

Clazz.newMeth(C$, 'handleDragAtom$org_jmol_viewer_MouseState$org_jmol_viewer_MouseState$IA',  function (pressed, dragged, countPlusIndices) {
switch (this.getMKState$()) {
case 0:
return false;
case 2:
if (countPlusIndices[0] > 2) return true;
C$.notImplemented$S("drag atom for XTAL edit");
break;
case 1:
if (this.getSymViewState$() == 0) this.setSymViewState$I(8);
switch (countPlusIndices[0]) {
case 1:
this.centerAtomIndex=countPlusIndices[1];
this.secondAtomIndex=-1;
break;
case 2:
this.centerAtomIndex=countPlusIndices[1];
this.secondAtomIndex=countPlusIndices[2];
break;
}
p$1.showXtalSymmetry.apply(this, []);
return true;
}
return true;
}, p$1);

Clazz.newMeth(C$, 'showSymop$O',  function (symop) {
this.secondAtomIndex=-1;
this.symop=symop;
p$1.showXtalSymmetry.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'showXtalSymmetry',  function () {
var script=null;
switch (this.getSymViewState$()) {
case 0:
script="draw * delete";
break;
case 8:
default:
var offset=null;
if (this.secondAtomIndex >= 0) {
script="draw ID sym symop " + (this.centerAtomIndex < 0 ? this.centerPoint : " {atomindex=" + this.centerAtomIndex + "}" ) + " {atomindex=" + this.secondAtomIndex + "}" ;
} else {
offset=this.viewOffset;
if (this.symop == null ) this.symop=Integer.valueOf$I(1);
var iatom=(this.centerAtomIndex >= 0 ? this.centerAtomIndex : this.centerPoint != null  ? -1 : this.iatom0);
script="draw ID sym symop " + (this.symop == null  ? "1" : Clazz.instanceOf(this.symop, "java.lang.String") ? "'" + this.symop + "'"  : $I$(7).toJSON$S$O(null, this.symop)) + (iatom < 0 ? this.centerPoint : " {atomindex=" + iatom + "}" ) + (offset == null  ? "" : " offset " + offset) ;
}this.drawData=p$1.runScriptBuffered$S.apply(this, [script]);
this.drawScript=script;
this.drawData=(this.showSymopInfo ? this.drawData.substring$I$I(0, this.drawData.indexOf$S("\n") + 1) : "");
p$1.appRunScript$S.apply(this, [";refresh;set echo top right;echo " + this.drawData.replace$C$C("\t", " ")]);
break;
}
}, p$1);

Clazz.newMeth(C$, 'getinfo',  function () {
var info=Clazz.new_($I$(14,1));
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "addHydrogens", Boolean.valueOf$Z(this.addXtalHydrogens)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "autobond", Boolean.valueOf$Z(this.autoBond)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "clickToSetElement", Boolean.valueOf$Z(this.clickToSetElement)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "hidden", Boolean.valueOf$Z(this.menu.hidden)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "showSymopInfo", Boolean.valueOf$Z(this.showSymopInfo)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "centerPoint", this.centerPoint]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "centerAtomIndex", Integer.valueOf$I(this.centerAtomIndex)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "secondAtomIndex", Integer.valueOf$I(this.secondAtomIndex)]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "symop", this.symop]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "offset", this.viewOffset]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "drawData", this.drawData]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "drawScript", this.drawScript]);
p$1.addInfo$java_util_Map$S$O.apply(this, [info, "isMolecular", Boolean.valueOf$Z(this.getMKState$() == 0)]);
return info;
}, p$1);

Clazz.newMeth(C$, 'addInfo$java_util_Map$S$O',  function (info, key, value) {
if (value != null ) info.put$O$O(key, value);
}, p$1);

Clazz.newMeth(C$, 'processAtomClick$I',  function (atomIndex) {
switch (this.getMKState$()) {
case 0:
return this.vwr.isModelkitPickingRotateBond$();
case 1:
this.centerAtomIndex=atomIndex;
if (this.getSymViewState$() == 0) this.setSymViewState$I(8);
p$1.showXtalSymmetry.apply(this, []);
return true;
case 2:
if (atomIndex == this.centerAtomIndex) return true;
C$.notImplemented$S("edit click");
return false;
}
C$.notImplemented$S("atom click unknown XTAL state");
return false;
}, p$1);

Clazz.newMeth(C$, 'processModeClick$S',  function (action) {
this.processMKPropertyItem$S$Z(action, false);
}, p$1);

Clazz.newMeth(C$, 'processSelClick$S',  function (action) {
if (action === "mksel_atom" ) {
this.centerPoint=null;
this.centerAtomIndex=-1;
this.secondAtomIndex=-1;
} else if (action === "mksel_position" ) {
var pos=p$1.promptUser$S$S.apply(this, ["Enter three fractional coordinates", this.lastCenter]);
if (pos == null ) return;
this.lastCenter=pos;
var p=C$.pointFromTriad$S(pos);
if (p == null ) {
p$1.processSelClick$S.apply(this, [action]);
return;
}this.centerAtomIndex=-2147483647;
this.centerPoint=p;
p$1.showXtalSymmetry.apply(this, []);
}}, p$1);

Clazz.newMeth(C$, 'processSelOpClick$S',  function (action) {
this.secondAtomIndex=-1;
if (action === "mkselop_addoffset" ) {
var pos=p$1.promptUser$S$S.apply(this, ["Enter i j k for an offset for viewing the operator - leave blank to clear", this.lastOffset]);
if (pos == null ) return null;
this.lastOffset=pos;
if (pos.length$() == 0 || pos === "none"  ) {
this.setProperty$S$O("offset", "none");
return null;
}var p=C$.pointFromTriad$S(pos);
if (p == null ) {
return action;
}this.setProperty$S$O("offset", p);
} else if (action === "mkselop_atom2" ) {
C$.notImplemented$S(action);
}return null;
}, p$1);

Clazz.newMeth(C$, 'processSymClick$S',  function (action) {
if (action === "mksymmetry_none" ) {
this.setSymEdit$I(0);
} else {
this.processMKPropertyItem$S$Z(action, false);
}}, p$1);

Clazz.newMeth(C$, 'processUCClick$S',  function (action) {
this.processMKPropertyItem$S$Z(action, false);
p$1.showXtalSymmetry.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'getHoverLabel$I',  function (atomIndex) {
var state=this.getMKState$();
var msg=null;
switch (state) {
case 1:
if (this.symop == null ) this.symop=Integer.valueOf$I(1);
msg="view symop " + this.symop + " for " + this.vwr.getAtomInfo$I(atomIndex) ;
break;
case 2:
msg="start editing for " + this.vwr.getAtomInfo$I(atomIndex);
break;
case 0:
var atoms=this.vwr.ms.at;
if (this.isRotateBond) {
p$1.setBranchAtom$I$Z.apply(this, [atomIndex, false]);
msg=(this.branchAtomIndex >= 0 ? "rotate branch " + atoms[atomIndex].getAtomName$() : "rotate bond for " + p$1.getBondLabel$org_jmol_modelset_AtomA.apply(this, [atoms]));
}if (this.bondIndex < 0) {
if (this.atomHoverLabel.length$() <= 2) {
msg=this.atomHoverLabel="Click to change to " + this.atomHoverLabel + " or drag to add " + this.atomHoverLabel ;
} else {
msg=atoms[atomIndex].getAtomName$() + ": " + this.atomHoverLabel ;
this.vwr.highlight$javajs_util_BS($I$(8).newAndSetBit$I(atomIndex));
}} else {
if (msg == null ) {
switch (this.isRotateBond ? this.bsHighlight.cardinality$() : atomIndex >= 0 ? 1 : -1) {
case 0:
this.vwr.highlight$javajs_util_BS($I$(8).newAndSetBit$I(atomIndex));
case 1:
case 2:
var a=this.vwr.ms.at[atomIndex];
if (!this.isRotateBond) {
this.menu.setActiveMenu$S("atomMenu");
if (this.vwr.acm.getAtomPickingMode$() == 1) return null;
}if (this.atomHoverLabel.indexOf$S("charge") >= 0) {
var ch=a.getFormalCharge$();
ch+=(this.atomHoverLabel.indexOf$S("increase") >= 0 ? 1 : -1);
msg=this.atomHoverLabel + " to " + (ch > 0 ? "+" : "") + ch ;
} else {
msg=this.atomHoverLabel;
}msg=atoms[atomIndex].getAtomName$() + ": " + msg ;
break;
case -1:
msg=(this.bondHoverLabel.length$() == 0 ? "" : this.bondHoverLabel + " for ") + p$1.getBondLabel$org_jmol_modelset_AtomA.apply(this, [atoms]);
break;
}
}}break;
}
return msg;
}, p$1);

Clazz.newMeth(C$, 'setBranchAtom$I$Z',  function (atomIndex, isClick) {
var isBondedAtom=(atomIndex == this.bondAtomIndex1 || atomIndex == this.bondAtomIndex2 );
if (isBondedAtom) {
this.branchAtomIndex=atomIndex;
this.bsRotateBranch=null;
} else {
this.bsRotateBranch=null;
this.branchAtomIndex=-1;
}}, p$1);

Clazz.newMeth(C$, 'getBondLabel$org_jmol_modelset_AtomA',  function (atoms) {
return atoms[Math.min(this.bondAtomIndex1, this.bondAtomIndex2)].getAtomName$() + "-" + atoms[Math.max(this.bondAtomIndex1, this.bondAtomIndex2)].getAtomName$() ;
}, p$1);

Clazz.newMeth(C$, 'getOtherAtomIndex$org_jmol_modelset_Atom$org_jmol_modelset_Atom',  function (a1, a2) {
var b=a1.bonds;
var a;
var ret=null;
var zmin=2147483647;
for (var i=-1; ++i < b.length; ) {
if (b[i] != null  && b[i].isCovalent$()  && (a=b[i].getOtherAtom$org_jmol_modelset_Atom(a1)) !== a2   && a.sZ < zmin ) {
zmin=a.sZ;
ret=a;
}}
return ret;
}, p$1);

Clazz.newMeth(C$, 'promptUser$S$S',  function (msg, def) {
return this.vwr.prompt$S$S$SA$Z(msg, def, null, false);
}, p$1);

Clazz.newMeth(C$, 'appRunScript$S',  function (script) {
this.vwr.runScript$S(script);
}, p$1);

Clazz.newMeth(C$, 'runScriptBuffered$S',  function (script) {
var sb=Clazz.new_($I$(15,1));
try {
(this.vwr.eval).runBufferedSafely$S$javajs_util_SB(script, sb);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
return sb.toString();
}, p$1);

Clazz.newMeth(C$, 'isTrue$O',  function (value) {
return (Boolean.valueOf$S(value.toString()) === Boolean.TRUE );
}, 1);

Clazz.newMeth(C$, 'pointFromTriad$S',  function (pos) {
var a=$I$(7,"parseDoubleArray$S",[$I$(7).replaceAllCharacters$S$S$S(pos, "{,}", " ")]);
return (a.length == 3 && !Double.isNaN$D(a[2])  ? $I$(2).new3$D$D$D(a[0], a[1], a[2]) : null);
}, 1);

Clazz.newMeth(C$, 'notImplemented$S',  function (action) {
System.err.println$S("ModelKit.notImplemented(" + action + ")" );
}, 1);

Clazz.newMeth(C$, 'cmdAssignAtom$I$javajs_util_P3d$S$S$Z',  function (atomIndex, pt, type, cmd, isClick) {
var bs=(atomIndex < 0 ? null : $I$(8).newAndSetBit$I(atomIndex));
p$1.assignAtoms$javajs_util_P3d$Z$I$S$S$Z$javajs_util_BS$I$I$org_jmol_api_SymmetryInterface$javajs_util_Lst$S.apply(this, [pt, (pt != null ), -1, type, cmd, isClick, bs, 0, 0, null, null, null]);
});

Clazz.newMeth(C$, 'assignAtoms$javajs_util_P3d$Z$I$S$S$Z$javajs_util_BS$I$I$org_jmol_api_SymmetryInterface$javajs_util_Lst$S',  function (pt, newPoint, atomIndex, type, cmd, isClick, bs, atomicNo, site, uc, points, packing) {
var haveAtom=(atomIndex >= 0);
if (bs == null ) bs=Clazz.new_($I$(6,1));
var nIgnored=0;
var np=0;
if (!haveAtom) atomIndex=bs.nextSetBit$I(0);
var atom=(atomIndex < 0 ? null : this.vwr.ms.at[atomIndex]);
var bd=(pt != null  && atom != null   ? pt.distance$javajs_util_T3d(atom) : -1);
if (points != null ) {
np=nIgnored=points.size$();
uc.toFractional$javajs_util_T3d$Z(pt, true);
points.addLast$O(pt);
if (newPoint && haveAtom ) ++nIgnored;
uc.getEquivPointList$javajs_util_Lst$I$S(points, nIgnored, packing + (newPoint && atomIndex < 0  ? "newpt" : ""));
}var bsEquiv=(atom == null  ? null : this.vwr.ms.getSymmetryEquivAtoms$javajs_util_BS(bs));
var bs0=(bsEquiv == null  ? null : uc == null  ? $I$(8).newAndSetBit$I(atomIndex) : $I$(8).copy$javajs_util_BS(bsEquiv));
var mi=(atom == null  ? this.vwr.am.cmi : atom.mi);
var ac=this.vwr.ms.ac;
var state=this.getMKState$();
var isDelete=type.equals$O("X");
var isXtal=(this.vwr.getOperativeSymmetry$() != null );
try {
if (isDelete) {
if (isClick) {
this.setProperty$S$O("rotateBondIndex", Integer.valueOf$I(-1));
}p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [null, atomIndex, C$.GET_DELETE]);
}if (pt == null  && points == null  ) {
if (atom == null ) return;
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(atomIndex, mi, 1, cmd, 1, bsEquiv);
p$1.assignAtom$I$S$Z$Z$Z$javajs_util_BS.apply(this, [atomIndex, type, this.autoBond, !isXtal, true, bsEquiv]);
if (!$I$(7).isOneOf$S$S(type, ";Mi;Pl;X;")) this.vwr.ms.setAtomNamesAndNumbers$I$I$org_jmol_modelset_AtomCollection$Z(atomIndex, -ac, null, true);
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(atomIndex, mi, -1, "OK", 1, bsEquiv);
this.vwr.refresh$I$S(3, "assignAtom");
return;
}this.setMKState$I(0);
var pts;
if (points == null ) {
pts=Clazz.array($I$(2), -1, [pt]);
} else {
pts=Clazz.array($I$(2), [Math.max(0, points.size$() - np)]);
for (var i=pts.length; --i >= 0; ) {
pts[i]=points.get$I(np + i);
}
}var vConnections=Clazz.new_($I$(16,1));
var isConnected=false;
if (site == 0) {
if (atom != null ) {
if (bs.cardinality$() <= 1) {
vConnections.addLast$O(atom);
isConnected=true;
} else if (uc != null ) {
var p=$I$(2).newP$javajs_util_T3d(atom);
uc.toFractional$javajs_util_T3d$Z(p, true);
bs.or$javajs_util_BS(bsEquiv);
var list=uc.getEquivPoints$javajs_util_Lst$javajs_util_P3d$S(null, p, packing);
for (var j=0, n=list.size$(); j < n; j++) {
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (this.vwr.ms.at[i].distanceSquared$javajs_util_T3d(list.get$I(j)) < 0.001 ) {
vConnections.addLast$O(this.vwr.ms.at[i]);
bs.clear$I(i);
}}
}
}isConnected=(vConnections.size$() == pts.length);
if (isConnected) {
var d=1.7976931348623157E308;
for (var i=pts.length; --i >= 0; ) {
var d1=vConnections.get$I(i).distance$javajs_util_T3d(pts[i]);
if (d == 1.7976931348623157E308 ) d1=d;
 else if (Math.abs(d1 - d) > 0.001 ) {
isConnected=false;
break;
}}
}if (!isConnected) {
vConnections.clear$();
}this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(atomIndex, mi, 3, cmd, 1, null);
}if (pt != null  || points != null  ) {
var bsM=this.vwr.getThisModelAtoms$();
for (var i=bsM.nextSetBit$I(0); i >= 0; i=bsM.nextSetBit$I(i + 1)) {
var as=this.vwr.ms.at[i].getAtomSite$();
if (as > site) site=as;
}
++site;
}}var pickingMode=this.vwr.acm.getAtomPickingMode$();
var wasHidden=this.menu.hidden;
var isMK=this.vwr.getBoolean$I(603983903);
if (!isMK) {
this.vwr.setBooleanProperty$S$Z("modelkitmode", true);
this.menu.hidden=true;
this.menu.allowPopup=false;
}var htParams=Clazz.new_($I$(14,1));
if (site > 0) htParams.put$O$O("fixedSite", Integer.valueOf$I(site));
bs=this.vwr.addHydrogensInline$javajs_util_BS$javajs_util_Lst$javajs_util_P3dA$java_util_Map(bs, vConnections, pts, htParams);
if (bd > 0  && !isConnected  && vConnections.isEmpty$() ) {
p$1.connectAtoms$D$I$javajs_util_BS$javajs_util_BS.apply(this, [bd, 1, bs0, bs]);
}if (!isMK) {
this.vwr.setBooleanProperty$S$Z("modelkitmode", false);
this.menu.hidden=wasHidden;
this.menu.allowPopup=true;
this.vwr.acm.setPickingMode$I(pickingMode);
this.menu.hidePopup$();
}var atomIndexNew=bs.nextSetBit$I(0);
if (points == null ) {
p$1.assignAtom$I$S$Z$Z$Z$javajs_util_BS.apply(this, [atomIndexNew, type, false, atomIndex >= 0 && !isXtal , true, null]);
if (atomIndex >= 0) p$1.assignAtom$I$S$Z$Z$Z$javajs_util_BS.apply(this, [atomIndex, ".", false, !isXtal && !"H".equals$O(type) , isClick, null]);
this.vwr.ms.setAtomNamesAndNumbers$I$I$org_jmol_modelset_AtomCollection$Z(atomIndexNew, -ac, null, true);
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(atomIndexNew, mi, -3, "OK", 1, bs);
return;
}if (atomIndexNew >= 0) {
for (var i=atomIndexNew; i >= 0; i=bs.nextSetBit$I(i + 1)) {
p$1.assignAtom$I$S$Z$Z$Z$javajs_util_BS.apply(this, [i, type, false, false, true, null]);
this.vwr.ms.setSite$org_jmol_modelset_Atom$I$Z(this.vwr.ms.at[i], -1, false);
this.vwr.ms.setSite$org_jmol_modelset_Atom$I$Z(this.vwr.ms.at[i], site, true);
}
this.vwr.ms.updateBasisFromSite$I(mi);
}var firstAtom=this.vwr.ms.am[mi].firstAtomIndex;
if (atomicNo >= 0) {
atomicNo=$I$(9).elementNumberFromSymbol$S$Z(type, true);
var bsM=this.vwr.getThisModelAtoms$();
for (var i=bsM.nextSetBit$I(0); i >= 0; i=bsM.nextSetBit$I(i + 1)) {
if (this.vwr.ms.at[i].getAtomSite$() == site) this.vwr.ms.setElement$org_jmol_modelset_Atom$I$Z(this.vwr.ms.at[i], atomicNo, true);
}
}this.vwr.ms.setAtomNamesAndNumbers$I$I$org_jmol_modelset_AtomCollection$Z(firstAtom, -ac, null, true);
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(-1, mi, -3, "OK", 1, bs);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
} finally {
this.setMKState$I(state);
}
}, p$1);

Clazz.newMeth(C$, 'connectAtoms$D$I$javajs_util_BS$javajs_util_BS',  function (bd, bondOrder, bs1, bs2) {
this.vwr.makeConnections$D$D$I$I$javajs_util_BS$javajs_util_BS$javajs_util_BS$Z$Z$D((bd - 0.01), (bd + 0.01), bondOrder, 1073742026, bs1, bs2, Clazz.new_($I$(6,1)), false, false, 0);
}, p$1);

Clazz.newMeth(C$, 'cmdAssignBond$I$C$S',  function (bondIndex, type, cmd) {
this.assignBondAndType$I$I$C$S(bondIndex, p$1.getBondOrder$C$org_jmol_modelset_Bond.apply(this, [type, this.vwr.ms.bo[bondIndex]]), type, cmd);
});

Clazz.newMeth(C$, 'assignBondAndType$I$I$C$S',  function (bondIndex, bondOrder, type, cmd) {
var modelIndex=-1;
var state=this.getMKState$();
try {
this.setMKState$I(0);
var a1=this.vwr.ms.bo[bondIndex].atom1;
modelIndex=a1.mi;
var ac=this.vwr.ms.ac;
var bsAtoms=$I$(8).newAndSetBit$I(a1.i);
bsAtoms.set$I(this.vwr.ms.bo[bondIndex].atom2.i);
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(bondIndex, modelIndex, 6, cmd, 1, bsAtoms);
p$1.assignBond$I$I$javajs_util_BS.apply(this, [bondIndex, bondOrder, bsAtoms]);
this.vwr.ms.setAtomNamesAndNumbers$I$I$org_jmol_modelset_AtomCollection$Z(a1.i, -ac, null, true);
this.vwr.refresh$I$S(3, "setBondOrder");
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(bondIndex, modelIndex, -6, "" + type, 1, bsAtoms);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
$I$(17).error$S("assignBond failed");
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(bondIndex, modelIndex, -6, "ERROR " + ex, 1, null);
} else {
throw ex;
}
} finally {
this.setMKState$I(state);
}
});

Clazz.newMeth(C$, 'assignBond$I$I$javajs_util_BS',  function (bondIndex, bondOrder, bsAtoms) {
var bond=this.vwr.ms.bo[bondIndex];
this.vwr.ms.clearDB$I(bond.atom1.i);
if (bondOrder < 0) return false;
try {
if (bondOrder == 0) {
this.vwr.deleteBonds$javajs_util_BS($I$(8).newAndSetBit$I(bond.index));
} else {
bond.setOrder$I(bondOrder | 131072);
if (bond.atom1.getElementNumber$() != 1 && bond.atom2.getElementNumber$() != 1 ) {
this.vwr.ms.removeUnnecessaryBonds$org_jmol_modelset_Atom$Z(bond.atom1, false);
this.vwr.ms.removeUnnecessaryBonds$org_jmol_modelset_Atom$Z(bond.atom2, false);
}}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(17,"error$S",["Exception in seBondOrder: " + e.toString()]);
} else {
throw e;
}
}
if (bondOrder != 0 && this.addXtalHydrogens ) this.vwr.addHydrogens$javajs_util_BS$I(bsAtoms, 1);
return true;
}, p$1);

Clazz.newMeth(C$, 'getBondOrder$C$org_jmol_modelset_Bond',  function (type, bond) {
if (type == "-") type=this.pickBondAssignType;
var bondOrder=type.$c() - 48;
switch (type.$c()) {
case 48:
case 49:
case 50:
case 51:
case 52:
case 53:
break;
case 112:
case 109:
bondOrder=($I$(18,"getBondOrderNumberFromOrder$I",[bond.getCovalentOrder$()]).charCodeAt$I(0)) - 48 + (type == "p" ? 1 : -1);
if (bondOrder > 3) bondOrder=1;
 else if (bondOrder < 0) bondOrder=3;
break;
default:
return -1;
}
return bondOrder;
}, p$1);

Clazz.newMeth(C$, 'cmdAssignConnect$I$I$C$S',  function (index, index2, type, cmd) {
var atoms=this.vwr.ms.at;
var a;
var b;
if (index < 0 || index2 < 0  || index >= atoms.length  || index2 >= atoms.length  || (a=atoms[index]) == null   || (b=atoms[index2]) == null  ) return;
var state=this.getMKState$();
try {
var bond=null;
if (type != "1") {
var bs=Clazz.new_($I$(6,1));
bs.set$I(index);
bs.set$I(index2);
bs=this.vwr.getBondsForSelectedAtoms$javajs_util_BS(bs);
bond=this.vwr.ms.bo[bs.nextSetBit$I(0)];
}var bondOrder=p$1.getBondOrder$C$org_jmol_modelset_Bond.apply(this, [type, bond]);
var bs1=this.vwr.ms.getSymmetryEquivAtoms$javajs_util_BS($I$(8).newAndSetBit$I(index));
var bs2=this.vwr.ms.getSymmetryEquivAtoms$javajs_util_BS($I$(8).newAndSetBit$I(index2));
p$1.connectAtoms$D$I$javajs_util_BS$javajs_util_BS.apply(this, [a.distance$javajs_util_T3d(b), bondOrder, bs1, bs2]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
} finally {
this.setMKState$I(state);
}
});

Clazz.newMeth(C$, 'assignAtomClick$I$S$javajs_util_P3d',  function (atomIndex, element, ptNew) {
p$1.appRunScript$S.apply(this, ["modelkit " + (this.vwr.getOperativeSymmetry$() == null  ? "assign atom" : "ADD") + " ({" + atomIndex + "}) \"" + element + "\" " + (ptNew == null  ? "" : $I$(19).eP$javajs_util_T3d(ptNew)) + " true" ]);
});

Clazz.newMeth(C$, 'cmdAssignAddAtoms$S$javajs_util_P3dA$javajs_util_BS$S$S$Z',  function (type, pts, bsAtoms, packing, cmd, isClick) {
try {
this.vwr.pushHoldRepaintWhy$S("modelkit");
var isPoint=(bsAtoms == null );
var atomIndex=(isPoint ? -1 : bsAtoms.nextSetBit$I(0));
if (!isPoint && atomIndex < 0 ) return 0;
var uc=this.vwr.getOperativeSymmetry$();
if (uc == null ) {
if (isPoint) {
for (var i=0; i < pts.length; i++) p$1.assignAtoms$javajs_util_P3d$Z$I$S$S$Z$javajs_util_BS$I$I$org_jmol_api_SymmetryInterface$javajs_util_Lst$S.apply(this, [pts[i], true, -1, type, cmd, false, null, 1, -1, null, null, ""]);

return pts.length;
}p$1.assignAtoms$javajs_util_P3d$Z$I$S$S$Z$javajs_util_BS$I$I$org_jmol_api_SymmetryInterface$javajs_util_Lst$S.apply(this, [pts[0], true, atomIndex, type, cmd, false, null, 1, -1, null, null, ""]);
return 1;
}var bsM=this.vwr.getThisModelAtoms$();
var n=bsM.cardinality$();
if (n == 0) packing="zapped;" + packing;
var stype="" + type;
var list=Clazz.new_($I$(16,1));
var atomicNo=-1;
var site=0;
var pf=null;
if (pts != null  && pts.length == 1 ) {
pf=$I$(2).newP$javajs_util_T3d(pts[0]);
uc.toFractional$javajs_util_T3d$Z(pf, true);
isPoint=true;
}for (var i=bsM.nextSetBit$I(0); i >= 0; i=bsM.nextSetBit$I(i + 1)) {
var p=$I$(2).newP$javajs_util_T3d(this.vwr.ms.at[i]);
uc.toFractional$javajs_util_T3d$Z(p, true);
if (pf != null  && pf.distanceSquared$javajs_util_T3d(p) < 1.96E-6  ) {
site=this.vwr.ms.at[i].getAtomSite$();
if (type == null  || pts == null  ) type=this.vwr.ms.at[i].getElementSymbolIso$Z(true);
}list.addLast$O(p);
}
var nIgnored=list.size$();
packing="fromfractional;tocartesian;" + packing;
if (type != null ) atomicNo=$I$(9).elementNumberFromSymbol$S$Z(type, true);
if (isPoint) {
var bsEquiv=(bsAtoms == null  ? null : this.vwr.ms.getSymmetryEquivAtoms$javajs_util_BS(bsAtoms));
for (var i=0; i < pts.length; i++) {
p$1.assignAtoms$javajs_util_P3d$Z$I$S$S$Z$javajs_util_BS$I$I$org_jmol_api_SymmetryInterface$javajs_util_Lst$S.apply(this, [$I$(2).newP$javajs_util_T3d(pts[i]), true, atomIndex, stype, null, false, bsEquiv, atomicNo, site, uc, list, packing]);
}
} else {
var sites=Clazz.new_($I$(6,1));
for (var i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var a=this.vwr.ms.at[i];
site=a.getAtomSite$();
if (sites.get$I(site)) continue;
sites.set$I(site);
stype=(type == null  ? a.getElementSymbolIso$Z(true) : stype);
p$1.assignAtoms$javajs_util_P3d$Z$I$S$S$Z$javajs_util_BS$I$I$org_jmol_api_SymmetryInterface$javajs_util_Lst$S.apply(this, [$I$(2).newP$javajs_util_T3d(a), false, -1, stype, null, false, null, atomicNo, site, uc, list, packing]);
for (var j=list.size$(); --j >= nIgnored; ) list.removeItemAt$I(j);

}
}if (isClick) {
this.vwr.setPickingMode$S$I("dragAtom", 0);
}n=this.vwr.getThisModelAtoms$().cardinality$() - n;
return n;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return 0;
} else {
throw e;
}
} finally {
this.vwr.popHoldRepaint$S("modelkit");
}
});

Clazz.newMeth(C$, 'cmdAssignMoveAtoms$javajs_util_BS$I$javajs_util_P3d$Z',  function (bsSelected, iatom, p, allowProjection) {
var sym=this.vwr.getOperativeSymmetry$();
if (sym == null ) return 0;
var nAtoms=bsSelected.cardinality$();
if (bsSelected.intersects$javajs_util_BS(this.vwr.getMotionFixedAtoms$()) || nAtoms > 1 && (this.constraint != null  || sym.getSpaceGroupOperationCount$() > 1 )  ) {
p.x=NaN;
return 0;
}if (nAtoms > 1) {
return 0;
}var n=0;
var bsOcc=Clazz.new_($I$(6,1));
var checkOcc=false;
var a=this.vwr.ms.at[iatom];
if (!checkOcc || this.vwr.ms.getOccupancyFloat$I(a.i) == 100  ) {
bsOcc.set$I(a.i);
} else {
this.vwr.getAtomsNearPt$D$javajs_util_P3d$javajs_util_BS(1.0E-4, a, bsOcc);
for (var i=bsOcc.nextSetBit$I(0); i >= 0; i=bsOcc.nextSetBit$I(i + 1)) {
if (this.vwr.ms.getOccupancyFloat$I(i) == 100 ) bsOcc.clear$I(i);
}
}var isOccSet=(bsOcc.cardinality$() > 1);
if ((n=this.moveConstrained$I$javajs_util_P3d$Z$Z(iatom, p, !isOccSet, allowProjection)) == 0 || Double.isNaN$D(p.x)  || !isOccSet ) {
this.vwr.setStatusAtomMoved$Z$javajs_util_BS(true, bsOcc);
return n;
}for (var i=bsOcc.nextSetBit$I(0); i >= 0; i=bsOcc.nextSetBit$I(i + 1)) {
iatom=(this.constraint == null  ? this.vwr.ms.getBasisAtom$I(i).i : i);
n+=this.assignMoveAtom$I$javajs_util_P3d$javajs_util_BS(iatom, p, null);
}
this.vwr.setStatusAtomMoved$Z$javajs_util_BS(true, bsOcc);
return n;
});

Clazz.newMeth(C$, 'assignMoveAtom$I$javajs_util_P3d$javajs_util_BS',  function (iatom, pt, bsFixed) {
if (Double.isNaN$D(pt.x) || iatom < 0 ) return 0;
var bs=$I$(8).newAndSetBit$I(iatom);
bs.and$javajs_util_BS(this.vwr.getThisModelAtoms$());
if (bs.isEmpty$()) return 0;
var state=this.getMKState$();
this.setMKState$I(0);
try {
var bseq=this.vwr.ms.getSymmetryEquivAtoms$javajs_util_BS(bs);
var sg=this.vwr.getCurrentUnitCell$();
if (p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [sg, bseq.nextSetBit$I(0), C$.GET_CREATE]).type == 6) {
return 0;
}if (bsFixed != null ) bseq.andNot$javajs_util_BS(bsFixed);
var n=bseq.cardinality$();
if (n == 0) {
return 0;
}var a=this.vwr.ms.at[iatom];
var v0=sg.getInvariantSymops$javajs_util_P3d$IA(a, null);
var v1=sg.getInvariantSymops$javajs_util_P3d$IA(pt, v0);
if ((v1 == null ) != (v0 == null )  || !$I$(20).equals$IA$IA(v0, v1) ) return 0;
var points=Clazz.array($I$(2), [n]);
var ia0=bseq.nextSetBit$I(0);
if (!p$1.fillPointsForMove$org_jmol_api_SymmetryInterface$javajs_util_BS$I$javajs_util_P3d$javajs_util_P3d$javajs_util_P3dA.apply(this, [sg, bseq, ia0, a, pt, points])) {
return 0;
}var mi=this.vwr.ms.at[ia0].mi;
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(ia0, mi, 3, "dragatom", n, bseq);
for (var k=0, ia=bseq.nextSetBit$I(0); ia >= 0; ia=bseq.nextSetBit$I(ia + 1)) {
var p=points[k++];
this.vwr.ms.setAtomCoord$I$D$D$D(ia, p.x, p.y, p.z);
}
this.vwr.sm.setStatusStructureModified$I$I$I$S$I$javajs_util_BS(ia0, mi, -3, "dragatom", n, bseq);
return n;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Modelkit err" + e);
return 0;
} else {
throw e;
}
} finally {
this.setMKState$I(state);
}
});

Clazz.newMeth(C$, 'fillPointsForMove$org_jmol_api_SymmetryInterface$javajs_util_BS$I$javajs_util_P3d$javajs_util_P3d$javajs_util_P3dA',  function (sg, bseq, i0, a, pt, points) {
var d=a.distance$javajs_util_T3d(pt);
var fa=$I$(2).newPd$javajs_util_T3d(a);
var fb=$I$(2).newPd$javajs_util_T3d(pt);
sg.toFractional$javajs_util_T3d$Z(fa, true);
sg.toFractional$javajs_util_T3d$Z(fb, true);
for (var k=0, i=i0; i >= 0; i=bseq.nextSetBit$I(i + 1)) {
var p=$I$(2).newPd$javajs_util_T3d(this.vwr.ms.at[i]);
var p0=$I$(2).newP$javajs_util_T3d(p);
sg.toFractional$javajs_util_T3d$Z(p, true);
var m=sg.getTransform$javajs_util_P3d$javajs_util_P3d$Z(fa, p, false);
if (m == null ) {
return false;
}var p2=$I$(2).newP$javajs_util_T3d(fb);
m.rotTrans$javajs_util_T3d(p2);
sg.toCartesian$javajs_util_T3d$Z(p2, true);
if (Math.abs(d - p0.distance$javajs_util_T3d(p2)) > 0.001 ) return false;
points[k++]=p2;
}
fa.setT$javajs_util_T3d(points[0]);
sg.toFractional$javajs_util_T3d$Z(fa, true);
for (var k=points.length; --k >= 0; ) {
fb.setT$javajs_util_T3d(points[k]);
sg.toFractional$javajs_util_T3d$Z(fb, true);
var m=sg.getTransform$javajs_util_P3d$javajs_util_P3d$Z(fa, fb, false);
if (m == null ) {
return false;
}for (var i=points.length; --i > k; ) {
if (points[i].distance$javajs_util_T3d(points[k]) < 0.1 ) return false;
}
}
return true;
}, p$1);

Clazz.newMeth(C$, 'clearAtomConstraints$',  function () {
if (this.atomConstraints != null ) {
for (var i=this.atomConstraints.length; --i >= 0; ) this.atomConstraints[i]=null;

}});

Clazz.newMeth(C$, 'hasConstraint$I$Z$Z',  function (iatom, ignoreGeneral, addNew) {
var c=p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [this.vwr.getOperativeSymmetry$(), iatom, addNew ? C$.GET_CREATE : C$.GET]);
return (c != null  && (!ignoreGeneral || c.type != 7 ) );
});

Clazz.newMeth(C$, 'moveConstrained$I$javajs_util_P3d$Z$Z',  function (iatom, ptNew, doAssign, allowProjection) {
var n=0;
var sym;
if (iatom < 0 || (sym=this.vwr.getOperativeSymmetry$()) == null  ) {
return 0;
}var a=this.vwr.ms.at[iatom];
var c=this.constraint;
if (c == null ) {
c=p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [sym, iatom, C$.GET_CREATE]);
if (c.type == 6) {
iatom=-1;
} else {
var b=this.vwr.ms.getBasisAtom$I(iatom);
var fa=$I$(2).newPd$javajs_util_T3d(a);
sym.toFractional$javajs_util_T3d$Z(fa, true);
var fb=$I$(2).newPd$javajs_util_T3d(b);
sym.toFractional$javajs_util_T3d$Z(fb, true);
var m=sym.getTransform$javajs_util_P3d$javajs_util_P3d$Z(fa, fb, true);
if (m == null ) {
System.err.println$S("ModelKit - null matrix for " + iatom + " " + a + " to " + b );
iatom=-1;
} else {
var p=$I$(2).new3$D$D$D(ptNew.x, ptNew.y, ptNew.z);
sym.toFractional$javajs_util_T3d$Z(p, true);
m.rotTrans$javajs_util_T3d(p);
sym.toCartesian$javajs_util_T3d$Z(p, true);
ptNew.set$D$D$D(p.x, p.y, p.z);
c.constrain$javajs_util_P3d$javajs_util_P3d$Z(b, ptNew, allowProjection);
iatom=b.i;
}}} else {
c.constrain$javajs_util_P3d$javajs_util_P3d$Z(this.vwr.ms.at[iatom], ptNew, allowProjection);
}if (iatom >= 0 && !Double.isNaN$D(ptNew.x) ) {
if (!doAssign) return 1;
n=this.assignMoveAtom$I$javajs_util_P3d$javajs_util_BS(iatom, ptNew, null);
}ptNew.x=NaN;
return n;
});

Clazz.newMeth(C$, 'getConstraint$org_jmol_api_SymmetryInterface$I$I',  function (sym, ia, mode) {
if (ia < 0) return null;
var a=this.vwr.ms.getBasisAtom$I(ia);
var iatom=a.i;
var ac=(this.atomConstraints != null  && iatom < this.atomConstraints.length  ? this.atomConstraints[iatom] : null);
if (ac != null  || mode != C$.GET_CREATE ) {
if (ac != null  && mode == C$.GET_DELETE ) {
this.atomConstraints[iatom]=null;
}return ac;
}if (sym == null ) return p$1.addConstraint$I$org_jmol_modelkit_ModelKit_Constraint.apply(this, [iatom, Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[a, 0, null])]);
var ops=sym.getInvariantSymops$javajs_util_P3d$IA(a, null);
if ($I$(17).debugging) System.out.println$S("MK.getConstraint atomIndex=" + iatom + " symops=" + $I$(20).toString$IA(ops) );
if (ops.length == 0) return p$1.addConstraint$I$org_jmol_modelkit_ModelKit_Constraint.apply(this, [iatom, Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[a, 7, null])]);
var plane1=null;
var line1=null;
for (var i=ops.length; --i >= 0; ) {
var line2=null;
var c=sym.getSymmetryInfoAtom$org_jmol_modelset_ModelSet$I$S$I$javajs_util_P3d$javajs_util_P3d$javajs_util_P3d$S$I$D$I$I(this.vwr.ms, iatom, null, ops[i], null, a, null, "invariant", 1275068418, 0, -1, 0);
if (Clazz.instanceOf(c, "java.lang.String")) {
return C$.locked;
} else if (Clazz.instanceOf(c, "javajs.util.P4d")) {
var plane=c;
if (plane1 == null ) {
plane1=plane;
continue;
}var line=$I$(3).getIntersectionPP$javajs_util_P4d$javajs_util_P4d(plane1, plane);
if (line == null  || line.size$() == 0 ) {
return C$.locked;
}line2=Clazz.array(java.lang.Object, -1, [line.get$I(0), line.get$I(1)]);
} else if (Clazz.instanceOf(c, "javajs.util.P3d")) {
return C$.locked;
} else {
line2=c;
}if (line2 != null ) {
if (line1 == null ) {
line1=line2;
} else {
var v1=line1[1];
if (Math.abs(v1.dot$javajs_util_T3d(line2[1])) < 0.999 ) return C$.locked;
}if (plane1 != null ) {
if (Math.abs(plane1.dot$javajs_util_T3d(line2[1])) > 0.001 ) return C$.locked;
}}}
if (line1 != null ) {
line1[0]=$I$(2).newP$javajs_util_T3d(a);
}return p$1.addConstraint$I$org_jmol_modelkit_ModelKit_Constraint.apply(this, [iatom, line1 != null  ? Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[a, 4, line1]) : plane1 != null  ? Clazz.new_([a, 5, Clazz.array(java.lang.Object, -1, [plane1])],$I$(4,1).c$$javajs_util_P3d$I$OA) : Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[a, 7, null])]);
}, p$1);

Clazz.newMeth(C$, 'addConstraint$I$org_jmol_modelkit_ModelKit_Constraint',  function (iatom, c) {
if (c == null ) {
if (this.atomConstraints != null  && this.atomConstraints.length > iatom ) {
this.atomConstraints[iatom]=null;
}return null;
}if (this.atomConstraints == null ) {
this.atomConstraints=Clazz.array($I$(4), [this.vwr.ms.ac + 10]);
}if (this.atomConstraints.length < iatom + 10) {
var a=Clazz.array($I$(4), [this.vwr.ms.ac + 10]);
System.arraycopy$O$I$O$I$I(this.atomConstraints, 0, a, 0, this.atomConstraints.length);
this.atomConstraints=a;
}return this.atomConstraints[iatom]=c;
}, p$1);

Clazz.newMeth(C$, 'addLockedAtoms$javajs_util_BS',  function (bs) {
var sg=this.vwr.getOperativeSymmetry$();
if (sg == null ) return;
var bsm=this.vwr.getThisModelAtoms$();
for (var i=bsm.nextSetBit$I(0); i >= 0; i=bsm.nextSetBit$I(i + 1)) {
if (p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [sg, i, C$.GET_CREATE]).type == 6) {
bs.set$I(i);
}}
});

Clazz.newMeth(C$, 'cmdRotateAtoms$javajs_util_BS$javajs_util_P3dA$D',  function (bsAtoms, points, endDegrees) {
var center=points[0];
var p=Clazz.new_($I$(2,1));
var sg=this.vwr.getOperativeSymmetry$();
var bsAU=Clazz.new_($I$(6,1));
var bsAtoms2=Clazz.new_($I$(6,1));
for (var i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var bai=this.vwr.ms.getBasisAtom$I(i).i;
if (bsAU.get$I(bai)) {
continue;
}if (p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [sg, bai, C$.GET_CREATE]).type == 6) {
return 0;
}bsAU.set$I(bai);
bsAtoms2.set$I(i);
}
var nAtoms=bsAtoms.cardinality$();
var apos0=Clazz.array($I$(2), [this.vwr.ms.at.length]);
for (var i=apos0.length; --i >= 0; ) {
var a=this.vwr.ms.at[i];
if (!$I$(21).isDeleted$org_jmol_modelset_Atom(a)) apos0[i]=$I$(2).newP$javajs_util_T3d(a);
}
var m=$I$(22,"newVA$javajs_util_T3d$D",[$I$(1).newVsub$javajs_util_T3d$javajs_util_T3d(points[1], points[0]), endDegrees]).getMatrix$();
var vt=Clazz.new_($I$(1,1));
var apos=Clazz.array($I$(2), [nAtoms]);
for (var ip=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var a=this.vwr.ms.at[i];
p=apos[ip++]=$I$(2).newP$javajs_util_T3d(a);
vt.sub2$javajs_util_T3d$javajs_util_T3d(p, center);
m.rotate$javajs_util_T3d(vt);
p.add2$javajs_util_T3d$javajs_util_T3d(center, vt);
p$1.getConstraint$org_jmol_api_SymmetryInterface$I$I.apply(this, [sg, i, C$.GET_CREATE]).constrain$javajs_util_P3d$javajs_util_P3d$Z(a, p, false);
if (Double.isNaN$D(p.x)) return 0;
}
nAtoms=0;
for (var ip=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms2.nextSetBit$I(i + 1), ip++) {
if (bsAtoms2.get$I(i)) {
nAtoms+=this.assignMoveAtom$I$javajs_util_P3d$javajs_util_BS(i, apos[ip], null);
}}
var ok=true;
for (var ip=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1), ip++) {
if (!bsAtoms2.get$I(i)) {
if (this.vwr.ms.at[i].distance$javajs_util_T3d(apos[ip]) > 1.0E-4 ) {
ok=false;
break;
}}}
if (!ok) {
for (var i=apos0.length; --i >= 0; ) {
var a=this.vwr.ms.at[i];
if (!$I$(21).isDeleted$org_jmol_modelset_Atom(a)) a.setT$javajs_util_T3d(apos0[i]);
}
return 0;
}return nAtoms;
});

Clazz.newMeth(C$, 'getText$S',  function (key) {
switch (("invSter delAtom dragBon dragAto dragMin dragMol dragMMo incChar decChar rotBond bondTo0 bondTo1 bondTo2 bondTo3 incBond decBond").indexOf$S(key.substring$I$I(0, 7))) {
case 0:
return $I$(5).$$S("invert ring stereochemistry");
case 8:
return $I$(5).$$S("delete atom");
case 16:
return $I$(5).$$S("drag to bond");
case 24:
return $I$(5).$$S("drag atom");
case 32:
return $I$(5,"$$S",["drag atom (and minimize)"]);
case 40:
return $I$(5,"$$S",["drag molecule (ALT to rotate)"]);
case 48:
return $I$(5,"$$S",["drag and minimize molecule (docking)"]);
case 56:
return $I$(5).$$S("increase charge");
case 64:
return $I$(5).$$S("decrease charge");
case 72:
return $I$(5).$$S("rotate bond");
case 80:
return $I$(5).$$S("delete bond");
case 88:
return $I$(5).$$S("single");
case 96:
return $I$(5).$$S("double");
case 104:
return $I$(5).$$S("triple");
case 112:
return $I$(5).$$S("increase order");
case 120:
return $I$(5).$$S("decrease order");
}
return key;
}, 1);

Clazz.newMeth(C$, 'wasRotating$',  function () {
var b=this.wasRotating;
this.wasRotating=false;
return b;
});

C$.$static$=function(){C$.$static$=0;
C$.locked=Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[null, 6, null]);
C$.none=Clazz.new_($I$(4,1).c$$javajs_util_P3d$I$OA,[null, 0, null]);
C$.Pt000=Clazz.new_($I$(2,1));
C$.GET=0;
C$.GET_CREATE=1;
C$.GET_DELETE=2;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.ModelKit, "Constraint", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['value'],'I',['type'],'O',['pt','javajs.util.P3d','+offset','plane','javajs.util.P4d','unitVector','javajs.util.V3d','points','javajs.util.P3d[]']]]

Clazz.newMeth(C$, 'c$$javajs_util_P3d$I$OA',  function (pt, type, params) {
;C$.$init$.apply(this);
this.pt=pt;
this.type=type;
switch (type) {
case 0:
case 7:
case 6:
break;
case 4:
this.offset=params[0];
this.unitVector=$I$(1).newV$javajs_util_T3d(params[1]);
this.unitVector.normalize$();
break;
case 5:
this.plane=params[0];
break;
case 1:
this.value=(params[0]).doubleValue$();
this.points=Clazz.array($I$(2), -1, [params[1], null]);
break;
case 2:
this.value=(params[0]).doubleValue$();
this.points=Clazz.array($I$(2), -1, [params[1], params[2], null]);
break;
case 3:
this.value=(params[0]).doubleValue$();
this.points=Clazz.array($I$(2), -1, [params[1], params[2], params[3], null]);
break;
default:
throw Clazz.new_(Clazz.load('IllegalArgumentException'));
}
}, 1);

Clazz.newMeth(C$, 'constrain$javajs_util_P3d$javajs_util_P3d$Z',  function (ptOld, ptNew, allowProjection) {
var v=Clazz.new_($I$(1,1));
var p=$I$(2).newP$javajs_util_T3d(ptOld);
var d=0;
switch (this.type) {
case 0:
return;
case 7:
return;
case 6:
ptNew.x=NaN;
return;
case 4:
if (this.pt == null ) {
d=$I$(3).projectOntoAxis$javajs_util_P3d$javajs_util_P3d$javajs_util_V3d$javajs_util_V3d(p, this.offset, this.unitVector, v);
if (d * d >= 1.96E-6 ) {
ptNew.x=NaN;
break;
}}d=$I$(3).projectOntoAxis$javajs_util_P3d$javajs_util_P3d$javajs_util_V3d$javajs_util_V3d(ptNew, this.offset, this.unitVector, v);
break;
case 5:
if (this.pt == null ) {
if (Math.abs($I$(3).getPlaneProjection$javajs_util_T3d$javajs_util_P4d$javajs_util_T3d$javajs_util_V3d(p, this.plane, v, v)) > 0.01 ) {
ptNew.x=NaN;
break;
}}d=$I$(3).getPlaneProjection$javajs_util_T3d$javajs_util_P4d$javajs_util_T3d$javajs_util_V3d(ptNew, this.plane, v, v);
ptNew.setT$javajs_util_T3d(v);
break;
}
if (!allowProjection && Math.abs(d) > 1.0E-10  ) {
ptNew.x=NaN;
}});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-17 09:35:24 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
