(function(){var P$=Clazz.newPackage("org.jmol.awt"),I$=[[0,'org.jmol.awt.AwtPopupHelper','javax.swing.ImageIcon']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtModelKitPopup", null, 'org.jmol.modelkit.ModelKitPopup');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.helper=Clazz.new_($I$(1,1).c$$org_jmol_popup_GenericPopup,[this]);
}, 1);

Clazz.newMeth(C$, 'addMenu$S$S$org_jmol_api_SC$S$org_jmol_popup_PopupResource',  function (id, item, subMenu, label, popupResourceBundle) {
var c=subMenu;
c.deferred=(item.indexOf$S("more") < 0);
if (!c.deferred && item.indexOf$S("Computed") < 0 ) this.addMenuItems$S$S$org_jmol_api_SC$org_jmol_popup_PopupResource(id, item, subMenu, popupResourceBundle);
c.jm.addMenuListener$javax_swing_event_MenuListener(((P$.AwtModelKitPopup$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtModelKitPopup$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.MenuListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'menuSelected$javax_swing_event_MenuEvent',  function (e) {
if (this.$finals$.c.deferred) {
this.$finals$.c.deferred=false;
if (this.$finals$.item.indexOf$S("Computed") < 0) {
this.b$['org.jmol.awt.AwtModelKitPopup'].helper.menuAddButtonGroup$org_jmol_api_SC(null);
this.b$['org.jmol.popup.GenericPopup'].addMenuItems$S$S$org_jmol_api_SC$org_jmol_popup_PopupResource.apply(this.b$['org.jmol.popup.GenericPopup'], [this.$finals$.id, this.$finals$.item, this.$finals$.subMenu, this.$finals$.popupResourceBundle]);
}this.b$['org.jmol.awt.AwtModelKitPopup'].updateAwtMenus$S.apply(this.b$['org.jmol.awt.AwtModelKitPopup'], [this.$finals$.item]);
}});

Clazz.newMeth(C$, 'menuDeselected$javax_swing_event_MenuEvent',  function (e) {
});

Clazz.newMeth(C$, 'menuCanceled$javax_swing_event_MenuEvent',  function (e) {
});
})()
), Clazz.new_(P$.AwtModelKitPopup$1.$init$,[this, {subMenu:subMenu,id:id,c:c,item:item,popupResourceBundle:popupResourceBundle}])));
});

Clazz.newMeth(C$, 'updateAwtMenus$S',  function (item) {
if (item.equals$O("xtalOp!PersistMenu")) {
this.clearLastModelSet$();
this.jpiUpdateComputedMenus$();
} else {
this.updateOperatorMenu$();
this.updateCheckBoxesForModelKit$S(item);
}});

Clazz.newMeth(C$, 'menuShowPopup$org_jmol_api_SC$I$I',  function (popup, x, y) {
try {
((popup).jc).show$java_awt_Component$I$I(this.vwr.display, x, y);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'menuHidePopup$org_jmol_api_SC',  function (popup) {
try {
((popup).jc).setVisible$Z(false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'exitBondRotation$',  function () {
try {
if (this.bondRotationCheckBox != null ) this.bondRotationCheckBox.setSelected$Z(false);
if (this.prevBondCheckBox != null ) this.prevBondCheckBox.setSelected$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
C$.superclazz.prototype.exitBondRotation$.apply(this, []);
});

Clazz.newMeth(C$, 'getImageIcon$S',  function (fileName) {
var imageName="org/jmol/modelkit/images/" + fileName;
var imageUrl=this.getClass$().getClassLoader$().getResource$S(imageName);
return (imageUrl == null  ? null : Clazz.new_($I$(2,1).c$$java_net_URL,[imageUrl]));
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-13 20:34:57 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
