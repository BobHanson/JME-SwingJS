(function(){var P$=Clazz.newPackage("org.jmol.export"),p$1={},I$=[[0,'java.util.Hashtable','org.jmol.export.UseTable','org.jmol.export.___Exporter']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSExporter", null, 'org.jmol.export.__CartesianExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.htSpheresRendered=Clazz.new_($I$(1,1));
this.htObjects=Clazz.new_($I$(1,1));
this.ret=Clazz.array(String, [1]);
},1);

C$.$fields$=[['O',['htSpheresRendered','java.util.Map','+htObjects','html5Applet','java.lang.Object','useTable','org.jmol.export.UseTable','ret','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'jsInitExport$O',  function (applet) {
}, p$1);

Clazz.newMeth(C$, 'jsEndExport$O',  function (applet) {
}, p$1);

Clazz.newMeth(C$, 'jsCylinder$O$S$Z$javajs_util_P3d$javajs_util_P3d$OA',  function (applet, id, isNew, pt1, pt2, o) {
}, p$1);

Clazz.newMeth(C$, 'jsSphere$O$S$Z$javajs_util_T3d$OA',  function (applet, id, isNew, pt, o) {
}, p$1);

Clazz.newMeth(C$, 'jsSurface$O$javajs_util_T3dA$javajs_util_T3dA$IAA$I$I$I$javajs_util_BS$I$I$IA$IA',  function (applet, vertices, normals, indices, nVertices, nPolygons, nFaces, bsPolygons, faceVertexMax, color, vertexColors, polygonColors) {
});

Clazz.newMeth(C$, 'jsTriangle$O$I$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d',  function (applet, color, pt1, pt2, pt3) {
});

Clazz.newMeth(C$, 'outputHeader$',  function () {
this.html5Applet=this.vwr.html5Applet;
this.useTable=Clazz.new_($I$(2,1).c$$S,["JS"]);
this.htSpheresRendered.clear$();
this.htObjects.clear$();
p$1.jsInitExport$O.apply(this, [this.html5Applet]);
});

Clazz.newMeth(C$, 'outputFooter$',  function () {
p$1.jsEndExport$O.apply(this, [this.html5Applet]);
this.htSpheresRendered.clear$();
this.htObjects.clear$();
this.useTable=null;
});

Clazz.newMeth(C$, 'outputSphere$javajs_util_P3d$D$H$Z',  function (ptCenter, radius, colix, checkRadius) {
var iRad=Long.$ival(Math.round$D(radius * 100));
var check=$I$(3).round$javajs_util_T3d(ptCenter) + (checkRadius ? " " + iRad : "");
if (this.htSpheresRendered.get$O(check) != null ) return;
this.htSpheresRendered.put$O$O(check, Boolean.TRUE);
var found=this.useTable.getDefRet$S$SA("S" + colix + "_" + iRad , this.ret);
var o;
if (found) o=this.htObjects.get$O(this.ret[0]);
 else this.htObjects.put$O$O(this.ret[0], o=Clazz.array(java.lang.Object, -1, [p$1.getColor$H.apply(this, [colix]), Double.valueOf$D(radius)]));
p$1.jsSphere$O$S$Z$javajs_util_T3d$OA.apply(this, [this.html5Applet, this.ret[0], !found, ptCenter, o]);
});

Clazz.newMeth(C$, 'outputCylinder$javajs_util_P3d$javajs_util_P3d$javajs_util_P3d$H$B$D$javajs_util_P3d$javajs_util_P3d$Z',  function (ptCenter, pt1, pt2, colix, endcaps, radius, ptX, ptY, checkRadius) {
if (ptX != null ) return false;
var length=pt1.distance$javajs_util_T3d(pt2);
var found=this.useTable.getDefRet$S$SA("C" + colix + "_" + Long.$s(Math.round$D(length * 100)) + "_" + new Double(radius).toString() + "_" + endcaps , this.ret);
var o;
if (found) o=this.htObjects.get$O(this.ret[0]);
 else this.htObjects.put$O$O(this.ret[0], o=Clazz.array(java.lang.Object, -1, [p$1.getColor$H.apply(this, [colix]), Double.valueOf$D(length), Double.valueOf$D(radius)]));
p$1.jsCylinder$O$S$Z$javajs_util_P3d$javajs_util_P3d$OA.apply(this, [this.html5Applet, this.ret[0], !found, pt1, pt2, o]);
return true;
});

Clazz.newMeth(C$, 'outputCircle$javajs_util_P3d$javajs_util_P3d$D$H$Z',  function (pt1, pt2, radius, colix, doFill) {
});

Clazz.newMeth(C$, 'outputEllipsoid$javajs_util_P3d$javajs_util_P3dA$H',  function (center, points, colix) {
});

Clazz.newMeth(C$, 'outputCone$javajs_util_P3d$javajs_util_P3d$D$H',  function (ptBase, ptTip, radius, colix) {
this.outputCylinder$javajs_util_P3d$javajs_util_P3d$javajs_util_P3d$H$B$D$javajs_util_P3d$javajs_util_P3d$Z(null, ptBase, ptTip, colix, 0, radius, null, null, false);
});

Clazz.newMeth(C$, 'getColor$H',  function (colix) {
return Integer.valueOf$I(this.gdata.getColorArgbOrGray$H(colix));
}, p$1);

Clazz.newMeth(C$, 'outputSurface$javajs_util_T3dA$javajs_util_T3dA$HA$IAA$HA$I$I$I$javajs_util_BS$I$H$javajs_util_Lst$java_util_Map$javajs_util_P3d',  function (vertices, normals, vertexColixes, indices, polygonColixes, nVertices, nPolygons, nTriangles, bsPolygons, faceVertexMax, colix, colorList, htColixes, offset) {
var vertexColors=p$1.getColors$HA.apply(this, [vertexColixes]);
var polygonColors=p$1.getColors$HA.apply(this, [polygonColixes]);
this.jsSurface$O$javajs_util_T3dA$javajs_util_T3dA$IAA$I$I$I$javajs_util_BS$I$I$IA$IA(this.html5Applet, vertices, normals, indices, nVertices, nPolygons, nTriangles, bsPolygons, faceVertexMax, this.gdata.getColorArgbOrGray$H(colix), vertexColors, polygonColors);
});

Clazz.newMeth(C$, 'outputTriangle$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d$H',  function (pt1, pt2, pt3, colix) {
this.jsTriangle$O$I$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d(this.html5Applet, this.gdata.getColorArgbOrGray$H(colix), pt1, pt2, pt3);
});

Clazz.newMeth(C$, 'outputTextPixel$javajs_util_P3d$I',  function (pt, argb) {
});

Clazz.newMeth(C$, 'outputFace$IA$IA$I',  function (is, coordMap, faceVertexMax) {
});

Clazz.newMeth(C$, 'output$javajs_util_T3d',  function (pt) {
});

Clazz.newMeth(C$, 'plotImage$I$I$I$O$H$I$I',  function (x, y, z, image, bgcolix, width, height) {
});

Clazz.newMeth(C$, 'plotText$I$I$I$H$S$org_jmol_util_Font',  function (x, y, z, colix, text, font3d) {
});

Clazz.newMeth(C$, 'getColors$HA',  function (colixes) {
if (colixes == null ) return null;
var colors=Clazz.array(Integer.TYPE, [colixes.length]);
for (var i=colors.length; --i >= 0; ) {
colors[i]=this.gdata.getColorArgbOrGray$H(colixes[i]);
}
return colors;
}, p$1);

C$.$static$=function(){C$.$static$=0;
{
{
Jmol && Jmol.GLmol && Jmol.GLmol.extendJSExporter(org.jmol.export.JSExporter.prototype);
}
};
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-13 20:34:57 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
