(function(){var P$=Clazz.newPackage("org.jmol.adapter.smarter"),p$1={},I$=[[0,'java.util.HashSet','javajs.util.P3d','javajs.util.Lst','javajs.util.P3i','org.jmol.symmetry.Symmetry','javajs.util.M4d','org.jmol.util.SimpleUnitCell','org.jmol.util.BSUtil','javajs.util.BS','javajs.util.V3d','org.jmol.symmetry.SymmetryOperation','java.util.Hashtable','javajs.util.SB','javajs.util.PT','org.jmol.adapter.smarter.Atom','javajs.util.M3d']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XtalSymmetry");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.doNormalize=true;
this.unitCellParams=Clazz.array(Double.TYPE, [6]);
this.bondsFound=Clazz.new_($I$(1,1));
this.ndims=3;
this.ptOffset=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['Z',['applySymmetryToBonds','centroidPacked','doCentroidUnitCell','doNormalize','doPackUnitCell','latticeOnly','checkAll'],'D',['symmetryRange','packingError','rminx','rminy','rminz','rmaxx','rmaxy','rmaxz'],'I',['ndims','firstAtom','latticeOp','noSymmetryCount','nVib','bondCount0','disorderMapMax'],'S',['filterSymop'],'O',['acr','org.jmol.adapter.smarter.AtomSetCollectionReader','asc','org.jmol.adapter.smarter.AtomSetCollection','baseSymmetry','org.jmol.api.SymmetryInterface','+sym2','trajectoryUnitCells','javajs.util.Lst','unitCellParams','double[]','+baseUnitCell','latticeCells','int[]','unitCellTranslations','javajs.util.V3d[]','bondsFound','java.util.Set','ptTemp','javajs.util.P3d','mTemp','javajs.util.M3d','ptOffset','javajs.util.P3d','minXYZ','javajs.util.P3i','+maxXYZ','minXYZ0','javajs.util.P3d','+maxXYZ0','symmetry','org.jmol.api.SymmetryInterface','disorderMap','java.util.Map','mident','javajs.util.M4d']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_adapter_smarter_AtomSetCollectionReader',  function (reader) {
this.acr=reader;
this.asc=reader.asc;
this.getSymmetry$();
return this;
});

Clazz.newMeth(C$, 'getSymmetry$',  function () {
return (this.symmetry == null  ? (this.symmetry=this.acr.getInterface$S("org.jmol.symmetry.Symmetry")) : this.symmetry);
});

Clazz.newMeth(C$, 'setSymmetry$org_jmol_api_SymmetryInterface',  function (symmetry) {
return (this.symmetry=symmetry);
});

Clazz.newMeth(C$, 'setSymmetryRange$D',  function (factor) {
this.symmetryRange=factor;
this.asc.setInfo$S$O("symmetryRange", Double.valueOf$D(factor));
}, p$1);

Clazz.newMeth(C$, 'setLatticeCells',  function () {
this.latticeCells=this.acr.latticeCells;
var isLatticeRange=(this.latticeCells[0] <= 555 && this.latticeCells[1] >= 555  && (this.latticeCells[2] == 0 || this.latticeCells[2] == 1  || this.latticeCells[2] == -1 ) );
this.doNormalize=this.latticeCells[0] != 0 && (!isLatticeRange || this.latticeCells[2] == 1 ) ;
this.applySymmetryToBonds=this.acr.applySymmetryToBonds;
this.doPackUnitCell=this.acr.doPackUnitCell && !this.applySymmetryToBonds ;
this.doCentroidUnitCell=this.acr.doCentroidUnitCell;
this.centroidPacked=this.acr.centroidPacked;
this.filterSymop=this.acr.filterSymop;
}, p$1);

Clazz.newMeth(C$, 'setUnitCell$DA$javajs_util_M3d$javajs_util_P3d',  function (info, matUnitCellOrientation, unitCellOffset) {
this.unitCellParams=Clazz.array(Double.TYPE, [info.length]);
for (var i=0; i < info.length; i++) this.unitCellParams[i]=info[i];

this.asc.haveUnitCell=true;
this.asc.setCurrentModelInfo$S$O("unitCellParams", this.unitCellParams);
if (this.asc.isTrajectory) {
if (this.trajectoryUnitCells == null ) {
this.trajectoryUnitCells=Clazz.new_($I$(3,1));
this.asc.setInfo$S$O("unitCells", this.trajectoryUnitCells);
}this.trajectoryUnitCells.addLast$O(this.unitCellParams);
}this.asc.setGlobalBoolean$I(2);
this.getSymmetry$().setUnitCell$DA$Z(this.unitCellParams, false);
if (unitCellOffset != null ) {
this.symmetry.setOffsetPt$javajs_util_T3d(unitCellOffset);
this.asc.setCurrentModelInfo$S$O("unitCellOffset", unitCellOffset);
}if (matUnitCellOrientation != null ) {
this.symmetry.initializeOrientation$javajs_util_M3d(matUnitCellOrientation);
this.asc.setCurrentModelInfo$S$O("matUnitCellOrientation", matUnitCellOrientation);
}}, p$1);

Clazz.newMeth(C$, 'addSpaceGroupOperation$S$Z',  function (xyz, andSetLattice) {
if (andSetLattice) p$1.setLatticeCells.apply(this, []);
this.symmetry.setSpaceGroup$Z(this.doNormalize);
return this.symmetry.addSpaceGroupOperation$S$I(xyz, 0);
});

Clazz.newMeth(C$, 'setLatticeParameter$I',  function (latt) {
this.symmetry.setSpaceGroup$Z(this.doNormalize);
this.symmetry.setLattice$I(latt);
});

Clazz.newMeth(C$, 'applySymmetryFromReader$org_jmol_api_SymmetryInterface',  function (readerSymmetry) {
this.asc.setCoordinatesAreFractional$Z(this.acr.iHaveFractionalCoordinates);
p$1.setUnitCell$DA$javajs_util_M3d$javajs_util_P3d.apply(this, [this.acr.unitCellParams, this.acr.matUnitCellOrientation, this.acr.unitCellOffset]);
p$1.setAtomSetSpaceGroupName$S.apply(this, [this.acr.sgName]);
p$1.setSymmetryRange$D.apply(this, [this.acr.symmetryRange]);
if (this.acr.doConvertToFractional || this.acr.fileCoordinatesAreFractional ) {
p$1.setLatticeCells.apply(this, []);
var doApplySymmetry=true;
if (this.acr.ignoreFileSpaceGroupName || !this.acr.iHaveSymmetryOperators ) {
if (!this.acr.merging || readerSymmetry == null  ) readerSymmetry=this.acr.getNewSymmetry$();
doApplySymmetry=readerSymmetry.createSpaceGroup$I$S$O$I(this.acr.desiredSpaceGroupIndex, (this.acr.sgName.indexOf$S("!") >= 0 ? "P1" : this.acr.sgName), this.acr.unitCellParams, this.acr.modDim);
} else {
this.acr.doPreSymmetry$();
readerSymmetry=null;
}this.packingError=this.acr.packingError;
if (doApplySymmetry) {
if (readerSymmetry != null ) this.setSpaceGroupFrom$org_jmol_api_SymmetryInterface(readerSymmetry);
p$1.applySymmetryLattice.apply(this, []);
if (readerSymmetry != null  && this.filterSymop == null  ) p$1.setAtomSetSpaceGroupName$S.apply(this, [readerSymmetry.getSpaceGroupName$()]);
}}if (this.acr.iHaveFractionalCoordinates && this.acr.merging && readerSymmetry != null   ) {
var atoms=this.asc.atoms;
for (var i=this.asc.getLastAtomSetAtomIndex$(), n=this.asc.ac; i < n; i++) readerSymmetry.toCartesian$javajs_util_T3d$Z(atoms[i], true);

this.asc.setCoordinatesAreFractional$Z(false);
this.acr.addVibrations=false;
}return this.symmetry;
});

Clazz.newMeth(C$, 'setSpaceGroupFrom$org_jmol_api_SymmetryInterface',  function (readerSymmetry) {
this.getSymmetry$().setSpaceGroupTo$O(readerSymmetry.getSpaceGroup$());
});

Clazz.newMeth(C$, 'setAtomSetSpaceGroupName$S',  function (spaceGroupName) {
this.symmetry.setSpaceGroupName$S(spaceGroupName);
this.asc.setCurrentModelInfo$S$O("spaceGroup", spaceGroupName + "");
}, p$1);

Clazz.newMeth(C$, 'applySymmetryLattice',  function () {
if (!this.asc.coordinatesAreFractional || this.symmetry.getSpaceGroup$() == null  ) return;
this.sym2=null;
var maxX=this.latticeCells[0];
var maxY=this.latticeCells[1];
var maxZ=Math.abs(this.latticeCells[2]);
var kcode=this.latticeCells[3];
var dim=(this.symmetry.getUnitCellInfoType$I(6)|0);
this.firstAtom=this.asc.getLastAtomSetAtomIndex$();
var bsAtoms=this.asc.bsAtoms;
if (bsAtoms != null ) {
p$1.updateBSAtoms.apply(this, []);
this.firstAtom=bsAtoms.nextSetBit$I(this.firstAtom);
}this.rminx=this.rminy=this.rminz=1.7976931348623157E308;
this.rmaxx=this.rmaxy=this.rmaxz=-1.7976931348623157E308;
var pt0=null;
if (this.acr.latticeType == null ) this.acr.latticeType="" + this.symmetry.getLatticeType$();
if (this.acr.isPrimitive) {
this.asc.setCurrentModelInfo$S$O("isprimitive", Boolean.TRUE);
if (!"P".equals$O(this.acr.latticeType) || this.acr.primitiveToCrystal != null  ) {
this.asc.setCurrentModelInfo$S$O("unitcell_conventional", this.symmetry.getConventionalUnitCell$S$javajs_util_M3d(this.acr.latticeType, this.acr.primitiveToCrystal));
}}if (this.acr.latticeType != null ) {
this.asc.setCurrentModelInfo$S$O("latticeType", this.acr.latticeType);
if (Clazz.instanceOf(this.acr.fillRange, "java.lang.String")) {
var type=this.acr.fillRange;
if (type.equals$O("conventional")) {
this.acr.fillRange=this.symmetry.getConventionalUnitCell$S$javajs_util_M3d(this.acr.latticeType, this.acr.primitiveToCrystal);
} else if (type.equals$O("primitive")) {
this.acr.fillRange=this.symmetry.getUnitCellVectors$();
this.symmetry.toFromPrimitive$Z$C$javajs_util_T3dA$javajs_util_M3d(true, this.acr.latticeType.charAt$I(0), this.acr.fillRange, this.acr.primitiveToCrystal);
} else {
this.acr.fillRange=null;
}if (this.acr.fillRange != null ) this.acr.addJmolScript$S("unitcell " + type);
}}if (this.acr.fillRange != null ) {
bsAtoms=p$1.updateBSAtoms.apply(this, []);
this.acr.forcePacked=true;
this.doPackUnitCell=false;
this.minXYZ=Clazz.new_($I$(4,1));
this.maxXYZ=$I$(4).new3$I$I$I(1, 1, 1);
var oabc=Clazz.array($I$(2), [4]);
for (var i=0; i < 4; i++) oabc[i]=$I$(2,"newP$javajs_util_T3d",[(this.acr.fillRange)[i]]);

p$1.adjustRangeMinMax$javajs_util_T3dA.apply(this, [oabc]);
if (this.sym2 == null ) {
this.sym2=Clazz.new_($I$(5,1));
this.sym2.getUnitCelld$javajs_util_T3dA$Z$S(this.acr.fillRange, false, null);
}p$1.applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS.apply(this, [this.acr.ms, bsAtoms]);
pt0=Clazz.new_($I$(2,1));
var atoms=this.asc.atoms;
for (var i=this.asc.ac; --i >= this.firstAtom; ) {
pt0.setT$javajs_util_T3d(atoms[i]);
this.symmetry.toCartesian$javajs_util_T3d$Z(pt0, false);
this.sym2.toFractional$javajs_util_T3d$Z(pt0, false);
if (this.acr.noPack ? !this.removePacking$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, pt0, 0, 1, 0, 1, 0, 1, this.packingError) : !this.isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, pt0, 0, 1, 0, 1, 0, 1, this.packingError)) bsAtoms.clear$I(i);
}
return;
}var offset=null;
this.nVib=0;
var va=null;
var vb=null;
var vc=null;
this.baseSymmetry=this.symmetry;
var supercell=this.acr.strSupercell;
var oabc=null;
var isSuper=(supercell != null  && supercell.indexOf$S(",") >= 0 );
if (isSuper) {
var m=Clazz.new_($I$(6,1));
if (this.mident == null ) this.mident=Clazz.new_($I$(6,1));
oabc=this.symmetry.getV0abc$O$javajs_util_M4d(supercell, m);
if (oabc != null  && !m.equals$O(this.mident) ) {
p$1.setMinMax$I$I$I$I$I.apply(this, [dim, kcode, maxX, maxY, maxZ]);
pt0=$I$(2).newP$javajs_util_T3d(oabc[0]);
va=$I$(2).newP$javajs_util_T3d(oabc[1]);
vb=$I$(2).newP$javajs_util_T3d(oabc[2]);
vc=$I$(2).newP$javajs_util_T3d(oabc[3]);
p$1.adjustRangeMinMax$javajs_util_T3dA.apply(this, [oabc]);
}}var iAtomFirst=this.asc.getLastAtomSetAtomIndex$();
if (bsAtoms != null ) iAtomFirst=bsAtoms.nextSetBit$I(iAtomFirst);
if (this.rminx == 1.7976931348623157E308 ) {
supercell=null;
oabc=null;
} else {
this.asc.setGlobalBoolean$I(7);
var doPack0=this.doPackUnitCell;
this.doPackUnitCell=doPack0;
bsAtoms=p$1.updateBSAtoms.apply(this, []);
p$1.applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS.apply(this, [this.acr.ms, null]);
this.doPackUnitCell=doPack0;
var atoms=this.asc.atoms;
var atomCount=this.asc.ac;
for (var i=iAtomFirst; i < atomCount; i++) {
this.symmetry.toCartesian$javajs_util_T3d$Z(atoms[i], true);
bsAtoms.set$I(i);
}
this.symmetry=null;
this.symmetry=this.getSymmetry$();
p$1.setUnitCell$DA$javajs_util_M3d$javajs_util_P3d.apply(this, [Clazz.array(Double.TYPE, -1, [0, 0, 0, 0, 0, 0, va.x, va.y, va.z, vb.x, vb.y, vb.z, vc.x, vc.y, vc.z]), null, offset]);
p$1.setAtomSetSpaceGroupName$S.apply(this, [oabc == null  || supercell == null   ? "P1" : "cell=" + supercell]);
this.symmetry.setSpaceGroup$Z(this.doNormalize);
this.symmetry.addSpaceGroupOperation$S$I("x,y,z", 0);
if (pt0 != null ) this.symmetry.toFractional$javajs_util_T3d$Z(pt0, true);
for (var i=iAtomFirst; i < atomCount; i++) {
this.symmetry.toFractional$javajs_util_T3d$Z(atoms[i], true);
if (pt0 != null ) atoms[i].sub$javajs_util_T3d(pt0);
}
this.asc.haveAnisou=false;
this.asc.setCurrentModelInfo$S$O("matUnitCellOrientation", null);
}p$1.setMinMax$I$I$I$I$I.apply(this, [dim, kcode, maxX, maxY, maxZ]);
if (oabc == null ) {
p$1.applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS.apply(this, [this.acr.ms, bsAtoms]);
if (!this.acr.noPack && (!this.applySymmetryToBonds || !this.acr.doPackUnitCell ) ) return;
p$1.setMinMax$I$I$I$I$I.apply(this, [dim, kcode, maxX, maxY, maxZ]);
}if (this.acr.forcePacked || this.acr.doPackUnitCell || this.acr.noPack  ) {
p$1.trimToUnitCell$I.apply(this, [iAtomFirst]);
}}, p$1);

Clazz.newMeth(C$, 'setMinMax$I$I$I$I$I',  function (dim, kcode, maxX, maxY, maxZ) {
this.minXYZ=Clazz.new_($I$(4,1));
this.maxXYZ=$I$(4).new3$I$I$I(maxX, maxY, maxZ);
$I$(7).setMinMaxLatticeParameters$I$javajs_util_P3i$javajs_util_P3i$I(dim, this.minXYZ, this.maxXYZ, kcode);
}, p$1);

Clazz.newMeth(C$, 'trimToUnitCell$I',  function (iAtomFirst) {
var atoms=this.asc.atoms;
var bs=p$1.updateBSAtoms.apply(this, []);
if (this.acr.noPack) {
for (var i=bs.nextSetBit$I(iAtomFirst); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (!this.removePacking$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, atoms[i], this.minXYZ.x, this.maxXYZ.x, this.minXYZ.y, this.maxXYZ.y, this.minXYZ.z, this.maxXYZ.z, this.packingError)) bs.clear$I(i);
}
} else {
for (var i=bs.nextSetBit$I(iAtomFirst); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (!this.isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, atoms[i], this.minXYZ.x, this.maxXYZ.x, this.minXYZ.y, this.maxXYZ.y, this.minXYZ.z, this.maxXYZ.z, this.packingError)) bs.clear$I(i);
}
}}, p$1);

Clazz.newMeth(C$, 'updateBSAtoms',  function () {
var bs=this.asc.bsAtoms;
if (bs == null ) bs=this.asc.bsAtoms=$I$(8).newBitSet2$I$I(0, this.asc.ac);
if (bs.nextSetBit$I(this.firstAtom) < 0) bs.setBits$I$I(this.firstAtom, this.asc.ac);
return bs;
}, p$1);

Clazz.newMeth(C$, 'adjustRangeMinMax$javajs_util_T3dA',  function (oabc) {
var pa=Clazz.new_($I$(2,1));
var pb=Clazz.new_($I$(2,1));
var pc=Clazz.new_($I$(2,1));
if (this.acr.forcePacked) {
pa.setT$javajs_util_T3d(oabc[1]);
pb.setT$javajs_util_T3d(oabc[2]);
pc.setT$javajs_util_T3d(oabc[3]);
pa.scale$D(this.packingError);
pb.scale$D(this.packingError);
pc.scale$D(this.packingError);
}oabc[0].scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(this.minXYZ.x, oabc[1], oabc[0]);
oabc[0].scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(this.minXYZ.y, oabc[2], oabc[0]);
oabc[0].scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(this.minXYZ.z, oabc[3], oabc[0]);
oabc[0].sub$javajs_util_T3d(pa);
oabc[0].sub$javajs_util_T3d(pb);
oabc[0].sub$javajs_util_T3d(pc);
var pt=$I$(2).newP$javajs_util_T3d(oabc[0]);
this.symmetry.toFractional$javajs_util_T3d$Z(pt, true);
p$1.setSymmetryMinMax$javajs_util_P3d.apply(this, [pt]);
oabc[1].scale$D(this.maxXYZ.x - this.minXYZ.x);
oabc[2].scale$D(this.maxXYZ.y - this.minXYZ.y);
oabc[3].scale$D(this.maxXYZ.z - this.minXYZ.z);
oabc[1].scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(2, pa, oabc[1]);
oabc[2].scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(2, pb, oabc[2]);
oabc[3].scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(2, pc, oabc[3]);
for (var i=0; i < 3; i++) {
for (var j=i + 1; j < 4; j++) {
pt.add2$javajs_util_T3d$javajs_util_T3d(oabc[i], oabc[j]);
if (i != 0) pt.add$javajs_util_T3d(oabc[0]);
this.symmetry.toFractional$javajs_util_T3d$Z(pt, false);
p$1.setSymmetryMinMax$javajs_util_P3d.apply(this, [pt]);
}
}
this.symmetry.toCartesian$javajs_util_T3d$Z(pt, false);
pt.add$javajs_util_T3d(oabc[1]);
this.symmetry.toFractional$javajs_util_T3d$Z(pt, false);
p$1.setSymmetryMinMax$javajs_util_P3d.apply(this, [pt]);
this.minXYZ=$I$(4,"new3$I$I$I",[(Math.min(0, Math.floor(this.rminx + 0.001))|0), (Math.min(0, Math.floor(this.rminy + 0.001))|0), (Math.min(0, Math.floor(this.rminz + 0.001))|0)]);
this.maxXYZ=$I$(4,"new3$I$I$I",[(Math.max(1, Math.ceil(this.rmaxx - 0.001))|0), (Math.max(1, Math.ceil(this.rmaxy - 0.001))|0), (Math.max(1, Math.ceil(this.rmaxz - 0.001))|0)]);
}, p$1);

Clazz.newMeth(C$, 'setSymmetryMinMax$javajs_util_P3d',  function (c) {
if (this.rminx > c.x ) this.rminx=c.x;
if (this.rminy > c.y ) this.rminy=c.y;
if (this.rminz > c.z ) this.rminz=c.z;
if (this.rmaxx < c.x ) this.rmaxx=c.x;
if (this.rmaxy < c.y ) this.rmaxy=c.y;
if (this.rmaxz < c.z ) this.rmaxz=c.z;
}, p$1);

Clazz.newMeth(C$, 'isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D',  function (ndims, pt, minX, maxX, minY, maxY, minZ, maxZ, slop) {
return (pt.x > minX - slop  && pt.x < maxX + slop   && (ndims < 2 || pt.y > minY - slop  && pt.y < maxY + slop   )  && (ndims < 3 || pt.z > minZ - slop  && pt.z < maxZ + slop   ) );
});

Clazz.newMeth(C$, 'removePacking$I$javajs_util_P3d$D$D$D$D$D$D$D',  function (ndims, pt, minX, maxX, minY, maxY, minZ, maxZ, slop) {
return (pt.x > minX - slop  && pt.x < maxX - slop   && (ndims < 2 || pt.y > minY - slop  && pt.y < maxY - slop   )  && (ndims < 3 || pt.z > minZ - slop  && pt.z < maxZ - slop   ) );
});

Clazz.newMeth(C$, 'applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS',  function (ms, bsAtoms) {
if (this.asc.ac == 0 || bsAtoms != null  && bsAtoms.isEmpty$()  ) return;
var n=this.noSymmetryCount=this.asc.baseSymmetryAtomCount > 0 ? this.asc.baseSymmetryAtomCount : bsAtoms == null  ? this.asc.getLastAtomSetAtomCount$() : this.asc.ac - bsAtoms.nextSetBit$I(this.asc.getLastAtomSetAtomIndex$());
this.asc.setTensors$();
this.applySymmetryToBonds=this.acr.applySymmetryToBonds;
this.doPackUnitCell=this.acr.doPackUnitCell && !this.applySymmetryToBonds ;
this.bondCount0=this.asc.bondCount;
this.ndims=(this.symmetry.getUnitCellInfoType$I(6)|0);
p$1.finalizeSymmetry$org_jmol_api_SymmetryInterface.apply(this, [this.symmetry]);
var operationCount=this.symmetry.getSpaceGroupOperationCount$();
var excludedOps=(this.acr.thisBiomolecule == null  ? null : Clazz.new_($I$(9,1)));
if (excludedOps != null ) this.asc.checkSpecial=true;
$I$(7).setMinMaxLatticeParameters$I$javajs_util_P3i$javajs_util_P3i$I(this.ndims, this.minXYZ, this.maxXYZ, 0);
this.latticeOp=this.symmetry.getLatticeOp$();
this.latticeOnly=(this.asc.checkLatticeOnly && this.latticeOp >= 0 );
if (this.doCentroidUnitCell) this.asc.setInfo$S$O("centroidMinMax", Clazz.array(Integer.TYPE, -1, [this.minXYZ.x, this.minXYZ.y, this.minXYZ.z, this.maxXYZ.x, this.maxXYZ.y, this.maxXYZ.z, (this.centroidPacked ? 1 : 0)]));
if (this.doCentroidUnitCell || this.acr.doPackUnitCell || this.symmetryRange != 0  && this.maxXYZ.x - this.minXYZ.x == 1  && this.maxXYZ.y - this.minXYZ.y == 1  && this.maxXYZ.z - this.minXYZ.z == 1   ) {
this.minXYZ0=$I$(2).new3$D$D$D(this.minXYZ.x, this.minXYZ.y, this.minXYZ.z);
this.maxXYZ0=$I$(2).new3$D$D$D(this.maxXYZ.x, this.maxXYZ.y, this.maxXYZ.z);
if (ms != null ) {
ms.setMinMax0$javajs_util_P3d$javajs_util_P3d(this.minXYZ0, this.maxXYZ0);
this.minXYZ.set$I$I$I((this.minXYZ0.x|0), (this.minXYZ0.y|0), (this.minXYZ0.z|0));
this.maxXYZ.set$I$I$I((this.maxXYZ0.x|0), (this.maxXYZ0.y|0), (this.maxXYZ0.z|0));
}switch (this.ndims) {
case 3:
--this.minXYZ.z;
++this.maxXYZ.z;
case 2:
--this.minXYZ.y;
++this.maxXYZ.y;
case 1:
--this.minXYZ.x;
++this.maxXYZ.x;
}
}var nCells=(this.maxXYZ.x - this.minXYZ.x) * (this.maxXYZ.y - this.minXYZ.y) * (this.maxXYZ.z - this.minXYZ.z) ;
var nsym=n * (this.latticeOnly ? 4 : operationCount);
var cartesianCount=(this.asc.checkSpecial || this.acr.thisBiomolecule != null   ? nsym * nCells : this.symmetryRange > 0  ? nsym : 1);
var cartesians=Clazz.array($I$(2), [cartesianCount]);
var atoms=this.asc.atoms;
for (var i=0; i < n; i++) atoms[this.firstAtom + i].bsSymmetry=$I$(9,"newN$I",[operationCount * (nCells + 1)]);

var pt=0;
this.unitCellTranslations=Clazz.array($I$(10), [nCells]);
var iCell=0;
var cell555Count=0;
var absRange=Math.abs(this.symmetryRange);
var checkCartesianRange=(this.symmetryRange != 0 );
var checkRangeNoSymmetry=(this.symmetryRange < 0 );
var checkRange111=(this.symmetryRange > 0 );
if (checkCartesianRange) {
this.rminx=this.rminy=this.rminz=1.7976931348623157E308;
this.rmaxx=this.rmaxy=this.rmaxz=-1.7976931348623157E308;
}var sym=this.symmetry;
var lastSymmetry=sym;
this.checkAll=(this.latticeOnly || this.asc.atomSetCount == 1 && this.asc.checkSpecial  && this.latticeOp >= 0  );
var lstNCS=this.acr.lstNCS;
if (lstNCS != null  && lstNCS.get$I(0).m33 == 0  ) {
var nOp=sym.getSpaceGroupOperationCount$();
var nn=lstNCS.size$();
for (var i=nn; --i >= 0; ) {
var m=lstNCS.get$I(i);
m.m33=1;
sym.toFractionalM$javajs_util_M4d(m);
}
for (var i=1; i < nOp; i++) {
var m1=sym.getSpaceGroupOperation$I(i);
for (var j=0; j < nn; j++) {
var m=$I$(6,"newM4$javajs_util_M4d",[lstNCS.get$I(j)]);
m.mul2$javajs_util_M4d$javajs_util_M4d(m1, m);
if (this.doNormalize && this.noSymmetryCount > 0 ) $I$(11).normalizeOperationToCentroid$I$javajs_util_M4d$javajs_util_P3dA$I$I(3, m, atoms, this.firstAtom, this.noSymmetryCount);
lstNCS.addLast$O(m);
}
}
}var pttemp=null;
var op=sym.getSpaceGroupOperation$I(0);
if (this.doPackUnitCell) {
pttemp=Clazz.new_($I$(2,1));
this.ptOffset.set$D$D$D(0, 0, 0);
}var atomMap=(this.bondCount0 > this.asc.bondIndex0 && this.applySymmetryToBonds  ? Clazz.array(Integer.TYPE, [n]) : null);
var unitCells=Clazz.array(Integer.TYPE, [nCells]);
for (var tx=this.minXYZ.x; tx < this.maxXYZ.x; tx++) {
for (var ty=this.minXYZ.y; ty < this.maxXYZ.y; ty++) {
for (var tz=this.minXYZ.z; tz < this.maxXYZ.z; tz++) {
this.unitCellTranslations[iCell]=$I$(10).new3$D$D$D(tx, ty, tz);
unitCells[iCell++]=555 + tx * 100 + ty * 10 + tz;
if (tx != 0 || ty != 0  || tz != 0  || cartesians.length == 0 ) continue;
for (pt=0; pt < n; pt++) {
var atom=atoms[this.firstAtom + pt];
if (ms != null ) {
sym=ms.getAtomSymmetry$org_jmol_adapter_smarter_Atom$org_jmol_api_SymmetryInterface(atom, this.symmetry);
if (sym !== lastSymmetry ) {
if (sym.getSpaceGroupOperationCount$() == 0) p$1.finalizeSymmetry$org_jmol_api_SymmetryInterface.apply(this, [lastSymmetry=sym]);
op=sym.getSpaceGroupOperation$I(0);
}}var c=$I$(2).newP$javajs_util_T3d(atom);
op.rotTrans$javajs_util_T3d(c);
sym.toCartesian$javajs_util_T3d$Z(c, false);
if (this.doPackUnitCell) {
sym.toUnitCellRnd$javajs_util_T3d$javajs_util_T3d(c, this.ptOffset);
pttemp.setT$javajs_util_T3d(c);
sym.toFractional$javajs_util_T3d$Z(pttemp, false);
if (bsAtoms == null ) atom.setT$javajs_util_T3d(pttemp);
 else if (atom.distance$javajs_util_T3d(pttemp) < 1.0E-4 ) bsAtoms.set$I(atom.index);
 else {
bsAtoms.clear$I(atom.index);
continue;
}}if (bsAtoms != null ) atom.bsSymmetry.clearAll$();
atom.bsSymmetry.set$I(iCell * operationCount);
atom.bsSymmetry.set$I(0);
if (checkCartesianRange) p$1.setSymmetryMinMax$javajs_util_P3d.apply(this, [c]);
if (pt < cartesianCount) cartesians[pt]=c;
}
if (checkRangeNoSymmetry) {
this.rminx-=absRange;
this.rminy-=absRange;
this.rminz-=absRange;
this.rmaxx+=absRange;
this.rmaxy+=absRange;
this.rmaxz+=absRange;
}cell555Count=pt=p$1.symmetryAddAtoms$I$I$I$I$I$I$javajs_util_P3dA$org_jmol_adapter_smarter_MSInterface$javajs_util_BS$IA.apply(this, [0, 0, 0, 0, pt, iCell * operationCount, cartesians, ms, excludedOps, atomMap]);
}
}
}
if (checkRange111) {
this.rminx-=absRange;
this.rminy-=absRange;
this.rminz-=absRange;
this.rmaxx+=absRange;
this.rmaxy+=absRange;
this.rmaxz+=absRange;
}iCell=0;
for (var tx=this.minXYZ.x; tx < this.maxXYZ.x; tx++) {
for (var ty=this.minXYZ.y; ty < this.maxXYZ.y; ty++) {
for (var tz=this.minXYZ.z; tz < this.maxXYZ.z; tz++) {
++iCell;
if (tx != 0 || ty != 0  || tz != 0 ) pt=p$1.symmetryAddAtoms$I$I$I$I$I$I$javajs_util_P3dA$org_jmol_adapter_smarter_MSInterface$javajs_util_BS$IA.apply(this, [tx, ty, tz, cell555Count, pt, iCell * operationCount, cartesians, ms, excludedOps, atomMap]);
}
}
}
if (iCell * n == this.asc.ac - this.firstAtom) p$1.duplicateAtomProperties$I.apply(this, [iCell]);
p$1.setSymmetryOps.apply(this, []);
this.asc.setCurrentModelInfo$S$O("presymmetryAtomIndex", Integer.valueOf$I(this.firstAtom));
this.asc.setCurrentModelInfo$S$O("presymmetryAtomCount", Integer.valueOf$I(n));
this.asc.setCurrentModelInfo$S$O("latticeDesignation", sym.getLatticeDesignation$());
this.asc.setCurrentModelInfo$S$O("unitCellRange", unitCells);
this.asc.setCurrentModelInfo$S$O("unitCellTranslations", this.unitCellTranslations);
this.baseUnitCell=this.unitCellParams;
this.unitCellParams=Clazz.array(Double.TYPE, [6]);
p$1.reset.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'symmetryAddAtoms$I$I$I$I$I$I$javajs_util_P3dA$org_jmol_adapter_smarter_MSInterface$javajs_util_BS$IA',  function (transX, transY, transZ, baseCount, pt, iCellOpPt, cartesians, ms, excludedOps, atomMap) {
var isBaseCell=(baseCount == 0);
var addBonds=(atomMap != null );
if (this.doPackUnitCell) this.ptOffset.set$D$D$D(transX, transY, transZ);
var range2=this.symmetryRange * this.symmetryRange;
var checkRangeNoSymmetry=(this.symmetryRange < 0 );
var checkRange111=(this.symmetryRange > 0 );
var checkSymmetryMinMax=(isBaseCell && checkRange111 );
checkRange111=!!(checkRange111&(!isBaseCell));
var nOp=this.symmetry.getSpaceGroupOperationCount$();
var lstNCS=this.acr.lstNCS;
var nNCS=(lstNCS == null  ? 0 : lstNCS.size$());
var nOperations=nOp + nNCS;
nNCS=(nNCS/nOp|0);
var checkSpecial=(nOperations == 1 && !this.doPackUnitCell  ? false : this.asc.checkSpecial);
var checkSymmetryRange=(checkRangeNoSymmetry || checkRange111 );
var checkDistances=(checkSpecial || checkSymmetryRange );
var checkOps=(excludedOps != null );
var addCartesian=(checkSpecial || checkSymmetryMinMax );
var bsAtoms=(this.acr.isMolecular ? null : this.asc.bsAtoms);
var sym=this.symmetry;
if (checkRangeNoSymmetry) baseCount=this.noSymmetryCount;
var atomMax=this.firstAtom + this.noSymmetryCount;
var bondAtomMin=(this.asc.firstAtomToBond < 0 ? atomMax : this.asc.firstAtomToBond);
var pttemp=Clazz.new_($I$(2,1));
var code=null;
var d0=(checkOps ? 0.01 : 1.0E-4);
var subSystemId="\u0000";
var j00=(bsAtoms == null  ? this.firstAtom : bsAtoms.nextSetBit$I(this.firstAtom));
 out : for (var iSym=0; iSym < nOperations; iSym++) {
if (isBaseCell && iSym == 0  || this.latticeOnly && iSym > 0  && (iSym % this.latticeOp) != 0   || excludedOps != null  && excludedOps.get$I(iSym)  ) continue;
var pt0=this.firstAtom + (checkSpecial || excludedOps != null   ? pt : checkRange111 ? baseCount : 0);
var spinOp=(iSym >= nOp ? 0 : this.asc.vibScale == 0 ? sym.getSpinOp$I(iSym) : this.asc.vibScale);
var i0=Math.max(this.firstAtom, (bsAtoms == null  ? 0 : bsAtoms.nextSetBit$I(0)));
var checkDistance=checkDistances;
var spt=(iSym >= nOp ? ((iSym - nOp)/nNCS|0) : iSym);
var cpt=spt + iCellOpPt;
for (var i=i0; i < atomMax; i++) {
var a=this.asc.atoms[i];
if (bsAtoms != null  && !bsAtoms.get$I(i) ) continue;
if (ms == null ) {
sym.newSpaceGroupPoint$javajs_util_P3d$I$javajs_util_M4d$I$I$I$javajs_util_P3d(a, iSym, (iSym >= nOp ? lstNCS.get$I(iSym - nOp) : null), transX, transY, transZ, pttemp);
} else {
sym=ms.getAtomSymmetry$org_jmol_adapter_smarter_Atom$org_jmol_api_SymmetryInterface(a, this.symmetry);
sym.newSpaceGroupPoint$javajs_util_P3d$I$javajs_util_M4d$I$I$I$javajs_util_P3d(a, iSym, null, transX, transY, transZ, pttemp);
code=sym.getSpaceGroupOperationCode$I(iSym);
if (code != null ) {
subSystemId=code.charAt$I(0);
sym=ms.getSymmetryFromCode$S(code);
if (sym.getSpaceGroupOperationCount$() == 0) p$1.finalizeSymmetry$org_jmol_api_SymmetryInterface.apply(this, [sym]);
}}var c=$I$(2).newP$javajs_util_T3d(pttemp);
sym.toCartesian$javajs_util_T3d$Z(c, false);
if (this.doPackUnitCell) {
sym.toUnitCellRnd$javajs_util_T3d$javajs_util_T3d(c, this.ptOffset);
pttemp.setT$javajs_util_T3d(c);
sym.toFractional$javajs_util_T3d$Z(pttemp, false);
if (!this.isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, pttemp, this.minXYZ0.x, this.maxXYZ0.x, this.minXYZ0.y, this.maxXYZ0.y, this.minXYZ0.z, this.maxXYZ0.z, this.packingError)) continue;
}if (checkSymmetryMinMax) p$1.setSymmetryMinMax$javajs_util_P3d.apply(this, [c]);
var special=null;
if (checkDistance) {
if (checkSymmetryRange && (c.x < this.rminx  || c.y < this.rminy   || c.z < this.rminz   || c.x > this.rmaxx   || c.y > this.rmaxy   || c.z > this.rmaxz  ) ) continue;
var minDist2=1.7976931348623157E308;
var j0=(this.checkAll ? this.asc.ac : pt0);
var name=a.atomName;
var id=(code == null  ? a.altLoc : subSystemId);
for (var j=j00; j < j0; j++) {
if (bsAtoms != null  && !bsAtoms.get$I(j) ) continue;
var pc=cartesians[j - this.firstAtom];
if (pc == null ) continue;
var d2=c.distanceSquared$javajs_util_T3d(pc);
if (checkSpecial && d2 < d0  ) {
if (checkOps) {
excludedOps.set$I(iSym);
continue out;
}special=this.asc.atoms[j];
if ((special.atomName == null  || special.atomName.equals$O(name) ) && special.altLoc == id ) break;
special=null;
}if (checkRange111 && j < baseCount  && d2 < minDist2  ) minDist2=d2;
}
if (checkRange111 && minDist2 > range2  ) continue;
}if (checkOps) {
checkDistance=false;
}var atomSite=a.atomSite;
if (special != null ) {
if (addBonds) atomMap[atomSite]=special.index;
special.bsSymmetry.set$I(cpt);
special.bsSymmetry.set$I(spt);
} else {
if (addBonds) atomMap[atomSite]=this.asc.ac;
var atom1=a.copyTo$javajs_util_P3d$org_jmol_adapter_smarter_AtomSetCollection(pttemp, this.asc);
if (this.asc.bsAtoms != null ) this.asc.bsAtoms.set$I(atom1.index);
if (spinOp != 0 && atom1.vib != null  ) {
sym.getSpaceGroupOperation$I(iSym).rotate$javajs_util_T3d(atom1.vib);
atom1.vib.scale$D(spinOp);
}if (atom1.isNegDisorder) {
if (this.disorderMap == null ) this.disorderMap=Clazz.new_($I$(12,1));
var key=Integer.valueOf$I(iSym * 1000 + atom1.altLoc.$c());
var ch=this.disorderMap.get$O(key);
if (ch == null ) {
if (this.disorderMapMax == 0 || this.disorderMapMax == 90  ) this.disorderMapMax=64;
this.disorderMap.put$O$O(key, ch=Clazz.new_(Character.c$$C,[String.fromCharCode((++this.disorderMapMax))]));
}atom1.altLoc=ch.charValue$();
}atom1.atomSite=atomSite;
if (code != null ) atom1.altLoc=subSystemId;
atom1.bsSymmetry=$I$(8).newAndSetBit$I(cpt);
atom1.bsSymmetry.set$I(spt);
if (addCartesian) cartesians[pt++]=c;
var tensors=a.tensors;
if (tensors != null ) {
atom1.tensors=null;
for (var j=tensors.size$(); --j >= 0; ) {
var t=tensors.get$I(j);
if (t == null ) continue;
if (nOp == 1) atom1.addTensor$org_jmol_util_Tensor$S$Z(t.copyTensor$(), null, false);
 else this.addRotatedTensor$org_jmol_adapter_smarter_Atom$org_jmol_util_Tensor$I$Z$org_jmol_api_SymmetryInterface(atom1, t, iSym, false, sym);
}
}}}
if (addBonds) {
var bonds=this.asc.bonds;
var atoms=this.asc.atoms;
var key;
for (var bondNum=this.asc.bondIndex0; bondNum < this.bondCount0; bondNum++) {
var bond=bonds[bondNum];
var atom1=atoms[bond.atomIndex1];
var atom2=atoms[bond.atomIndex2];
if (atom1 == null  || atom2 == null   || atom2.atomSetIndex < atom1.atomSetIndex ) continue;
var ia1=atomMap[atom1.atomSite];
var ia2=atomMap[atom2.atomSite];
if (ia1 > ia2) {
var i=ia1;
ia1=ia2;
ia2=i;
}if ((ia1 != ia2 && (ia1 >= bondAtomMin || ia2 >= bondAtomMin ) ) && !this.bondsFound.contains$O(key="-" + ia1 + "," + ia2 ) ) {
this.bondsFound.add$O(key);
this.asc.addNewBondWithOrder$I$I$I(ia1, ia2, bond.order);
}}
}}
return pt;
}, p$1);

Clazz.newMeth(C$, 'duplicateAtomProperties$I',  function (nTimes) {
var p=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, "atomProperties");
if (p != null ) for (var entry, $entry = p.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var key=entry.getKey$();
var val=entry.getValue$();
if (Clazz.instanceOf(val, "java.lang.String")) {
var data=val;
var s=Clazz.new_($I$(13,1));
for (var i=nTimes; --i >= 0; ) s.append$S(data);

p.put$O$O(key, s.toString());
} else {
var f=val;
var fnew=Clazz.array(Double.TYPE, [f.length * nTimes]);
for (var i=nTimes; --i >= 0; ) System.arraycopy$O$I$O$I$I(f, 0, fnew, i * f.length, f.length);

}}
}, p$1);

Clazz.newMeth(C$, 'finalizeSymmetry$org_jmol_api_SymmetryInterface',  function (symmetry) {
var name=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, "spaceGroup");
symmetry.setFinalOperations$I$S$javajs_util_P3dA$I$I$Z$S(this.ndims, name, this.asc.atoms, this.firstAtom, this.noSymmetryCount, this.doNormalize, this.filterSymop);
if (this.filterSymop != null  || name == null   || name.equals$O("unspecified!") ) p$1.setAtomSetSpaceGroupName$S.apply(this, [symmetry.getSpaceGroupName$()]);
}, p$1);

Clazz.newMeth(C$, 'setSymmetryOps',  function () {
var operationCount=this.symmetry.getSpaceGroupOperationCount$();
if (operationCount > 0) {
var symmetryList=Clazz.array(String, [operationCount]);
for (var i=0; i < operationCount; i++) symmetryList[i]="" + this.symmetry.getSpaceGroupXyz$I$Z(i, this.doNormalize);

this.asc.setCurrentModelInfo$S$O("symmetryOperations", symmetryList);
this.asc.setCurrentModelInfo$S$O("symmetryOps", this.symmetry.getSymmetryOperations$());
}this.asc.setCurrentModelInfo$S$O("symmetryCount", Integer.valueOf$I(operationCount));
this.asc.setCurrentModelInfo$S$O("latticeType", this.acr.latticeType == null  ? "P" : this.acr.latticeType);
this.asc.setCurrentModelInfo$S$O("intlTableNo", this.symmetry.getIntTableNumber$());
if (this.acr.sgName == null  || this.acr.sgName.indexOf$S("?") >= 0  || this.acr.sgName.indexOf$S("!") >= 0 ) p$1.setAtomSetSpaceGroupName$S.apply(this, [this.acr.sgName=this.symmetry.getSpaceGroupName$()]);
}, p$1);

Clazz.newMeth(C$, 'getOverallSpan$',  function () {
return (this.maxXYZ0 == null  ? $I$(10).new3$D$D$D(this.maxXYZ.x - this.minXYZ.x, this.maxXYZ.y - this.minXYZ.y, this.maxXYZ.z - this.minXYZ.z) : $I$(10).newVsub$javajs_util_T3d$javajs_util_T3d(this.maxXYZ0, this.minXYZ0));
});

Clazz.newMeth(C$, 'applySymmetryBio$java_util_Map$Z$S',  function (thisBiomolecule, applySymmetryToBonds, filter) {
var biomts=thisBiomolecule.get$O("biomts");
var len=biomts.size$();
if (this.mident == null ) {
this.mident=Clazz.new_($I$(6,1));
this.mident.setIdentity$();
}this.acr.lstNCS=null;
p$1.setLatticeCells.apply(this, []);
var lc=(this.latticeCells != null  && this.latticeCells[0] != 0  ? Clazz.array(Integer.TYPE, [3]) : null);
if (lc != null ) for (var i=0; i < 3; i++) lc[i]=this.latticeCells[i];

this.latticeCells=null;
var bmChains=this.acr.getFilterWithCase$S("BMCHAINS");
var fixBMChains=(bmChains == null  ? -1 : bmChains.length$() < 2 ? 0 : $I$(14,"parseInt$S",[bmChains.substring$I(1)]));
if (fixBMChains == -2147483648) {
fixBMChains=-bmChains.charAt$I(1).$c();
}var particleMode=(filter.indexOf$S("BYCHAIN") >= 0 ? 1 : filter.indexOf$S("BYSYMOP") >= 0 ? 2 : 0);
this.doNormalize=false;
var biomtchains=thisBiomolecule.get$O("chains");
this.symmetry=null;
this.getSymmetry$().setSpaceGroup$Z(this.doNormalize);
this.addSpaceGroupOperation$S$Z("x,y,z", false);
var name=thisBiomolecule.get$O("name");
p$1.setAtomSetSpaceGroupName$S.apply(this, [this.acr.sgName=name]);
this.applySymmetryToBonds=applySymmetryToBonds;
this.bondCount0=this.asc.bondCount;
this.firstAtom=this.asc.getLastAtomSetAtomIndex$();
var atomMax=this.asc.ac;
var ht=Clazz.new_($I$(12,1));
var nChain=0;
var atoms=this.asc.atoms;
var addBonds=(this.bondCount0 > this.asc.bondIndex0 && applySymmetryToBonds );
switch (particleMode) {
case 1:
for (var i=atomMax; --i >= this.firstAtom; ) {
var id=Integer.valueOf$I(atoms[i].chainID);
var bs=ht.get$O(id);
if (bs == null ) {
++nChain;
ht.put$O$O(id, bs=Clazz.new_($I$(9,1)));
}bs.set$I(i);
}
this.asc.bsAtoms=Clazz.new_($I$(9,1));
for (var i=0; i < nChain; i++) {
this.asc.bsAtoms.set$I(atomMax + i);
var a=Clazz.new_($I$(15,1));
a.set$D$D$D(0, 0, 0);
a.radius=16;
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
}
var ichain=0;
for (var e, $e = ht.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var a=atoms[atomMax + ichain++];
var bs=e.getValue$();
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) a.add$javajs_util_T3d(atoms[i]);

a.scale$D(1.0 / bs.cardinality$());
a.atomName="Pt" + ichain;
a.chainID=e.getKey$().intValue$();
}
this.firstAtom=atomMax;
atomMax+=nChain;
addBonds=false;
break;
case 2:
this.asc.bsAtoms=Clazz.new_($I$(9,1));
this.asc.bsAtoms.set$I(atomMax);
var a=atoms[atomMax]=Clazz.new_($I$(15,1));
a.set$D$D$D(0, 0, 0);
for (var i=atomMax; --i >= this.firstAtom; ) a.add$javajs_util_T3d(atoms[i]);

a.scale$D(1.0 / (atomMax - this.firstAtom));
a.atomName="Pt";
a.radius=16;
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
this.firstAtom=atomMax++;
addBonds=false;
break;
}
var assemblyIdAtoms=thisBiomolecule.get$O("asemblyIdAtoms");
if (filter.indexOf$S("#<") >= 0) {
len=Math.min(len, $I$(14,"parseInt$S",[filter.substring$I(filter.indexOf$S("#<") + 2)]) - 1);
filter=$I$(14).rep$S$S$S(filter, "#<", "_<");
}var maxChain=0;
for (var iAtom=this.firstAtom; iAtom < atomMax; iAtom++) {
atoms[iAtom].bsSymmetry=Clazz.new_($I$(9,1));
var chainID=atoms[iAtom].chainID;
if (chainID > maxChain) maxChain=chainID;
}
var bsAtoms=this.asc.bsAtoms;
var atomMap=(addBonds ? Clazz.array(Integer.TYPE, [this.asc.ac]) : null);
for (var imt=(biomtchains == null  ? 1 : 0); imt < len; imt++) {
if (filter.indexOf$S("!#") >= 0) {
if (filter.indexOf$S("!#" + (imt + 1) + ";" ) >= 0) continue;
} else if (filter.indexOf$S("#") >= 0 && filter.indexOf$S("#" + (imt + 1) + ";" ) < 0 ) {
continue;
}var mat=biomts.get$I(imt);
var notIdentity=!mat.equals$O(this.mident);
var chains=(biomtchains == null  ? null : biomtchains.get$I(imt));
if (chains != null  && assemblyIdAtoms != null  ) {
bsAtoms=Clazz.new_($I$(9,1));
for (var e, $e = assemblyIdAtoms.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) if (chains.indexOf$S(":" + e.getKey$() + ";" ) >= 0) bsAtoms.or$javajs_util_BS(e.getValue$());

if (this.asc.bsAtoms != null ) bsAtoms.and$javajs_util_BS(this.asc.bsAtoms);
chains=null;
}var lastID=-1;
var id;
var skipping=false;
for (var iAtom=this.firstAtom; iAtom < atomMax; iAtom++) {
if (bsAtoms != null ) {
skipping=!bsAtoms.get$I(iAtom);
} else if (chains != null  && (id=atoms[iAtom].chainID) != lastID ) {
skipping=(chains.indexOf$S(":" + this.acr.vwr.getChainIDStr$I(lastID=id) + ";" ) < 0);
}if (skipping) continue;
try {
var atomSite=atoms[iAtom].atomSite;
var atom1;
if (addBonds) atomMap[atomSite]=this.asc.ac;
atom1=this.asc.newCloneAtom$org_jmol_adapter_smarter_Atom(atoms[iAtom]);
atom1.bondingRadius=imt;
this.asc.atomSymbolicMap.put$O$O("" + atom1.atomSerial, atom1);
if (this.asc.bsAtoms != null ) this.asc.bsAtoms.set$I(atom1.index);
atom1.atomSite=atomSite;
if (notIdentity) mat.rotTrans$javajs_util_T3d(atom1);
atom1.bsSymmetry=$I$(8).newAndSetBit$I(imt);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.asc.errorMessage="appendAtomCollection error: " + e;
} else {
throw e;
}
}
}
if (notIdentity) this.symmetry.addBioMoleculeOperation$javajs_util_M4d$Z(mat, false);
if (addBonds) {
for (var bondNum=this.asc.bondIndex0; bondNum < this.bondCount0; bondNum++) {
var bond=this.asc.bonds[bondNum];
var iAtom1=atomMap[atoms[bond.atomIndex1].atomSite];
var iAtom2=atomMap[atoms[bond.atomIndex2].atomSite];
this.asc.addNewBondWithOrder$I$I$I(iAtom1, iAtom2, bond.order);
}
}}
if (biomtchains != null ) {
if (this.asc.bsAtoms == null ) this.asc.bsAtoms=$I$(8).newBitSet2$I$I(0, this.asc.ac);
this.asc.bsAtoms.clearBits$I$I(this.firstAtom, atomMax);
if (particleMode == 0) {
if (fixBMChains != -1) {
var assignABC=(fixBMChains != 0);
var bsChains=(assignABC ? Clazz.new_($I$(9,1)) : null);
atoms=this.asc.atoms;
var firstNew=0;
if (assignABC) {
firstNew=(fixBMChains < 0 ? Math.max(-fixBMChains, maxChain + 1) : Math.max(maxChain + fixBMChains, 65));
bsChains.setBits$I$I(0, firstNew - 1);
bsChains.setBits$I$I(91, 97);
bsChains.setBits$I$I(123, 200);
}var bsAll=(this.asc.structureCount == 1 ? this.asc.structures[0].bsAll : null);
var chainMap=Clazz.new_($I$(12,1));
var knownMap=Clazz.new_($I$(12,1));
var knownAtomMap=(bsAll == null  ? null : Clazz.new_($I$(12,1)));
var lastKnownAtom=null;
for (var i=atomMax, n=this.asc.ac; i < n; i++) {
var ic=atoms[i].chainID;
var isym=atoms[i].bsSymmetry.nextSetBit$I(0);
var ch0=this.acr.vwr.getChainIDStr$I(ic);
var ch=(isym == 0 ? ch0 : ch0 + isym);
var known=chainMap.get$O(ch);
if (known == null ) {
if (assignABC && isym != 0 ) {
var pt=(firstNew < 200 ? bsChains.nextClearBit$I(firstNew) : 200);
if (pt < 200) {
bsChains.set$I(pt);
known=Integer.valueOf$I(this.acr.vwr.getChainID$S$Z("" + String.fromCharCode(pt), true));
firstNew=pt;
} else {
}}if (known == null ) known=Integer.valueOf$I(this.acr.vwr.getChainID$S$Z(ch, true));
if (ch != ch0) {
knownMap.put$O$O(known, Integer.valueOf$I(ic));
if (bsAll != null ) {
if (lastKnownAtom != null ) lastKnownAtom[1]=i;
knownAtomMap.put$O$O(known, lastKnownAtom=Clazz.array(Integer.TYPE, -1, [i, n]));
}}chainMap.put$O$O(ch, known);
}atoms[i].chainID=known.intValue$();
}
if (this.asc.structureCount > 0) {
var strucs=this.asc.structures;
var nStruc=this.asc.structureCount;
for (var e, $e = knownMap.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var known=e.getKey$();
var ch1=known.intValue$();
var ch0=e.getValue$().intValue$();
for (var i=0; i < nStruc; i++) {
var s=strucs[i];
if (s.bsAll != null ) {
} else if (s.startChainID == s.endChainID) {
if (s.startChainID == ch0) {
var s1=s.clone$();
s1.startChainID=s1.endChainID=ch1;
this.asc.addStructure$org_jmol_adapter_smarter_Structure(s1);
}} else {
System.err.println$S("XtalSymmetry not processing biomt chain structure " + this.acr.vwr.getChainIDStr$I(ch0) + " to " + this.acr.vwr.getChainIDStr$I(ch1) );
}}
}
}}var vConnect=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, "PDB_CONECT_bonds");
if (!addBonds && vConnect != null  ) {
for (var i=vConnect.size$(); --i >= 0; ) {
var bond=vConnect.get$I(i);
var a=this.asc.getAtomFromName$S("" + bond[0]);
var b=this.asc.getAtomFromName$S("" + bond[1]);
if (a != null  && b != null   && a.bondingRadius != b.bondingRadius   && (bsAtoms == null  || bsAtoms.get$I(a.index) && bsAtoms.get$I(b.index)  )  && a.distanceSquared$javajs_util_T3d(b) > 25.0  ) {
vConnect.removeItemAt$I(i);
System.out.println$S("long interchain bond removed for @" + a.atomSerial + "-@" + b.atomSerial );
}}
}}for (var i=atomMax, n=this.asc.ac; i < n; i++) {
this.asc.atoms[i].bondingRadius=NaN;
}
}this.noSymmetryCount=atomMax - this.firstAtom;
this.asc.setCurrentModelInfo$S$O("presymmetryAtomIndex", Integer.valueOf$I(this.firstAtom));
this.asc.setCurrentModelInfo$S$O("presymmetryAtomCount", Integer.valueOf$I(this.noSymmetryCount));
this.asc.setCurrentModelInfo$S$O("biosymmetryCount", Integer.valueOf$I(len));
this.asc.setCurrentModelInfo$S$O("biosymmetry", this.symmetry);
p$1.finalizeSymmetry$org_jmol_api_SymmetryInterface.apply(this, [this.symmetry]);
p$1.setSymmetryOps.apply(this, []);
p$1.reset.apply(this, []);
});

Clazz.newMeth(C$, 'reset',  function () {
this.asc.coordinatesAreFractional=false;
this.asc.setCurrentModelInfo$S$O("hasSymmetry", Boolean.TRUE);
this.asc.setGlobalBoolean$I(1);
}, p$1);

Clazz.newMeth(C$, 'addRotatedTensor$org_jmol_adapter_smarter_Atom$org_jmol_util_Tensor$I$Z$org_jmol_api_SymmetryInterface',  function (a, t, iSym, reset, symmetry) {
if (this.ptTemp == null ) {
this.ptTemp=Clazz.new_($I$(2,1));
this.mTemp=Clazz.new_($I$(16,1));
}return a.addTensor$org_jmol_util_Tensor$S$Z((this.acr.getInterface$S("org.jmol.util.Tensor")).setFromEigenVectors$javajs_util_T3dA$DA$S$S$org_jmol_util_Tensor(symmetry.rotateAxes$I$javajs_util_V3dA$javajs_util_P3d$javajs_util_M3d(iSym, t.eigenVectors, this.ptTemp, this.mTemp), t.eigenValues, t.isIsotropic ? "iso" : t.type, t.id, t), null, reset);
});

Clazz.newMeth(C$, 'setTensors$',  function () {
var n=this.asc.ac;
for (var i=this.asc.getLastAtomSetAtomIndex$(); i < n; i++) {
var a=this.asc.atoms[i];
if (a.anisoBorU == null ) continue;
a.addTensor$org_jmol_util_Tensor$S$Z(this.symmetry.getTensor$org_jmol_viewer_Viewer$DA(this.acr.vwr, a.anisoBorU), null, false);
if (Double.isNaN$D(a.bfactor)) a.bfactor=a.anisoBorU[7] * 100.0;
a.anisoBorU=null;
}
});

Clazz.newMeth(C$, 'setTimeReversal$I$I',  function (op, timeRev) {
this.symmetry.setTimeReversal$I$I(op, timeRev);
});

Clazz.newMeth(C$, 'setSpinVectors$',  function () {
if (this.nVib > 0 || this.asc.iSet < 0  || !this.acr.vibsFractional ) return this.nVib;
var i0=this.asc.getAtomSetAtomIndex$I(this.asc.iSet);
var sym=this.getBaseSymmetry$();
for (var i=this.asc.ac; --i >= i0; ) {
var v=this.asc.atoms[i].vib;
if (v != null ) {
if (v.modDim > 0) {
(v).setMoment$();
} else {
v=v.clone$();
sym.toCartesian$javajs_util_T3d$Z(v, true);
this.asc.atoms[i].vib=v;
}++this.nVib;
}}
return this.nVib;
});

Clazz.newMeth(C$, 'scaleFractionalVibs$',  function () {
var params=this.getBaseSymmetry$().getUnitCellParams$();
var ptScale=$I$(2).new3$D$D$D(1 / params[0], 1 / params[1], 1 / params[2]);
var i0=this.asc.getAtomSetAtomIndex$I(this.asc.iSet);
for (var i=this.asc.ac; --i >= i0; ) {
var v=this.asc.atoms[i].vib;
if (v != null ) {
v.scaleT$javajs_util_T3d(ptScale);
}}
});

Clazz.newMeth(C$, 'getBaseSymmetry$',  function () {
return (this.baseSymmetry == null  ? this.symmetry : this.baseSymmetry);
});

Clazz.newMeth(C$, 'finalizeUnitCell$javajs_util_P3d',  function (ptSupercell) {
if (ptSupercell != null  && this.baseUnitCell != null  ) {
this.baseUnitCell[22]=Math.max(1, (ptSupercell.x|0));
this.baseUnitCell[23]=Math.max(1, (ptSupercell.y|0));
this.baseUnitCell[24]=Math.max(1, (ptSupercell.z|0));
}});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-13 20:34:49 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
