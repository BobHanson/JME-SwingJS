(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'javajs.util.P3d','javajs.util.BS','javajs.util.SB','org.jmol.viewer.Viewer','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CIFWriter", null, 'org.jmol.adapter.writers.XtlWriter', 'org.jmol.api.JmolWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isP1'],'O',['vwr','org.jmol.viewer.Viewer','oc','javajs.util.OC']]
,['O',['fset0','javajs.util.T3d']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, oc, data) {
this.vwr=viewer;
this.oc=(oc == null  ? this.vwr.getOutputChannel$S$SA(null, null) : oc);
this.isP1=(data != null  && data.length > 0  && "P1".equals$O(data[0]) );
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
if (bs == null ) bs=this.vwr.bsA$();
try {
var mi=this.vwr.ms.at[bs.nextSetBit$I(0)].mi;
var uc=this.vwr.getCurrentUnitCell$();
this.haveUnitCell=(uc != null );
if (!this.haveUnitCell) uc=this.vwr.getSymTemp$().setUnitCell$DA$Z(Clazz.array(Double.TYPE, -1, [1, 1, 1, 90, 90, 90]), false);
var offset=uc.getFractionalOffset$();
var fractionalOffset=offset != null  && (offset.x != (offset.x|0)  || offset.y != (offset.y|0)   || offset.z != (offset.z|0)  ) ;
var fset;
var haveCustom=(fractionalOffset || (fset=uc.getUnitCellMultiplier$()) != null  && (fset.z == 1  ? !fset.equals$O(C$.fset0) : fset.z != 0 )  );
var ucm=uc.getUnitCellMultiplied$();
this.isP1=(this.isP1 || ucm !== uc   || fractionalOffset  || uc.getSpaceGroupOperationCount$() < 2 );
uc=ucm;
var modelAU=(!this.haveUnitCell ? bs : this.isP1 ? uc.removeDuplicates$org_jmol_modelset_ModelSet$javajs_util_BS$Z(this.vwr.ms, bs, false) : this.vwr.ms.am[mi].bsAsymmetricUnit);
var bsOut;
if (modelAU == null ) {
bsOut=bs;
} else {
bsOut=Clazz.new_($I$(2,1));
bsOut.or$javajs_util_BS(modelAU);
bsOut.and$javajs_util_BS(bs);
}this.vwr.setErrorMessage$S$S(null, " (" + bsOut.cardinality$() + " atoms)" );
if (bsOut.isEmpty$()) return "";
var sb=Clazz.new_($I$(3,1));
sb.append$S("## CIF file created by Jmol " + $I$(4).getJmolVersion$());
if (haveCustom) {
sb.append$S($I$(5,"rep$S$S$S",["\n" + uc.getUnitCellInfo$Z(false), "\n", "\n##Jmol_orig "]));
}sb.append$S("\ndata_global");
var params=uc.getUnitCellAsArray$Z(false);
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_cell_length_a"]).appendD$D(params[0]);
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_cell_length_b"]).appendD$D(params[1]);
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_cell_length_c"]).appendD$D(params[2]);
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_cell_angle_alpha"]).appendD$D(params[3]);
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_cell_angle_beta"]).appendD$D(params[4]);
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_cell_angle_gamma"]).appendD$D(params[5]);
sb.append$S("\n");
var n;
var hallName;
var hmName;
var ita;
if (this.isP1) {
ita="1";
hallName="P 1";
hmName="P1";
n=0;
} else {
uc.getSpaceGroupInfo$org_jmol_modelset_ModelSet$S$I$Z$DA(this.vwr.ms, null, mi, true, null);
ita=uc.getSpaceGroupNameType$S("ITA");
hallName=uc.getSpaceGroupNameType$S("Hall");
hmName=uc.getSpaceGroupNameType$S("HM");
n=uc.getSpaceGroupOperationCount$();
}p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_space_group_IT_number"]).append$S(ita == null  ? "?" : ita.toString());
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_space_group_name_Hall"]).append$S(hallName == null  || hallName.equals$O("?")  ? "?" : "'" + hallName + "'" );
p$1.appendKey$javajs_util_SB$S.apply(this, [sb, "_space_group_name_H-M_alt"]).append$S(hmName == null  ? "?" : "'" + hmName + "'" );
sb.append$S("\n\nloop_\n_space_group_symop_id\n_space_group_symop_operation_xyz");
if (n == 0) {
sb.append$S("\n1 x,y,z");
} else {
for (var i=0; i < n; i++) {
sb.append$S("\n").appendI$I(i + 1).append$S("\t").append$S(uc.getSpaceGroupXyz$I$Z(i, false).replaceAll$S$S(" ", ""));
}
}var atoms=this.vwr.ms.at;
var elements="";
var sbLength=sb.length$();
sb.append$S("\n\nloop_\n_atom_site_label\n_atom_site_type_symbol\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z");
if (!this.haveUnitCell) sb.append$S("\n_atom_site_Cartn_x\n_atom_site_Cartn_y\n_atom_site_Cartn_z");
sb.append$S("\n");
var jmol_atom=Clazz.new_($I$(3,1));
jmol_atom.append$S("\n\nloop_\n_jmol_atom_index\n_jmol_atom_name\n_jmol_atom_site_label\n");
var nAtoms=0;
var p=Clazz.new_($I$(1,1));
var elemNums=Clazz.array(Integer.TYPE, [130]);
for (var i=bsOut.nextSetBit$I(0); i >= 0; i=bsOut.nextSetBit$I(i + 1)) {
var a=atoms[i];
p.setT$javajs_util_T3d(a);
if (this.haveUnitCell) {
uc.toFractional$javajs_util_T3d$Z(p, !this.isP1);
}++nAtoms;
var name=a.getAtomName$();
var sym=a.getElementSymbol$();
var elemno=a.getElementNumber$();
var key=sym + "\n";
if (elements.indexOf$S(key) < 0) elements+=key;
var label=sym + ++elemNums[elemno];
sb.append$S($I$(5).formatS$S$I$I$Z$Z(label, 5, 0, true, false)).append$S(" ").append$S($I$(5).formatS$S$I$I$Z$Z(sym, 3, 0, true, false)).append$S(this.cleanF$D(p.x)).append$S(this.cleanF$D(p.y)).append$S(this.cleanF$D(p.z));
if (!this.haveUnitCell) sb.append$S(this.cleanF$D(a.x)).append$S(this.cleanF$D(a.y)).append$S(this.cleanF$D(a.z));
sb.append$S("\n");
jmol_atom.append$S($I$(5,"formatS$S$I$I$Z$Z",["" + a.getIndex$(), 3, 0, false, false])).append$S(" ");
p$1.writeChecked$javajs_util_SB$S.apply(this, [jmol_atom, name]);
jmol_atom.append$S(" ").append$S($I$(5).formatS$S$I$I$Z$Z(label, 5, 0, false, false)).append$S("\n");
}
if (nAtoms > 0) {
sb.append$S("\nloop_\n_atom_type_symbol\n").append$S(elements).append$S("\n");
sb.appendSB$javajs_util_SB(jmol_atom);
} else {
sb.setLength$I(sbLength);
}sb.append$S("\n# ").appendI$I(nAtoms).append$S(" atoms\n");
this.oc.append$S(sb.toString());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!$I$(4).isJS) e.printStackTrace$();
} else {
throw e;
}
}
return this.toString();
});

Clazz.newMeth(C$, 'writeChecked$javajs_util_SB$S',  function (output, val) {
if (val == null  || val.length$() == 0 ) {
output.append$S(". ");
return false;
}var escape=val.charAt$I(0) == "_";
var escapeCharStart="\'";
var escapeCharEnd="\' ";
var hasWhitespace=false;
var hasSingle=false;
var hasDouble=false;
for (var i=0; i < val.length$(); i++) {
var c=val.charAt$I(i);
switch (c.$c()) {
case 9:
case 32:
hasWhitespace=true;
break;
case 10:
p$1.writeMultiline$javajs_util_SB$S.apply(this, [output, val]);
return true;
case 34:
if (hasSingle) {
p$1.writeMultiline$javajs_util_SB$S.apply(this, [output, val]);
return true;
}hasDouble=true;
escape=true;
escapeCharStart="\'";
escapeCharEnd="\' ";
break;
case 39:
if (hasDouble) {
p$1.writeMultiline$javajs_util_SB$S.apply(this, [output, val]);
return true;
}escape=true;
hasSingle=true;
escapeCharStart="\"";
escapeCharEnd="\" ";
break;
}
}
var fst=val.charAt$I(0);
if (!escape && (fst == "#" || fst == "$"  || fst == ";"  || fst == "["  || fst == "]"  || hasWhitespace ) ) {
escapeCharStart="\'";
escapeCharEnd="\' ";
escape=true;
}if (escape) {
output.append$S(escapeCharStart).append$S(val).append$S(escapeCharEnd);
} else {
output.append$S(val).append$S(" ");
}return false;
}, p$1);

Clazz.newMeth(C$, 'writeMultiline$javajs_util_SB$S',  function (output, val) {
output.append$S("\n;").append$S(val).append$S("\n;\n");
}, p$1);

Clazz.newMeth(C$, 'appendKey$javajs_util_SB$S',  function (sb, key) {
return sb.append$S("\n").append$S($I$(5).formatS$S$I$I$Z$Z(key, 27, 0, true, false));
}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
return (this.oc == null  ? "" : this.oc.toString());
});

C$.$static$=function(){C$.$static$=0;
C$.fset0=$I$(1).new3$D$D$D(555, 555, 1);
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-22 15:32:40 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
