(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XtlWriter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.haveUnitCell=true;
},1);

C$.$fields$=[['Z',['haveUnitCell']]
,['O',['twelfths','String[]','+twelfthsF']]]

Clazz.newMeth(C$, 'twelfthsOf$D$D',  function (f, p) {
if (f == 0 ) return 0;
f=Math.abs(f * 12);
var i=Long.$ival(Math.round$D(f));
return (i <= 12 && Math.abs(f - i) < p * 12   ? i : -1);
}, 1);

Clazz.newMeth(C$, 'clean$D',  function (f) {
var t;
return (!this.haveUnitCell || (t=C$.twelfthsOf$D$D(f, 1.5E-10)) < 0  ? $I$(1).formatD$D$I$I$Z$Z(f, 26, 15, false, false) : (f < 0  ? "        -" : "         ") + C$.twelfths[t]);
});

Clazz.newMeth(C$, 'cleanF$D',  function (f) {
return this.clean$D(f);
});

C$.$static$=function(){C$.$static$=0;
C$.twelfths=Clazz.array(String, -1, ["0.000000000000000", "0.083333333333333", "0.166666666666667", "0.250000000000000", "0.333333333333333", "0.416666666666667", "0.500000000000000", "0.583333333333333", "0.666666666666667", "0.750000000000000", "0.833333333333333", "0.916666666666667", "1.000000000000000"]);
C$.twelfthsF=Clazz.array(String, -1, ["0.0000000", "0.0833333", "0.1666667", "0.2500000", "0.3333333", "0.4166667", "0.5000000", "0.5833333", "0.6666667", "0.7500000", "0.8333333", "0.9166667", "1.0000000"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-12 13:55:26 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
