(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},I$=[[0,'javajs.util.Lst','org.jmol.util.Edge','org.jmol.adapter.smarter.Bond','java.util.Stack','java.util.ArrayList','javajs.util.BS',['org.jmol.adapter.readers.xml.XmlChemDrawReader','.CDNode'],'javajs.util.PT','org.jmol.api.JmolAdapter','org.jmol.util.Logger',['org.jmol.adapter.readers.xml.XmlChemDrawReader','.CDBond']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlChemDrawReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.readers.xml.XmlReader');
C$.$classes$=[['CDNode',0],['CDBond',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.minX=1.7976931348623157E308;
this.minY=1.7976931348623157E308;
this.minZ=1.7976931348623157E308;
this.maxZ=-1.7976931348623157E308;
this.maxY=-1.7976931348623157E308;
this.maxX=-1.7976931348623157E308;
this.fragments=Clazz.new_($I$(4,1));
this.nodes=Clazz.new_($I$(4,1));
this.nostereo=Clazz.new_($I$(5,1));
},1);

C$.$fields$=[['Z',['no3D','isCDX'],'D',['minX','minY','minZ','maxZ','maxY','maxX'],'S',['thisFragment','textBuffer'],'O',['fragments','java.util.Stack','thisNode','org.jmol.adapter.readers.xml.XmlChemDrawReader.CDNode','nodes','java.util.Stack','nostereo','java.util.List']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.is2D=true;
if (parent == null ) {
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(this, saxReader);
parent=this;
} else {
this.no3D=parent.checkFilterKey$S("NO3D");
this.noHydrogens=parent.noHydrogens;
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
this.filter=parent.filter;
}});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
var id=this.atts.get$O("id");
if ("fragment".equals$O(localName)) {
this.fragments.push$O(this.thisFragment=id);
return;
}if ("n".equals$O(localName)) {
p$1.setNode$S.apply(this, [id]);
return;
}if ("t".equals$O(localName)) {
this.textBuffer="";
}if ("s".equals$O(localName)) {
this.setKeepChars$Z(true);
}if ("b".equals$O(localName)) {
p$1.setBond.apply(this, []);
return;
}});

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
if ("fragment".equals$O(localName)) {
this.thisFragment=this.fragments.pop$();
return;
}if ("n".equals$O(localName)) {
this.thisNode=(this.nodes.size$() == 0 ? null : this.nodes.pop$());
return;
}if ("s".equals$O(localName)) {
this.textBuffer+=this.chars.toString();
}if ("t".equals$O(localName)) {
if (this.thisNode == null ) {
System.out.println$S("XmlChemDrawReader unassigned text: " + this.textBuffer);
} else {
this.thisNode.text=this.textBuffer;
if (this.atom.elementNumber == 0) {
System.err.println$S("XmlChemDrawReader: Problem with \"" + this.textBuffer + "\"" );
}if (this.thisNode.warning != null ) this.parent.appendLoadNote$S("Warning: " + this.textBuffer + " " + this.thisNode.warning );
}this.textBuffer="";
}this.setKeepChars$Z(false);
});

Clazz.newMeth(C$, 'setNode$S',  function (id) {
var nodeType=this.atts.get$O("nodetype");
if (this.asc.bsAtoms == null ) this.asc.bsAtoms=Clazz.new_($I$(6,1));
if (this.thisNode != null ) this.nodes.push$O(this.thisNode);
if ("_".equals$O(nodeType)) {
this.atom=this.thisNode=null;
return;
}this.atom=this.thisNode=Clazz.new_($I$(7,1).c$$S$S$S$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDNode,[this, null, id, nodeType, this.thisFragment, this.thisNode]);
this.asc.addAtomWithMappedSerialNumber$org_jmol_adapter_smarter_Atom(this.atom);
this.asc.bsAtoms.set$I(this.atom.index);
var w=this.atts.get$O("warning");
if (w != null ) {
this.thisNode.warning=$I$(8).rep$S$S$S(w, "&apos;", "\'");
this.thisNode.isValid=(w.indexOf$S("ChemDraw can\'t interpret") < 0);
}var element=this.atts.get$O("element");
var s=this.atts.get$O("genericnickname");
if (s != null ) {
element=s;
}this.atom.elementNumber=($s$[0] = (!p$1.checkWarningOK$S.apply(this, [w]) ? 0 : element == null  ? 6 : this.parseIntStr$S(element)), $s$[0]);
element=$I$(9).getElementSymbol$I(this.atom.elementNumber);
s=this.atts.get$O("isotope");
if (s != null ) element=s + element;
this.setElementAndIsotope$org_jmol_adapter_smarter_Atom$S(this.atom, element);
s=this.atts.get$O("charge");
if (s != null ) {
this.atom.formalCharge=this.parseIntStr$S(s);
}var hasXYZ=(this.atts.containsKey$O("xyz"));
var hasXY=(this.atts.containsKey$O("p"));
if (hasXYZ && (!this.no3D || !hasXY ) ) {
this.is2D=false;
p$1.setAtom$S.apply(this, ["xyz"]);
} else if (this.atts.containsKey$O("p")) {
p$1.setAtom$S.apply(this, ["p"]);
}s=this.atts.get$O("attachments");
if (s != null ) {
this.thisNode.setMultipleAttachments$SA($I$(8,"split$S$S",[s.trim$(), " "]));
}if ($I$(10).debugging) $I$(10,"info$S",["XmlChemDraw id=" + id + " " + element + " " + this.atom ]);
}, p$1);

Clazz.newMeth(C$, 'checkWarningOK$S',  function (warning) {
return (warning == null  || warning.indexOf$S("valence") >= 0  || warning.indexOf$S("very close") >= 0  || warning.indexOf$S("two identical colinear bonds") >= 0 );
}, p$1);

Clazz.newMeth(C$, 'setBond',  function () {
var atom1=this.atts.get$O("b");
var atom2=this.atts.get$O("e");
var a=this.atts.get$O("beginattach");
var beginAttach=(a == null  ? 0 : this.parseIntStr$S(a));
a=this.atts.get$O("endattach");
var endAttach=(a == null  ? 0 : this.parseIntStr$S(a));
var s=this.atts.get$O("order");
var disp=this.atts.get$O("display");
var disp2=this.atts.get$O("display2");
var order=131071;
var invertEnds=false;
if (disp == null ) {
if (s == null ) {
order=1;
} else if (s.equals$O("1.5")) {
order=515;
} else {
if (s.indexOf$S(".") > 0 && !"Dash".equals$O(disp2) ) {
s=s.substring$I$I(0, s.indexOf$S("."));
}order=$I$(2).getBondOrderFromString$S(s);
}} else if (disp.equals$O("WedgeBegin")) {
order=1025;
} else if (disp.equals$O("Hash") || disp.equals$O("WedgedHashBegin") ) {
order=1041;
} else if (disp.equals$O("WedgeEnd")) {
invertEnds=true;
order=1025;
} else if (disp.equals$O("WedgedHashEnd")) {
invertEnds=true;
order=1041;
} else if (disp.equals$O("Wavy")) {
order=1057;
}if (order == 131071) {
System.err.println$S("XmlChemDrawReader ignoring bond type " + s);
return;
}var b=(invertEnds ? Clazz.new_($I$(11,1).c$$S$S$I,[this, null, atom2, atom1, order]) : Clazz.new_($I$(11,1).c$$S$S$I,[this, null, atom1, atom2, order]));
var node1=this.asc.atoms[b.atomIndex1];
var node2=this.asc.atoms[b.atomIndex2];
if (order == 1057) {
if (!this.nostereo.contains$O(node1)) this.nostereo.add$O(node1);
if (!this.nostereo.contains$O(node2)) this.nostereo.add$O(node2);
}if (node1.hasMultipleAttachments) {
node1.attachedAtom=node2;
return;
} else if (node2.hasMultipleAttachments) {
node2.attachedAtom=node1;
return;
}if (node1.isFragment && beginAttach == 0 ) beginAttach=1;
if (node2.isFragment && endAttach == 0 ) endAttach=1;
if (beginAttach > 0) {
(invertEnds ? node2 : node1).addAttachedAtom$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDBond$I(b, beginAttach);
}if (endAttach > 0) {
(invertEnds ? node1 : node2).addAttachedAtom$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDBond$I(b, endAttach);
}if (node1.isExternalPt) {
node1.internalBond=b;
node2.parentNode.addExternalPoint$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDNode(node2);
}if (node2.isExternalPt) {
node2.internalBond=b;
node1.parentNode.addExternalPoint$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDNode(node1);
}this.asc.addBondNoCheck$org_jmol_adapter_smarter_Bond(b);
}, p$1);

Clazz.newMeth(C$, 'setAtom$S',  function (key) {
var xyz=this.atts.get$O(key);
var tokens=$I$(8).getTokens$S(xyz);
var x=this.parseDoubleStr$S(tokens[0]);
var y=-this.parseDoubleStr$S(tokens[1]);
var z=(key === "xyz"  ? this.parseDoubleStr$S(tokens[2]) : 0);
if (x < this.minX ) this.minX=x;
if (x > this.maxX ) this.maxX=x;
if (y < this.minY ) this.minY=y;
if (y > this.maxY ) this.maxY=y;
if (z < this.minZ ) this.minZ=z;
if (z > this.maxZ ) this.maxZ=z;
this.atom.set$D$D$D(x, y, z);
}, p$1);

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
p$1.fixConnections.apply(this, []);
p$1.fixInvalidAtoms.apply(this, []);
p$1.centerAndScale.apply(this, []);
this.parent.appendLoadNote$S((this.isCDX ? "CDX: " : "CDXML: ") + (this.is2D ? "2D" : "3D"));
this.asc.setInfo$S$O("minimize3D", Boolean.valueOf$Z(!this.is2D && !this.noHydrogens ));
this.asc.setInfo$S$O("is2D", Boolean.valueOf$Z(this.is2D));
if (this.is2D) {
this.optimize2D=!this.noHydrogens && !this.noMinimize ;
this.asc.setModelInfoForSet$S$O$I("dimension", "2D", this.asc.iSet);
this.set2D$();
}});

Clazz.newMeth(C$, 'fixConnections',  function () {
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
if (a.isFragment || a.hasMultipleAttachments ) a.fixAttachments$();
}
for (var i=0, n=this.asc.bondCount; i < n; i++) {
var b=this.asc.bonds[i];
if (b == null ) {
continue;
}var a1=this.asc.atoms[b.atomIndex1];
var a2=this.asc.atoms[b.atomIndex2];
a1.isConnected=true;
a2.isConnected=true;
if (this.nostereo.contains$O(a1) != this.nostereo.contains$O(a2) ) {
b.order=1;
}}
}, p$1);

Clazz.newMeth(C$, 'centerAndScale',  function () {
if (this.minX > this.maxX ) return;
var sum=0;
var n=0;
var lenH=1;
for (var i=this.asc.bondCount; --i >= 0; ) {
var a1=this.asc.atoms[this.asc.bonds[i].atomIndex1];
var a2=this.asc.atoms[this.asc.bonds[i].atomIndex2];
var d=a1.distance$javajs_util_T3d(a2);
if (a1.elementNumber > 1 && a2.elementNumber > 1 ) {
sum+=d;
++n;
} else {
lenH=d;
}}
var f=(sum > 0  ? 1.45 * n / sum : lenH > 0  ? 1 / lenH : 1);
if (f > 0.5 ) f=1;
var cx=(this.maxX + this.minX) / 2;
var cy=(this.maxY + this.minY) / 2;
var cz=(this.maxZ + this.minZ) / 2;
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
a.x=(a.x - cx) * f;
a.y=(a.y - cy) * f;
a.z=(a.z - cz) * f;
}
}, p$1);

Clazz.newMeth(C$, 'fixInvalidAtoms',  function () {
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
a.atomSerial=-2147483648;
if (a.isFragment || a.isExternalPt || !a.isConnected && (!a.isValid || a.elementNumber == 6  || a.elementNumber == 0 )   ) {
this.asc.bsAtoms.clear$I(a.index);
}}
}, p$1);
var $s$ = new Int16Array(1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlChemDrawReader, "CDNode", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Atom');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isValid=true;
},1);

C$.$fields$=[['Z',['isValid','isConnected','isFragment','isExternalPt','hasMultipleAttachments','isGeneric'],'I',['intID'],'S',['warning','id','nodeType','fragment','text'],'O',['parentNode','org.jmol.adapter.readers.xml.XmlChemDrawReader.CDNode','orderedExternalPoints','javajs.util.Lst','+orderedAttachedBonds','internalBond','org.jmol.adapter.readers.xml.XmlChemDrawReader.CDBond','attachments','String[]','attachedAtom','org.jmol.adapter.readers.xml.XmlChemDrawReader.CDNode']]]

Clazz.newMeth(C$, 'c$$S$S$S$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDNode',  function (id, nodeType, fragment, parent) {
Clazz.super_(C$, this);
this.id=id;
this.fragment=fragment;
this.atomSerial=this.intID=Integer.parseInt$S(id);
this.nodeType=nodeType;
this.parentNode=parent;
this.isFragment="Fragment".equals$O(nodeType) || "Nickname".equals$O(nodeType) ;
this.isExternalPt="ExternalConnectionPoint".equals$O(nodeType);
this.isGeneric="GenericNickname".equals$O(nodeType);
}, 1);

Clazz.newMeth(C$, 'setMultipleAttachments$SA',  function (attachments) {
this.attachments=attachments;
this.hasMultipleAttachments=true;
});

Clazz.newMeth(C$, 'addExternalPoint$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDNode',  function (node) {
if (this.orderedExternalPoints == null ) this.orderedExternalPoints=Clazz.new_($I$(1,1));
var i=this.orderedExternalPoints.size$();
while (--i >= 0 && this.orderedExternalPoints.get$I(i).intID >= node.intID ){
}
this.orderedExternalPoints.add$I$O(++i, node);
});

Clazz.newMeth(C$, 'addAttachedAtom$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDBond$I',  function (bond, pt) {
if (this.orderedAttachedBonds == null ) this.orderedAttachedBonds=Clazz.new_($I$(1,1));
var i=this.orderedAttachedBonds.size$();
while (--i >= 0 && (this.orderedAttachedBonds.get$I(i)[0]).intValue$() > pt ){
}
this.orderedAttachedBonds.add$I$O(++i, Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(pt), bond]));
});

Clazz.newMeth(C$, 'fixAttachments$',  function () {
if (this.hasMultipleAttachments && this.attachedAtom != null  ) {
var order=$I$(2).getBondOrderFromString$S("partial");
var a1=this.attachedAtom.index;
for (var i=this.attachments.length; --i >= 0; ) {
var a=this.b$['org.jmol.adapter.readers.xml.XmlChemDrawReader'].asc.getAtomFromName$S(this.attachments[i]);
if (a != null ) this.b$['org.jmol.adapter.readers.xml.XmlChemDrawReader'].asc.addBondNoCheck$org_jmol_adapter_smarter_Bond(Clazz.new_($I$(3,1).c$$I$I$I,[a1, a.index, order]));
}
}if (this.orderedExternalPoints == null  || this.text == null  ) return;
var n=this.orderedExternalPoints.size$();
if (n != this.orderedAttachedBonds.size$()) {
System.err.println$S("cannot fix attachments for " + this.text);
}for (var i=0; i < n; i++) {
var a=this.orderedExternalPoints.get$I(i);
var b=this.orderedAttachedBonds.get$I(i)[1];
if (b.atomIndex2 == this.index) {
b.atomIndex2=a.index;
} else {
b.atomIndex1=a.index;
}}
});

Clazz.newMeth(C$, 'toString',  function () {
return this.id + " " + this.elementSymbol + " " + this.elementNumber + " index=" + this.index + " ext=" + this.isExternalPt + " frag=" + this.isFragment + " " + this.elementSymbol + " " + new Double(this.x).toString() + " " + new Double(this.y).toString() ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlChemDrawReader, "CDBond", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Bond');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['id1','id2']]]

Clazz.newMeth(C$, 'c$$S$S$I',  function (id1, id2, order) {
;C$.superclazz.c$$I$I$I.apply(this,[this.b$['org.jmol.adapter.readers.xml.XmlChemDrawReader'].asc.getAtomFromName$S(id1).index, this.b$['org.jmol.adapter.readers.xml.XmlChemDrawReader'].asc.getAtomFromName$S(id2).index, order]);C$.$init$.apply(this);
this.id1=id1;
this.id2=id2;
}, 1);

Clazz.newMeth(C$, 'getOtherNode$org_jmol_adapter_readers_xml_XmlChemDrawReader_CDNode',  function (a) {
return this.b$['org.jmol.adapter.readers.xml.XmlChemDrawReader'].asc.atoms[this.atomIndex1 == a.index ? this.atomIndex2 : this.atomIndex1];
});

Clazz.newMeth(C$, 'toString',  function () {
return C$.superclazz.prototype.toString.apply(this, []) + " id1=" + this.id1 + " id2=" + this.id2 ;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-10 09:37:11 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
