(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'javajs.util.PT','javajs.util.Lst','org.jmol.adapter.smarter.AtomSetCollectionReader','org.jmol.util.Logger','java.util.Hashtable']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PWmatReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.haveMagnetic=false;
this.global3=";STRESS_MASK;STRESS_EXTERNAL;PTENSOR_EXTERNAL;";
},1);

C$.$fields$=[['Z',['haveLattice','havePositions','haveMagnetic'],'I',['nAtoms'],'S',['global3']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.setHighPrecision$();
this.doApplySymmetry=true;
});

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.nAtoms == 0) {
p$1.readComments.apply(this, []);
this.setSpaceGroupName$S("P1");
this.nAtoms=$I$(1).parseInt$S(this.line);
this.setFractionalCoordinates$Z(true);
return true;
}p$1.removeComments.apply(this, []);
var lc=this.line.toLowerCase$().trim$();
if (lc.length$() == 0) return true;
if (!this.haveLattice) {
if (lc.startsWith$S("lattice")) {
p$1.readUnitCell.apply(this, []);
this.haveLattice=true;
}return true;
}if (!this.havePositions) {
if (lc.startsWith$S("position")) {
p$1.readCoordinates.apply(this, []);
this.havePositions=true;
}return true;
}if (!p$1.readDataBlock$S.apply(this, [lc])) {
this.continuing=false;
}return true;
});

Clazz.newMeth(C$, 'readComments',  function () {
}, p$1);

Clazz.newMeth(C$, 'readUnitCell',  function () {
var unitCellData=Clazz.array(Double.TYPE, [3]);
this.addExplicitLatticeVector$I$DA$I(0, this.fillDoubleArray$S$I$DA(p$1.getLine.apply(this, []), 0, unitCellData), 0);
this.addExplicitLatticeVector$I$DA$I(1, this.fillDoubleArray$S$I$DA(p$1.getLine.apply(this, []), 0, unitCellData), 0);
this.addExplicitLatticeVector$I$DA$I(2, this.fillDoubleArray$S$I$DA(p$1.getLine.apply(this, []), 0, unitCellData), 0);
}, p$1);

Clazz.newMeth(C$, 'readCoordinates',  function () {
var constraints=Clazz.new_($I$(2,1));
var haveConstraints=true;
var i=0;
while (i++ < this.nAtoms && p$1.getLine.apply(this, []) != null  ){
var tokens=this.getTokens$();
var z=Integer.parseInt$S(tokens[0]);
this.addAtomXYZSymName$SA$I$S$S(tokens, 1, $I$(3).getElementSymbol$I(z), null).elementNumber=($s$[0] = z, $s$[0]);
haveConstraints=(tokens.length >= 7) && haveConstraints ;
if (haveConstraints) constraints.addLast$O(Clazz.array(Double.TYPE, -1, [Double.parseDouble$S(tokens[4]), Double.parseDouble$S(tokens[5]), Double.parseDouble$S(tokens[6])]));
}
var cx=Clazz.array(Double.TYPE, [this.nAtoms]);
var cy=Clazz.array(Double.TYPE, [this.nAtoms]);
var cz=Clazz.array(Double.TYPE, [this.nAtoms]);
var c=Clazz.array(Double.TYPE, -1, [1, 1, 1]);
for (i=this.nAtoms; --i >= 0; ) {
if (haveConstraints) c=constraints.get$I(i);
cx[i]=c[0];
cy[i]=c[1];
cz[i]=c[2];
}
p$1.setVectors$S$DA$DA$DA$I.apply(this, ["constraints", cx, cy, cz, this.nAtoms]);
}, p$1);

Clazz.newMeth(C$, 'readDataBlock$S',  function (name) {
name=p$1.trimPWPropertyNameTo$S$S.apply(this, [name, " ([,"]);
p$1.getLine.apply(this, []);
if (this.line == null ) return false;
var tokens=this.getTokens$();
switch (tokens.length) {
case 1:
case 2:
case 3:
p$1.readItems$S$I$DA.apply(this, [name, tokens.length - 1, null]);
return true;
case 4:
p$1.readVectors$S$I$Z.apply(this, [name, 1, true]);
return true;
default:
$I$(4,"error$S",["PWmatReader block " + name.toUpperCase$() + " ignored" ]);
return false;
}
}, p$1);

Clazz.newMeth(C$, 'trimPWPropertyNameTo$S$S',  function (name, chars) {
for (var i=chars.length$(); --i >= 0; ) {
var pt=name.indexOf$I(chars.charAt$I(i));
if (pt > 0) name=name.substring$I$I(0, pt);
}
return name;
}, p$1);

Clazz.newMeth(C$, 'readItems$S$I$DA',  function (name, offset, values) {
if (name.equalsIgnoreCase$S("magnetic")) this.haveMagnetic=true;
var isGlobal=$I$(1,"isOneOf$S$S",[name.toUpperCase$(), this.global3]);
if (isGlobal) {
var lines=Clazz.array(String, [3]);
lines[0]=this.line;
lines[1]=p$1.getLine.apply(this, []);
lines[2]=p$1.getLine.apply(this, []);
var info=this.asc.getAtomSetAuxiliaryInfo$I(0);
var data=info.get$O("globalPWmatData");
if (data == null ) info.put$O$O("globalPWmatData", data=Clazz.new_($I$(5,1)));
data.put$O$O(name, lines);
} else {
name="pwm_" + name;
if (values == null ) {
values=Clazz.array(Double.TYPE, [this.nAtoms]);
} else {
p$1.getLine.apply(this, []);
}var n=0;
for (var i=0; ; ) {
var tokens=this.getTokens$();
if ((values[i]=Double.parseDouble$S(tokens[offset])) != 0 ) ++n;
if (++i == this.nAtoms) break;
p$1.getLine.apply(this, []);
}
p$1.setProperties$S$DA$I.apply(this, [name, values, n]);
}}, p$1);

Clazz.newMeth(C$, 'setProperties$S$DA$I',  function (name, values, n) {
this.asc.setAtomProperties$S$O$I$Z(name, values, this.asc.iSet, false);
$I$(4,"info$S",["PWmatReader: " + name.toUpperCase$() + " processed for " + n + " atoms" ]);
this.appendLoadNote$S("PWmatReader read property_" + name);
}, p$1);

Clazz.newMeth(C$, 'readVectors$S$I$Z',  function (name, offset, haveLine) {
if (!haveLine) p$1.getLine.apply(this, []);
var valuesX=Clazz.array(Double.TYPE, [this.nAtoms]);
var valuesY=Clazz.array(Double.TYPE, [this.nAtoms]);
var valuesZ=Clazz.array(Double.TYPE, [this.nAtoms]);
var n=0;
for (var i=0; ; ) {
var tokens=this.getTokens$();
if ((((valuesX[i]=Double.parseDouble$S(tokens[offset])) == 0  ? 0 : 1) | ((valuesY[i]=Double.parseDouble$S(tokens[offset + 1])) == 0  ? 0 : 1) | ((valuesZ[i]=Double.parseDouble$S(tokens[offset + 2])) == 0  ? 0 : 1) ) != 0) ++n;
if (++i == this.nAtoms) break;
p$1.getLine.apply(this, []);
}
p$1.setVectors$S$DA$DA$DA$I.apply(this, [name, valuesX, valuesY, valuesZ, n]);
}, p$1);

Clazz.newMeth(C$, 'getLine',  function () {
this.rd$();
return p$1.removeComments.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'removeComments',  function () {
if (this.line != null ) {
var pt=this.line.indexOf$S("#");
if (pt >= 0) {
this.line=this.line.substring$I$I(0, pt).trim$();
}}return this.line;
}, p$1);

Clazz.newMeth(C$, 'setVectors$S$DA$DA$DA$I',  function (name, valuesX, valuesY, valuesZ, n) {
name="pwm_" + name;
this.asc.setAtomProperties$S$O$I$Z(name + "_x", valuesX, this.asc.iSet, false);
this.asc.setAtomProperties$S$O$I$Z(name + "_y", valuesY, this.asc.iSet, false);
this.asc.setAtomProperties$S$O$I$Z(name + "_z", valuesZ, this.asc.iSet, false);
$I$(4,"info$S",["PWmatReader: " + name.toUpperCase$() + " processed for " + n + " atoms" ]);
this.appendLoadNote$S("PWmatReader read property_" + name + "_x/_y/_z" );
if (name.equals$O("pwm_magnetic_xyz")) {
for (var i=0; i < this.nAtoms; i++) {
this.asc.addVibrationVector$I$D$D$D(i, valuesX[i], valuesY[i], valuesZ[i]);
}
this.addJmolScript$S("vectors 0.2;set vectorscentered");
}}, p$1);

Clazz.newMeth(C$, 'applySymmetryAndSetTrajectory$',  function () {
C$.superclazz.prototype.applySymmetryAndSetTrajectory$.apply(this, []);
if (this.nAtoms != this.asc.ac) {
this.nAtoms=this.asc.ac;
var p=this.asc.getAtomSetAuxiliaryInfoValue$I$S(this.asc.iSet, "atomProperties");
if (p != null ) {
var atoms=this.asc.atoms;
var n=(this.asc.bsAtoms == null  ? this.nAtoms : this.asc.bsAtoms.cardinality$());
var map=(n == this.nAtoms ? null : Clazz.array(Integer.TYPE, [this.nAtoms]));
if (map != null ) {
for (var j=0, k=0; j < this.nAtoms; j++) {
if (this.asc.bsAtoms.get$I(j)) map[j]=k++;
}
}for (var e, $e = p.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var key=e.getKey$();
if (key.startsWith$S("pwm_")) {
var af=e.getValue$();
var af2=Clazz.array(Double.TYPE, [n]);
for (var j=0; j < this.nAtoms; j++) {
af2[map == null  ? j : map[j]]=af[atoms[j].atomSite];
}
e.setValue$O(af2);
}}
}}});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
if (!this.haveMagnetic && this.asc.ac > 0 ) {
p$1.setProperties$S$DA$I.apply(this, ["pwm_magnetic", Clazz.array(Double.TYPE, [this.asc.ac]), this.nAtoms]);
}});
var $s$ = new Int16Array(1);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-27 08:01:50 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
