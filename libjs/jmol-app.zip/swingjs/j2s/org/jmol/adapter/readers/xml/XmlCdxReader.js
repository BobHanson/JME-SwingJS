(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},p$2={},I$=[[0,'javajs.util.Lst','org.jmol.util.Edge','org.jmol.adapter.smarter.Bond','java.util.Stack','java.util.ArrayList','java.util.HashMap','javajs.util.PT','javajs.util.BS',['org.jmol.adapter.readers.xml.XmlCdxReader','.CDNode'],'org.jmol.api.JmolAdapter','org.jmol.util.Logger',['org.jmol.adapter.readers.xml.XmlCdxReader','.CDBond']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlCdxReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.readers.xml.XmlReader');
C$.$classes$=[['CDNode',0],['CDBond',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.minX=1.7976931348623157E308;
this.minY=1.7976931348623157E308;
this.minZ=1.7976931348623157E308;
this.maxZ=-1.7976931348623157E308;
this.maxY=-1.7976931348623157E308;
this.maxX=-1.7976931348623157E308;
this.fragments=Clazz.new_($I$(4,1));
this.nodes=Clazz.new_($I$(4,1));
this.nostereo=Clazz.new_($I$(5,1));
this.objectsByID=Clazz.new_($I$(6,1));
},1);

C$.$fields$=[['Z',['no3D','isCDX'],'D',['minX','minY','minZ','maxZ','maxY','maxX'],'S',['thisFragmentID','textBuffer'],'O',['fragments','java.util.Stack','thisNode','org.jmol.adapter.readers.xml.XmlCdxReader.CDNode','nodes','java.util.Stack','nostereo','java.util.List','objectsByID','java.util.Map']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.is2D=true;
if (parent == null ) {
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(this, saxReader);
parent=this;
} else {
this.no3D=parent.checkFilterKey$S("NO3D");
this.noHydrogens=parent.noHydrogens;
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
this.filter=parent.filter;
}});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
var id=this.atts.get$O("id");
if ("fragment".equals$O(localName)) {
this.objectsByID.put$O$O(id, p$2.setFragment$S.apply(this, [id]));
return;
}if ("n".equals$O(localName)) {
this.objectsByID.put$O$O(id, p$2.setNode$S.apply(this, [id]));
return;
}if ("b".equals$O(localName)) {
this.objectsByID.put$O$O(id, p$2.setBond$S.apply(this, [id]));
return;
}if ("t".equals$O(localName)) {
this.textBuffer="";
}if ("s".equals$O(localName)) {
this.setKeepChars$Z(true);
}});

Clazz.newMeth(C$, 'setFragment$S',  function (id) {
this.fragments.push$O(this.thisFragmentID=id);
var fragmentNode=(this.thisNode == null  || !this.thisNode.isFragment  ? null : this.thisNode);
if (fragmentNode != null ) {
fragmentNode.setInnerFragmentID$S(id);
}var s=this.atts.get$O("connectionorder");
if (s != null ) {
System.out.println$S(id + " ConnectionOrder is " + s );
this.thisNode.setConnectionOrder$SA($I$(7,"split$S$S",[s.trim$(), " "]));
}return fragmentNode;
}, p$2);

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
if ("fragment".equals$O(localName)) {
this.thisFragmentID=this.fragments.pop$();
return;
}if ("n".equals$O(localName)) {
this.thisNode=(this.nodes.size$() == 0 ? null : this.nodes.pop$());
return;
}if ("s".equals$O(localName)) {
this.textBuffer+=this.chars.toString();
}if ("t".equals$O(localName)) {
if (this.thisNode == null ) {
System.out.println$S("XmlChemDrawReader unassigned text: " + this.textBuffer);
} else {
this.thisNode.text=this.textBuffer;
if (this.atom.elementNumber == 0) {
System.err.println$S("XmlChemDrawReader: Problem with \"" + this.textBuffer + "\"" );
}if (this.thisNode.warning != null ) this.parent.appendLoadNote$S("Warning: " + this.textBuffer + " " + this.thisNode.warning );
}this.textBuffer="";
}this.setKeepChars$Z(false);
});

Clazz.newMeth(C$, 'setNode$S',  function (id) {
var nodeType=this.atts.get$O("nodetype");
if (this.asc.bsAtoms == null ) this.asc.bsAtoms=Clazz.new_($I$(8,1));
if (this.thisNode != null ) this.nodes.push$O(this.thisNode);
if ("_".equals$O(nodeType)) {
this.atom=this.thisNode=null;
return null;
}this.atom=this.thisNode=Clazz.new_($I$(9,1).c$$S$S$S$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode,[this, null, id, nodeType, this.thisFragmentID, this.thisNode]);
this.asc.addAtomWithMappedSerialNumber$org_jmol_adapter_smarter_Atom(this.atom);
this.asc.bsAtoms.set$I(this.atom.index);
var w=this.atts.get$O("warning");
if (w != null ) {
this.thisNode.warning=$I$(7).rep$S$S$S(w, "&apos;", "\'");
this.thisNode.isValid=(w.indexOf$S("ChemDraw can\'t interpret") < 0);
}var element=this.atts.get$O("element");
var s=this.atts.get$O("genericnickname");
if (s != null ) {
element=s;
}this.atom.elementNumber=($s$[0] = (!p$2.checkWarningOK$S.apply(this, [w]) ? 0 : element == null  ? 6 : this.parseIntStr$S(element)), $s$[0]);
element=$I$(10).getElementSymbol$I(this.atom.elementNumber);
s=this.atts.get$O("isotope");
if (s != null ) element=s + element;
this.setElementAndIsotope$org_jmol_adapter_smarter_Atom$S(this.atom, element);
s=this.atts.get$O("charge");
if (s != null ) {
this.atom.formalCharge=this.parseIntStr$S(s);
}var hasXYZ=(this.atts.containsKey$O("xyz"));
var hasXY=(this.atts.containsKey$O("p"));
if (hasXYZ && (!this.no3D || !hasXY ) ) {
this.is2D=false;
p$2.setAtom$S.apply(this, ["xyz"]);
} else if (this.atts.containsKey$O("p")) {
p$2.setAtom$S.apply(this, ["p"]);
}s=this.atts.get$O("attachments");
if (s != null ) {
System.out.println$S(id + " Attachments is " + s );
this.thisNode.setMultipleAttachments$SA($I$(7,"split$S$S",[s.trim$(), " "]));
}s=this.atts.get$O("bondordering");
if (s != null ) {
System.out.println$S(id + " BondOrdering is " + s );
this.thisNode.setBondOrdering$SA($I$(7,"split$S$S",[s.trim$(), " "]));
}if ($I$(11).debugging) $I$(11,"info$S",["XmlChemDraw id=" + id + " " + element + " " + this.atom ]);
return this.thisNode;
}, p$2);

Clazz.newMeth(C$, 'checkWarningOK$S',  function (warning) {
return (warning == null  || warning.indexOf$S("valence") >= 0  || warning.indexOf$S("very close") >= 0  || warning.indexOf$S("two identical colinear bonds") >= 0 );
}, p$2);

Clazz.newMeth(C$, 'setBond$S',  function (id) {
var atom1=this.atts.get$O("b");
var atom2=this.atts.get$O("e");
var a=this.atts.get$O("beginattach");
var beginAttach=(a == null  ? 0 : this.parseIntStr$S(a));
a=this.atts.get$O("endattach");
var endAttach=(a == null  ? 0 : this.parseIntStr$S(a));
var s=this.atts.get$O("order");
var disp=this.atts.get$O("display");
var disp2=this.atts.get$O("display2");
var order=131071;
var invertEnds=false;
if (disp == null ) {
if (s == null ) {
order=1;
} else if (s.equals$O("1.5")) {
order=515;
} else {
if (s.indexOf$S(".") > 0 && !"Dash".equals$O(disp2) ) {
s=s.substring$I$I(0, s.indexOf$S("."));
}order=$I$(2).getBondOrderFromString$S(s);
}} else if (disp.equals$O("WedgeBegin")) {
order=1025;
} else if (disp.equals$O("Hash") || disp.equals$O("WedgedHashBegin") ) {
order=1041;
} else if (disp.equals$O("WedgeEnd")) {
invertEnds=true;
order=1025;
} else if (disp.equals$O("WedgedHashEnd")) {
invertEnds=true;
order=1041;
} else if (disp.equals$O("Wavy")) {
order=1057;
}if (order == 131071) {
System.err.println$S("XmlChemDrawReader ignoring bond type " + s);
return null;
}var b=(invertEnds ? Clazz.new_($I$(12,1).c$$S$S$S$I,[this, null, id, atom2, atom1, order]) : Clazz.new_($I$(12,1).c$$S$S$S$I,[this, null, id, atom1, atom2, order]));
var node1=this.asc.atoms[b.atomIndex1];
var node2=this.asc.atoms[b.atomIndex2];
if (order == 1057) {
if (!this.nostereo.contains$O(node1)) this.nostereo.add$O(node1);
if (!this.nostereo.contains$O(node2)) this.nostereo.add$O(node2);
}if (node1.hasMultipleAttachments) {
node1.attachedAtom=node2;
return b;
} else if (node2.hasMultipleAttachments) {
node2.attachedAtom=node1;
return b;
}if (node1.isFragment && beginAttach == 0 ) beginAttach=1;
if (node2.isFragment && endAttach == 0 ) endAttach=1;
if (beginAttach > 0) {
(invertEnds ? node2 : node1).addAttachedAtom$org_jmol_adapter_readers_xml_XmlCdxReader_CDBond$I(b, beginAttach);
}if (endAttach > 0) {
(invertEnds ? node1 : node2).addAttachedAtom$org_jmol_adapter_readers_xml_XmlCdxReader_CDBond$I(b, endAttach);
}if (node1.isExternalPt) {
node1.setInternalAtom$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode(node2);
}if (node2.isExternalPt) {
node2.setInternalAtom$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode(node1);
}this.asc.addBondNoCheck$org_jmol_adapter_smarter_Bond(b);
return b;
}, p$2);

Clazz.newMeth(C$, 'setAtom$S',  function (key) {
var xyz=this.atts.get$O(key);
var tokens=$I$(7).getTokens$S(xyz);
var x=this.parseDoubleStr$S(tokens[0]);
var y=-this.parseDoubleStr$S(tokens[1]);
var z=(key === "xyz"  ? this.parseDoubleStr$S(tokens[2]) : 0);
if (x < this.minX ) this.minX=x;
if (x > this.maxX ) this.maxX=x;
if (y < this.minY ) this.minY=y;
if (y > this.maxY ) this.maxY=y;
if (z < this.minZ ) this.minZ=z;
if (z > this.maxZ ) this.maxZ=z;
this.atom.set$D$D$D(x, y, z);
}, p$2);

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
p$2.fixConnections.apply(this, []);
p$2.fixInvalidAtoms.apply(this, []);
p$2.centerAndScale.apply(this, []);
this.parent.appendLoadNote$S((this.isCDX ? "CDX: " : "CDXML: ") + (this.is2D ? "2D" : "3D"));
this.asc.setInfo$S$O("minimize3D", Boolean.valueOf$Z(!this.is2D && !this.noHydrogens ));
this.asc.setInfo$S$O("is2D", Boolean.valueOf$Z(this.is2D));
if (this.is2D) {
this.optimize2D=!this.noHydrogens && !this.noMinimize ;
this.asc.setModelInfoForSet$S$O$I("dimension", "2D", this.asc.iSet);
this.set2D$();
}});

Clazz.newMeth(C$, 'fixConnections',  function () {
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
if (a.isFragment || a.hasMultipleAttachments ) a.fixAttachments$();
}
for (var i=0, n=this.asc.bondCount; i < n; i++) {
var b=this.asc.bonds[i];
if (b == null ) {
continue;
}var a1=this.asc.atoms[b.atomIndex1];
var a2=this.asc.atoms[b.atomIndex2];
a1.isConnected=true;
a2.isConnected=true;
if (this.nostereo.contains$O(a1) != this.nostereo.contains$O(a2) ) {
b.order=1;
}}
}, p$2);

Clazz.newMeth(C$, 'centerAndScale',  function () {
if (this.minX > this.maxX ) return;
var sum=0;
var n=0;
var lenH=1;
for (var i=this.asc.bondCount; --i >= 0; ) {
var a1=this.asc.atoms[this.asc.bonds[i].atomIndex1];
var a2=this.asc.atoms[this.asc.bonds[i].atomIndex2];
var d=a1.distance$javajs_util_T3d(a2);
if (a1.elementNumber > 1 && a2.elementNumber > 1 ) {
sum+=d;
++n;
} else {
lenH=d;
}}
var f=(sum > 0  ? 1.45 * n / sum : lenH > 0  ? 1 / lenH : 1);
if (f > 0.5 ) f=1;
var cx=(this.maxX + this.minX) / 2;
var cy=(this.maxY + this.minY) / 2;
var cz=(this.maxZ + this.minZ) / 2;
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
a.x=(a.x - cx) * f;
a.y=(a.y - cy) * f;
a.z=(a.z - cz) * f;
}
}, p$2);

Clazz.newMeth(C$, 'fixInvalidAtoms',  function () {
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
a.atomSerial=-2147483648;
if (a.isFragment || a.isExternalPt || !a.isConnected && (!a.isValid || a.elementNumber == 6  || a.elementNumber == 0 )   ) {
this.asc.bsAtoms.clear$I(a.index);
}}
}, p$2);
var $s$ = new Int16Array(1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlCdxReader, "CDNode", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Atom');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isValid=true;
},1);

C$.$fields$=[['Z',['isValid','isConnected','isExternalPt','isFragment','hasMultipleAttachments','isGeneric'],'I',['intID'],'S',['warning','id','nodeType','outerFragmentID','innerFragmentID','text'],'O',['parentNode','org.jmol.adapter.readers.xml.XmlCdxReader.CDNode','orderedConnectionBonds','javajs.util.Lst','internalAtom','org.jmol.adapter.readers.xml.XmlCdxReader.CDNode','orderedExternalPoints','javajs.util.Lst','attachments','String[]','+bondOrdering','+connectionOrder','attachedAtom','org.jmol.adapter.readers.xml.XmlCdxReader.CDNode']]]

Clazz.newMeth(C$, 'c$$S$S$S$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode',  function (id, nodeType, fragmentID, parent) {
Clazz.super_(C$, this);
this.id=id;
this.outerFragmentID=fragmentID;
this.atomSerial=this.intID=Integer.parseInt$S(id);
this.nodeType=nodeType;
this.parentNode=parent;
this.isFragment="Fragment".equals$O(nodeType) || "Nickname".equals$O(nodeType) ;
this.isExternalPt="ExternalConnectionPoint".equals$O(nodeType);
this.isGeneric="GenericNickname".equals$O(nodeType);
}, 1);

Clazz.newMeth(C$, 'setInnerFragmentID$S',  function (id) {
this.innerFragmentID=id;
});

Clazz.newMeth(C$, 'setBondOrdering$SA',  function (bondOrdering) {
this.bondOrdering=bondOrdering;
});

Clazz.newMeth(C$, 'setConnectionOrder$SA',  function (connectionOrder) {
this.connectionOrder=connectionOrder;
});

Clazz.newMeth(C$, 'setMultipleAttachments$SA',  function (attachments) {
this.attachments=attachments;
this.hasMultipleAttachments=true;
});

Clazz.newMeth(C$, 'addExternalPoint$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode',  function (externalPoint) {
if (this.orderedExternalPoints == null ) this.orderedExternalPoints=Clazz.new_($I$(1,1));
var i=this.orderedExternalPoints.size$();
while (--i >= 0 && this.orderedExternalPoints.get$I(i).intID >= externalPoint.internalAtom.intID ){
}
this.orderedExternalPoints.add$I$O(++i, externalPoint);
});

Clazz.newMeth(C$, 'setInternalAtom$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode',  function (a) {
this.internalAtom=a;
if (this.parentNode == null ) {
} else {
this.parentNode.addExternalPoint$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode(this);
}});

Clazz.newMeth(C$, 'addAttachedAtom$org_jmol_adapter_readers_xml_XmlCdxReader_CDBond$I',  function (bond, pt) {
if (this.orderedConnectionBonds == null ) this.orderedConnectionBonds=Clazz.new_($I$(1,1));
var i=this.orderedConnectionBonds.size$();
while (--i >= 0 && (this.orderedConnectionBonds.get$I(i)[0]).intValue$() > pt ){
}
this.orderedConnectionBonds.add$I$O(++i, Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(pt), bond]));
});

Clazz.newMeth(C$, 'fixAttachments$',  function () {
if (this.hasMultipleAttachments && this.attachedAtom != null  ) {
var order=$I$(2).getBondOrderFromString$S("partial");
var a1=this.attachedAtom.index;
for (var i=this.attachments.length; --i >= 0; ) {
var a=this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].objectsByID.get$O(this.attachments[i]);
if (a != null ) this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].asc.addBondNoCheck$org_jmol_adapter_smarter_Bond(Clazz.new_($I$(3,1).c$$I$I$I,[a1, a.index, order]));
}
}if (this.orderedExternalPoints == null  || this.text == null  ) return;
var n=this.orderedExternalPoints.size$();
if (n != this.orderedConnectionBonds.size$()) {
System.err.println$S("XmlCdxReader cannot fix attachments for fragment " + this.text);
return;
}System.out.println$S("XmlCdxReader attaching fragment " + this.outerFragmentID + " " + this.text );
if (this.bondOrdering == null ) {
this.bondOrdering=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.bondOrdering[i]=(this.orderedConnectionBonds.get$I(i)[1]).id;
}
}if (this.connectionOrder == null ) {
this.connectionOrder=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.connectionOrder[i]=this.orderedExternalPoints.get$I(i).id;
}
}for (var i=0; i < n; i++) {
var b=this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].objectsByID.get$O(this.bondOrdering[i]);
var pt=this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].objectsByID.get$O(this.connectionOrder[i]);
var a=pt.internalAtom;
p$1.updateExternalBond$org_jmol_adapter_readers_xml_XmlCdxReader_CDBond$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode.apply(this, [b, a]);
}
});

Clazz.newMeth(C$, 'updateExternalBond$org_jmol_adapter_readers_xml_XmlCdxReader_CDBond$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode',  function (bond2f, intAtom) {
if (bond2f.atomIndex2 == this.index) {
bond2f.atomIndex2=intAtom.index;
} else if (bond2f.atomIndex1 == this.index) {
bond2f.atomIndex1=intAtom.index;
} else {
System.err.println$S("XmlCdxReader attachment failed! " + intAtom + " " + bond2f );
}}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
return "[CDNode " + this.id + " " + this.elementSymbol + " " + this.elementNumber + " index=" + this.index + " ext=" + this.isExternalPt + " frag=" + this.isFragment + " " + this.elementSymbol + " " + new Double(this.x).toString() + " " + new Double(this.y).toString() + "]" ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlCdxReader, "CDBond", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Bond');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['id','id1','id2']]]

Clazz.newMeth(C$, 'c$$S$S$S$I',  function (id, id1, id2, order) {
;C$.superclazz.c$$I$I$I.apply(this,[(this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].objectsByID.get$O(id1)).index, (this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].objectsByID.get$O(id2)).index, order]);C$.$init$.apply(this);
this.id=id;
this.id1=id1;
this.id2=id2;
}, 1);

Clazz.newMeth(C$, 'getOtherNode$org_jmol_adapter_readers_xml_XmlCdxReader_CDNode',  function (a) {
return this.b$['org.jmol.adapter.readers.xml.XmlCdxReader'].asc.atoms[this.atomIndex1 == a.index ? this.atomIndex2 : this.atomIndex1];
});

Clazz.newMeth(C$, 'toString',  function () {
return "[CDBond " + this.id + " id1=" + this.id1 + " id2=" + this.id2 + C$.superclazz.prototype.toString.apply(this, []) + "]" ;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-27 08:01:47 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
