(function(){var P$=Clazz.newPackage("org.jmol.modelset"),p$1={};
/*c*/var C$=Clazz.newClass(P$, "AtomIteratorWithinModelSet", null, 'org.jmol.modelset.AtomIteratorWithinModel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['distance'],'O',['bsModels','javajs.util.BS','center','javajs.util.T3d']]]

Clazz.newMeth(C$, 'c$$javajs_util_BS',  function (bsModels) {
Clazz.super_(C$, this);
this.bsModels=bsModels;
}, 1);

Clazz.newMeth(C$, 'setCenter$javajs_util_T3d$D',  function (center, distance) {
this.center=center;
this.distance=distance;
p$1.set$I.apply(this, [0]);
});

Clazz.newMeth(C$, 'set$I',  function (iModel) {
if ((this.modelIndex=this.bsModels.nextSetBit$I(iModel)) < 0 || (this.cubeIterator=this.bspf.getCubeIterator$I(this.modelIndex)) == null  ) return false;
this.setCenter2$javajs_util_T3d$D(this.center, this.distance);
return true;
}, p$1);

Clazz.newMeth(C$, 'hasNext$',  function () {
if (this.hasNext2$()) return true;
if (!p$1.set$I.apply(this, [this.modelIndex + 1])) return false;
return this.hasNext$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-12 13:55:32 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
