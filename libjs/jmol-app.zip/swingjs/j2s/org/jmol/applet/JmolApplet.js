(function(){var P$=Clazz.newPackage("org.jmol.applet"),p$1={},I$=[[0,'java.awt.Color','org.jmol.api.Interface','org.jmol.util.Logger','javajs.util.PT','javajs.util.SB']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JmolApplet", null, 'javax.swing.JApplet', 'org.jmol.api.JmolAppletInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isSigned=true;
this.needToCompleteInitialization=true;
},1);

C$.$fields$=[['Z',['isSigned','needToCompleteInitialization'],'O',['jmol','org.jmol.applet.Jmol','bgcolor','java.awt.Color']]
,['O',['colorNames','String[]','colors','java.awt.Color[]']]]

Clazz.newMeth(C$, ['destroy$','destroy'],  function () {
try {
(this.jmol).destroy$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.jmol=null;
C$.superclazz.prototype.destroy$.apply(this, []);
});

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, ['isSigned$','isSigned'],  function () {
System.out.println$S("appletwrapper2 isSigned = " + this.isSigned);
return this.isSigned;
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'],  function () {
return (this.jmol != null  ? (this.jmol).getAppletInfo$() : null);
});

Clazz.newMeth(C$, ['init$','init'],  function () {
try {
this.jmol=$I$(2).getOption$S$org_jmol_viewer_Viewer$S("applet.Jmol", null, null);
this.jmol.setApplet$O$Z(this, this.isSigned);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(3).errorEx$S$Throwable("Could not instantiate applet", e);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, ['update$java_awt_Graphics','update'],  function (g) {
this.jmol.update$java_awt_Graphics(g);
if (this.jmol != null ) {
return;
}var dim=this.getSize$();
if (this.needToCompleteInitialization) p$1.completeInitialization$java_awt_Graphics$java_awt_Dimension.apply(this, [g, dim]);
g.setColor$java_awt_Color(this.bgcolor);
g.fillRect$I$I$I$I(0, 0, dim.width, dim.height);
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'],  function (g) {
if (this.jmol != null ) {
this.jmol.paint$java_awt_Graphics(g);
return;
}this.update$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['handleEvent$java_awt_Event','handleEvent'],  function (e) {
if (this.jmol != null ) return (this.jmol).handleEvent$java_awt_Event(e);
return false;
});

Clazz.newMeth(C$, 'completeInitialization$java_awt_Graphics$java_awt_Dimension',  function (g, dim) {
this.needToCompleteInitialization=false;
var bgcolorName=this.getParameter$S("boxbgcolor");
if (bgcolorName == null ) bgcolorName=this.getParameter$S("bgcolor");
this.bgcolor=p$1.getColorFromName$S.apply(this, [bgcolorName]);
return this.isSigned=true;
}, p$1);

Clazz.newMeth(C$, 'getColorFromName$S',  function (strColor) {
if (strColor != null ) {
if (strColor.length$() == 7 && strColor.charAt$I(0) == "#" ) {
try {
var red=$I$(4,"parseIntRadix$S$I",[strColor.substring$I$I(1, 3), 16]);
var grn=$I$(4,"parseIntRadix$S$I",[strColor.substring$I$I(3, 5), 16]);
var blu=$I$(4,"parseIntRadix$S$I",[strColor.substring$I$I(5, 7), 16]);
return Clazz.new_($I$(1,1).c$$I$I$I,[red, grn, blu]);
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
} else {
throw e;
}
}
} else {
strColor=strColor.toLowerCase$().intern$();
for (var i=C$.colorNames.length; --i >= 0; ) if (strColor == C$.colorNames[i]) return C$.colors[i];

}}return $I$(1).black;
}, p$1);

Clazz.newMeth(C$, ['setCallback$S$O','setCallback'],  function (name, callbackObject) {
if (this.jmol != null ) (this.jmol).setCallback$S$O(name, callbackObject);
});

Clazz.newMeth(C$, ['getPropertyAsString$S','getPropertyAsString'],  function (infoType) {
return (this.jmol == null  ? null : "" + (this.jmol).getPropertyAsString$S("" + infoType));
});

Clazz.newMeth(C$, ['getPropertyAsString$S$S','getPropertyAsString'],  function (infoType, paramInfo) {
return (this.jmol == null  ? null : "" + (this.jmol).getPropertyAsString$S$S("" + infoType, "" + paramInfo));
});

Clazz.newMeth(C$, ['getPropertyAsJSON$S','getPropertyAsJSON'],  function (infoType) {
return (this.jmol == null  ? null : "" + (this.jmol).getPropertyAsJSON$S("" + infoType));
});

Clazz.newMeth(C$, ['getPropertyAsJSON$S$S','getPropertyAsJSON'],  function (infoType, paramInfo) {
return (this.jmol == null  ? null : "" + (this.jmol).getPropertyAsJSON$S$S("" + infoType, "" + paramInfo));
});

Clazz.newMeth(C$, ['getJSpecViewProperty$S','getJSpecViewProperty'],  function (infoType) {
return null;
});

Clazz.newMeth(C$, ['getProperty$S$S','getProperty'],  function (infoType, paramInfo) {
return (this.jmol == null  ? null : (this.jmol).getProperty$S$S("" + infoType, "" + paramInfo));
});

Clazz.newMeth(C$, ['getProperty$S','getProperty'],  function (infoType) {
return (this.jmol == null  ? null : (this.jmol).getProperty$S("" + infoType));
});

Clazz.newMeth(C$, ['loadInlineArray$SA$S$Z','loadInlineArray'],  function (strModels, script, isAppend) {
if (this.jmol == null  || strModels == null   || strModels.length == 0 ) return null;
var s="" + strModels[0];
if (s.indexOf$I("\n") >= 0 || s.indexOf$I("\r") >= 0 ) {
var converted=Clazz.array(String, [strModels.length]);
for (var i=0; i < strModels.length; ++i) converted[i]="" + strModels[i];

return (this.jmol).loadInlineArray$SA$S$Z(converted, "" + script, isAppend);
}var sb=Clazz.new_($I$(5,1));
for (var i=0; i < strModels.length; ++i) sb.append$S(strModels[i]).appendC$C("\n");

return (this.jmol).loadInlineString$S$S$Z(sb.toString(), "" + script, isAppend);
});

Clazz.newMeth(C$, ['loadInlineString$S$S$Z','loadInlineString'],  function (strModel, script, isAppend) {
return (this.jmol == null  ? null : (this.jmol).loadInlineString$S$S$Z("" + strModel, "" + script, isAppend));
});

Clazz.newMeth(C$, ['loadInline$S','loadInline'],  function (strModel) {
return (this.jmol == null  ? null : (this.jmol).loadInline$S("" + strModel));
});

Clazz.newMeth(C$, ['loadInline$S$S','loadInline'],  function (strModel, script) {
return (this.jmol == null  ? null : (this.jmol).loadInline$S$S("" + strModel, "" + script));
});

Clazz.newMeth(C$, ['loadInline$SA','loadInline'],  function (strModels) {
return (this.jmol == null  ? null : (this.jmol).loadInline$SA(strModels));
});

Clazz.newMeth(C$, ['loadInline$SA$S','loadInline'],  function (strModels, script) {
return (this.jmol == null  ? null : (this.jmol).loadInline$SA$S(strModels, script));
});

Clazz.newMeth(C$, ['loadDOMNode$O','loadDOMNode'],  function (DOMNode) {
return (this.jmol == null  ? null : (this.jmol).loadDOMNode$O(DOMNode));
});

Clazz.newMeth(C$, ['script$S','script'],  function (script) {
if (this.jmol != null ) (this.jmol).script$S("" + script);
});

Clazz.newMeth(C$, ['syncScript$S','syncScript'],  function (script) {
if (this.jmol != null ) (this.jmol).syncScript$S("" + script);
});

Clazz.newMeth(C$, ['setStereoGraphics$Z','setStereoGraphics'],  function (isStereo) {
return (this.jmol == null  ? null : (this.jmol).setStereoGraphics$Z(isStereo));
});

Clazz.newMeth(C$, ['scriptNoWait$S','scriptNoWait'],  function (script) {
if (this.jmol != null ) return "" + ((this.jmol).scriptNoWait$S("" + script));
return null;
});

Clazz.newMeth(C$, ['scriptCheck$S','scriptCheck'],  function (script) {
if (this.jmol != null ) return "" + ((this.jmol).scriptCheck$S("" + script));
return null;
});

Clazz.newMeth(C$, ['scriptWait$S','scriptWait'],  function (script) {
if (this.jmol != null ) return "" + ((this.jmol).scriptWait$S("" + script));
return null;
});

Clazz.newMeth(C$, ['scriptWait$S$S','scriptWait'],  function (script, statusParams) {
if (statusParams == null ) statusParams="";
if (this.jmol != null ) return "" + ((this.jmol).scriptWait$S$S("" + script, statusParams));
return null;
});

Clazz.newMeth(C$, ['scriptWaitOutput$S','scriptWaitOutput'],  function (script) {
if (this.jmol != null ) return "" + ((this.jmol).scriptWaitOutput$S("" + script));
return null;
});

Clazz.newMeth(C$, ['registerApplet$S$S','registerApplet'],  function (id, fullName) {
var applet=this.getAppletContext$().getApplet$S(id);
if (applet == null ) System.out.println$S("could not find " + id);
this.register$S$org_jmol_api_JmolSyncInterface(fullName, applet);
});

Clazz.newMeth(C$, ['register$S$org_jmol_api_JmolSyncInterface','register'],  function (id, jsi) {
if (this.jmol != null ) (this.jmol).register$S$org_jmol_api_JmolSyncInterface(id, jsi);
});

Clazz.newMeth(C$, ['getModelIndexFromId$S','getModelIndexFromId'],  function (id) {
return (this.jmol == null  ? -2147483648 : (this.jmol).getModelIndexFromId$S(id));
});

Clazz.newMeth(C$, ['notifyAudioEnded$O','notifyAudioEnded'],  function (htParams) {
if (this.jmol != null ) (this.jmol).notifyAudioEnded$O(htParams);
});

C$.$static$=function(){C$.$static$=0;
C$.colorNames=Clazz.array(String, -1, ["aqua", "black", "blue", "fuchsia", "gray", "green", "lime", "maroon", "navy", "olive", "purple", "red", "silver", "teal", "white", "yellow"]);
C$.colors=Clazz.array($I$(1), -1, [$I$(1).cyan, $I$(1).black, $I$(1).blue, $I$(1).magenta, $I$(1).gray, Clazz.new_($I$(1,1).c$$I$I$I,[0, 128, 0]), $I$(1).green, Clazz.new_($I$(1,1).c$$I$I$I,[128, 0, 0]), Clazz.new_($I$(1,1).c$$I$I$I,[0, 0, 128]), Clazz.new_($I$(1,1).c$$I$I$I,[128, 128, 0]), Clazz.new_($I$(1,1).c$$I$I$I,[128, 0, 128]), $I$(1).red, $I$(1).lightGray, Clazz.new_($I$(1,1).c$$I$I$I,[0, 128, 128]), $I$(1).white, $I$(1).yellow]);
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-27 08:01:46 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
