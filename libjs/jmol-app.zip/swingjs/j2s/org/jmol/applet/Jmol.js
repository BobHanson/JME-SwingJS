(function(){var P$=Clazz.newPackage("org.jmol.applet"),p$1={},I$=[[0,'org.jmol.util.GenericApplet','org.jmol.awt.FileDropper','java.util.Hashtable','javax.swing.UIManager','org.jmol.util.Logger','netscape.javascript.JSObject','org.jmol.c.CBK','java.awt.Dimension','java.awt.Color','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Jmol", null, 'org.jmol.util.GenericApplet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isUpdating','showPaintTime'],'I',['timeLast','timeCount','timeTotal','lastMotionEventNumber'],'J',['timeBegin'],'O',['dropper','org.jmol.awt.FileDropper','applet','javax.swing.JApplet']]
,['O',['jsutil','swingjs.api.JSUtilI']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'setApplet$O$Z',  function (a, isSigned) {
this.appletObject=a;
this.applet=a;
this.isSigned=isSigned;
this.init$O(this.appletObject);
if (isSigned) {
try {
this.dropper=Clazz.new_($I$(2,1).c$$org_jmol_api_JmolStatusListener$org_jmol_viewer_Viewer$org_jmol_api_JmolDropEditor,[null, this.viewer, null]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$O(e);
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics',  function (g) {
p$1.update$java_awt_Graphics$S.apply(this, [g, "paint "]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
p$1.update$java_awt_Graphics$S.apply(this, [g, "update"]);
});

Clazz.newMeth(C$, 'destroy$',  function () {
C$.superclazz.prototype.destroy$.apply(this, []);
if (this.dropper != null ) {
this.dropper.dispose$();
this.dropper=null;
}System.out.println$S("Jmol applet " + this.fullName + " destroyed" );
});

Clazz.newMeth(C$, 'setStereoGraphics$Z',  function (isStereo) {
return (isStereo ? this.applet.getGraphics$() : null);
});

Clazz.newMeth(C$, 'initOptions$',  function () {
{
var ms=this.getJmolParameter$S("mayscript");
if (ms == null ) ms=this.getJmolParameter$S("allowjavascript");
this.mayScript=(ms != null ) && (!ms.equalsIgnoreCase$S("false")) ;
var base=this.applet.getDocumentBase$();
this.documentBase=(base == null  ? this.getValue$S$S("documentBase", null) : base.toString());
base=this.applet.getCodeBase$();
this.codeBase=(base == null  ? this.getValue$S$S("codePath", this.getValue$S$S("codeBase", null)) : base.toString());
if (this.codeBase != null  && !this.codeBase.endsWith$S("/") ) this.codeBase+="/";
this.vwrOptions=Clazz.new_($I$(3,1));
this.isSigned=true;
if (this.isSigned) p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "signedApplet", Boolean.TRUE]);
if (this.getBooleanValue$S$Z("useCommandThread", this.isSigned && !$I$(1).isJS )) p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "useCommandThread", Boolean.TRUE]);
var options="";
if (this.isSigned && this.getBooleanValue$S$Z("multiTouchSparshUI-simulated", false) ) options+="-multitouch-sparshui-simulated";
 else if (this.isSigned && this.getBooleanValue$S$Z("multiTouchSparshUI", false) ) options+="-multitouch-sparshui";
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "options", options]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "display", this.applet]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "fullName", this.fullName]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "documentBase", this.documentBase]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "codePath", this.codeBase]);
if (this.getBooleanValue$S$Z("noScripting", false)) p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, null, "noScripting", Boolean.TRUE]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, "MaximumSize", "maximumSize", null]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, "JmolAppletProxy", "appletProxy", null]);
p$1.addValue$java_util_Map$S$S$O.apply(this, [this.vwrOptions, "documentLocation", null, null]);
try {
$I$(4,"setLookAndFeel$S",[$I$(4).getCrossPlatformLookAndFeelClassName$()]);
} catch (exc) {
System.err.println$S("Error loading L&F: " + exc);
}
if ($I$(5).debugging) {
$I$(5,"debug$S",["checking for jsoWindow mayScript=" + this.mayScript]);
}if (this.mayScript) {
this.mayScript=this.haveDocumentAccess=false;
var jsoWindow=null;
var jsoDocument=null;
try {
jsoWindow=$I$(6).getWindow$java_applet_Applet(this.applet);
if ($I$(5).debugging) {
$I$(5,"debug$S",["jsoWindow=" + jsoWindow]);
}if (jsoWindow == null ) {
$I$(5,"error$S",["jsoWindow returned null ... no JavaScript callbacks :-("]);
} else {
this.mayScript=true;
}jsoDocument=jsoWindow.getMember$S("document");
if (jsoDocument == null ) {
$I$(5,"error$S",["jsoDocument returned null ... no DOM manipulations :-("]);
} else {
this.haveDocumentAccess=true;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
if ($I$(5).debugging) {
$I$(5).debug$S("jsoWindow:" + jsoWindow + " jsoDocument:" + jsoDocument + " mayScript:" + this.mayScript + " haveDocumentAccess:" + this.haveDocumentAccess );
}if (!$I$(1).isJS) C$.cleanRegistry$();
}}});

Clazz.newMeth(C$, 'addValue$java_util_Map$S$S$O',  function (info, key, putKey, value) {
if (key != null ) value=this.getValue$S$S(key, null);
if (value != null ) info.put$O$O(putKey == null  ? key : putKey, value);
var haveCallback=false;
for (var item, $item = 0, $$item = $I$(7).values$(); $item<$$item.length&&((item=($$item[$item])),1);$item++) {
if (this.callbacks.get$O(item) != null ) {
haveCallback=true;
break;
}}
if (haveCallback || this.statusForm != null   || this.statusText != null  ) {
if (!this.mayScript) $I$(5).warn$S("MAYSCRIPT missing -- all applet JavaScript calls disabled");
}this.statusForm=this.getValue$S$S("StatusForm", null);
this.statusText=this.getValue$S$S("StatusText", null);
this.statusTextarea=this.getValue$S$S("StatusTextarea", null);
if (this.statusForm != null  && this.statusText != null  ) {
$I$(5).info$S("applet text status will be reported to document." + this.statusForm + "." + this.statusText );
}if (this.statusForm != null  && this.statusTextarea != null  ) {
$I$(5).info$S("applet textarea status will be reported to document." + this.statusForm + "." + this.statusTextarea );
}}, p$1);

Clazz.newMeth(C$, 'getJmolParameter$S',  function (paramName) {
return this.applet.getParameter$S(paramName);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics$S',  function (g, source) {
if (this.viewer == null ) return;
if (this.isUpdating) return;
this.isUpdating=true;
if (this.showPaintTime) p$1.startPaintClock.apply(this, []);
var size=Clazz.new_($I$(8,1));
this.applet.getSize$java_awt_Dimension(size);
this.viewer.setScreenDimension$I$I(size.width, size.height);
if (!this.isStereoSlave) this.viewer.renderScreenImageStereo$O$Z$I$I(g, true, size.width, size.height);
if (this.showPaintTime) {
p$1.stopPaintClock.apply(this, []);
p$1.showTimes$I$I$java_awt_Graphics.apply(this, [10, 10, g]);
}this.isUpdating=false;
}, p$1);

Clazz.newMeth(C$, 'startPaintClock',  function () {
this.timeBegin=System.currentTimeMillis$();
var motionEventNumber=this.viewer.getMotionEventNumber$();
if (this.lastMotionEventNumber != motionEventNumber) {
this.lastMotionEventNumber=motionEventNumber;
this.timeCount=this.timeTotal=0;
this.timeLast=-1;
}}, p$1);

Clazz.newMeth(C$, 'stopPaintClock',  function () {
var time=Long.$ival((Long.$sub(System.currentTimeMillis$(),this.timeBegin)));
if (this.timeLast != -1) {
this.timeTotal+=this.timeLast;
++this.timeCount;
}this.timeLast=time;
}, p$1);

Clazz.newMeth(C$, 'fmt$I',  function (num) {
if (num < 0) return "---";
if (num < 10) return "  " + num;
if (num < 100) return " " + num;
return "" + num;
}, p$1);

Clazz.newMeth(C$, 'showTimes$I$I$java_awt_Graphics',  function (x, y, g) {
var timeAverage=(this.timeCount == 0) ? -1 : ((this.timeTotal + (this.timeCount/2|0))/this.timeCount|0);
g.setColor$java_awt_Color($I$(9).green);
g.drawString$S$I$I(p$1.fmt$I.apply(this, [this.timeLast]) + "ms : " + p$1.fmt$I.apply(this, [timeAverage]) + "ms" , x, y);
}, p$1);

Clazz.newMeth(C$, 'resizeInnerPanel$S',  function (data) {
if ($I$(1).isJS) C$.superclazz.prototype.resizeInnerPanel$S.apply(this, [data]);
return null;
});

Clazz.newMeth(C$, 'doSendCallback$org_jmol_c_CBK$O$OA$S',  function (type, callback, data, strInfo) {
if ($I$(1).isJS) {
return C$.superclazz.prototype.doSendCallback$org_jmol_c_CBK$O$OA$S.apply(this, [type, callback, data, strInfo]);
}return null;
});

Clazz.newMeth(C$, 'doEval$S',  function (strEval) {
if ($I$(1).isJS) {
return C$.superclazz.prototype.doEval$S.apply(this, [strEval]);
}return null;
});

Clazz.newMeth(C$, 'functionXY$S$I$I',  function (functionName, nX, nY) {
if ($I$(1).isJS) {
return C$.superclazz.prototype.functionXY$S$I$I.apply(this, [functionName, nX, nY]);
}return null;
});

Clazz.newMeth(C$, 'functionXYZ$S$I$I$I',  function (functionName, nX, nY, nZ) {
if ($I$(1).isJS) {
return C$.superclazz.prototype.functionXYZ$S$I$I$I.apply(this, [functionName, nX, nY, nZ]);
}return null;
});

Clazz.newMeth(C$, 'doShowDocument$java_net_URL',  function (url) {
this.applet.getAppletContext$().showDocument$java_net_URL$S(url, "_blank");
});

Clazz.newMeth(C$, 'doShowStatus$S',  function (message) {
try {
if (!$I$(1).isJS) this.applet.showStatus$S($I$(10,"rep$S$S$S",[$I$(10).split$S$S(message, "\n")[0], "\'", "\\\'"]));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

C$.$static$=function(){C$.$static$=0;
{

self.Jmol || (Jmol = self.J2S);
Jmol._isSwingJS = true; Jmol._isAWTjs = true;
};
{
try {
if ($I$(1).isJS) {
C$.jsutil=(Clazz.forName("swingjs.JSUtil").newInstance$());
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Assets could not create swinjs.JSUtil instance");
} else {
throw e;
}
}
};
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-22 15:32:35 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
