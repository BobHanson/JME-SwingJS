(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[[0,'javajs.util.SB']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JTextField", null, 'org.jmol.awtjs.swing.JComponent');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S',  function (value) {
;C$.superclazz.c$$S.apply(this,["txtJT"]);C$.$init$.apply(this);
this.text=value;
}, 1);

Clazz.newMeth(C$, 'toHTML$',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$S("<input type=text id='" + this.id + "' class='JTextField' style='" + this.getCSSstyle$I$I(0, 0) + "' value='" + this.text + "' onkeyup	=SwingController.click(this,event)	>" );
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-12 13:55:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
