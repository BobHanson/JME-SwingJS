(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JCheckBoxMenuItem", null, 'org.jmol.awtjs.swing.JMenuItem');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S$I.apply(this,["chk", 2]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-12 13:55:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
