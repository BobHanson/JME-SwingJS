awtjs and awtjs.swing are minimal AWT/Swing-like 
implementations used by Jmol and JSpecView to 
provide consoles without any reference to AWT 
or Swing. It is a relatively simple implementation 
without many features. It does do the job for Jmol 
and JSpecView, and it is very tight, but I don't 
recommend it.

Bob Hanson  