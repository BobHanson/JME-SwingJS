(function(){var P$=Clazz.newPackage("org.jmol.inchi"),p$1={},I$=[[0,'javajs.util.PT','net.sf.jniinchi.JniInchiInput','net.sf.jniinchi.JniInchiWrapper','net.sf.jniinchi.JniInchiInputInchi','net.sf.jniinchi.JniInchiStructure','net.sf.jniinchi.JniInchiAtom','net.sf.jniinchi.INCHI_BOND_STEREO','net.sf.jniinchi.JniInchiBond','java.io.BufferedReader','java.io.StringReader','java.util.Hashtable','org.jmol.util.Elements','net.sf.jniinchi.INCHI_BOND_TYPE','javajs.util.Lst','org.jmol.smiles.SmilesAtom','org.jmol.smiles.SmilesBond','net.sf.jniinchi.INCHI_PARITY','net.sf.jniinchi.INCHI_STEREOTYPE','org.jmol.util.BSUtil','javajs.util.BS']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJNI", null, null, 'org.jmol.api.JmolInChI');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mapTet','java.util.Map','+mapPlanar']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S',  function (vwr, atoms, molData, options) {
try {
if (atoms == null  ? molData == null  : atoms.isEmpty$()) return "";
var getKey=false;
if (options == null ) options="";
var inchi=null;
var lc=options.toLowerCase$();
var getSmiles=(lc.indexOf$S("smiles") == 0);
var getStructure=(lc.indexOf$S("structure") >= 0);
var smilesOptions=(getSmiles ? options : null);
if (lc.startsWith$S("structure/")) {
inchi=options.substring$I(10);
options=lc="";
}if (Clazz.instanceOf(molData, "java.lang.String") && (molData).startsWith$S("InChI=") ) {
inchi=molData;
if (!getSmiles) {
options=lc.replace$CharSequence$CharSequence("structure", "");
getKey=true;
}} else {
options=lc;
getKey=(options.indexOf$S("key") >= 0);
if (getKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "");
options=options.replace$CharSequence$CharSequence("key", "");
}if (options.indexOf$S("fixedh?") >= 0) {
var fxd=this.getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S(vwr, atoms, molData, options.replace$C$C("?", " "));
options=$I$(1).rep$S$S$S(options, "fixedh?", "");
var std=this.getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S(vwr, atoms, molData, options);
inchi=(fxd != null  && fxd.length$() <= std.length$()  ? std : fxd);
} else {
var $in=Clazz.new_($I$(2,1).c$$S,[getSmiles ? "fixedh" : options]);
var struc;
if (atoms == null ) {
$in.setStructure$net_sf_jniinchi_JniInchiStructure(struc=C$.newJniInchiStructure$org_jmol_viewer_Viewer$O(vwr, molData));
} else {
$in.setStructure$net_sf_jniinchi_JniInchiStructure(struc=C$.newJniInchiStructureBS$org_jmol_viewer_Viewer$javajs_util_BS(vwr, atoms));
}if (getStructure) {
return C$.toString$net_sf_jniinchi_JniInchiStructure(struc);
}var out=$I$(3).getInchi$net_sf_jniinchi_JniInchiInput($in);
var msg=out.getMessage$();
if (msg != null ) System.err.println$S(msg);
inchi=out.getInchi$();
}}if (getSmiles || getStructure ) {
var $in=Clazz.new_($I$(4,1).c$$S,[inchi]);
var struc=$I$(3).getStructureFromInchi$net_sf_jniinchi_JniInchiInputInchi($in);
return (getSmiles ? p$1.getSmiles$org_jmol_viewer_Viewer$net_sf_jniinchi_JniInchiOutputStructure$S.apply(this, [vwr, struc, smilesOptions]) : p$1.getStructure$net_sf_jniinchi_JniInchiStructure.apply(this, [struc]));
}return (getKey ? $I$(3).getInchiKey$S(inchi).getKey$() : inchi);
} catch (e) {
System.out.println$O(e);
if (e.getMessage$().indexOf$S("ption") >= 0) System.out.println$S(e.getMessage$() + ": " + options.toLowerCase$() + "\n See https://www.inchi-trust.org/download/104/inchi-faq.pdf for valid options" );
 else e.printStackTrace$();
return "";
}
});

Clazz.newMeth(C$, 'getStructure$net_sf_jniinchi_JniInchiStructure',  function (mol) {
return C$.toString$net_sf_jniinchi_JniInchiStructure(mol);
}, p$1);

Clazz.newMeth(C$, 'newJniInchiStructureBS$org_jmol_viewer_Viewer$javajs_util_BS',  function (vwr, bsAtoms) {
var mol=Clazz.new_($I$(5,1));
var atoms=Clazz.array($I$(6), [bsAtoms.cardinality$()]);
var map=Clazz.array(Integer.TYPE, [bsAtoms.length$()]);
var bsBonds=vwr.ms.getBondsForSelectedAtoms$javajs_util_BS$Z(bsAtoms, false);
for (var pt=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var a=vwr.ms.at[i];
var sym=a.getElementSymbol$();
var iso=a.getIsotopeNumber$();
if (a.getElementNumber$() == 1) {
sym="H";
}mol.addAtom$net_sf_jniinchi_JniInchiAtom(atoms[pt]=Clazz.new_($I$(6,1).c$$D$D$D$S,[a.x, a.y, a.z, sym]));
atoms[pt].setCharge$I(a.getFormalCharge$());
if (iso > 0) atoms[pt].setIsotopicMass$I(iso);
map[i]=pt++;
}
var bonds=vwr.ms.bo;
for (var i=bsBonds.nextSetBit$I(0); i >= 0; i=bsBonds.nextSetBit$I(i + 1)) {
var bond=bonds[i];
var order=C$.getOrder$I(Math.max(bond.isPartial$() ? 1 : 0, bond.getCovalentOrder$()));
if (order != null ) {
var stereo;
switch (bond.getBondType$()) {
case 1041:
stereo=$I$(7).SINGLE_1DOWN;
break;
case 1025:
stereo=$I$(7).SINGLE_1UP;
break;
case 1057:
stereo=$I$(7).SINGLE_1EITHER;
break;
default:
stereo=$I$(7).NONE;
break;
}
var b=Clazz.new_([atoms[map[bond.getAtomIndex1$()]], atoms[map[bond.getAtomIndex2$()]], order, stereo],$I$(8,1).c$$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_INCHI_BOND_TYPE$net_sf_jniinchi_INCHI_BOND_STEREO);
mol.addBond$net_sf_jniinchi_JniInchiBond(b);
}}
return mol;
}, 1);

Clazz.newMeth(C$, 'newJniInchiStructure$org_jmol_viewer_Viewer$O',  function (vwr, molData) {
var mol=Clazz.new_($I$(5,1));
var r=null;
try {
if (Clazz.instanceOf(molData, "java.lang.String")) {
r=Clazz.new_([Clazz.new_($I$(10,1).c$$S,[molData])],$I$(9,1).c$$java_io_Reader);
} else if (Clazz.instanceOf(molData, "java.io.InputStream")) {
r=molData;
}var htParams=Clazz.new_($I$(11,1));
var adapter=vwr.getModelAdapter$();
var atomSetReader=adapter.getAtomSetCollectionReader$S$S$O$java_util_Map("String", null, r, htParams);
if (Clazz.instanceOf(atomSetReader, "java.lang.String")) {
System.err.println$S("InChIJNI could not read molData");
return null;
}var asc=adapter.getAtomSetCollection$O(atomSetReader);
var ai=adapter.getAtomIterator$O(asc);
var bi=adapter.getBondIterator$O(asc);
var atoms=Clazz.array($I$(6), [asc.getAtomSetAtomCount$I(0)]);
var n=0;
var atomMap=Clazz.new_($I$(11,1));
while (ai.hasNext$() && n < atoms.length ){
var p=ai.getXYZ$();
var atno=ai.getElementNumber$();
if (atno <= 0) {
System.err.println$S("InChIJNI atom " + p + " index " + ai.getUniqueID$() + " is not a valid element" );
return null;
}var sym=$I$(12).elementSymbolFromNumber$I(atno);
var a=Clazz.new_($I$(6,1).c$$D$D$D$S,[p.x, p.y, p.z, sym]);
a.setCharge$I(ai.getFormalCharge$());
mol.addAtom$net_sf_jniinchi_JniInchiAtom(a);
atomMap.put$O$O(ai.getUniqueID$(), Integer.valueOf$I(n));
atoms[n++]=a;
}
var nb=0;
while (bi.hasNext$()){
var order=C$.getOrder$I(bi.getEncodedOrder$());
if (order != null ) {
var id1=atomMap.get$O(bi.getAtomUniqueID1$());
var id2=atomMap.get$O(bi.getAtomUniqueID2$());
if (id1 == null  || id2 == null  ) {
System.err.println$S("InChIJNI bond " + nb + "has null atom " + (id1 == null  ? bi.getAtomUniqueID1$() : "") + " " + (id2 == null  ? bi.getAtomUniqueID2$() : "") );
return null;
}var a=atoms[id1.intValue$()];
var b=atoms[id2.intValue$()];
if (a == null  || b == null  ) {
System.err.println$S("InChIJNI bond " + nb + "has null atom: " + a + "/" + b + " for ids " + id1 + " " + id2 + " and " + n + " atoms" );
return null;
}mol.addBond$net_sf_jniinchi_JniInchiBond(Clazz.new_($I$(8,1).c$$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_INCHI_BOND_TYPE,[a, b, order]));
++nb;
}}
} catch (t) {
t.printStackTrace$();
System.err.println$S(t.toString());
} finally {
try {
if (Clazz.instanceOf(r, "java.io.BufferedReader")) {
(r).close$();
} else {
(r).close$();
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
}
return mol;
}, 1);

Clazz.newMeth(C$, 'getOrder$I',  function (order) {
switch (order) {
case 1:
return $I$(13).SINGLE;
case 2:
return $I$(13).DOUBLE;
case 3:
return $I$(13).TRIPLE;
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'toString$net_sf_jniinchi_JniInchiStructure',  function (mol) {
var na=mol.getNumAtoms$();
var nb=mol.getNumBonds$();
var s="";
for (var i=0; i < na; i++) {
s+=mol.getAtom$I(i).getDebugString$() + "\n";
}
for (var i=0; i < nb; i++) {
s+=mol.getBond$I(i).getDebugString$() + "\n";
}
return s;
}, 1);

Clazz.newMeth(C$, 'getSmiles$org_jmol_viewer_Viewer$net_sf_jniinchi_JniInchiOutputStructure$S',  function (vwr, struc, smilesOptions) {
var hackImine=(smilesOptions.indexOf$S("imine") >= 0);
var nAtoms=struc.getNumAtoms$();
var nBonds=struc.getNumBonds$();
var nh=0;
for (var i=0; i < nAtoms; i++) {
var a=struc.getAtom$I(i);
nh+=a.getImplicitH$();
}
var atoms=Clazz.new_($I$(14,1));
var map=Clazz.new_($I$(11,1));
this.mapTet=Clazz.new_($I$(11,1));
this.mapPlanar=Clazz.new_($I$(11,1));
var nb=0;
var na=0;
for (var i=0; i < nAtoms; i++) {
var a=struc.getAtom$I(i);
var n=((P$.InChIJNI$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "InChIJNI$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('org.jmol.smiles.SmilesAtom'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'definesStereo$',  function () {
return true;
});

Clazz.newMeth(C$, 'getStereoAtAt$org_jmol_util_SimpleNodeA',  function (nodes) {
return this.b$['org.jmol.inchi.InChIJNI'].decodeInchiStereo$org_jmol_util_SimpleNodeA.apply(this.b$['org.jmol.inchi.InChIJNI'], [nodes]);
});

Clazz.newMeth(C$, 'isStereoOpposite$I$I$I',  function (i2, iA, iB) {
return this.b$['org.jmol.inchi.InChIJNI'].isInchiOpposite$I$I$I$I.apply(this.b$['org.jmol.inchi.InChIJNI'], [this.getIndex$(), i2, iA, iB]);
});
})()
), Clazz.new_($I$(15,1),[this, null],P$.InChIJNI$1));
atoms.addLast$O(n);
n.set$D$D$D(a.getX$(), a.getY$(), a.getZ$());
n.setIndex$I(na++);
n.setCharge$I(a.getCharge$());
n.setSymbol$S(a.getElementType$());
nh=a.getImplicitH$();
for (var j=0; j < nh; j++) {
p$1.addH$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I.apply(this, [atoms, n, nb++]);
++na;
}
map.put$O$O(a, n);
}
for (var i=0; i < nBonds; i++) {
var b=struc.getBond$I(i);
var a1=b.getOriginAtom$();
var a2=b.getTargetAtom$();
var bt=C$.getJmolBondType$net_sf_jniinchi_JniInchiBond(b);
var sa1=map.get$O(a1);
var sa2=map.get$O(a2);
var sb=Clazz.new_($I$(16,1).c$$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom$I$Z,[sa1, sa2, bt, false]);
sb.index=nb++;
}
nb=p$1.checkFormalCharges$javajs_util_Lst$I$Z.apply(this, [atoms, nb, hackImine]);
na=atoms.size$();
var aatoms=Clazz.array($I$(15), [na]);
atoms.toArray$OA(aatoms);
for (var i=0; i < na; i++) {
aatoms[i].setBondArray$();
}
var iA=-1;
var iB=-1;
for (var i=struc.getNumStereo0D$(); --i >= 0; ) {
var sd=struc.getStereo0D$I(i);
var an=sd.getNeighbors$();
if (an.length != 4) continue;
var ca=sd.getCentralAtom$();
var i0=map.get$O(an[0]).getIndex$();
var i1=map.get$O(an[1]).getIndex$();
var i2=map.get$O(an[2]).getIndex$();
var i3=map.get$O(an[3]).getIndex$();
var isEven=(sd.getParity$() === $I$(17).EVEN );
var type=sd.getStereoType$();
switch (type) {
case $I$(18).ALLENE:
case $I$(18).DOUBLEBOND:
iA=i1;
iB=i2;
i1=C$.getOtherEneAtom$org_jmol_smiles_SmilesAtomA$I$I(aatoms, i1, i0);
i2=C$.getOtherEneAtom$org_jmol_smiles_SmilesAtomA$I$I(aatoms, i2, i3);
break;
case $I$(18).NONE:
continue;
case $I$(18).TETRAHEDRAL:
break;
}
if (ca == null ) {
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i0, i3, iA, iB, Boolean.valueOf$Z(isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i0, i2, iA, iB, Boolean.valueOf$Z(!isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i1, i2, iA, iB, Boolean.valueOf$Z(isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i1, i3, iA, iB, Boolean.valueOf$Z(!isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i0, i1, iA, iB, Boolean.TRUE]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i2, i3, iA, iB, Boolean.TRUE]);
} else {
var list=Clazz.array(Integer.TYPE, -1, [isEven ? i0 : i1, isEven ? i1 : i0, i2, i3]);
this.mapTet.put$O$O(C$.orderList$IA(list), list);
}}
try {
var m=vwr.getSmilesMatcher$();
return m.getSmiles$org_jmol_util_NodeA$I$javajs_util_BS$S$I(aatoms, na, $I$(19).newBitSet2$I$I(0, na), smilesOptions, 1);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return "";
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'setPlanarKey$I$I$I$I$Boolean',  function (i0, i3, iA, iB, v) {
this.mapPlanar.put$O$O(C$.getIntKey$I$I$I(i0, iA, i3), v);
this.mapPlanar.put$O$O(C$.getIntKey$I$I$I(i0, iB, i3), v);
}, p$1);

Clazz.newMeth(C$, 'addH$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I',  function (atoms, n, nb) {
var h=Clazz.new_($I$(15,1));
h.setIndex$I(atoms.size$());
h.setSymbol$S("H");
atoms.addLast$O(h);
var sb=Clazz.new_($I$(16,1).c$$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom$I$Z,[n, h, 1, false]);
sb.index=nb;
return h;
}, p$1);

Clazz.newMeth(C$, 'checkFormalCharges$javajs_util_Lst$I$Z',  function (atoms, nb, hackImine) {
for (var i=atoms.size$(); --i >= 0; ) {
var a=atoms.get$I(i);
var val=a.getValence$();
var nbonds=a.getCovalentBondCount$();
var nbtot=a.getBondCount$();
var ano=a.getElementNumber$();
var formalCharge=a.getCharge$();
var b1=null;
var b2=null;
switch (val * 10 + nbonds) {
case 32:
if (ano == 7 && hackImine ) {
a.setSymbol$S("C");
a.setAtomicMass$I(17);
var h=p$1.addH$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I.apply(this, [atoms, a, nb++]);
h.setAtomicMass$I(5);
}break;
case 53:
if (ano == 7 && formalCharge == 0 ) {
for (var j=0; j < nbtot; j++) {
var b=a.getBond$I(j);
if (b.getCovalentOrder$() == 2) {
if (b1 == null ) {
b1=b;
} else {
b2=b;
break;
}}}
}break;
case 54:
break;
}
if (b2 != null ) {
var a2=b2.getOtherAtom$org_jmol_smiles_SmilesAtom(a);
a2.setCharge$I(-1);
a.setCharge$I(1);
b2.set2$I$Z(1, false);
}}
return nb;
}, p$1);

Clazz.newMeth(C$, 'isInchiOpposite$I$I$I$I',  function (i1, i2, iA, iB) {
return this.mapPlanar.get$O(C$.getIntKey$I$I$I(i1, Math.max(iA, iB), i2));
});

Clazz.newMeth(C$, 'decodeInchiStereo$org_jmol_util_SimpleNodeA',  function (nodes) {
var list=Clazz.array(Integer.TYPE, -1, [C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[0]), C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[1]), C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[2]), C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[3])]);
var list2=this.mapTet.get$O(C$.orderList$IA(list));
return (list2 == null  ? null : C$.isPermutation$IA$IA(list, list2) ? "@@" : "@");
});

Clazz.newMeth(C$, 'getNodeIndex$org_jmol_util_SimpleNode',  function (node) {
return (node == null  ? -1 : node.getIndex$());
}, 1);

Clazz.newMeth(C$, 'getIntKey$I$I$I',  function (i, iA, j) {
var v=Integer.valueOf$I((Math.min(i, j) << 24) + (iA << 12) + Math.max(i, j) );
return v;
}, 1);

Clazz.newMeth(C$, 'orderList$IA',  function (list) {
var bs=Clazz.new_($I$(20,1));
for (var i=0; i < list.length; i++) bs.set$I(list[i]);

return bs;
}, 1);

Clazz.newMeth(C$, 'isPermutation$IA$IA',  function (list, list2) {
var ok=true;
for (var i=0; i < 3; i++) {
var l1=list[i];
for (var j=i + 1; j < 4; j++) {
var l2=list2[j];
if (l2 == l1) {
if (j != i) {
list2[j]=list2[i];
list2[i]=l2;
ok=!ok;
}}}
}
return ok;
}, 1);

Clazz.newMeth(C$, 'getOtherEneAtom$org_jmol_smiles_SmilesAtomA$I$I',  function (atoms, i0, i1) {
var a=atoms[i0];
for (var i=a.getBondCount$(); --i >= 0; ) {
if (a.getBond$I(i).getBondType$() == 1) {
var i2=a.getBondedAtomIndex$I(i);
if (i2 != i1) {
return i2;
}}}
return -1;
}, 1);

Clazz.newMeth(C$, 'getJmolBondType$net_sf_jniinchi_JniInchiBond',  function (b) {
var type=b.getBondType$();
switch (type) {
case $I$(13).NONE:
return 0;
case $I$(13).ALTERN:
return 515;
case $I$(13).DOUBLE:
return 2;
case $I$(13).TRIPLE:
return 3;
case $I$(13).SINGLE:
default:
return 1;
}
}, 1);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-22 15:32:45 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
