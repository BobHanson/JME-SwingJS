(function(){var P$=Clazz.newPackage("org.jmol.inchi"),I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJS", null, null, 'org.jmol.api.JmolInChI');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S',  function (vwr, atoms, molData, options) {
if (atoms == null  ? molData == null  : atoms.isEmpty$()) return "";
var ret="";
try {
if (options == null ) options="";
options=$I$(1,"rep$S$S$S",[$I$(1,"rep$S$S$S",[options.replace$C$C("-", " "), "  ", " "]).trim$(), " ", " -"]).toLowerCase$();
if (options.length$() > 0) options="-" + options;
if (molData == null ) molData=vwr.getModelExtract$O$Z$Z$S(atoms, false, false, "MOL");
if (Clazz.instanceOf(molData, "java.lang.String") && (molData).startsWith$S("InChI=") ) {
{
ret = (Jmol.inchiToInchiKey ? Jmol.inchiToInchiKey(molData) : "");
}
} else {
var haveKey=(options.indexOf$S("key") >= 0);
if (haveKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "key");
}{
ret = (Jmol.molfileToInChI ? Jmol.molfileToInChI(molData, options) : "");
}
}} catch (e) {
{
e = (e.getMessage$ ? e.getMessage$() : e);
}
System.err.println$S("InChIJS exception: " + e);
}
return ret;
});

C$.$static$=function(){C$.$static$=0;
{
var wasmPath="/_WASM";
var es6Path="/_ES6";
try {
{
var j2sPath = Jmol._applets.master._j2sFullPath;
//
Jmol.inchiPath = j2sPath + wasmPath;
//
var importPath = j2sPath + es6Path;
//
import(importPath + "/molfile-to-inchi.js");
}
} catch (t) {
}
};
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-22 15:32:47 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
