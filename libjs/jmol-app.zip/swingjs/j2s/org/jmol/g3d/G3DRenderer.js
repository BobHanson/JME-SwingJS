(function(){var P$=Clazz.newPackage("org.jmol.g3d"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "G3DRenderer");
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-12 13:55:29 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
