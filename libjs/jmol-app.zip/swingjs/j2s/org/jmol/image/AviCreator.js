(function(){var P$=Clazz.newPackage("org.jmol.image"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AviCreator", null, null, 'org.jmol.api.JmolMovieCreatorInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['errorMsg']]]

Clazz.newMeth(C$, 'createMovie$org_jmol_viewer_Viewer$SA$I$I$I$S',  function (vwr, files, width, height, fps, fileName) {
return this.errorMsg;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-23 13:10:37 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
