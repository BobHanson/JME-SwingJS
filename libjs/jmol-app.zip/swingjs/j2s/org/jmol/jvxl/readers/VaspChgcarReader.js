(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[[0,'javajs.util.SB','org.jmol.util.SimpleUnitCell','org.jmol.util.Logger','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VaspChgcarReader", null, 'org.jmol.jvxl.readers.PeriodicVolumeFileReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['volume'],'I',['pt','nPerLine']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader',  function (sg, br) {
this.init2VFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
this.isAngstroms=true;
this.isPeriodic=true;
this.isProgressive=false;
this.nSurfaces=1;
});

Clazz.newMeth(C$, 'readParameters$',  function () {
this.jvxlFileHeaderBuffer=Clazz.new_($I$(1,1));
this.jvxlFileHeaderBuffer.append$S("Vasp CHGCAR format\n\n\n");
this.rd$();
var scale=this.parseDoubleStr$S(this.rd$());
var data=Clazz.array(Double.TYPE, [15]);
data[0]=-1;
for (var i=0, pt=6; i < 3; ++i) this.volumetricVectors[i].set$D$D$D(data[pt++]=this.parseDoubleStr$S(this.rd$()) * scale, data[pt++]=this.parseDouble$() * scale, data[pt++]=this.parseDouble$() * scale);

this.volume=$I$(2).newA$DA(data).volume;
while (this.rd$().length$() > 2){
}
this.rd$();
var counts=this.getTokens$();
for (var i=0; i < 3; ++i) {
this.volumetricVectors[i].scale$D(1.0 / ((this.voxelCounts[i]=this.parseIntStr$S(counts[i]) + 1) - 1));
if (this.isAnisotropic) this.setVectorAnisotropy$javajs_util_T3d(this.volumetricVectors[i]);
}
this.swapXZ$();
this.volumetricOrigin.set$D$D$D(0, 0, 0);
if (this.params.thePlane == null  && (this.params.cutoffAutomatic || !Double.isNaN$D(this.params.sigma) ) ) {
this.params.cutoff=0.5;
$I$(3,"info$S",["Cutoff set to " + new Double(this.params.cutoff).toString()]);
}});

Clazz.newMeth(C$, 'nextVoxel$',  function () {
if (this.pt++ % this.nPerLine == 0 && this.nData > 0 ) {
this.rd$();
this.next[0]=0;
}return this.parseDouble$() / this.volume;
});

Clazz.newMeth(C$, 'getPeriodicVoxels$',  function () {
var ni=this.voxelCounts[0] - 1;
var nj=this.voxelCounts[1] - 1;
var nk=this.voxelCounts[2] - 1;
var downSampling=(this.nSkipX > 0);
this.nPerLine=$I$(4,"countTokens$S$I",[this.rd$(), 0]);
for (var i=0; i < ni; i++) {
for (var j=0; j < nj; j++) {
for (var k=0; k < nk; k++) {
this.voxelData[i][j][k]=this.recordData$D(this.nextVoxel$());
if (downSampling) for (var m=this.nSkipX; --m >= 0; ) this.nextVoxel$();

}
if (downSampling) for (var m=this.nSkipY; --m >= 0; ) this.nextVoxel$();

}
if (downSampling) for (var m=this.nSkipZ; --m >= 0; ) this.nextVoxel$();

}
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-27 08:01:45 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
