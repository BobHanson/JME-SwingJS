(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[[0,'javajs.util.P3d','org.jmol.util.Logger','org.jmol.util.SimpleUnitCell']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MapFileReader", null, 'org.jmol.jvxl.readers.VolumeFileReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.dmin=1.7976931348623157E308;
this.xyzStart=Clazz.array(Double.TYPE, [3]);
this.origin=Clazz.new_($I$(1,1));
this.vectors=Clazz.array($I$(1), [3]);
this.xIndex=-1;
this.p3=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['D',['dmin','dmax','dmean','drange','a','b','c','alpha','beta','gamma'],'I',['mapc','mapr','maps','n0','n1','n2','mode','na','nb','nc','xIndex','yIndex','zIndex'],'O',['xyzStart','double[]','origin','javajs.util.P3d','vectors','javajs.util.P3d[]','p3','javajs.util.P3d']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader',  function (sg, br) {
this.init2MFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
});

Clazz.newMeth(C$, 'init2MFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader',  function (sg, br) {
this.init2VFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
this.isAngstroms=true;
});

Clazz.newMeth(C$, 'checkInsideOut$I$I$I',  function (mapc, mapr, maps) {
if (this.params.thePlane == null ) this.params.insideOut=(";123;231;312;".indexOf$S(";" + mapc + mapr + maps ) >= 0);
});

Clazz.newMeth(C$, 'getVectorsAndOrigin$',  function () {
this.checkInsideOut$I$I$I(this.mapc, this.mapr, this.maps);
$I$(2).info$S("grid parameters: nx,ny,nz: " + this.n0 + "," + this.n1 + "," + this.n2 );
$I$(2,"info$S",["grid parameters: nxStart,nyStart,nzStart: " + new Double(this.xyzStart[0]).toString() + "," + new Double(this.xyzStart[1]).toString() + "," + new Double(this.xyzStart[2]).toString() ]);
$I$(2).info$S("grid parameters: mx,my,mz: " + this.na + "," + this.nb + "," + this.nc );
$I$(2,"info$S",["grid parameters: a,b,c,alpha,beta,gamma: " + new Double(this.a).toString() + "," + new Double(this.b).toString() + "," + new Double(this.c).toString() + "," + new Double(this.alpha).toString() + "," + new Double(this.beta).toString() + "," + new Double(this.gamma).toString() ]);
$I$(2).info$S("grid parameters: mapc,mapr,maps: " + this.mapc + "," + this.mapr + "," + this.maps );
$I$(2).info$S("grid parameters: originX,Y,Z: " + this.origin);
var unitCell=$I$(3,"newA$DA",[Clazz.array(Double.TYPE, -1, [this.a / this.na, this.b / this.nb, this.c / this.nc, this.alpha, this.beta, this.gamma])]);
this.vectors[0]=$I$(1).new3$D$D$D(1, 0, 0);
this.vectors[1]=$I$(1).new3$D$D$D(0, 1, 0);
this.vectors[2]=$I$(1).new3$D$D$D(0, 0, 1);
unitCell.toCartesian$javajs_util_T3d$Z(this.vectors[0], false);
unitCell.toCartesian$javajs_util_T3d$Z(this.vectors[1], false);
unitCell.toCartesian$javajs_util_T3d$Z(this.vectors[2], false);
$I$(2).info$S("Jmol unit cell vectors:");
$I$(2).info$S("    a: " + this.vectors[0]);
$I$(2).info$S("    b: " + this.vectors[1]);
$I$(2).info$S("    c: " + this.vectors[2]);
this.voxelCounts[0]=this.n2;
this.voxelCounts[1]=this.n1;
this.voxelCounts[2]=this.n0;
this.volumetricVectors[0].setT$javajs_util_T3d(this.vectors[this.maps - 1]);
this.volumetricVectors[1].setT$javajs_util_T3d(this.vectors[this.mapr - 1]);
this.volumetricVectors[2].setT$javajs_util_T3d(this.vectors[this.mapc - 1]);
if (this.origin.x == 0  && this.origin.y == 0   && this.origin.z == 0  ) {
if (this.xIndex == -1) {
var xyz2crs=Clazz.array(Integer.TYPE, [3]);
xyz2crs[this.mapc - 1]=0;
xyz2crs[this.mapr - 1]=1;
xyz2crs[this.maps - 1]=2;
this.xIndex=xyz2crs[0];
this.yIndex=xyz2crs[1];
this.zIndex=xyz2crs[2];
}this.origin.scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(this.xyzStart[this.xIndex], this.vectors[0], this.origin);
this.origin.scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(this.xyzStart[this.yIndex], this.vectors[1], this.origin);
this.origin.scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(this.xyzStart[this.zIndex], this.vectors[2], this.origin);
}this.volumetricOrigin.setT$javajs_util_T3d(this.origin);
$I$(2).info$S("Jmol grid origin in Cartesian coordinates: " + this.origin);
$I$(2).info$S("Use  isosurface OFFSET {x y z}  if you want to shift it.\n");
this.p3.set$D$D$D(this.na, this.nb, this.nc);
unitCell.toCartesian$javajs_util_T3d$Z(this.p3, true);
this.p3.add$javajs_util_T3d(this.origin);
$I$(2).info$S("boundbox corners " + this.origin + " " + this.p3 + ";draw bbox boundbox mesh nofill" );
});

Clazz.newMeth(C$, 'setCutoffAutomatic$',  function () {
if (this.params.thePlane == null  && this.params.cutoffAutomatic ) {
this.params.cutoff=-1.0;
$I$(2,"info$S",["MapReader: setting cutoff to default value of " + new Double(this.params.cutoff).toString() + (this.boundingBox == null  ? " (no BOUNDBOX parameter)\n" : "\n") ]);
}});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-12 13:55:30 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
