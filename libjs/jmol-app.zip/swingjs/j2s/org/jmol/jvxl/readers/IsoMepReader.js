(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[[0,'org.jmol.api.Interface']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IsoMepReader", null, 'org.jmol.jvxl.readers.AtomDataReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['type']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init$org_jmol_jvxl_readers_SurfaceGenerator',  function (sg) {
this.initIMR$org_jmol_jvxl_readers_SurfaceGenerator(sg);
});

Clazz.newMeth(C$, 'initIMR$org_jmol_jvxl_readers_SurfaceGenerator',  function (sg) {
this.initADR$org_jmol_jvxl_readers_SurfaceGenerator(sg);
this.type="Mep";
});

Clazz.newMeth(C$, 'setup$Z',  function (isMapData) {
this.setup2$();
this.doAddHydrogens=false;
this.getAtoms$javajs_util_BS$Z$Z$Z$Z$Z$Z$D$javajs_util_M4d(this.params.bsSelected, this.doAddHydrogens, true, false, false, false, false, this.params.mep_marginAngstroms, null);
this.setHeader$S$S("MEP", "");
this.setRanges$D$I$D(this.params.mep_ptsPerAngstrom, this.params.mep_gridMax, 0);
});

Clazz.newMeth(C$, 'generateCube$',  function () {
this.newVoxelDataCube$();
var m=$I$(1).getOption$S$org_jmol_viewer_Viewer$S("quantum." + this.type + "Calculation" , this.sg.atomDataServer, "file");
m.calculate$org_jmol_jvxl_data_VolumeData$javajs_util_BS$javajs_util_P3dA$org_jmol_modelset_AtomA$DA$I(this.volumeData, this.bsMySelected, this.atomData.xyz, this.atomData.atoms, this.params.theProperty, this.params.mep_calcType);
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-23 13:10:32 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
