(function(){var P$=Clazz.newPackage("_"),p$1={},p$2={},I$=[[0,'java.awt.Color','jme.JME','jme.JMEmol','java.util.Vector','java.awt.Frame','java.awt.Font','java.util.StringTokenizer','jme.MultiBox','jme.QueryBox','java.awt.Event','java.awt.Point','java.awt.TextField','java.awt.GridLayout','java.awt.Label','java.awt.Panel','java.awt.Button','java.awt.BorderLayout','java.awt.FlowLayout','java.awt.Choice']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JME", null, 'java.applet.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.infoText="JME Molecular Editor by Peter Ertl, Novartis";
this.sd=24;
this.arrowWidth=48;
this.bwMode=false;
this.runsmi=false;
this.depictcgi=null;
this.depictservlet=null;
this.canonize=true;
this.stereo=true;
this.multipart=false;
this.xButton=true;
this.rButton=false;
this.showHydrogens=true;
this.query=false;
this.reaction=false;
this.autoez=false;
this.writesmi=false;
this.writemi=false;
this.writemol=false;
this.number=false;
this.star=false;
this.autonumber=false;
this.jmeh=false;
this.depict=false;
this.depictBorder=false;
this.keepHydrogens=true;
this.canvasBg=$I$(1).white;
this.atomColors=null;
this.atomBgColors=null;
this.depictScale=1.0;
this.nocenter=false;
this.polarnitro=false;
this.showAtomNumbers=false;
this.smiles=null;
this.jmeString=null;
this.molString=null;
this.doMenu=true;
this.lastAction=0;
this.newMolecule=false;
this.afterClear=false;
this.mouseShift=false;
this.smilesBox=null;
this.atomxBox=null;
this.aboutBox=null;
this.dyMode=true;
this.molText=null;
this.nmols=0;
this.actualMolecule=0;
this.saved=0;
this.template=null;
this.tmol=null;
this.mols=Clazz.array($I$(3), [99]);
this.molStack=Clazz.new_($I$(4,1));
this.stackPointer=-1;
this.doTags=false;
this.webme=false;
this.revertStereo=false;
this.relativeStereo=false;
this.allHs=false;
this.markUsed=true;
this.currentMark=1;
},1);

C$.$fields$=[['Z',['bwMode','runsmi','canonize','stereo','multipart','xButton','rButton','showHydrogens','query','reaction','autoez','writesmi','writemi','writemol','number','star','autonumber','jmeh','depict','depictBorder','keepHydrogens','nocenter','polarnitro','showAtomNumbers','doMenu','movePossible','newMolecule','afterClear','mouseShift','dyMode','doTags','webme','revertStereo','relativeStereo','allHs','markUsed'],'D',['depictScale'],'I',['action','active_an','sd','arrowWidth','fontSize','lastAction','xold','yold','nmols','actualMolecule','saved','stackPointer','currentMark'],'S',['infoText','depictcgi','depictservlet','atomColors','atomBgColors','smiles','jmeString','molString','molText','template'],'O',['$font','java.awt.Font','+fontBold','+fontSmall','fontMet','java.awt.FontMetrics','+fontBoldMet','+fontSmallMet','canvasBg','java.awt.Color','dimension','java.awt.Dimension','topMenu','java.awt.Image','+leftMenu','+infoArea','+molecularArea','smilesBox','jme.MultiBox','+atomxBox','+aboutBox','queryBox','jme.QueryBox','mol','jme.JMEmol','+tmol','mols','jme.JMEmol[]','smol','jme.JMEmol','molStack','java.util.Vector','apointx','int[]','+apointy','+bpointx','+bpointy','infoImage','java.awt.Image','+clearImage','+deleteImage','+deleterImage','+chargeImage','+templatesImage','+rtemplatesImage','+undoImage','+endImage','+smiImage','+smitImage','+smartsImage','+stereoImage','+stereoxImage']]
,['Z',['application'],'I',['ACTIONA'],'S',['separator'],'O',['bgColor','java.awt.Color','+brightColor','color','java.awt.Color[]','zlabel','String[]','psColor','java.awt.Color[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.mol=Clazz.new_($I$(3,1).c$$jme_JME,[this]);
$I$(2).psColor[0]=$I$(1).gray;
$I$(2).psColor[1]=Clazz.new_($I$(1,1).c$$I$I$I,[255, 153, 153]);
$I$(2).psColor[2]=Clazz.new_($I$(1,1).c$$I$I$I,[255, 204, 102]);
$I$(2).psColor[3]=Clazz.new_($I$(1,1).c$$I$I$I,[255, 255, 153]);
$I$(2).psColor[4]=Clazz.new_($I$(1,1).c$$I$I$I,[102, 255, 255]);
$I$(2).psColor[5]=Clazz.new_($I$(1,1).c$$I$I$I,[51, 204, 255]);
$I$(2).psColor[6]=Clazz.new_($I$(1,1).c$$I$I$I,[255, 153, 255]);
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
$I$(2).application=true;
var jme=Clazz.new_($I$(2,1));
var frame=Clazz.new_($I$(5,1).c$$S,["JME Molecular Editor"]);
frame.add$S$java_awt_Component("Center", jme);
frame.setBounds$I$I$I$I(300, 200, 432, 384);
jme.init$();
if (args.length == 1) jme.options$S(args[0]);
frame.show$();
jme.start$();
var fileName=null;
for (var i=0; i < args.length; i++) {
if (args[i].startsWith$S("-f")) {
fileName=args[++i];
} else if (args[i].startsWith$S("-o")) {
jme.options$S(args[++i]);
}}
}, 1);

Clazz.newMeth(C$, ['getColor$','getColor'],  function () {
return $I$(2).bgColor;
});

Clazz.newMeth(C$, ['activateQuery$','activateQuery'],  function () {
if (this.action != 107) {
this.action=107;
this.repaint$();
}});

Clazz.newMeth(C$, ['init$','init'],  function () {
this.dimension=this.size$();
this.setLayout$java_awt_LayoutManager(null);
this.fontSize=12;
if (this.$font == null ) {
this.$font=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 0, this.fontSize]);
this.fontMet=this.getFontMetrics$java_awt_Font(this.$font);
}if (this.fontBold == null ) {
this.fontBold=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 1, this.fontSize]);
this.fontBoldMet=this.getFontMetrics$java_awt_Font(this.fontBold);
}var fs=this.fontSize;
if (this.fontSmall == null ) {
this.fontSmall=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 0, fs]);
this.fontSmallMet=this.getFontMetrics$java_awt_Font(this.fontSmall);
}this.query=false;
this.reaction=false;
this.autoez=false;
this.stereo=true;
this.canonize=true;
this.xButton=true;
this.rButton=false;
$I$(2).ACTIONA=10;
this.showHydrogens=true;
if (!$I$(2).application) {
try {
var options=this.getParameter$S("options");
if (options != null ) this.options$S(options);
var jme=this.getParameter$S("jme");
if (jme != null ) this.jmeString=jme;
var molf=this.getParameter$S("mol");
if (molf != null ) this.molString=molf;
var dc=this.getParameter$S("depictcgi");
if (dc != null ) {
this.depictcgi=dc;
this.runsmi=true;
}var s=this.getParameter$S("smiles");
if (s != null ) this.smiles=s;
var mt=this.getParameter$S("text");
if (mt != null ) {
this.molText=mt;
this.repaint$();
}this.atomColors=this.getParameter$S("atomcolors");
this.atomBgColors=this.getParameter$S("atombg");
var bc=this.getParameter$S("depictbg");
if (bc != null  && this.depict ) this.canvasBg=p$1.parseHexColor$S.apply(this, [bc]);
if (this.showAtomNumbers) this.showAtomNumbers$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}this.action=202;
$I$(2).atomicData$();
this.validate$();
});

Clazz.newMeth(C$, 'parseHexColor$S',  function (hex) {
var c=$I$(1).white;
try {
if (!hex.startsWith$S("#")) throw Clazz.new_(Clazz.load('Exception').c$$S,["bad hex encoding"]);
var r=Integer.parseInt$S$I(hex.substring$I$I(1, 3), 16);
var g=Integer.parseInt$S$I(hex.substring$I$I(3, 5), 16);
var b=Integer.parseInt$S$I(hex.substring$I$I(5, 7), 16);
c=Clazz.new_($I$(1,1).c$$I$I$I,[r, g, b]);
return c;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Problems in parsing background color " + hex);
return c;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, ['start$','start'],  function () {
this.dimension=this.size$();
if (this.jmeString != null ) {
this.readMolecule$S(this.jmeString);
if (this.atomBgColors != null  && this.mol != null  ) this.mol.setAtomColors$S$Z(this.atomBgColors, true);
if (this.atomColors != null  && this.mol != null  ) this.mol.setAtomColors$S$Z(this.atomColors, false);
} else if (this.molString != null ) this.readMolFile$S(this.molString);
});

Clazz.newMeth(C$, ['stop$','stop'],  function () {
if (this.smilesBox != null ) this.smilesBox.dispose$();
if (this.atomxBox != null ) this.atomxBox.dispose$();
if (this.aboutBox != null ) this.aboutBox.dispose$();
if (this.queryBox != null ) this.queryBox.dispose$();
this.mols=null;
});

Clazz.newMeth(C$, ['ping$','ping'],  function () {
});

Clazz.newMeth(C$, ['smiles$','smiles'],  function () {
var smiles=this.Smiles$();
this.repaint$();
return smiles;
});

Clazz.newMeth(C$, ['nonisomericSmiles$','nonisomericSmiles'],  function () {
var originalStereo=this.stereo;
this.stereo=false;
var smiles=this.Smiles$();
this.stereo=originalStereo;
this.repaint$();
return smiles;
});

Clazz.newMeth(C$, 'Smiles$',  function () {
var s;
if (this.reaction) s=this.partSmiles$I(1) + ">" + this.partSmiles$I(2) + ">" + this.partSmiles$I(3) ;
 else {
s=this.partSmiles$I(0);
if (s.length$() > 0) {
this.molStack.addElement$O(Clazz.new_($I$(3,1).c$$jme_JMEmol,[this.mol]));
this.stackPointer=this.molStack.size$() - 1;
}}return s;
});

Clazz.newMeth(C$, 'partSmiles$I',  function (pp) {
var s="";
for (var m=1; m <= this.nmols; m++) {
if (pp > 0) {
var p=this.mols[m].reactionPart$();
if (p != pp) continue;
}var smiles=this.mols[m].createSmiles$();
if (smiles.length$() > 0) {
if (s.length$() > 0) s+=".";
s+=smiles;
}}
return s;
});

Clazz.newMeth(C$, ['reset$','reset'],  function () {
this.action=202;
this.newMolecule=false;
this.nmols=0;
this.actualMolecule=0;
this.mol=Clazz.new_($I$(3,1).c$$jme_JME,[this]);
this.mol.maxMark=0;
this.molText=null;
this.depictScale=1.0;
this.repaint$();
});

Clazz.newMeth(C$, ['clear$','clear'],  function () {
this.action=202;
this.newMolecule=false;
if (this.nmols == 0) return;
this.mol.save$();
this.afterClear=true;
for (var i=this.actualMolecule; i < this.nmols; i++) this.mols[i]=this.mols[i + 1];

--this.nmols;
this.actualMolecule=this.nmols;
if (this.nmols > 0) this.mol=this.mols[this.actualMolecule];
 else {
this.mol=Clazz.new_($I$(3,1).c$$jme_JME,[this]);
this.mol.maxMark=0;
}});

Clazz.newMeth(C$, ['jmeFile$','jmeFile'],  function () {
var s="";
if (this.reaction) s=this.partJme$I(1) + ">" + this.partJme$I(2) + ">" + this.partJme$I(3) ;
 else s=this.partJme$I(0);
return s;
});

Clazz.newMeth(C$, 'partJme$I',  function (pp) {
var s="";
for (var m=1; m <= this.nmols; m++) {
if (pp > 0) {
var p=this.mols[m].reactionPart$();
if (p != pp) continue;
}var jme=this.mols[m].createJME$();
if (jme.length$() > 0) {
if (s.length$() > 0) s+="|";
s+=jme;
}}
return s;
});

Clazz.newMeth(C$, 'getReactionParts$',  function () {
var part=Clazz.array(Integer.TYPE, [4, this.nmols + 1]);
for (var p=1; p <= 3; p++) {
var np=0;
for (var m=1; m <= this.nmols; m++) if (this.mols[m].reactionPart$() == p) part[p][++np]=m;

part[p][0]=np;
}
return part;
});

Clazz.newMeth(C$, ['readMolecule$S','readMolecule'],  function (molecule) {
this.reset$();
var lastReactant=0;
var firstProduct=0;
var st=Clazz.new_($I$(7,1).c$$S$S$Z,[molecule, "|>", true]);
var isReaction=(molecule.indexOf$S(">") > -1);
var rx=1;
var nt=st.countTokens$();
this.nmols=0;
for (var i=1; i <= nt; i++) {
var s=st.nextToken$();
s.trim$();
if (s.equals$O("|")) continue;
if (s.equals$O(">")) {
++rx;
if (rx == 2) lastReactant=this.nmols;
 else if (rx == 3) firstProduct=this.nmols + 1;
continue;
}this.mol=Clazz.new_($I$(3,1).c$$jme_JME$S$Z,[this, s, true]);
if (this.mol.natoms == 0) {
this.info$S("ERROR - problems in reading/processing molecule !");
System.err.println$S("ERROR while processing\n" + s);
continue;
}++this.nmols;
this.actualMolecule=this.nmols;
this.mols[this.nmols]=this.mol;
this.smol=null;
}
if (rx == 2) {
firstProduct=lastReactant + 1;
this.info$S("ERROR - strange reaction - fixing !");
System.err.println$S("ERROR - reactant and product should be separated by >>\n");
} else if (rx > 3) {
this.info$S("ERROR - strange reaction !");
System.err.println$S("ERROR - strange reaction !\n");
return;
}if (this.nmols > 1 && !isReaction ) this.options$S("multipart");
if (isReaction && !this.reaction ) this.options$S("reaction");
if (!isReaction && this.reaction ) this.options$S("noreaction");
if (!isReaction) this.alignMolecules$I$I$I(1, this.nmols, 0);
 else {
this.alignMolecules$I$I$I(1, lastReactant, 1);
this.alignMolecules$I$I$I(lastReactant + 1, firstProduct - 1, 2);
this.alignMolecules$I$I$I(firstProduct, this.nmols, 3);
}this.repaint$();
});

Clazz.newMeth(C$, ['setTemplate$S$S','setTemplate'],  function (t, name) {
this.afterClear=false;
this.tmol=Clazz.new_($I$(3,1).c$$jme_JME$S$Z,[this, t, true]);
this.tmol.complete$();
this.action=253;
this.info$S(name);
this.repaint$();
});

Clazz.newMeth(C$, 'alignMolecules$I$I$I',  function (m1, m2, part) {
if (this.nocenter) return;
var nm=m2 - m1 + 1;
if (nm <= 0 || m1 > this.nmols  || m2 > this.nmols ) return;
var center=Clazz.array(Double.TYPE, [4]);
var RBOND=25;
var share=Clazz.array(Double.TYPE, [99]);
var sumx=0.0;
var sumy=0.0;
var maxy=0.0;
for (var i=m1; i <= m2; i++) {
this.mols[i].centerPoint$DA(center);
sumx+=center[2];
sumy+=center[3];
if (center[3] > maxy ) maxy=center[3];
share[i]=center[2];
if (part == 2) share[i]=center[3];
}
if (this.depict) {
sumx+=RBOND * (nm + 1);
sumy+=RBOND * (nm + 1);
maxy+=RBOND;
}if (this.dimension.width == 0 || this.dimension.height == 0 ) this.dimension=this.size$();
if (this.dimension.width == 0) this.dimension.width=400;
if (this.dimension.height == 0) this.dimension.height=300;
var scalex=1.0;
var scaley=1.0;
var xsize=this.dimension.width;
var ysize=this.dimension.height;
if (!this.depict) {
xsize-=this.sd;
ysize-=3 * this.sd;
}if (part == 1 || part == 3 ) xsize=((xsize - this.arrowWidth)/2|0);
 else if (part == 2) ysize=(ysize/2|0);
if (sumx >= xsize ) scalex=(xsize) / sumx;
if (maxy >= ysize ) scaley=(ysize) / maxy;
var medzera=0.0;
if (this.depict) {
this.depictScale=Math.min(scalex, scaley);
medzera=RBOND * xsize / sumx;
if (part == 2) medzera=RBOND * ysize / sumy;
}for (var i=m1; i <= m2; i++) {
if (part == 2) share[i]=share[i] * ysize / sumy;
 else share[i]=share[i] * xsize / sumx;
}
var shiftx=-xsize / 2.0;
var shifty=0.0;
if (part == 1) shiftx=-xsize - this.arrowWidth / 2.0;
 else if (part == 3) shiftx=this.arrowWidth / 2.0;
 else if (part == 2) {
shiftx=0.0;
shifty=-ysize;
}for (var i=m1; i <= m2; i++) {
if (this.depict) {
for (var a=1; a <= this.mols[i].natoms; a++) {
this.mols[i].x[a]*=this.depictScale;
this.mols[i].y[a]*=this.depictScale;
}
this.mols[i].center$();
}if (part == 2) shifty+=(share[i] / 2.0 + medzera);
 else shiftx+=(share[i] / 2.0 + medzera);
for (var a=1; a <= this.mols[i].natoms; a++) {
this.mols[i].x[a]+=shiftx;
this.mols[i].y[a]+=shifty;
}
if (part == 2) shifty+=share[i] / 2.0;
 else shiftx+=share[i] / 2.0;
if (!this.depict) this.mols[i].findBondCenters$();
}
});

Clazz.newMeth(C$, ['molFile$','molFile'],  function () {
var smiles=this.smiles$();
var s="";
if (this.reaction) {
var part=this.getReactionParts$();
s+="$RXN" + $I$(2).separator + $I$(2).separator + $I$(2).separator + "JME Molecular Editor" + $I$(2).separator ;
s+=$I$(3).iformat$I$I(part[1][0], 3) + $I$(3).iformat$I$I(part[3][0], 3) + $I$(2).separator ;
for (var i=1; i <= part[1][0]; i++) s+="$MOL" + $I$(2).separator + this.mols[part[1][i]].createMolFile$S(smiles) ;

for (var i=1; i <= part[3][0]; i++) s+="$MOL" + $I$(2).separator + this.mols[part[3][i]].createMolFile$S(smiles) ;

} else {
if (this.nmols > 1) this.mol=Clazz.new_($I$(3,1).c$$jme_JME$jme_JMEmolA$I,[this, this.mols, this.nmols]);
s=this.mol.createMolFile$S(smiles);
if (this.nmols > 1) this.mol=this.mols[this.actualMolecule];
}return s;
});

Clazz.newMeth(C$, ['readMolFile$S','readMolFile'],  function (s) {
this.reset$();
if (s.startsWith$S("$RXN")) {
this.reaction=true;
this.multipart=true;
var separator=$I$(3).findSeparator$S(s);
var st=Clazz.new_($I$(7,1).c$$S$S$Z,[s, separator, true]);
var line="";
for (var i=1; i <= 5; i++) {
line=$I$(3).nextData$java_util_StringTokenizer$S(st, separator);
}
var nr=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
var np=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
$I$(3).nextData$java_util_StringTokenizer$S(st, separator);
for (var p=1; p <= nr + np; p++) {
var m="";
while (true){
var ns=$I$(3).nextData$java_util_StringTokenizer$S(st, separator);
if (ns == null  || ns.equals$O("$MOL") ) break;
 else m+=ns + separator;
}
this.mols[++this.nmols]=Clazz.new_($I$(3,1).c$$jme_JME$S,[this, m]);
}
this.alignMolecules$I$I$I(1, nr, 1);
this.alignMolecules$I$I$I(nr + 1, nr + np, 3);
} else {
this.reaction=false;
this.mol=Clazz.new_($I$(3,1).c$$jme_JME$S,[this, s]);
if (this.mol == null  || this.mol.natoms == 0 ) {
return;
}if (this.atomBgColors != null  && this.mol != null  ) this.mol.setAtomColors$S$Z(this.atomBgColors, true);
if (this.atomColors != null  && this.mol != null  ) this.mol.setAtomColors$S$Z(this.atomColors, false);
var nparts=this.mol.checkMultipart$Z(false);
if (nparts == 1) {
this.mols[++this.nmols]=this.mol;
} else {
this.multipart=true;
for (var p=1; p <= nparts; p++) this.mols[++this.nmols]=Clazz.new_($I$(3,1).c$$jme_JME$jme_JMEmol$I,[this, this.mol, p]);

}this.actualMolecule=1;
this.mol=this.mols[this.actualMolecule];
this.smol=null;
this.alignMolecules$I$I$I(1, nparts, 0);
}this.repaint$();
});

Clazz.newMeth(C$, ['setSubstituent$S','setSubstituent'],  function (s) {
var pressed=-1;
if (s.equals$O("Select substituent")) {
pressed=202;
s="";
} else if (s.equals$O("-C(=O)OH")) pressed=235;
 else if (s.equals$O("-C(=O)OMe")) pressed=240;
 else if (s.equals$O("-OC(=O)Me")) pressed=241;
 else if (s.equals$O("-CMe3")) pressed=233;
 else if (s.equals$O("-CF3")) pressed=236;
 else if (s.equals$O("-CCl3")) pressed=237;
 else if (s.equals$O("-NO2")) pressed=234;
 else if (s.equals$O("-NMe2")) pressed=243;
 else if (s.equals$O("-SO2-NH2")) pressed=252;
 else if (s.equals$O("-NH-SO2-Me")) pressed=244;
 else if (s.equals$O("-SO3H")) pressed=239;
 else if (s.equals$O("-PO3H2")) pressed=251;
 else if (s.equals$O("-C#N")) pressed=242;
 else if (s.equals$O("-C#C-Me")) pressed=245;
 else if (s.equals$O("-C#CH")) pressed=238;
if (pressed > 0) this.menuAction$I(pressed);
 else s="Not known group!";
this.info$S(s);
this.repaint$();
});

Clazz.newMeth(C$, ['options$S','options'],  function (parameters) {
parameters=parameters.toLowerCase$();
if (parameters.indexOf$S("norbutton") > -1) this.rButton=false;
 else if (parameters.indexOf$S("rbutton") > -1) this.rButton=true;
if (parameters.indexOf$S("nohydrogens") > -1) this.showHydrogens=false;
 else if (parameters.indexOf$S("hydrogens") > -1) this.showHydrogens=true;
if (parameters.indexOf$S("keephs") > -1) this.keepHydrogens=true;
if (parameters.indexOf$S("removehs") > -1) this.keepHydrogens=false;
if (parameters.indexOf$S("noquery") > -1) this.query=false;
 else if (parameters.indexOf$S("query") > -1) this.query=true;
if (parameters.indexOf$S("noreaction") > -1) this.reaction=false;
 else if (parameters.indexOf$S("reaction") > -1) this.reaction=true;
if (parameters.indexOf$S("noautoez") > -1) this.autoez=false;
 else if (parameters.indexOf$S("autoez") > -1) this.autoez=true;
if (parameters.indexOf$S("nostereo") > -1) this.stereo=false;
 else if (parameters.indexOf$S("stereo") > -1) this.stereo=true;
if (parameters.indexOf$S("nocanonize") > -1) this.canonize=false;
 else if (parameters.indexOf$S("canonize") > -1) this.canonize=true;
if (parameters.indexOf$S("nomultipart") > -1) this.multipart=false;
 else if (parameters.indexOf$S("multipart") > -1) this.multipart=true;
if (parameters.indexOf$S("nonumber") > -1) {
this.number=false;
this.autonumber=false;
} else if (parameters.indexOf$S("number") > -1) {
this.number=true;
this.autonumber=false;
}if (parameters.indexOf$S("autonumber") > -1) {
this.autonumber=true;
this.number=true;
}if (parameters.indexOf$S("star") > -1) {
this.star=true;
this.number=true;
}if (parameters.indexOf$S("polarnitro") > -1) this.polarnitro=true;
if (parameters.indexOf$S("depict") > -1) {
this.depict=true;
this.sd=0;
this.molecularArea=null;
this.alignMolecules$I$I$I(1, this.nmols, 0);
}if (parameters.indexOf$S("nodepict") > -1) {
this.depict=false;
for (var i=1; i <= this.nmols; i++) {
this.mols[i].scaling$();
this.mols[i].center$();
}
this.depictScale=1;
this.sd=24;
if (this.mol != null ) this.mol.needRecentering=true;
}if (parameters.indexOf$S("border") > -1) {
this.depictBorder=true;
}if (parameters.indexOf$S("writesmi") > -1) this.writesmi=true;
if (parameters.indexOf$S("writemi") > -1) this.writemi=true;
if (parameters.indexOf$S("writemol") > -1) this.writemol=true;
if (parameters.indexOf$S("nocenter") > -1) this.nocenter=true;
if (parameters.indexOf$S("jmeh") > -1) this.jmeh=true;
if (parameters.indexOf$S("showan") > -1) this.showAtomNumbers=true;
if (this.reaction) {
this.number=true;
this.multipart=true;
}if (!this.depict) this.depictBorder=false;
if (this.rButton) ++$I$(2).ACTIONA;
this.repaint$();
});

Clazz.newMeth(C$, ['setText$S','setText'],  function (text) {
this.molText=text;
this.repaint$();
});

Clazz.newMeth(C$, ['showAtomNumbers$','showAtomNumbers'],  function () {
if (this.mol != null ) this.mol.numberAtoms$();
});

Clazz.newMeth(C$, ['hasPrevious$','hasPrevious'],  function () {
if (this.molStack.size$() == 0 || this.stackPointer == 0 ) return false;
return true;
});

Clazz.newMeth(C$, ['getPreviousMolecule$','getPreviousMolecule'],  function () {
this.getFromStack$I(-1);
});

Clazz.newMeth(C$, 'getFromStack$I',  function (n) {
this.info$S("");
this.clear$();
this.stackPointer+=n;
this.mol=Clazz.new_([this.molStack.elementAt$I(this.stackPointer)],$I$(3,1).c$$jme_JMEmol);
this.mol.complete$();
this.mol.center$();
this.nmols=1;
this.actualMolecule=1;
this.mols[1]=this.mol;
this.repaint$();
this.smol=null;
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'],  function (g) {
this.update$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['update$java_awt_Graphics','update'],  function (g) {
var d=this.size$();
if (this.dimension == null  || (d.width != this.dimension.width)  || (d.height != this.dimension.height)  || this.molecularArea == null   || this.infoArea == null  ) {
this.dimension=d;
var imagew=d.width - this.sd;
var imageh=d.height - this.sd * 3;
if (imagew < 1) imagew=1;
if (imageh < 1) imageh=1;
this.molecularArea=this.createImage$I$I(imagew, imageh);
this.drawMolecularArea$java_awt_Graphics(g);
if (this.depict) return;
this.topMenu=this.createImage$I$I(d.width, this.sd * 2);
this.drawTopMenu$java_awt_Graphics(g);
imageh=d.height - this.sd * 2;
if (imageh < 1) imageh=1;
this.leftMenu=this.createImage$I$I(this.sd, imageh);
this.drawLeftMenu$java_awt_Graphics(g);
this.infoArea=this.createImage$I$I(imagew, this.sd);
this.drawInfo$java_awt_Graphics(g);
} else {
this.drawMolecularArea$java_awt_Graphics(g);
if (this.depict) return;
this.drawInfo$java_awt_Graphics(g);
if (this.doMenu) {
this.drawTopMenu$java_awt_Graphics(g);
this.drawLeftMenu$java_awt_Graphics(g);
}this.doMenu=true;
}});

Clazz.newMeth(C$, 'atomicData$',  function () {
for (var i=0; i < 23; i++) {
$I$(2).color[i]=$I$(1).orange;
$I$(2).zlabel[i]="X";
}
$I$(2).zlabel[1]="H";
$I$(2).color[1]=$I$(1).darkGray;
$I$(2).zlabel[2]="B";
$I$(2).color[2]=$I$(1).orange;
$I$(2).zlabel[3]="C";
$I$(2).color[3]=$I$(1).darkGray;
$I$(2).zlabel[4]="N";
$I$(2).color[4]=$I$(1).blue;
$I$(2).zlabel[5]="O";
$I$(2).color[5]=$I$(1).red;
$I$(2).zlabel[9]="F";
$I$(2).color[9]=$I$(1).magenta;
$I$(2).zlabel[10]="Cl";
$I$(2).color[10]=$I$(1).magenta;
$I$(2).zlabel[11]="Br";
$I$(2).color[11]=$I$(1).magenta;
$I$(2).zlabel[12]="I";
$I$(2).color[12]=$I$(1).magenta;
$I$(2).zlabel[8]="S";
$I$(2).color[8]=$I$(1).yellow.darker$();
$I$(2).zlabel[7]="P";
$I$(2).color[7]=$I$(1).orange;
$I$(2).zlabel[6]="Si";
$I$(2).color[6]=$I$(1).darkGray;
$I$(2).zlabel[13]="Se";
$I$(2).color[13]=$I$(1).darkGray;
$I$(2).zlabel[18]="X";
$I$(2).color[18]=$I$(1).darkGray;
$I$(2).zlabel[19]="R";
$I$(2).color[19]=$I$(1).darkGray;
$I$(2).zlabel[20]="R1";
$I$(2).color[20]=$I$(1).darkGray;
$I$(2).zlabel[21]="R2";
$I$(2).color[21]=$I$(1).darkGray;
$I$(2).zlabel[22]="R3";
$I$(2).color[22]=$I$(1).darkGray;
}, 1);

Clazz.newMeth(C$, 'drawMolecularArea$java_awt_Graphics',  function (g) {
var og=this.molecularArea.getGraphics$();
var imgWidth=this.dimension.width - this.sd;
var imgHeight=this.dimension.height - this.sd * 3;
og.setColor$java_awt_Color(this.canvasBg);
og.fillRect$I$I$I$I(0, 0, imgWidth, imgHeight);
for (var m=1; m <= this.nmols; m++) this.mols[m].draw$java_awt_Graphics(og);

if (!this.depict) {
og.setColor$java_awt_Color($I$(2).bgColor.darker$());
og.drawLine$I$I$I$I(imgWidth - 1, 0, imgWidth - 1, imgHeight - 1);
og.setColor$java_awt_Color($I$(2).bgColor);
og.drawLine$I$I$I$I(imgWidth - 2, 0, imgWidth - 2, imgHeight - 1);
og.setColor$java_awt_Color($I$(2).brightColor);
og.drawLine$I$I$I$I(imgWidth - 3, 0, imgWidth - 3, imgHeight - 1);
}if (this.reaction) {
var pWidth=this.arrowWidth;
var pStart=((imgWidth - pWidth)/2|0);
var m=(this.arrowWidth/8|0);
og.setColor$java_awt_Color($I$(1).magenta);
og.drawLine$I$I$I$I(pStart, (imgHeight/2|0), pStart + pWidth, (imgHeight/2|0));
og.drawLine$I$I$I$I(pStart + pWidth, (imgHeight/2|0), pStart + pWidth - m, (imgHeight/2|0) + m);
og.drawLine$I$I$I$I(pStart + pWidth, (imgHeight/2|0), pStart + pWidth - m, (imgHeight/2|0) - m);
}if (this.depict) {
this.$font=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 0, this.fontSize]);
this.fontMet=this.getFontMetrics$java_awt_Font(this.$font);
if (this.molText != null ) {
var w=this.fontMet.stringWidth$S(this.molText);
var xstart=Long.$ival(Math.round$D((imgWidth - w) / 2.0));
var ystart=imgHeight - this.fontSize;
og.setColor$java_awt_Color($I$(1).black);
og.setFont$java_awt_Font(this.$font);
og.drawString$S$I$I(this.molText, xstart, ystart);
}}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.molecularArea, this.sd, this.sd * 2, this);
});

Clazz.newMeth(C$, 'drawTopMenu$java_awt_Graphics',  function (g) {
var og=this.topMenu.getGraphics$();
var imgWidth=this.dimension.width;
var imgHeight=this.sd * 2;
og.setColor$java_awt_Color($I$(2).bgColor);
og.fillRect$I$I$I$I(0, 0, imgWidth, imgHeight);
og.setColor$java_awt_Color($I$(2).bgColor.darker$());
og.drawLine$I$I$I$I(imgWidth - 1, 0, imgWidth - 1, imgHeight - 1);
og.drawLine$I$I$I$I(0, imgHeight - 1, imgWidth - 1 - 2 , imgHeight - 1);
og.setColor$java_awt_Color($I$(2).brightColor);
og.drawLine$I$I$I$I(0, 0, imgWidth - 1, 0);
og.drawLine$I$I$I$I(12 * this.sd, 0, 12 * this.sd, imgHeight - 1);
for (var i=1; i <= 12; i++) {
this.createSquare$java_awt_Graphics$I$I(og, i, 1);
this.createSquare$java_awt_Graphics$I$I(og, i, 2);
}
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.topMenu, 0, 0, this);
});

Clazz.newMeth(C$, 'drawLeftMenu$java_awt_Graphics',  function (g) {
var og=this.leftMenu.getGraphics$();
var imgWidth=this.sd;
var imgHeight=this.dimension.height - this.sd * 2;
og.setColor$java_awt_Color($I$(2).bgColor);
og.fillRect$I$I$I$I(0, 0, imgWidth, imgHeight);
og.setColor$java_awt_Color($I$(2).brightColor);
og.drawLine$I$I$I$I(0, 0, 0, imgHeight - 1);
og.drawLine$I$I$I$I(0, $I$(2).ACTIONA * this.sd, imgHeight - 1, $I$(2).ACTIONA * this.sd);
og.setColor$java_awt_Color($I$(2).bgColor.darker$());
og.drawLine$I$I$I$I(imgWidth - 1, 0, imgWidth - 1, imgHeight - 1 - this.sd );
og.drawLine$I$I$I$I(0, imgHeight - 1, imgWidth - 1, imgHeight - 1);
for (var i=3; i <= $I$(2).ACTIONA + 2; i++) this.createSquare$java_awt_Graphics$I$I(og, 1, i);

g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.leftMenu, 0, this.sd * 2, this);
});

Clazz.newMeth(C$, 'drawInfo$java_awt_Graphics',  function (g) {
var og=this.infoArea.getGraphics$();
var imgWidth=this.dimension.width - this.sd;
var imgHeight=this.sd;
og.setColor$java_awt_Color($I$(2).bgColor);
og.fillRect$I$I$I$I(0, 0, imgWidth, imgHeight);
og.setColor$java_awt_Color($I$(2).brightColor);
og.drawLine$I$I$I$I(0, 0, imgWidth - 1 - 2 , 0);
og.setColor$java_awt_Color($I$(2).bgColor.darker$());
og.drawLine$I$I$I$I(0, imgHeight - 1, imgWidth - 1, imgHeight - 1);
og.drawLine$I$I$I$I(imgWidth - 1, 0, imgWidth - 1, imgHeight - 1);
og.setFont$java_awt_Font(this.fontSmall);
og.setColor$java_awt_Color($I$(1).black);
if (this.infoText.startsWith$S("E")) og.setColor$java_awt_Color($I$(1).red);
og.drawString$S$I$I(this.infoText, 10, 15);
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.infoArea, this.sd, this.dimension.height - this.sd, this);
});

Clazz.newMeth(C$, 'menuAction$I',  function (pressed) {
if (pressed == 0) return;
var action_old=this.action;
this.action=pressed;
if (pressed <= 300) {
switch (pressed) {
case 102:
this.clear$();
break;
case 110:
this.action=action_old;
if (this.smol == null ) {
this.actualMolecule=this.nmols;
this.clear$();
} else if (this.afterClear) {
this.saved=++this.nmols;
this.actualMolecule=this.nmols;
this.afterClear=false;
}if (this.smol == null ) break;
this.mol=Clazz.new_($I$(3,1).c$$jme_JMEmol,[this.smol]);
this.mol.complete$();
this.mols[this.saved]=this.mol;
break;
case 152:
var ssize=this.molStack.size$();
this.action=action_old;
if (ssize == 0) this.info$S("No molecules in molstack");
 else if (this.stackPointer == 0) this.info$S("Bottom of molstack reached");
 else this.getFromStack$I(-1);
break;
case 151:
ssize=this.molStack.size$();
this.action=action_old;
if (ssize == 0) this.info$S("No molecules in molstack");
 else if (this.stackPointer == ssize - 1) this.info$S("Top of molstack reached");
 else this.getFromStack$I(1);
break;
case 101:
if ($I$(2).application) {
;}if (this.smilesBox != null  && this.smilesBox.isVisible$() ) {
$I$(8).smilesBoxPoint=this.smilesBox.getLocationOnScreen$();
this.smilesBox.dispose$();
this.smilesBox=null;
}this.smilesBox=Clazz.new_($I$(8,1).c$$I$jme_JME,[1, this]);
this.action=action_old;
break;
case 107:
if (this.queryBox != null  && this.queryBox.isVisible$() ) {
$I$(9).point=this.queryBox.getLocationOnScreen$();
this.queryBox.dispose$();
this.queryBox=null;
}this.queryBox=Clazz.new_($I$(9,1).c$$jme_JME,[this]);
break;
case 112:
if (this.aboutBox != null  && this.aboutBox.isVisible$() ) {
$I$(8).aboutBoxPoint=this.aboutBox.getLocationOnScreen$();
this.aboutBox.dispose$();
this.aboutBox=null;
}this.aboutBox=Clazz.new_($I$(8,1).c$$I$jme_JME,[0, this]);
this.action=action_old;
break;
case 103:
this.newMolecule=true;
this.action=action_old;
break;
case 105:
if (this.autonumber) {
if (this.mouseShift) {
this.mouseShift=false;
this.mol.numberAtoms$();
this.action=action_old;
}}this.currentMark=1;
break;
case 111:
System.exit$I(0);
case 109:
this.action=action_old;
var part=this.mol.reactionPart$();
if (part == 2) {
this.info$S("Copying the agent not possible !");
break;
}var center=Clazz.array(Double.TYPE, [4]);
this.mol.centerPoint$DA(center);
this.mol=Clazz.new_($I$(3,1).c$$jme_JMEmol,[this.mol]);
var dx=((((this.dimension.width - this.sd)/2|0) - center[0])|0);
for (var i=1; i <= this.mol.natoms; i++) this.mol.x[i]+=dx * 2;

this.mol.complete$();
this.mols[++this.nmols]=this.mol;
this.actualMolecule=this.nmols;
break;
case 104:
if (this.mol.touchedAtom > 0) {
this.mol.save$();
this.mol.deleteAtom$I(this.mol.touchedAtom);
this.mol.touchedAtom=0;
} else if (this.mol.touchedBond > 0) {
this.mol.save$();
this.mol.deleteBond$I(this.mol.touchedBond);
this.mol.touchedBond=0;
}this.mol.valenceState$();
break;
default:
break;
}
} else {
switch (pressed) {
case 301:
this.active_an=3;
break;
case 401:
this.active_an=4;
break;
case 501:
this.active_an=5;
break;
case 701:
this.active_an=9;
break;
case 801:
this.active_an=10;
break;
case 901:
this.active_an=11;
break;
case 1001:
this.active_an=12;
break;
case 601:
this.active_an=8;
break;
case 1101:
this.active_an=7;
break;
case 1300:
this.active_an=1;
break;
case 1201:
if (!this.webme) {
if (this.atomxBox != null  && this.atomxBox.isVisible$() ) {
$I$(8).atomxBoxPoint=this.atomxBox.getLocationOnScreen$();
this.atomxBox.dispose$();
this.atomxBox=null;
}if (this.mol.touchedAtom == 0) this.atomxBox=Clazz.new_($I$(8,1).c$$I$jme_JME,[2, this]);
}this.active_an=18;
break;
case 1301:
this.active_an=19;
break;
case 1302:
this.active_an=20;
break;
case 1303:
this.active_an=21;
break;
case 1304:
this.active_an=22;
break;
}
if (this.mol.touchedAtom > 0) {
if (this.active_an != this.mol.an[this.mol.touchedAtom] && this.active_an != 18 ) {
this.mol.save$();
this.mol.an[this.mol.touchedAtom]=this.active_an;
this.mol.q[this.mol.touchedAtom]=0;
this.mol.nh[this.mol.touchedAtom]=0;
}if (this.active_an == 18) {
var xx=$I$(8).atomicSymbol.getText$();
this.mol.setAtom$I$S(this.mol.touchedAtom, xx);
}this.mol.valenceState$();
}}this.repaint$();
});

Clazz.newMeth(C$, 'createSquare$java_awt_Graphics$I$I',  function (g, xpos, ypos) {
var square=ypos * 100 + xpos;
var xstart=(xpos - 1) * this.sd;
var ystart=(ypos - 1) * this.sd;
if (xpos == 1 && ypos > 2 ) ystart-=(2 * this.sd);
g.setColor$java_awt_Color($I$(2).bgColor);
if (square == this.action) g.fill3DRect$I$I$I$I$Z(xstart + 1, ystart + 1, this.sd, this.sd, false);
 else g.fill3DRect$I$I$I$I$Z(xstart, ystart, this.sd, this.sd, true);
if (square == 1301 && !this.rButton ) return;
if (square == 111 && !$I$(2).application ) return;
if (square == 107 && !this.query ) return;
if (square == 201 && !this.stereo ) return;
if (square == 103 && !this.multipart ) return;
if (square == 105 && !(this.number || this.autonumber ) ) return;
if (square == 109 && !this.reaction ) return;
var m=(this.sd/4|0);
if (ypos < 3) {
g.setColor$java_awt_Color($I$(1).black);
switch (square) {
case 101:
if (!this.bwMode) {
g.setColor$java_awt_Color($I$(1).yellow);
g.fillOval$I$I$I$I(xstart + 3, ystart + 3, this.sd - 6, this.sd - 6);
g.setColor$java_awt_Color($I$(1).black);
}g.drawOval$I$I$I$I(xstart + 3, ystart + 3, this.sd - 6, this.sd - 6);
g.drawArc$I$I$I$I$I$I(xstart + 6, ystart + 6, this.sd - 12, this.sd - 12, -35, -110);
g.fillRect$I$I$I$I(xstart + 9, ystart + 9, 2, 4);
g.fillRect$I$I$I$I(xstart + this.sd - 10, ystart + 9, 2, 4);
if (Math.random() < 0.04 ) {
g.setColor$java_awt_Color($I$(1).red);
g.fillRect$I$I$I$I(xstart + 10, ystart + 18, 4, 4);
}if (Math.random() > 0.96 ) {
g.setColor$java_awt_Color($I$(1).yellow);
g.fillRect$I$I$I$I(xstart + this.sd - 10, ystart + 8, 2, 3);
}break;
case 111:
this.squareText$java_awt_Graphics$I$I$S(g, xstart, ystart, "END");
break;
case 107:
g.setColor$java_awt_Color($I$(1).orange);
g.fillRect$I$I$I$I(xstart + 4, ystart + 4, this.sd - 8, this.sd - 8);
g.setColor$java_awt_Color($I$(1).black);
g.drawRect$I$I$I$I(xstart + 4, ystart + 4, this.sd - 8, this.sd - 8);
g.drawArc$I$I$I$I$I$I(xstart + 6, ystart + 6, this.sd - 11, this.sd - 12, -35, -110);
g.fillRect$I$I$I$I(xstart + 9, ystart + 9, 2, 4);
g.fillRect$I$I$I$I(xstart + this.sd - 10, ystart + 9, 2, 4);
break;
case 108:
this.squareText$java_awt_Graphics$I$I$S(g, xstart, ystart, "+ /  ");
g.drawLine$I$I$I$I(xstart + 15, ystart + 13, xstart + 19, ystart + 13);
break;
case 110:
g.drawArc$I$I$I$I$I$I(xstart + 6, ystart + 7, this.sd - 12, this.sd - 14, 270, 270);
g.drawLine$I$I$I$I(xstart + 6, ystart + 13, xstart + 3, ystart + 10);
g.drawLine$I$I$I$I(xstart + 6, ystart + 13, xstart + 9, ystart + 10);
break;
case 109:
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0), xstart + this.sd - m, ystart + (this.sd/2|0));
g.drawLine$I$I$I$I(xstart + this.sd - m, ystart + (this.sd/2|0), xstart + this.sd - (m * 3/2|0), ystart + (this.sd/2|0) + (m/2|0));
g.drawLine$I$I$I$I(xstart + this.sd - m, ystart + (this.sd/2|0), xstart + this.sd - (m * 3/2|0), ystart + (this.sd/2|0) - (m/2|0));
break;
case 102:
g.setColor$java_awt_Color($I$(1).white);
g.fillRect$I$I$I$I(xstart + 3, ystart + 5, this.sd - 7, this.sd - 11);
g.setColor$java_awt_Color($I$(1).black);
g.drawRect$I$I$I$I(xstart + 3, ystart + 5, this.sd - 7, this.sd - 11);
break;
case 103:
g.setColor$java_awt_Color($I$(2).bgColor);
if (this.newMolecule) g.fill3DRect$I$I$I$I$Z(xstart + 1, ystart + 1, this.sd, this.sd, false);
g.setColor$java_awt_Color($I$(1).black);
this.squareText$java_awt_Graphics$I$I$S(g, xstart, ystart, "NEW");
break;
case 106:
g.setColor$java_awt_Color($I$(1).red);
g.drawLine$I$I$I$I(xstart + 7, ystart + 7, xstart + this.sd - 7, ystart + this.sd - 7);
g.drawLine$I$I$I$I(xstart + 8, ystart + 7, xstart + this.sd - 6, ystart + this.sd - 7);
g.drawLine$I$I$I$I(xstart + 7, ystart + this.sd - 7, xstart + this.sd - 7, ystart + 7);
g.drawLine$I$I$I$I(xstart + 8, ystart + this.sd - 7, xstart + this.sd - 6, ystart + 7);
g.setColor$java_awt_Color($I$(1).black);
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0), xstart + 12, ystart + (this.sd/2|0));
this.squareText$java_awt_Graphics$I$I$S(g, xstart + 6, ystart, "R");
break;
case 104:
g.setColor$java_awt_Color($I$(1).red);
g.drawLine$I$I$I$I(xstart + 7, ystart + 7, xstart + this.sd - 7, ystart + this.sd - 7);
g.drawLine$I$I$I$I(xstart + 8, ystart + 7, xstart + this.sd - 6, ystart + this.sd - 7);
g.drawLine$I$I$I$I(xstart + 7, ystart + this.sd - 7, xstart + this.sd - 7, ystart + 7);
g.drawLine$I$I$I$I(xstart + 8, ystart + this.sd - 7, xstart + this.sd - 6, ystart + 7);
g.setColor$java_awt_Color($I$(1).black);
break;
case 105:
if (this.star) {
g.setColor$java_awt_Color($I$(1).cyan);
g.drawLine$I$I$I$I(xstart + 11, ystart + 5, xstart + 9, ystart + 9);
g.drawLine$I$I$I$I(xstart + 9, ystart + 9, xstart + 4, ystart + 9);
g.drawLine$I$I$I$I(xstart + 4, ystart + 9, xstart + 8, ystart + 12);
g.drawLine$I$I$I$I(xstart + 8, ystart + 12, xstart + 6, ystart + 18);
g.drawLine$I$I$I$I(xstart + 6, ystart + 18, xstart + 11, ystart + 15);
g.drawLine$I$I$I$I(xstart + 12, ystart + 5, xstart + 14, ystart + 9);
g.drawLine$I$I$I$I(xstart + 14, ystart + 9, xstart + 19, ystart + 9);
g.drawLine$I$I$I$I(xstart + 19, ystart + 9, xstart + 15, ystart + 12);
g.drawLine$I$I$I$I(xstart + 15, ystart + 12, xstart + 17, ystart + 18);
g.drawLine$I$I$I$I(xstart + 17, ystart + 18, xstart + 12, ystart + 15);
g.setColor$java_awt_Color($I$(1).black);
} else this.squareText$java_awt_Graphics$I$I$S(g, xstart, ystart, "123");
break;
case 112:
g.setColor$java_awt_Color($I$(1).blue);
g.fillRect$I$I$I$I(xstart + 4, ystart + 4, this.sd - 8, this.sd - 8);
g.setColor$java_awt_Color($I$(1).black);
g.drawRect$I$I$I$I(xstart + 4, ystart + 4, this.sd - 8, this.sd - 8);
this.squareTextBold$java_awt_Graphics$I$I$java_awt_Color$S(g, xstart + 1, ystart - 1, $I$(1).white, "i");
break;
case 201:
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0), xstart + this.sd - m, ystart + (this.sd/2|0) + 2);
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0), xstart + this.sd - m, ystart + (this.sd/2|0) - 2);
g.drawLine$I$I$I$I(xstart + this.sd - m, ystart + (this.sd/2|0) + 2, xstart + this.sd - m, ystart + (this.sd/2|0) - 2);
break;
case 202:
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0), xstart + this.sd - m, ystart + (this.sd/2|0));
break;
case 203:
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0) - 2, xstart + this.sd - m, ystart + (this.sd/2|0) - 2);
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0) + 2, xstart + this.sd - m, ystart + (this.sd/2|0) + 2);
break;
case 204:
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0), xstart + this.sd - m, ystart + (this.sd/2|0));
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0) - 2, xstart + this.sd - m, ystart + (this.sd/2|0) - 2);
g.drawLine$I$I$I$I(xstart + m, ystart + (this.sd/2|0) + 2, xstart + this.sd - m, ystart + (this.sd/2|0) + 2);
break;
case 205:
g.drawLine$I$I$I$I(xstart + (m/2|0), ystart + m * 2 + (m/3|0), xstart + (m/2|0) * 3, ystart + m * 2 - (m/3|0));
g.drawLine$I$I$I$I(xstart + (m/2|0) * 3, ystart + m * 2 - (m/3|0), xstart + (m/2|0) * 5, ystart + m * 2 + (m/3|0));
g.drawLine$I$I$I$I(xstart + (m/2|0) * 5, ystart + m * 2 + (m/3|0), xstart + (m/2|0) * 7, ystart + m * 2 - (m/3|0));
break;
case 206:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart + 2, 3);
break;
case 207:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart, 4);
break;
case 208:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart, 5);
break;
case 209:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart, 1);
break;
case 210:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart, 6);
break;
case 211:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart, 7);
break;
case 212:
this.drawRingIcon$java_awt_Graphics$I$I$I(g, xstart, ystart, 8);
break;
}
} else {
var dan=3;
if (square == 301) dan=3;
 else if (square == 401) dan=4;
 else if (square == 501) dan=5;
 else if (square == 601) dan=8;
 else if (square == 701) dan=9;
 else if (square == 801) dan=10;
 else if (square == 901) dan=11;
 else if (square == 1001) dan=12;
 else if (square == 1101) dan=7;
 else if (square == 1201) dan=18;
 else if (square == 1301) dan=19;
this.squareTextBold$java_awt_Graphics$I$I$java_awt_Color$S(g, xstart, ystart, $I$(2).color[dan], $I$(2).zlabel[dan]);
}});

Clazz.newMeth(C$, 'squareText$java_awt_Graphics$I$I$S',  function (g, xstart, ystart, text) {
g.setFont$java_awt_Font(this.fontSmall);
var hSmall=this.fontSmallMet.getAscent$();
var w=this.fontSmallMet.stringWidth$S(text);
g.drawString$S$I$I(text, xstart + ((this.sd - w)/2|0), ystart + ((this.sd - hSmall)/2|0) + hSmall);
});

Clazz.newMeth(C$, 'squareTextBold$java_awt_Graphics$I$I$java_awt_Color$S',  function (g, xstart, ystart, col, text) {
var h=this.fontBoldMet.getAscent$();
var w=this.fontBoldMet.stringWidth$S(text);
g.setFont$java_awt_Font(this.fontBold);
g.setColor$java_awt_Color(col);
if (this.bwMode) g.setColor$java_awt_Color($I$(1).black);
g.drawString$S$I$I(text, xstart + ((this.sd - w)/2|0), ystart + ((this.sd - h)/2|0) + h);
});

Clazz.newMeth(C$, 'drawRingIcon$java_awt_Graphics$I$I$I',  function (g, xstart, ystart, n) {
var m=(this.sd/4|0);
var ph=false;
var xp=Clazz.array(Integer.TYPE, [9]);
var yp=Clazz.array(Integer.TYPE, [9]);
var xcenter=xstart + (this.sd/2|0);
var ycenter=ystart + (this.sd/2|0);
var rc=(this.sd/2|0) - (m/2|0);
if (n == 1) {
n=6;
ph=true;
}for (var i=0; i <= n; i++) {
var uhol=6.283185307179586 / n * (i - 0.5);
xp[i]=((xcenter + rc * Math.sin(uhol))|0);
yp[i]=((ycenter + rc * Math.cos(uhol))|0);
}
g.drawPolygon$IA$IA$I(xp, yp, n + 1);
if (ph) {
for (var i=0; i <= n; i++) {
var uhol=6.283185307179586 / n * (i - 0.5);
xp[i]=((xcenter + (rc - 3) * Math.sin(uhol))|0);
yp[i]=((ycenter + (rc - 3) * Math.cos(uhol))|0);
}
g.drawLine$I$I$I$I(xp[0], yp[0], xp[1], yp[1]);
g.drawLine$I$I$I$I(xp[2], yp[2], xp[3], yp[3]);
g.drawLine$I$I$I$I(xp[4], yp[4], xp[5], yp[5]);
}});

Clazz.newMeth(C$, 'info$S',  function (text) {
this.infoText=text;
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'],  function (e, x, y) {
var status=true;
if (this.depict) return true;
this.xold=x - this.sd;
this.yold=y - 2 * this.sd;
this.info$S("");
this.mouseShift=e.shiftDown$();
this.movePossible=false;
if (x < this.sd || y < this.sd * 2 ) {
var xbutton=0;
for (var i=1; i <= 12; i++) if (x < i * this.sd) {
xbutton=i;
break;
}
var ybutton=0;
for (var i=1; i <= $I$(2).ACTIONA + 2; i++) if (y < i * this.sd) {
ybutton=i;
break;
}
if (xbutton == 0 || ybutton == 0 ) return true;
var action=ybutton * 100 + xbutton;
if (!$I$(2).application && action == 111 ) return true;
if (!this.query && action == 107 ) return true;
if (!this.stereo && action == 201 ) return true;
if (!this.multipart && action == 103 ) return true;
if (!(this.number || this.autonumber ) && action == 105 ) return true;
if (!this.reaction && action == 109 ) return true;
this.menuAction$I(action);
} else if (y > this.dimension.height - this.sd - 1 ) {
return true;
} else {
this.movePossible=true;
x-=this.sd;
y-=2 * this.sd;
if (this.mol.touchedAtom > 0) {
if (this.action == 104) {
this.mol.save$();
this.mol.deleteAtom$I(this.mol.touchedAtom);
this.mol.touchedAtom=0;
} else if (this.action == 106) {
return true;
} else if (this.action == 108) {
this.mol.changeCharge$I$I(this.mol.touchedAtom, 0);
} else if (this.action == 157) {
this.mol.changeCharge$I$I(this.mol.touchedAtom, 1);
} else if (this.action == 158) {
this.mol.changeCharge$I$I(this.mol.touchedAtom, -1);
} else if (this.action == 202 || this.action == 203  || this.action == 204  || this.action == 201  || this.action == 205 ) {
this.mol.save$();
this.lastAction=1;
this.mol.addBond$();
this.mol.touched_org=this.mol.touchedAtom;
if (this.action == 205) {
this.mol.nchain=1;
this.mol.chain[1]=this.mol.natoms;
this.mol.chain[0]=this.mol.touchedAtom;
this.mol.touchedBond=0;
}} else if (this.action >= 206 && this.action <= 229 ) {
this.mol.save$();
this.lastAction=2;
this.mol.addRing$();
} else if (this.action == 230) {
this.mol.save$();
this.lastAction=3;
} else if (this.action >= 233 && this.action < 260 ) {
this.mol.save$();
this.mol.addGroup$Z(false);
this.lastAction=3;
} else if (this.action == 107) {
if (this.queryBox.isBondQuery$()) return true;
this.mol.setAtom$I$S(this.mol.touchedAtom, this.queryBox.getSmarts$());
} else if (this.action == 105) {
this.mol.mark$();
} else if (this.action > 300) {
if (this.active_an != this.mol.an[this.mol.touchedAtom] || this.active_an == 18 ) {
this.mol.save$();
this.mol.an[this.mol.touchedAtom]=this.active_an;
this.mol.q[this.mol.touchedAtom]=0;
this.mol.nh[this.mol.touchedAtom]=0;
if (this.active_an == 18) {
var xx=$I$(8).atomicSymbol.getText$();
if (xx.length$() < 1) xx="X";
this.mol.setAtom$I$S(this.mol.touchedAtom, xx);
}}}status=false;
} else if (this.mol.touchedBond > 0) {
if (this.action == 104) {
this.mol.save$();
this.mol.deleteBond$I(this.mol.touchedBond);
this.mol.touchedBond=0;
} else if (this.action == 106) {
this.mol.save$();
this.mol.deleteGroup$I(this.mol.touchedBond);
this.mol.touchedBond=0;
} else if (this.action == 201) this.mol.stereoBond$I(this.mol.touchedBond);
 else if (this.action == 202 || this.action == 205 ) {
if (this.mol.nasv[this.mol.touchedBond] == 1 && this.mol.stereob[this.mol.touchedBond] == 0 ) this.mol.nasv[this.mol.touchedBond]=2;
 else this.mol.nasv[this.mol.touchedBond]=1;
this.mol.stereob[this.mol.touchedBond]=0;
} else if (this.action == 203) {
this.mol.nasv[this.mol.touchedBond]=2;
this.mol.stereob[this.mol.touchedBond]=0;
} else if (this.action == 204) {
this.mol.nasv[this.mol.touchedBond]=3;
this.mol.stereob[this.mol.touchedBond]=0;
} else if (this.action >= 206 && this.action <= 229 ) {
this.mol.save$();
this.lastAction=2;
this.mol.addRing$();
} else if (this.action == 107) {
if (!this.queryBox.isBondQuery$()) return true;
var bondQuery=this.queryBox.getSmarts$();
this.mol.nasv[this.mol.touchedBond]=9;
this.mol.btag[this.mol.touchedBond]=bondQuery;
} else if (this.action == 105) {
this.info$S("Only atoms may be marked !");
}status=false;
} else if (this.nmols == 0 || this.newMolecule == true  ) {
if (this.action <= 201) return true;
++this.nmols;
this.actualMolecule=this.nmols;
this.mols[this.nmols]=Clazz.new_($I$(3,1).c$$jme_JME,[this]);
this.mol=this.mols[this.nmols];
this.newMolecule=false;
this.smol=null;
if (this.action >= 202 && this.action <= 204  || this.action == 205 ) {
this.mol.createAtom$();
this.mol.nbonds=0;
this.mol.nv[1]=0;
this.mol.x[1]=x;
this.mol.y[1]=y;
this.mol.touchedAtom=1;
this.mol.touched_org=1;
this.lastAction=1;
this.mol.addBond$();
if (this.action == 205) {
this.mol.x[2]=x + 21.65;
this.mol.y[2]=y - 12.5;
this.mol.chain[0]=1;
this.mol.chain[1]=2;
this.mol.nchain=1;
}} else if (this.action >= 206 && this.action <= 229 ) {
this.mol.xorg=x;
this.mol.yorg=y;
this.lastAction=2;
this.mol.addRing$();
} else if (this.action > 300) {
this.mol.createAtom$();
this.mol.an[1]=this.active_an;
this.mol.nbonds=0;
this.mol.nv[1]=0;
this.mol.x[1]=x;
this.mol.y[1]=y;
this.mol.touchedAtom=1;
if (this.active_an == 18) {
var xx=$I$(8).atomicSymbol.getText$();
if (xx.length$() < 1) xx="X";
this.mol.setAtom$I$S(1, xx);
}} else if (this.action == 230) {
this.readMolecule$S(this.template);
} else if (this.action >= 233 && this.action < 260 ) {
this.mol.createAtom$();
this.mol.nbonds=0;
this.mol.nv[1]=0;
this.mol.x[1]=x;
this.mol.y[1]=y;
this.mol.touchedAtom=1;
this.mol.addGroup$Z(true);
} else {
System.err.println$S("error -report fall through bug !");
}status=false;
}this.mol.valenceState$();
this.repaint$();
}return status;
});

Clazz.newMeth(C$, ['mouseUp$java_awt_Event$I$I','mouseUp'],  function (e, x, y) {
if (this.depict) return true;
if (this.lastAction == 1) {
if (this.action == 205) this.mol.checkChain$();
 else this.mol.checkBond$();
this.mol.findBondCenters$();
} else if (this.lastAction == 5) {
this.mol.findBondCenters$();
}if (this.lastAction > 0) {
this.doMenu=false;
this.mol.valenceState$();
this.mol.cleanPolarBonds$();
this.repaint$();
this.lastAction=0;
this.afterClear=false;
}return true;
});

Clazz.newMeth(C$, ['mouseDrag$java_awt_Event$I$I','mouseDrag'],  function (e, x, y) {
if (this.depict) return true;
if (!this.movePossible) return true;
x-=this.sd;
y-=this.sd * 2;
var movex=(x - this.xold);
var movey=(y - this.yold);
if (this.lastAction == 2 || this.lastAction == 3  || this.lastAction == 9 ) return true;
 else if (this.lastAction == 1) {
this.mol.rubberBanding$I$I(x, y);
} else if (e.shiftDown$() || e.metaDown$() ) {
this.mol.rotate$I(movex);
this.lastAction=5;
} else if (this.mol.touchedAtom == 0 && this.mol.touchedBond == 0 ) {
this.mol.move$I$I(movex, movey);
this.lastAction=5;
}this.doMenu=false;
this.repaint$();
this.xold=x;
this.yold=y;
return true;
});

Clazz.newMeth(C$, ['mouseMove$java_awt_Event$I$I','mouseMove'],  function (e, x, y) {
if (this.depict) return true;
x-=this.sd;
y-=this.sd * 2;
var repaintFlag=false;
var newActual=0;
 touchLoop : for (var m=1; m <= this.nmols; m++) {
var a=0;
var b=0;
a=this.mols[m].testAtomTouch$I$I(x, y);
if (a == 0) b=this.mols[m].testBondTouch$I$I(x, y);
if (a > 0) {
this.mols[m].touchedAtom=a;
this.mols[m].touchedBond=0;
newActual=m;
repaintFlag=true;
break touchLoop;
} else if (b > 0) {
this.mols[m].touchedAtom=0;
this.mols[m].touchedBond=b;
newActual=m;
repaintFlag=true;
break touchLoop;
} else {
if (this.mols[m].touchedAtom > 0 || this.mols[m].touchedBond > 0 ) {
this.mols[m].touchedAtom=0;
this.mols[m].touchedBond=0;
repaintFlag=true;
}}}
if (repaintFlag) {
for (var m=this.actualMolecule + 1; m <= this.nmols; m++) {
this.mols[m].touchedAtom=0;
this.mols[m].touchedBond=0;
}
this.doMenu=false;
this.repaint$();
}if (newActual != 0 && newActual != this.actualMolecule ) {
this.actualMolecule=newActual;
this.mol=this.mols[this.actualMolecule];
}return true;
});

Clazz.newMeth(C$, ['keyDown$java_awt_Event$I','keyDown'],  function (e, key) {
if (this.depict) return true;
this.info$S("");
var pressed=0;
var alt=e.modifiers == $I$(10).ALT_MASK;
switch (key) {
case 99:
case 67:
pressed=301;
break;
case 110:
case 78:
pressed=401;
break;
case 111:
case 79:
pressed=501;
break;
case 115:
case 83:
pressed=601;
break;
case 112:
case 80:
pressed=1101;
break;
case 102:
case 70:
pressed=701;
break;
case 108:
case 76:
pressed=801;
break;
case 98:
case 66:
pressed=901;
break;
case 105:
case 73:
pressed=1001;
break;
case 120:
case 88:
this.info$S($I$(8).atomicSymbol.getText$());
pressed=1201;
this.active_an=18;
break;
case 104:
case 72:
this.info$S("H");
pressed=1300;
break;
case 114:
case 82:
this.info$S("R");
pressed=1301;
break;
case 116:
case 84:
if (this.action == 701) {
pressed=236;
this.info$S("-CF3");
} else if (this.action == 801) {
pressed=237;
this.info$S("-CCl3");
} else {
pressed=233;
this.info$S("-tBu");
}break;
case 121:
case 89:
pressed=234;
this.info$S("-NO2");
break;
case 122:
case 90:
pressed=239;
this.info$S("-SO3H");
break;
case 97:
case 65:
pressed=235;
this.info$S("-COOH");
break;
case 101:
case 69:
pressed=238;
this.info$S("-C#CH");
break;
case 117:
case 85:
pressed=110;
break;
case 113:
case 81:
pressed=242;
this.info$S("-C#N");
break;
case 103:
return true;
case 27:
pressed=202;
break;
case 45:
if (this.action == 701) {
pressed=254;
this.info$S("-F");
} else if (this.action == 801) {
pressed=255;
this.info$S("-Cl");
} else if (this.action == 901) {
pressed=256;
this.info$S("-Br");
} else if (this.action == 1001) {
pressed=257;
this.info$S("-I");
} else if (this.action == 501) {
pressed=259;
this.info$S("-OH");
} else if (this.action == 401) {
pressed=258;
this.info$S("-NH2");
} else pressed=202;
break;
case 61:
if (this.action == 501) {
pressed=250;
this.info$S("=O");
} else pressed=203;
break;
case 35:
pressed=204;
break;
case 48:
if (this.action == 105) p$1.updateMark$I.apply(this, [0]);
 else {
if (!alt) {
pressed=221;
this.info$S("-Furyl");
} else {
pressed=223;
this.info$S("-3-Furyl");
}}break;
case 49:
if (this.action == 105) p$1.updateMark$I.apply(this, [1]);
 else if (this.action == 1301) {
this.info$S("-R1");
pressed=1302;
} else pressed=209;
break;
case 50:
if (this.action == 105) p$1.updateMark$I.apply(this, [2]);
if (this.action == 1301) {
this.info$S("-R2");
pressed=1303;
}break;
case 51:
if (this.action == 105) p$1.updateMark$I.apply(this, [3]);
 else if (this.action == 1301) {
this.info$S("-R3");
pressed=1304;
} else pressed=206;
break;
case 52:
if (this.action == 105) p$1.updateMark$I.apply(this, [4]);
 else pressed=207;
break;
case 53:
if (this.action == 105) p$1.updateMark$I.apply(this, [5]);
 else pressed=208;
break;
case 54:
if (this.action == 105) p$1.updateMark$I.apply(this, [6]);
 else pressed=210;
break;
case 55:
if (this.action == 105) p$1.updateMark$I.apply(this, [7]);
 else pressed=211;
break;
case 56:
if (this.action == 105) p$1.updateMark$I.apply(this, [8]);
 else pressed=212;
break;
case 57:
if (this.action == 105) p$1.updateMark$I.apply(this, [9]);
 else {
this.info$S("9 ring");
pressed=229;
}break;
case 100:
case 68:
case 8:
case 127:
pressed=104;
break;
case 32:
pressed=205;
break;
case 1002:
pressed=151;
break;
case 1003:
pressed=152;
break;
}
this.menuAction$I(pressed);
return true;
});

Clazz.newMeth(C$, 'updateMark$I',  function (n) {
if (this.autonumber) {
if (n == 0) {
this.currentMark=-1;
this.info$S("click marked atom to delete mark");
this.repaint$();
}return;
}if (this.markUsed) this.currentMark=n;
 else {
if (this.currentMark > -1 && this.currentMark < 10 ) this.currentMark=this.currentMark * 10 + n;
 else this.currentMark=n;
}this.markUsed=false;
if (this.currentMark == 0) {
this.currentMark=-1;
this.info$S("click marked atom to delete mark");
} else this.info$S(this.currentMark + " ");
this.repaint$();
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.application=false;
C$.separator="\n";
C$.bgColor=$I$(1).lightGray;
C$.brightColor=$I$(2).bgColor.brighter$();
C$.color=Clazz.array($I$(1), [23]);
C$.zlabel=Clazz.array(String, [23]);
C$.ACTIONA=10;
C$.psColor=Clazz.array($I$(1), [7]);
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-08 09:52:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
