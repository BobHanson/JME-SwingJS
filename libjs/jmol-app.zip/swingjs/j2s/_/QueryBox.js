(function(){var P$=Clazz.newPackage("_"),p$1={},p$2={},I$=[[0,'java.awt.Color','jme.JME','jme.JMEmol','java.util.Vector','java.awt.Frame','java.awt.Font','java.util.StringTokenizer','jme.MultiBox','jme.QueryBox','java.awt.Event','java.awt.Point','java.awt.TextField','java.awt.GridLayout','java.awt.Label','java.awt.Panel','java.awt.Button','java.awt.BorderLayout','java.awt.FlowLayout','java.awt.Choice']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QueryBox", null, 'java.awt.Frame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bgc=$I$(2).bgColor;
this.isBondQuery=false;
},1);

C$.$fields$=[['Z',['isBondQuery'],'O',['text','java.awt.TextField','bgc','java.awt.Color','jme','jme.JME']]
,['O',['point','java.awt.Point','c','java.awt.Button','+n','+o','+s','+p','+f','+cl','+br','+i','+any','+anyec','+halogen','+aromatic','+nonaromatic','+ring','+nonring','+anyBond','+aromaticBond','+ringBond','+nonringBond','+sdBond','choiced','java.awt.Choice','+choiceh']]]

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.superclazz.c$$S.apply(this,["Atom/Bond Query"]);C$.$init$.apply(this);
this.jme=jme;
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(13,1).c$$I$I,[0, 1]));
this.setFont$java_awt_Font(jme.fontSmall);
this.setBackground$java_awt_Color(this.bgc);
var p1=Clazz.new_($I$(15,1));
p1.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
p1.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S,["Atom type :"]));
var first=true;
if (first) {
$I$(9).any=Clazz.new_($I$(16,1).c$$S,["Any"]);
$I$(9).anyec=Clazz.new_($I$(16,1).c$$S,["Any except C"]);
$I$(9).halogen=Clazz.new_($I$(16,1).c$$S,["Halogen"]);
}p1.add$java_awt_Component($I$(9).any);
p1.add$java_awt_Component($I$(9).anyec);
p1.add$java_awt_Component($I$(9).halogen);
this.add$java_awt_Component(p1);
var p2=Clazz.new_($I$(15,1));
p2.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
p2.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S$I,["Or select one or more from the list :", 0]));
this.add$java_awt_Component(p2);
var p3=Clazz.new_($I$(15,1));
p3.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
if (first) {
$I$(9).c=Clazz.new_($I$(16,1).c$$S,["C"]);
$I$(9).n=Clazz.new_($I$(16,1).c$$S,["N"]);
$I$(9).o=Clazz.new_($I$(16,1).c$$S,["O"]);
$I$(9).s=Clazz.new_($I$(16,1).c$$S,["S"]);
$I$(9).p=Clazz.new_($I$(16,1).c$$S,["P"]);
$I$(9).f=Clazz.new_($I$(16,1).c$$S,["F"]);
$I$(9).cl=Clazz.new_($I$(16,1).c$$S,["Cl"]);
$I$(9).br=Clazz.new_($I$(16,1).c$$S,["Br"]);
$I$(9).i=Clazz.new_($I$(16,1).c$$S,["I"]);
}p3.add$java_awt_Component($I$(9).c);
p3.add$java_awt_Component($I$(9).n);
p3.add$java_awt_Component($I$(9).o);
p3.add$java_awt_Component($I$(9).s);
p3.add$java_awt_Component($I$(9).p);
p3.add$java_awt_Component($I$(9).f);
p3.add$java_awt_Component($I$(9).cl);
p3.add$java_awt_Component($I$(9).br);
p3.add$java_awt_Component($I$(9).i);
this.add$java_awt_Component(p3);
var p4=Clazz.new_($I$(15,1));
p4.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
if (first) {
$I$(9).choiceh=Clazz.new_($I$(19,1));
$I$(9).choiceh.addItem$S("Any");
$I$(9).choiceh.addItem$S("0");
$I$(9).choiceh.addItem$S("1");
$I$(9).choiceh.addItem$S("2");
$I$(9).choiceh.addItem$S("3");
}p4.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S,["Number of hydrogens :  "]));
p4.add$java_awt_Component($I$(9).choiceh);
this.add$java_awt_Component(p4);
var p5=Clazz.new_($I$(15,1));
p5.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
if (first) {
$I$(9).choiced=Clazz.new_($I$(19,1));
$I$(9).choiced.addItem$S("Any");
$I$(9).choiced.addItem$S("0");
$I$(9).choiced.addItem$S("1");
$I$(9).choiced.addItem$S("2");
$I$(9).choiced.addItem$S("3");
$I$(9).choiced.addItem$S("4");
$I$(9).choiced.addItem$S("5");
$I$(9).choiced.addItem$S("6");
}p5.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S$I,["Number of connections :", 0]));
p5.add$java_awt_Component($I$(9).choiced);
p5.add$java_awt_Component(Clazz.new_([" (H\'s don\'t count.)", 0],$I$(14,1).c$$S$I));
this.add$java_awt_Component(p5);
var p6=Clazz.new_($I$(15,1));
p6.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
p6.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S,["Atom is :"]));
if (first) $I$(9).aromatic=Clazz.new_($I$(16,1).c$$S,["Aromatic"]);
p6.add$java_awt_Component($I$(9).aromatic);
if (first) $I$(9).nonaromatic=Clazz.new_($I$(16,1).c$$S,["Nonaromatic"]);
p6.add$java_awt_Component($I$(9).nonaromatic);
if (first) $I$(9).ring=Clazz.new_($I$(16,1).c$$S,["Ring"]);
p6.add$java_awt_Component($I$(9).ring);
if (first) $I$(9).nonring=Clazz.new_($I$(16,1).c$$S,["Nonring"]);
p6.add$java_awt_Component($I$(9).nonring);
this.add$java_awt_Component(p6);
var p9=Clazz.new_($I$(15,1));
p9.setBackground$java_awt_Color(this.getBackground$().darker$());
p9.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[0, 3, 1]));
p9.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S,["Bond is :"]));
if (first) $I$(9).anyBond=Clazz.new_($I$(16,1).c$$S,["Any"]);
p9.add$java_awt_Component($I$(9).anyBond);
if (first) $I$(9).aromaticBond=Clazz.new_($I$(16,1).c$$S,["Aromatic"]);
p9.add$java_awt_Component($I$(9).aromaticBond);
if (first) $I$(9).ringBond=Clazz.new_($I$(16,1).c$$S,["Ring"]);
p9.add$java_awt_Component($I$(9).ringBond);
if (first) $I$(9).nonringBond=Clazz.new_($I$(16,1).c$$S,["Nonring"]);
p9.add$java_awt_Component($I$(9).nonringBond);
this.add$java_awt_Component(p9);
var p8=Clazz.new_($I$(15,1));
p8.setLayout$java_awt_LayoutManager(Clazz.new_($I$(18,1).c$$I$I$I,[1, 3, 1]));
if (first) this.text=Clazz.new_($I$(12,1).c$$S$I,["*", 20]);
p8.add$java_awt_Component(this.text);
p8.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Reset"]));
p8.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Close"]));
this.add$java_awt_Component(p8);
this.setResizable$Z(false);
if (first) {
p$2.resetAtomList.apply(this, []);
p$2.resetAtomType.apply(this, []);
p$2.resetBondType.apply(this, []);
$I$(9).aromatic.setBackground$java_awt_Color(this.bgc);
$I$(9).nonaromatic.setBackground$java_awt_Color(this.bgc);
$I$(9).ring.setBackground$java_awt_Color(this.bgc);
$I$(9).nonring.setBackground$java_awt_Color(this.bgc);
$I$(9).choiceh.setBackground$java_awt_Color(this.bgc);
$I$(9).choiced.setBackground$java_awt_Color(this.bgc);
p$2.changeColor$java_awt_Button.apply(this, [$I$(9).any]);
}this.pack$();
this.setLocation$java_awt_Point($I$(9).point);
this.show$();
}, 1);

Clazz.newMeth(C$, 'action$java_awt_Event$O',  function (e, arg) {
if (arg.equals$O("Close")) {
$I$(9).point=this.getLocationOnScreen$();
this.hide$();
} else if (arg.equals$O("Reset")) {
p$2.resetAll.apply(this, []);
p$2.changeColor$java_awt_Button.apply(this, [$I$(9).any]);
p$2.doSmarts.apply(this, []);
} else if (Clazz.instanceOf(e.target, "java.awt.Button")) {
p$2.resetBondType.apply(this, []);
if (e.target === $I$(9).any ) {
p$2.resetAtomList.apply(this, []);
p$2.resetAtomType.apply(this, []);
} else if (e.target === $I$(9).anyec ) {
p$2.resetAtomList.apply(this, []);
p$2.resetAtomType.apply(this, []);
} else if (e.target === $I$(9).halogen ) {
p$2.resetAtomList.apply(this, []);
p$2.resetAtomType.apply(this, []);
} else if (e.target === $I$(9).ring ) {
$I$(9).nonring.setBackground$java_awt_Color(this.bgc);
} else if (e.target === $I$(9).nonring ) {
$I$(9).ring.setBackground$java_awt_Color(this.bgc);
$I$(9).aromatic.setBackground$java_awt_Color(this.bgc);
} else if (e.target === $I$(9).aromatic ) {
$I$(9).nonaromatic.setBackground$java_awt_Color(this.bgc);
$I$(9).nonring.setBackground$java_awt_Color(this.bgc);
} else if (e.target === $I$(9).nonaromatic ) {
$I$(9).aromatic.setBackground$java_awt_Color(this.bgc);
} else if (e.target === $I$(9).anyBond  || e.target === $I$(9).aromaticBond   || e.target === $I$(9).ringBond   || e.target === $I$(9).nonringBond  ) {
p$2.resetAll.apply(this, []);
this.isBondQuery=true;
} else {
p$2.resetAtomType.apply(this, []);
}p$2.changeColor$java_awt_Button.apply(this, [(e.target)]);
p$2.doSmarts.apply(this, []);
} else if (Clazz.instanceOf(e.target, "java.awt.Choice")) {
p$2.resetBondType.apply(this, []);
var choice=(e.target);
if (choice.getSelectedIndex$() == 0) choice.setBackground$java_awt_Color(this.bgc);
 else choice.setBackground$java_awt_Color($I$(1).orange);
p$2.doSmarts.apply(this, []);
}if (this.jme.action != 107) {
this.jme.action=107;
this.jme.repaint$();
}return true;
});

Clazz.newMeth(C$, 'resetAll',  function () {
p$2.resetAtomList.apply(this, []);
p$2.resetAtomType.apply(this, []);
$I$(9).choiceh.select$I(0);
$I$(9).choiced.select$I(0);
$I$(9).aromatic.setBackground$java_awt_Color(this.bgc);
$I$(9).nonaromatic.setBackground$java_awt_Color(this.bgc);
$I$(9).ring.setBackground$java_awt_Color(this.bgc);
$I$(9).nonring.setBackground$java_awt_Color(this.bgc);
$I$(9).choiceh.setBackground$java_awt_Color(this.bgc);
$I$(9).choiced.setBackground$java_awt_Color(this.bgc);
p$2.resetBondType.apply(this, []);
}, p$2);

Clazz.newMeth(C$, 'resetAtomList',  function () {
$I$(9).c.setBackground$java_awt_Color(this.bgc);
$I$(9).n.setBackground$java_awt_Color(this.bgc);
$I$(9).o.setBackground$java_awt_Color(this.bgc);
$I$(9).s.setBackground$java_awt_Color(this.bgc);
$I$(9).p.setBackground$java_awt_Color(this.bgc);
$I$(9).f.setBackground$java_awt_Color(this.bgc);
$I$(9).cl.setBackground$java_awt_Color(this.bgc);
$I$(9).br.setBackground$java_awt_Color(this.bgc);
$I$(9).i.setBackground$java_awt_Color(this.bgc);
}, p$2);

Clazz.newMeth(C$, 'resetAtomType',  function () {
$I$(9).any.setBackground$java_awt_Color(this.bgc);
$I$(9).anyec.setBackground$java_awt_Color(this.bgc);
$I$(9).halogen.setBackground$java_awt_Color(this.bgc);
}, p$2);

Clazz.newMeth(C$, 'resetBondType',  function () {
$I$(9).anyBond.setBackground$java_awt_Color(this.bgc);
$I$(9).aromaticBond.setBackground$java_awt_Color(this.bgc);
$I$(9).ringBond.setBackground$java_awt_Color(this.bgc);
$I$(9).nonringBond.setBackground$java_awt_Color(this.bgc);
this.isBondQuery=false;
}, p$2);

Clazz.newMeth(C$, 'changeColor$java_awt_Button',  function (b) {
if (b.getBackground$() === this.bgc ) b.setBackground$java_awt_Color($I$(1).orange);
 else b.setBackground$java_awt_Color(this.bgc);
}, p$2);

Clazz.newMeth(C$, 'doSmarts',  function () {
var smarts="";
var showaA=false;
if ($I$(9).any.getBackground$() !== this.bgc ) {
smarts="*";
showaA=true;
} else if ($I$(9).anyec.getBackground$() !== this.bgc ) {
smarts="!#6";
showaA=true;
} else if ($I$(9).halogen.getBackground$() !== this.bgc ) {
$I$(9).f.setBackground$java_awt_Color($I$(1).orange);
$I$(9).cl.setBackground$java_awt_Color($I$(1).orange);
$I$(9).br.setBackground$java_awt_Color($I$(1).orange);
$I$(9).i.setBackground$java_awt_Color($I$(1).orange);
smarts="F,Cl,Br,I";
} else {
var ar=$I$(9).aromatic.getBackground$() !== this.bgc ;
var nar=$I$(9).nonaromatic.getBackground$() !== this.bgc ;
if ($I$(9).c.getBackground$() !== this.bgc ) {
if (ar) smarts+="c,";
 else if (nar) smarts+="C,";
 else smarts+="#6,";
}if ($I$(9).n.getBackground$() !== this.bgc ) {
if (ar) smarts+="n,";
 else if (nar) smarts+="N,";
 else smarts+="#7,";
}if ($I$(9).o.getBackground$() !== this.bgc ) {
if (ar) smarts+="o,";
 else if (nar) smarts+="O,";
 else smarts+="#8,";
}if ($I$(9).s.getBackground$() !== this.bgc ) {
if (ar) smarts+="s,";
 else if (nar) smarts+="S,";
 else smarts+="#16,";
}if ($I$(9).p.getBackground$() !== this.bgc ) {
if (ar) smarts+="p,";
 else if (nar) smarts+="P,";
 else smarts+="#15,";
}if ($I$(9).f.getBackground$() !== this.bgc ) smarts+="F,";
if ($I$(9).cl.getBackground$() !== this.bgc ) smarts+="Cl,";
if ($I$(9).br.getBackground$() !== this.bgc ) smarts+="Br,";
if ($I$(9).i.getBackground$() !== this.bgc ) smarts+="I,";
if (smarts.endsWith$S(",")) smarts=smarts.substring$I$I(0, smarts.length$() - 1);
if (smarts.length$() < 1 && !this.isBondQuery ) {
if (ar) smarts="a";
 else if (nar) smarts="A";
 else {
$I$(9).any.setBackground$java_awt_Color($I$(1).orange);
smarts="*";
}}}var ap="";
if (showaA && $I$(9).aromatic.getBackground$() !== this.bgc  ) ap+=";a";
if (showaA && $I$(9).nonaromatic.getBackground$() !== this.bgc  ) ap+=";A";
if ($I$(9).ring.getBackground$() !== this.bgc ) ap+=";R";
if ($I$(9).nonring.getBackground$() !== this.bgc ) ap+=";!R";
if ($I$(9).any.getBackground$() !== this.bgc  && ap.length$() > 0 ) smarts=ap.substring$I$I(1, ap.length$());
 else smarts+=ap;
var nh=$I$(9).choiceh.getSelectedIndex$();
if (nh > 0) {
--nh;
smarts+=";H" + nh;
}var nd=$I$(9).choiced.getSelectedIndex$();
if (nd > 0) {
--nd;
smarts+=";D" + nd;
}if ($I$(9).anyBond.getBackground$() !== this.bgc ) smarts="~";
if ($I$(9).aromaticBond.getBackground$() !== this.bgc ) smarts=":";
if ($I$(9).ringBond.getBackground$() !== this.bgc ) smarts="@";
if ($I$(9).nonringBond.getBackground$() !== this.bgc ) smarts="!@";
this.text.setText$S(smarts);
}, p$2);

Clazz.newMeth(C$, 'isBondQuery$',  function () {
return this.isBondQuery;
});

Clazz.newMeth(C$, 'getSmarts$',  function () {
return this.text.getText$();
});

C$.$static$=function(){C$.$static$=0;
C$.point=Clazz.new_($I$(11,1).c$$I$I,[20, 200]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-08 09:52:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
