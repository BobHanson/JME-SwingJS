(function(){var P$=Clazz.newPackage("_"),p$1={},p$2={},I$=[[0,'java.awt.Color','jme.JME','jme.JMEmol','java.util.Vector','java.awt.Frame','java.awt.Font','java.util.StringTokenizer','jme.MultiBox','jme.QueryBox','java.awt.Event','java.awt.Point','java.awt.TextField','java.awt.GridLayout','java.awt.Label','java.awt.Panel','java.awt.Button','java.awt.BorderLayout','java.awt.FlowLayout','java.awt.Choice']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MultiBox", null, 'java.awt.Frame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['+smilesText','jme','jme.JME']]
,['O',['aboutBoxPoint','java.awt.Point','+smilesBoxPoint','+atomxBoxPoint','atomicSymbol','java.awt.TextField']]]

Clazz.newMeth(C$, 'c$$I$jme_JME',  function (box, jme) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.jme=jme;
this.setFont$java_awt_Font(jme.fontSmall);
this.setBackground$java_awt_Color($I$(2).bgColor);
this.setResizable$Z(false);
if (box == 1) this.createSmilesBox$S(jme.Smiles$());
 else if (box == 2) this.createAtomxBox$();
 else this.createAboutBox$();
this.pack$();
this.show$();
}, 1);

Clazz.newMeth(C$, 'createAboutBox$',  function () {
this.setTitle$S("about JSME");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(13,1).c$$I$I$I$I,[0, 1, 0, 0]));
this.setFont$java_awt_Font(this.jme.fontSmall);
this.setBackground$java_awt_Color($I$(2).bgColor);
this.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S$I,["JSME Molecular Editor v2013.01", 1]));
this.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S$I,["Peter Ertl and Bruno BienFait", 1]));
var p=Clazz.new_($I$(15,1));
var b=Clazz.new_($I$(16,1).c$$S,[" Close "]);
p.add$java_awt_Component(b);
this.add$java_awt_Component(p);
this.setLocation$java_awt_Point($I$(8).aboutBoxPoint);
});

Clazz.newMeth(C$, 'createSmilesBox$S',  function (smiles) {
this.setTitle$S("SMILES");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(17,1).c$$I$I,[2, 0]));
this.smilesText=Clazz.new_($I$(12,1).c$$S,[smiles + "     "]);
if (!this.jme.runsmi) this.smilesText.setEditable$Z(false);
this.add$S$java_awt_Component("Center", this.smilesText);
var p=Clazz.new_($I$(15,1));
var b=Clazz.new_($I$(16,1).c$$S,["Close"]);
p.add$java_awt_Component(b);
if (this.jme.runsmi) {
b=Clazz.new_($I$(16,1).c$$S,["Submit"]);
p.add$java_awt_Component(b);
}this.add$S$java_awt_Component("South", p);
this.smilesText.setText$S(this.smilesText.getText$().trim$());
this.setResizable$Z(true);
this.setLocation$java_awt_Point($I$(8).smilesBoxPoint);
});

Clazz.newMeth(C$, 'setSmiles$S',  function (smiles) {
var d=this.size$();
var l=this.jme.fontSmallMet.stringWidth$S(smiles) + 30;
if (l < 150) l=150;
this.resize$I$I(l, d.height);
this.validate$();
this.smilesText.setText$S(smiles);
});

Clazz.newMeth(C$, 'createAtomxBox$',  function () {
this.setTitle$S("nonstandard atom");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(17,1).c$$I$I,[2, 0]));
var p=Clazz.new_($I$(15,1));
p.add$java_awt_Component(Clazz.new_($I$(14,1).c$$S$I,["atomic SMILES", 1]));
this.add$S$java_awt_Component("North", p);
var as="H";
if ($I$(8).atomicSymbol != null ) as=$I$(8).atomicSymbol.getText$();
$I$(8).atomicSymbol=Clazz.new_($I$(12,1).c$$S$I,[as, 8]);
this.add$S$java_awt_Component("Center", $I$(8).atomicSymbol);
p=Clazz.new_($I$(15,1));
p.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Close "]));
this.add$S$java_awt_Component("South", p);
this.setLocation$java_awt_Point($I$(8).atomxBoxPoint);
});

Clazz.newMeth(C$, 'action$java_awt_Event$O',  function (e, arg) {
if (" Close ".equals$O(arg)) {
$I$(8).aboutBoxPoint=this.jme.aboutBox.getLocationOnScreen$();
this.hide$();
} else if ("Close".equals$O(arg)) {
$I$(8).smilesBoxPoint=this.jme.smilesBox.getLocationOnScreen$();
this.hide$();
} else if ("Close ".equals$O(arg)) {
$I$(8).atomxBoxPoint=this.jme.atomxBox.getLocationOnScreen$();
this.hide$();
}return true;
});

Clazz.newMeth(C$, 'keyDown$java_awt_Event$I',  function (e, key) {
if ($I$(8).atomicSymbol == null ) return false;
if (this.jme.action != 1201) {
this.jme.action=1201;
this.jme.active_an=18;
}return false;
});

C$.$static$=function(){C$.$static$=0;
C$.aboutBoxPoint=Clazz.new_($I$(11,1).c$$I$I,[500, 10]);
C$.smilesBoxPoint=Clazz.new_($I$(11,1).c$$I$I,[200, 50]);
C$.atomxBoxPoint=Clazz.new_($I$(11,1).c$$I$I,[150, 420]);
C$.atomicSymbol=Clazz.new_($I$(12,1).c$$S,["H"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-01-08 09:52:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
